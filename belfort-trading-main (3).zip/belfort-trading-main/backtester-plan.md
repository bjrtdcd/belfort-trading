# Backtester Implementation Plan

> **Goal:** Replace `strategy-validator/` with a full TypeScript backtester: CSV trade-log import, simulation engine, Monte Carlo, prop-firm Monte Carlo with presets, and 3D charts, all client-side.

**Architecture:** TypeScript modules compiled to a single `backtester.js` bundle loaded by a Belfort Trading-styled `index.html`. Pure logic modules (CSV parsing, metrics, Monte Carlo, prop simulation, RNG, 3D projection) are separate from DOM rendering. Deterministic seeded RNG throughout.

**Steps:**

1. Check for the TypeScript compiler; install `typescript` locally in `Downloads/quantpad` if needed and add a compile script.
2. Write `backtester-src/*.ts` modules:
   - `csv.ts` — quoted CSV parser + column detection + validation.
   - `types.ts` — Trade, TradeLog, Metrics, MonteCarloResult, PropFirmConfig, PropFirmResult types.
   - `rng.ts` — seeded RNG (mulberry32).
   - `metrics.ts` — equity, drawdown, profit factor, expectancy, streaks, grade.
   - `montecarlo.ts` — block resampling, path fan, terminal/drawdown distributions, risk of ruin.
   - `propfirm.ts` — preset configs and full prop simulation.
   - `charts3d.ts` — inline canvas 3D projection (equity fan, drawdown surface, outcome distribution).
   - `render.ts` — DOM rendering of the report and controls.
   - `main.ts` — wiring: file/paste input, run, clear, sample data.
3. Write `backtester/index.html` — Belfort Trading-styled shell, controls, report layout, loads `backtester.js`.
4. Compile with `tsc` to `backtester/backtester.js` and verify with `node --check`.
5. Validate logic via Node against fixtures (valid CSV, invalid CSV, prop preset sanity).
6. Serve and verify the route, navigation links, and absence of the old verification flow.
