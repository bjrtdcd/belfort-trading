# Redesign mockups — v3 (current), v2, v1, design plan, original-UI reference

Nothing in this folder is served as part of the product. It exists so the redesign can be
reviewed before any live page changes, and so the original UI can always be brought back.

## What is here

| File | What it is |
| --- | --- |
| `index.html` | **Mockup v3 — "Plain".** Black-and-white, minimal. Six clickable screens (Home, Backtester with all four tabs, Workspace, Copilot IDE, Checkout, Sign-in) plus the command palette. Dark by default, light mode behind the **Light / Dark** button in the nav. Strictly monochrome: wins are filled, losses are outlined; no green/red anywhere. |
| `v2.html` | Mockup v2 — the decorated "Examiner" pass (copper accent, generated backdrops, 3D band, icons). Kept for comparison; uses `assets/`. |
| `v1.html` | Mockup v1 — first pass, four screens. |
| `design-plan.html` | The original design plan and front-end architecture. Its palette, stamp and imagery sections are superseded by v3 (a note at the top says so); type, motion, page structure and architecture still apply. |
| `assets/` | Two generated backdrops, used by v2 only. |
| `original-ui/*.png` | Reference captures of the current UI at commit `2065a33`, 1280px wide. |

## Why v3

Owner feedback on v2 (2026-08-20): *make it black and white, more minimalistic — it looks like
AI made it, too much overboard.* v3 removes the accent colour, the generated images, glow,
grain, vignette, the icon set, the rotated stamp, the full-bleed 3D band, dotted chips,
uppercase expanded type and the section meta text. It keeps what is the product's own: the
motion system (chart trace, count-up, idle orbit, sliding tab indicator), the six screens, the
command palette, the loading/empty states and the mobile layout.

## View it

```bash
python -m http.server 4173        # from the repo root
# http://localhost:4173/mockup/             v3
# http://localhost:4173/mockup/v2.html      v2
# http://localhost:4173/mockup/v1.html      v1
# http://localhost:4173/mockup/design-plan.html
```

Switches: the **MOCKUP v3** pill bottom-right flips screens, or use the URL —
`#home`, `#backtester`, `#workspace`, `#ide`, `#checkout`, `#signin`;
`?tab=montecarlo|propfirm|views3d` opens a report tab; `?theme=light|dark` forces a theme
(the nav button also remembers your choice in this browser); `?static=1` renders every final
state at once (screenshots, reduced motion). **Ctrl+K / Cmd+K** opens the command palette.
In the Backtester, **Run backtest** shows the progress state and re-animates the report;
**Clear** shows the empty state; **Load sample log** restores it. In the Copilot IDE, **Run**
(or Ctrl+Enter) prints the engine output. The 3D surfaces can be dragged and idle-orbit while
visible; **Animations on/off** behaves like the product's Stop animations.

## What the numbers are

Every figure on every screen is computed in-page from one bundled 24-trade series: the metrics,
the 1,000-path Monte Carlo (seed 4060720449), the 2,000-attempt prop-firm evaluation (100k
account, +10,000 target, 10,000 static max loss, 60 trades, 549 fee, 80% split) and the 3D
surfaces (40 resampled paths sorted by outcome). Import a different log in the real product and
every number changes; nothing is staged. The five pillar scores (20/17/25/8/3) are the one
hand-set thing, matched to the current grader's output for that log. The workspace shows one real
saved run and an honest empty state, not invented history.

## What was pulled from the original UI and kept

- The motion system in `backtester-src/animations.ts`: 0.9s entries, staggered reveals, 1.4s 3D
  camera intro, idle orbit only while on screen, per-animator `__restore`, the Stop animations
  switch. The mockup promotes the same constants to CSS tokens so static pages and charts share
  one clock.
- The report structure: verdict, five pillars, charts, summary, calendar, trade log; tabs with a
  jump bar and an essentials chart picker (`js/chart-browser.js`).
- The sample-data banner (`js/sample-badge.js`) and the "nothing simulated" stance.
- The workspace's GitHub connect, diagnostics and codespace-state flows; the Copilot IDE layout
  (explorer, editor, Output/Linux panel, command palette) and its sample `backtest.js`.

## Going back to the original UI

The pre-redesign code is preserved at **branch `original-ui`** and **tag
`original-ui-2026-08-20`**, both pointing at `2065a33`.

```bash
git checkout original-ui                          # look at it
git checkout original-ui -- css js index.html     # restore specific paths onto a branch
git revert <redesign commit sha>                  # undo a redesign commit on main
```

Never force-push; the history is the backup.
