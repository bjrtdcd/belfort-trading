import assert from 'node:assert/strict';
import { test } from 'node:test';

import { buildTradeLog } from '../backtester-src/csv.ts';
import { computeMetrics } from '../backtester-src/metrics.ts';
import { runMonteCarlo } from '../backtester-src/montecarlo.ts';
import { runPropFirmSimulation, PROP_FIRM_PRESETS } from '../backtester-src/propfirm.ts';
import {
  runStationaryBootstrap,
  walkForward,
  purgedKFold,
  deflatedSharpeRatio,
  probabilityOfBacktestOverfitting,
  buildOverfitReport,
  autoBlockSize,
} from '../backtester-src/overfit.ts';

const FIXTURE =
  'date,direction,entry,exit,size,pnl\n' +
  '2025-01-03,long,100,105,2,10\n' +
  '2025-01-07,short,50,48,1,2\n' +
  '2025-01-10,long,90,88,3,-6\n' +
  '2025-01-14,long,80,92,2,24\n';

test('buildTradeLog parses trades, dates, and ignores unusable rows', () => {
  const log = buildTradeLog(FIXTURE);
  assert.equal(log.trades.length, 4);
  assert.equal(log.ignored, 0);
  assert.equal(log.hasDates, true);
  assert.deepEqual(log.detected, ['pnl', 'date', 'entry', 'exit', 'size', 'direction']);
  assert.equal(log.trades[0].pnl, 10);
  assert.equal(log.trades[0].direction, 'long');
});

test('buildTradeLog derives P&L from entry/exit when no result column exists', () => {
  const log = buildTradeLog('entry,exit,size,direction\n100,106,2,long\n50,47,1,short\n');
  assert.equal(log.trades.length, 2);
  assert.equal(log.derivedPnl, true);
  assert.equal(log.trades[0].pnl, 12);
  assert.equal(log.trades[1].pnl, 3);
});

test('buildTradeLog rejects logs without a usable result column', () => {
  assert.throws(() => buildTradeLog('date,price\n2025-01-01,100\n2025-01-02,101'));
});

test('buildTradeLog rejects logs with fewer than two valid trades', () => {
  assert.throws(() => buildTradeLog('pnl\n1'));
});

test('computeMetrics produces correct core performance numbers', () => {
  const metrics = computeMetrics(buildTradeLog(FIXTURE));
  assert.equal(metrics.count, 4);
  assert.equal(metrics.winCount, 3);
  assert.equal(metrics.winRate, 0.75);
  assert.equal(metrics.netPnl, 30);
  assert.equal(metrics.expectancy, 7.5);
  assert.match(metrics.grade, /^[A-F]$/);
  assert.ok(metrics.maxDrawdown >= 0);
  assert.equal(metrics.equity.length, 4);
});

test('runMonteCarlo returns ordered percentiles and the requested path count', () => {
  const metrics = computeMetrics(buildTradeLog(FIXTURE));
  const result = runMonteCarlo(metrics.returns, { paths: 500, blockSize: 2, seed: 42 });
  assert.equal(result.terminals.length, 500);
  assert.ok(result.p5 <= result.p50 && result.p50 <= result.p95);
  assert.ok(result.positivePathsPct >= 0 && result.positivePathsPct <= 1);
});

test('runPropFirmSimulation produces rates, failure modes, and expected value', () => {
  const log = buildTradeLog(FIXTURE);
  const result = runPropFirmSimulation(log.trades, PROP_FIRM_PRESETS[0], { runs: 200, seed: 7 });
  assert.equal(result.runs, 200);
  assert.ok(result.passRatePct >= 0 && result.passRatePct <= 100);
  assert.ok(result.failRatePct >= 0 && result.failRatePct <= 100);
  assert.ok(Math.abs(result.passRatePct + result.failRatePct - 100) < 1e-9);
  assert.ok(result.failures.length > 0);
  assert.ok(Number.isFinite(result.expectedValue));
});

test('runPropFirmSimulation projects attempt economics over a year', () => {
  const log = buildTradeLog(FIXTURE);
  const result = runPropFirmSimulation(log.trades, PROP_FIRM_PRESETS[0], { runs: 500, seed: 7 });
  const passRate = result.passRatePct / 100;
  assert.ok(result.avgDaysPerAttempt > 0);
  assert.ok(result.attemptsPerYear > 0);
  // Evals passed per year is attempts × pass rate.
  assert.ok(Math.abs(result.evalsPassedPerYear - result.attemptsPerYear * passRate) < 1e-6);
  // Expected attempts to a first pass is the geometric mean 1/passRate (or Infinity).
  if (passRate > 0) {
    assert.ok(Math.abs(result.expectedAttemptsToPass - 1 / passRate) < 1e-6);
    assert.ok(Number.isFinite(result.expectedCostToPass));
  } else {
    assert.equal(result.expectedAttemptsToPass, Infinity);
  }
  // Median days to target, when present, is not below the fastest possible.
  if (result.medianDaysToTarget != null) assert.ok(result.medianDaysToTarget >= 1);
  assert.ok(Number.isFinite(result.annualExpectedValue));
  assert.ok(Number.isFinite(result.roiPerAttempt));
});

test('runPropFirmSimulation accepts a fully custom rule set', () => {
  const log = buildTradeLog(FIXTURE);
  const custom = {
    ...PROP_FIRM_PRESETS[0],
    name: 'Custom rules',
    accountSize: 25000, profitTarget: 1500, maxDailyLoss: 750,
    maxTotalDrawdown: 1250, evaluationDays: 10, challengeFee: 99, resetFee: 99,
    payoutPct: 90, consistencyPct: 0,
  };
  const result = runPropFirmSimulation(log.trades, custom, { runs: 300, seed: 3 });
  assert.equal(result.config.name, 'Custom rules');
  assert.equal(result.config.accountSize, 25000);
  assert.ok(result.passRatePct >= 0 && result.passRatePct <= 100);
  assert.ok(Number.isFinite(result.expectedValue));
});

test('prop firm presets are internally consistent', () => {
  for (const preset of PROP_FIRM_PRESETS) {
    assert.ok(preset.accountSize > 0);
    assert.ok(preset.profitTarget > 0);
    assert.ok(preset.maxDailyLoss > 0);
    assert.ok(preset.maxTotalDrawdown > 0);
    assert.ok(preset.evaluationDays > 0);
  }
});

const TV_FIXTURE =
  'Trade #,Type,Signal,Date/Time,Price,Qty,P&L,Cumulative P&L,Drawdown,Run-up,Cumulative P&L %,Buy & Hold %,Trade #\n' +
  '1,Entry long,,2025-01-03 09:30,100.00,2,,,,,, ,1\n' +
  '1,Exit long,,2025-01-05 16:00,105.00,2,10.00,10.00,,,, ,1\n' +
  '2,Entry short,,2025-01-07 10:00,50.00,1,,,,,, ,2\n' +
  '2,Exit short,,2025-01-08 11:00,48.00,1,2.00,12.00,,,, ,2\n' +
  '3,Entry long,,2025-01-10 09:30,90.00,3,,,,,, ,3\n' +
  '3,Exit long,,2025-01-12 15:00,88.00,3,-6.00,6.00,,,, ,3\n' +
  '4,Entry long,,2025-01-14 10:00,80.00,2,,,,,, ,4\n' +
  '4,Exit long,,2025-01-15 14:00,92.00,2,24.00,30.00,,,, ,4\n';

test('buildTradeLog parses TradingView trade list export', () => {
  const log = buildTradeLog(TV_FIXTURE);
  assert.equal(log.trades.length, 4);
  assert.equal(log.ignored, 0);
  assert.equal(log.hasDates, true);
  assert.ok(log.detected.includes('tradingview'));
  assert.deepEqual(
    log.trades.map((t) => t.direction),
    ['long', 'short', 'long', 'long']
  );
  assert.deepEqual(
    log.trades.map((t) => t.pnl),
    [10, 2, -6, 24]
  );
  assert.equal(log.trades[0].entry, 100);
  assert.equal(log.trades[0].exit, 105);
  assert.equal(log.trades[0].size, 2);
  assert.equal(log.trades[1].entry, 50);
  assert.equal(log.trades[1].exit, 48);
});

test('buildTradeLog derives TradingView P&L from prices when P&L column is blank', () => {
  const csv =
    'Trade #,Type,Signal,Date/Time,Price,Qty,P&L,Cumulative P&L,Trade #\n' +
    '1,Entry long,,2025-01-03 09:30,100.00,2,,,\n' +
    '1,Exit long,,2025-01-05 16:00,106.00,2,,,\n' +
    '2,Entry short,,2025-01-10 10:00,50.00,1,,,\n' +
    '2,Exit short,,2025-01-11 10:00,47.00,1,,,\n';
  const log = buildTradeLog(csv);
  assert.equal(log.trades.length, 2);
  assert.equal(log.trades[0].pnl, 12);
  assert.equal(log.trades[1].pnl, 3);
  assert.equal(log.derivedPnl, false);
});

test('computeMetrics exposes trade dates and monthly returns', () => {
  const metrics = computeMetrics(buildTradeLog(TV_FIXTURE));
  assert.equal(metrics.tradeDates.length, 4);
  assert.ok(metrics.tradeDates.every((d) => d !== null));
  assert.ok(metrics.monthlyReturns.length >= 1);
  const jan = metrics.monthlyReturns.find((m) => m.month === 0 && m.year === 2025);
  assert.ok(jan);
  assert.equal(jan!.pnl, 30);
});

// ── Multi-platform trade-log imports ──────────────────────────────────
// The generic parser accepts a flat round-trip trade list with a P&L column;
// these cover NinjaTrader, MultiCharts, and MetaTrader export shapes, with the
// date formats each platform actually produces.

test('parses a NinjaTrader-style trade list (US date format)', () => {
  const csv =
    'Instrument,Type,Quantity,Entry price,Exit price,Entry time,Profit\n' +
    'ES 12-25,Buy,1,4500.00,4550.00,1/2/2025 9:30:00 AM,50.00\n' +
    'ES 12-25,Sell,1,4550.00,4500.00,1/3/2025 10:00:00 AM,-50.00\n' +
    'ES 12-25,Buy,2,4500.00,4600.00,1/4/2025 9:30:00 AM,200.00\n';
  const log = buildTradeLog(csv);
  assert.equal(log.trades.length, 3);
  assert.ok(log.detected.includes('ninjatrader'), 'detected: ' + log.detected.join(','));
  assert.equal(log.trades[0].pnl, 50);
  assert.equal(log.trades[0].direction, 'long');
  assert.equal(log.hasDates, true);
  assert.match(log.trades[0].date!, /^2025-01-02/);
});

test('parses a MultiCharts-style trade list (Profit/Loss column)', () => {
  const csv =
    'Date,Signal,Contracts,Entry Price,Exit Price,Profit/Loss\n' +
    '2025-01-10,Buy,1,100.00,105.00,5.00\n' +
    '2025-01-11,Sell,1,105.00,100.00,-5.00\n' +
    '2025-01-12,Buy,2,100.00,110.00,20.00\n';
  const log = buildTradeLog(csv);
  assert.equal(log.trades.length, 3);
  assert.ok(log.detected.includes('multicharts'), 'detected: ' + log.detected.join(','));
  assert.equal(log.trades[1].pnl, -5);
  assert.equal(log.hasDates, true);
});

test('parses a MetaTrader-style history (dotted date + volume + swap)', () => {
  const csv =
    'Open Time,Type,Volume,Price,Commission,Swap,Profit\n' +
    '2024.05.01 10:00:00,buy,1.0,4500.00,2.5,0.0,120.00\n' +
    '2024.05.02 11:00:00,sell,1.0,4520.00,2.5,0.0,-30.00\n' +
    '2024.05.03 09:30:00,buy,2.0,4510.00,5.0,0.0,260.00\n';
  const log = buildTradeLog(csv);
  assert.equal(log.trades.length, 3);
  assert.ok(log.detected.includes('metatrader'), 'detected: ' + log.detected.join(','));
  assert.equal(log.hasDates, true);
  assert.match(log.trades[0].date!, /^2024-05-01/);
  // PnL is profit minus commission (fee).
  assert.equal(log.trades[0].pnl, 117.5);
});

test('parseDate handles D/M/YYYY when month > 12', () => {
  const csv =
    'date,pnl\n' + '13/05/2024 10:00:00,10\n' + '14/05/2024 11:00:00,-3\n';
  const log = buildTradeLog(csv);
  assert.equal(log.trades.length, 2);
  assert.equal(log.hasDates, true);
  assert.match(log.trades[0].date!, /^2024-05-13/);
});

// ── Institutional metrics + overfit checks ───────────────────────────

// A longer, dated fixture with enough trades to exercise the new stats.
const OVERFIT_FIXTURE = (() => {
  const rows = ['date,pnl'];
  let d = new Date('2024-01-02');
  // Pseudo-random but deterministic per-trade P&L so the new metrics + overfit
  // checks have something to chew on. Positive drift, fat-tailed losses.
  let seed = 7;
  for (let i = 0; i < 80; i += 1) {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    const u = (seed / 0x7fffffff) - 0.5;
    // Mean ~ +1.5, occasional big loss.
    const pnl = u > 0.45 ? -20 * (u - 0.45) * 20 : 3 + u * 5;
    rows.push(d.toISOString().slice(0, 10) + ',' + pnl.toFixed(2));
    d = new Date(d.getTime() + (d.getDay() === 5 ? 3 * 24 * 3600 * 1000 : 24 * 3600 * 1000));
  }
  return rows.join('\n');
})();

test('computeMetrics exposes the institutional extensions', () => {
  const m = computeMetrics(buildTradeLog(OVERFIT_FIXTURE));
  assert.ok(Number.isFinite(m.sharpe), 'sharpe finite');
  assert.ok(Number.isFinite(m.sortino), 'sortino finite');
  assert.ok(Number.isFinite(m.calmar), 'calmar finite');
  assert.ok(Number.isFinite(m.omega), 'omega finite');
  assert.ok(Number.isFinite(m.tailRatio), 'tailRatio finite');
  assert.ok(m.valueAtRisk95 >= 0, 'VaR95 >= 0');
  assert.ok(m.cvar95 >= m.valueAtRisk95, 'CVaR95 >= VaR95');
  assert.ok(m.maxDrawdownDuration >= 0, 'max DD duration >= 0');
  assert.ok(m.maxDrawdownDurationDays === null || m.maxDrawdownDurationDays >= 0);
  assert.ok(Number.isFinite(m.recoveryFactor));
  assert.ok(Number.isFinite(m.ulcerIndex));
  assert.ok(Number.isFinite(m.skewness));
  assert.ok(Number.isFinite(m.kurtosis));
  assert.equal(m.benchmark, null);
  assert.equal(m.beta, null);
  assert.equal(m.informationRatio, null);
  // sharpeLike is still there for back-compat with render.ts
  assert.ok(Number.isFinite(m.sharpeLike));
});

test('computeMetrics accepts a benchmark and computes beta/alpha/IR', () => {
  const bench = [];
  for (let i = 0; i < 80; i += 1) bench.push(Math.sin(i / 5) * 2 + (i % 3) - 1);
  const m = computeMetrics(buildTradeLog(OVERFIT_FIXTURE), {
    benchmark: { name: 'SPY', returns: bench },
  });
  assert.equal(m.benchmark, 'SPY');
  assert.ok(m.beta != null && Number.isFinite(m.beta));
  assert.ok(m.alpha != null && Number.isFinite(m.alpha));
  assert.ok(m.informationRatio != null && Number.isFinite(m.informationRatio));
});

test('runStationaryBootstrap preserves serial structure with ordered percentiles', () => {
  const m = computeMetrics(buildTradeLog(OVERFIT_FIXTURE));
  const r = runStationaryBootstrap(m.returns, { paths: 200, blockLength: 5, seed: 42 });
  assert.equal(r.terminals.length, 200);
  assert.ok(r.p5 <= r.p50 && r.p50 <= r.p95);
  assert.ok(r.positivePathsPct >= 0 && r.positivePathsPct <= 1);
  assert.ok(r.drawdownPercentiles.p50 <= r.drawdownPercentiles.p95);
});

test('autoBlockSize grows with positive autocorrelation and stays >= 1', () => {
  // Positively autocorrelated series
  const ar: number[] = [];
  let v = 0;
  for (let i = 0; i < 200; i += 1) { v = 0.9 * v + (Math.sin(i) * 0.5); ar.push(v); }
  const b = autoBlockSize(ar);
  assert.ok(b >= 1, 'block size >= 1');
  // An IID series should collapse to a small block size
  const iid: number[] = [];
  let s = 12345;
  for (let i = 0; i < 200; i += 1) {
    s = (s * 1103515245 + 12345) & 0x7fffffff;
    iid.push((s / 0x7fffffff) - 0.5);
  }
  assert.ok(autoBlockSize(iid) <= b, 'autocorrelated block >= IID block');
});

test('walkForward returns folds and a verdict with sensible OOS stats', () => {
  const m = computeMetrics(buildTradeLog(OVERFIT_FIXTURE));
  const r = walkForward(m.returns, { folds: 4, tradesPerYear: m.tradesPerYear });
  assert.equal(r.folds.length, 3); // folds - 1 (first fold has no IS)
  assert.ok(['stable', 'decaying', 'unstable'].includes(r.verdict));
  assert.ok(r.oosPositivePct >= 0 && r.oosPositivePct <= 1);
});

test('purgedKFold respects purge + embargo and reports per-fold stats', () => {
  const m = computeMetrics(buildTradeLog(OVERFIT_FIXTURE));
  const r = purgedKFold(m.returns, { folds: 5, purge: 2, embargo: 2, tradesPerYear: m.tradesPerYear });
  assert.equal(r.nFolds, 5);
  assert.equal(r.purge, 2);
  assert.equal(r.embargo, 2);
  assert.equal(r.folds.length, 5);
  assert.ok(r.oosPositivePct >= 0 && r.oosPositivePct <= 1);
});

test('deflatedSharpeRatio is in [0,1] and flagged inflated for many trials', () => {
  const r1 = deflatedSharpeRatio({ sharpe: 1.5, years: 2, skew: 0, kurtosis: 3, trials: 1 });
  assert.ok(r1.dsr >= 0 && r1.dsr <= 1);
  const rMany = deflatedSharpeRatio({ sharpe: 1.5, years: 2, skew: 0, kurtosis: 3, trials: 1000 });
  // With 1000 trials, a 1.5 SR over 2 years should not be credible.
  assert.ok(rMany.dsr < r1.dsr, 'DSR drops with more trials');
  assert.ok(['credible', 'marginal', 'inflated'].includes(rMany.verdict));
});

test('probabilityOfBacktestOverfitting is in [0,1] and rises with overfit input', () => {
  // Two strategies: IS-best is OOS-worst. PBO should be high.
  const matrix = [
    [1, 2, 3, 4, -5, -5, -5, -5], // good IS, bad OOS
    [-1, -2, -3, -4, 5, 5, 5, 5], // bad IS, good OOS
  ];
  const r = probabilityOfBacktestOverfitting(matrix);
  assert.ok(r.pbo >= 0 && r.pbo <= 1);
  assert.ok(['not overfit', 'suspect', 'overfit'].includes(r.verdict));
  assert.equal(r.nStrategies, 2);
  // Honest when there's too little data
  const tiny = probabilityOfBacktestOverfitting([[1, 2]]);
  assert.equal(tiny.pbo, 0);
});

test('buildOverfitReport runs all checks and returns an honest summary', () => {
  const m = computeMetrics(buildTradeLog(OVERFIT_FIXTURE));
  const r = buildOverfitReport(
    m.returns,
    { sharpe: m.sharpe, skewness: m.skewness, kurtosis: m.kurtosis, count: m.count, tradesPerYear: m.tradesPerYear },
    { paths: 200, seed: 11, trials: 1 },
  );
  assert.ok(r.walkForward.folds.length > 0);
  assert.ok(r.purgedKFold.folds.length > 0);
  assert.ok(r.deflatedSharpe.dsr >= 0 && r.deflatedSharpe.dsr <= 1);
  assert.equal(r.pbo, null, 'PBO is null without a parameter matrix');
  assert.ok(r.summary.length > 0);
  assert.ok(r.verdict.length > 0);
  // With a matrix supplied, PBO is computed.
  const matrix = [m.returns, m.returns.slice().reverse()];
  const r2 = buildOverfitReport(
    m.returns,
    { sharpe: m.sharpe, skewness: m.skewness, kurtosis: m.kurtosis, count: m.count, tradesPerYear: m.tradesPerYear },
    { paths: 200, seed: 11, trials: 1, pboMatrix: matrix },
  );
  assert.ok(r2.pbo != null);
  assert.ok(r2.pbo!.pbo >= 0 && r2.pbo!.pbo <= 1);
});

test('detectRegimes labels every trade with a Bull/Bear x Vol regime', async () => {
  const { detectRegimes, REGIME_ORDER } = await import('../backtester-src/regimes.ts');
  const log = buildTradeLog(FIXTURE);
  const metrics = computeMetrics(log);
  const regimes = detectRegimes(metrics);
  assert.equal(regimes.length, metrics.returns.length);
  for (const rp of regimes) {
    assert.ok(REGIME_ORDER.includes(rp.regime));
    assert.ok(REGIME_ORDER.includes(rp.shortRegime));
    assert.ok(REGIME_ORDER.includes(rp.longRegime));
  }
});

test('regime attribution, stats, and bands are consistent', async () => {
  const { detectRegimes, attributeRegimes, computeRegimeStats, regimeEquityBands } =
    await import('../backtester-src/regimes.ts');
  const log = buildTradeLog(FIXTURE);
  const metrics = computeMetrics(log);
  const regimes = detectRegimes(metrics);
  const attributed = attributeRegimes(regimes, 'entry');
  assert.equal(attributed.length, metrics.returns.length);
  const stats = computeRegimeStats(metrics.returns, attributed);
  assert.equal(stats.length, 4);
  const totalTrades = stats.reduce((a, s) => a + s.trades, 0);
  assert.equal(totalTrades, metrics.returns.length);
  const totalPnl = stats.reduce((a, s) => a + s.netPnl, 0);
  assert.ok(Math.abs(totalPnl - metrics.netPnl) < 1e-9);
  const bands = regimeEquityBands(attributed);
  assert.equal(bands[0].start, 0);
  assert.equal(bands[bands.length - 1].end, attributed.length);
});

test('runRegimeAwareMC is deterministic per seed and returns ordered percentiles', async () => {
  const { detectRegimes, attributeRegimes, runRegimeAwareMC } =
    await import('../backtester-src/regimes.ts');
  const log = buildTradeLog(FIXTURE);
  const metrics = computeMetrics(log);
  const attributed = attributeRegimes(detectRegimes(metrics), 'entry');
  const opts = { paths: 200, blockSize: 5, seed: 42, regimeAware: true };
  const a = runRegimeAwareMC(metrics.returns, attributed, opts);
  const b = runRegimeAwareMC(metrics.returns, attributed, opts);
  assert.equal(a.paths.length, 200);
  assert.deepEqual(a.terminals, b.terminals);
  assert.ok(a.p5 <= a.p50 && a.p50 <= a.p95);
});

test('buildOverfitReport surfaces walk-forward, DSR, and a stationary-bootstrap envelope', () => {
  const pnls = Array.from({ length: 60 }, (_, i) => (i % 3 === 0 ? -8 : 12) + (i % 7) - 3);
  const rep = buildOverfitReport(pnls, {
    sharpe: 1.1, skewness: 0.2, kurtosis: 3.1, count: 60, tradesPerYear: 252,
  }, { folds: 5, trials: 1, paths: 300, seed: 42 });
  assert.ok(rep.walkForward.folds.length >= 2);
  assert.ok(rep.deflatedSharpe.dsr >= 0 && rep.deflatedSharpe.dsr <= 1);
  assert.ok(rep.stationaryBootstrap.paths.length === 300);
  assert.ok(typeof rep.verdict === 'string' && rep.verdict.length > 0);
});
