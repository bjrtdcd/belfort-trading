import assert from 'node:assert/strict';
import { test } from 'node:test';
import http from 'node:http';
import { createServer, hash, safeName, portFor } from '../server/codeserver/api.js';

// A fake docker that records calls and answers `inspect` based on a name set.
function fakeDocker(state) {
  return function (args) {
    state.calls.push(args);
    if (args[0] === 'inspect') {
      const name = args[args.length - 1];
      if (!state.containers[name]) return Promise.reject(new Error('no such container'));
      return Promise.resolve(state.containers[name].running ? 'true\n' : 'false\n');
    }
    if (args[0] === 'run') {
      const i = args.indexOf('--name');
      const name = args[i + 1];
      state.containers[name] = { running: true };
      return Promise.resolve(name);
    }
    if (args[0] === 'start') {
      const name = args[args.length - 1];
      if (state.containers[name]) state.containers[name].running = true;
      return Promise.resolve(name);
    }
    if (args[0] === 'stop') {
      const name = args[args.length - 1];
      if (state.containers[name]) state.containers[name].running = false;
      return Promise.resolve(name);
    }
    if (args[0] === 'rm') {
      const name = args[args.length - 1];
      delete state.containers[name];
      return Promise.resolve(name);
    }
    return Promise.resolve('');
  };
}

function boot(state, opts) {
  opts = opts || {};
  const server = createServer({
    docker: fakeDocker(state),
    apiKey: opts.apiKey || '',
    origin: opts.origin || 'https://site.example',
    image: 'img:1',
    host: 'cs.host',
    portBase: 9000,
    portRange: 1000,
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve({ server, port: server.address().port })));
}

function close(srv) { return new Promise((r) => srv.server.close(r)); }

function req(srv, method, path, body, headers) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    const r = http.request({ method, path, host: '127.0.0.1', port: srv.port, agent: false, headers: Object.assign({ host: 'site.example', origin: 'https://site.example', connection: 'close' }, headers || {}) }, (res) => {
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        const text = Buffer.concat(chunks).toString();
        try { resolve({ code: res.statusCode, headers: res.headers, body: text ? JSON.parse(text) : {} }); }
        catch { resolve({ code: res.statusCode, headers: res.headers, body: text }); }
      });
    });
    r.on('error', reject);
    if (body) r.write(JSON.stringify(body));
    r.end();
  });
}

test('hash/safeName/portFor are deterministic', () => {
  assert.equal(hash('abc'), hash('abc'));
  assert.ok(safeName('User 42!').startsWith('belfort-cs-user-42'));
  assert.equal(portFor('abc', 9000, 1000), 9000 + (hash('abc') % 1000));
});

test('/start creates a container when none exists', async () => {
  const state = { calls: [], containers: {} };
  const srv = await boot(state);
  const res = await req(srv, 'POST', '/start', { session: 'user-a' });
  assert.equal(res.code, 200);
  assert.equal(res.body.status, 'created');
  assert.match(res.body.url, /^http:\/\/cs\.host:\d+$/);
  assert.ok(state.calls.find((c) => c[0] === 'run'), 'docker run was called');
  await close(srv);
});

test('/start is idempotent — returns running if the container already runs', async () => {
  const state = { calls: [], containers: {} };
  state.containers[safeName('user-a')] = { running: true };
  const srv = await boot(state);
  const res = await req(srv, 'POST', '/start', { session: 'user-a' });
  assert.equal(res.code, 200);
  assert.equal(res.body.status, 'running');
  assert.equal(state.calls.filter((c) => c[0] === 'run').length, 0, 'did not run again');
  await close(srv);
});

test('/start starts a stopped container', async () => {
  const state = { calls: [], containers: {} };
  state.containers[safeName('user-b')] = { running: false };
  const srv = await boot(state);
  const res = await req(srv, 'POST', '/start', { session: 'user-b' });
  assert.equal(res.code, 200);
  assert.equal(res.body.status, 'started');
  assert.ok(state.calls.find((c) => c[0] === 'start'));
  await close(srv);
});

test('/stop tears the container down', async () => {
  const state = { calls: [], containers: { [safeName('user-a')]: { running: true } } };
  const srv = await boot(state);
  const res = await req(srv, 'POST', '/stop', { session: 'user-a' });
  assert.equal(res.code, 200);
  assert.equal(res.body.ok, true);
  assert.equal(state.containers[safeName('user-a')], undefined, 'container removed');
  await close(srv);
});

test('/status reports running + url', async () => {
  const state = { calls: [], containers: { [safeName('user-a')]: { running: true } } };
  const srv = await boot(state);
  const res = await req(srv, 'GET', '/status?session=user-a');
  assert.equal(res.code, 200);
  assert.equal(res.body.running, true);
  assert.match(res.body.url, /^http:\/\/cs\.host:\d+$/);
  await close(srv);
});

test('CORS preflight + origin allowlist', async () => {
  const state = { calls: [], containers: {} };
  const srv = await boot(state, { origin: 'https://site.example' });
  const pre = await req(srv, 'OPTIONS', '/start', null, { origin: 'https://site.example' });
  assert.equal(pre.code, 204);
  assert.equal(pre.headers['access-control-allow-origin'], 'https://site.example');
  const blocked = await req(srv, 'GET', '/health', null, { origin: 'https://evil.example' });
  assert.equal(blocked.code, 403);
  await close(srv);
});

test('API key is required when set', async () => {
  const state = { calls: [], containers: {} };
  const srv = await boot(state, { apiKey: 'secret' });
  const noKey = await req(srv, 'GET', '/health', null, { origin: 'https://site.example' });
  assert.equal(noKey.code, 401);
  const withKey = await req(srv, 'GET', '/health', null, { origin: 'https://site.example', 'x-belfort-key': 'secret' });
  assert.equal(withKey.code, 200);
  await close(srv);
});

test('missing session is a 400', async () => {
  const state = { calls: [], containers: {} };
  const srv = await boot(state);
  const res = await req(srv, 'POST', '/start', {});
  assert.equal(res.code, 400);
  await close(srv);
});
