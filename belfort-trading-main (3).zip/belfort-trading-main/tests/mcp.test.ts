import assert from 'node:assert/strict';
import { test } from 'node:test';

import {
  backtestSummary,
  monteCarloSummary,
  propFirmSummary,
  validateSummary,
  listPresets,
  sampleLog,
  graph3D,
  overfitSummary,
} from '../mcp/server';
import { renderSurface } from '../mcp/raster';
import { computeMetrics } from '../backtester-src/metrics.ts';
import { buildTradeLog } from '../backtester-src/csv.ts';

const csv = sampleLog();

// Build a longer fixture for the overfit tools (the 24-trade sample is too short).
const LONG_CSV = (() => {
  const rows = ['date,pnl'];
  let d = new Date('2024-01-02');
  let seed = 7;
  for (let i = 0; i < 80; i += 1) {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    const u = (seed / 0x7fffffff) - 0.5;
    const pnl = u > 0.45 ? -20 * (u - 0.45) * 20 : 3 + u * 5;
    rows.push(d.toISOString().slice(0, 10) + ',' + pnl.toFixed(2));
    d = new Date(d.getTime() + (d.getDay() === 5 ? 3 * 24 * 3600 * 1000 : 24 * 3600 * 1000));
  }
  return rows.join('\n');
})();

test('backtestSummary produces metrics and a grade on the sample log', () => {
  const s = backtestSummary(csv);
  assert.equal(s.trades, 24);
  assert.ok(['A', 'B', 'C', 'D', 'F'].includes(s.grade), 'grade is ' + s.grade);
  assert.ok(s.gradeBreakdown.length > 0);
  assert.ok(s.detectedFields.length > 0);
  // Institutional extensions present and finite.
  assert.ok(Number.isFinite(s.sharpe), 'sharpe finite');
  assert.ok(Number.isFinite(s.sortino));
  assert.ok(Number.isFinite(s.calmar));
  assert.ok(Number.isFinite(s.valueAtRisk95));
  assert.ok(s.cvar95 >= s.valueAtRisk95, 'CVaR >= VaR');
  assert.ok(Number.isFinite(s.recoveryFactor));
  assert.ok(Number.isFinite(s.skewness));
  assert.ok(Number.isFinite(s.kurtosis));
  assert.ok(s.tradesPerYear > 0);
});

test('monteCarloSummary clamps paths, keeps the seed, and orders percentiles', () => {
  const s = monteCarloSummary(csv, 50, 1, 123);
  assert.equal(s.seed, 123);
  assert.equal(s.paths, 50);
  assert.ok(s.p5 <= s.p50, 'p5 <= p50');
  assert.ok(s.p50 <= s.p95, 'p50 <= p95');
  assert.ok(s.positivePathsPct >= 0 && s.positivePathsPct <= 100);
});

test('propFirmSummary simulates FTMO and reconciles pass + fail counts', () => {
  const s = propFirmSummary(csv, 'FTMO 100k', 300, 42);
  assert.equal(s.preset, 'FTMO 100k');
  assert.equal(s.accountSize, 100000);
  assert.ok(s.passRatePct >= 0 && s.passRatePct <= 100);
  const fails = s.failures.reduce((a, f) => a + f.count, 0);
  assert.equal(s.passCount + fails, s.runs, 'pass + fail counts equal runs');
});

test('validateSummary combines backtest, Monte Carlo, and prop firm', () => {
  const v = validateSummary(csv, { paths: 100, runs: 100, seed: 1 });
  assert.ok(v.backtest.grade);
  assert.equal(v.monteCarlo.paths, 100);
  assert.equal(v.propFirm.preset, 'FTMO 100k');
  assert.ok(v.verdict.includes('—'), 'verdict has a grade line');
  assert.ok(Array.isArray(v.advice));
});

test('listPresets includes FTMO 100k with sane limits', () => {
  const p = listPresets();
  assert.ok(p.some((x) => x.name === 'FTMO 100k'));
  const ftmo = p.find((x) => x.name === 'FTMO 100k')!;
  assert.equal(ftmo.profitTarget, 10000);
  assert.equal(ftmo.maxDailyLoss, 5000);
});

test('sampleLog returns a parseable TradingView export', () => {
  assert.ok(csv.startsWith('Trade #,Type,Signal'));
  assert.ok(csv.split('\n').length > 24);
});

test('renderSurface returns a valid PNG for a small grid', () => {
  const z = [[0, 1, 2], [1, 2, 3], [2, 3, 4]];
  const png = renderSurface(z, { width: 120, height: 80, ssaa: 1 });
  assert.ok(Buffer.isBuffer(png));
  // PNG signature
  assert.deepEqual(Array.from(png.slice(0, 8)), [137, 80, 78, 71, 13, 10, 26, 10]);
  // IHDR chunk type at bytes 12–16
  assert.equal(png.toString('ascii', 12, 16), 'IHDR');
  assert.equal(png.toString('ascii', png.length - 8, png.length - 4), 'IEND');
});

test('graph3D produces a PNG image and a caption for both views', () => {
  for (const view of ['equity', 'drawdown'] as const) {
    const r = graph3D(csv, view, 200, 1, 42);
    assert.ok(Buffer.isBuffer(r.image), view + ' image is a Buffer');
    assert.equal(r.mimeType, 'image/png');
    assert.deepEqual(Array.from(r.image.slice(0, 8)), [137, 80, 78, 71, 13, 10, 26, 10], view + ' PNG signature');
    assert.match(r.caption, /3D (equity|drawdown) surface/);
    assert.match(r.caption, /Axes:/);
  }
});

test('overfitSummary runs the full battery and returns an honest verdict', () => {
  const s = overfitSummary(LONG_CSV, { paths: 200, folds: 4, trials: 1, seed: 11 });
  assert.ok(s.trades > 0);
  assert.ok(['stable', 'decaying', 'unstable'].includes(s.walkForward.verdict));
  assert.ok(s.walkForward.folds > 0);
  assert.ok(s.purgedKFold.nFolds === 4);
  assert.ok(s.deflatedSharpe.dsr >= 0 && s.deflatedSharpe.dsr <= 1);
  assert.ok(['credible', 'marginal', 'inflated'].includes(s.deflatedSharpe.verdict));
  assert.equal(s.pbo, null, 'PBO null without a parameter matrix');
  assert.ok(s.stationaryBootstrap.paths === 200);
  assert.ok(s.stationaryBootstrap.p5 <= s.stationaryBootstrap.p50);
  assert.ok(s.stationaryBootstrap.p50 <= s.stationaryBootstrap.p95);
  assert.ok(s.verdict.length > 0);
  assert.ok(s.summary.length > 0);
});

test('overfitSummary computes PBO when a parameter matrix is supplied', () => {
  // Two synthetic strategies over the LONG_CSV period: a real one and a reversed one.
  const m = computeMetrics(buildTradeLog(LONG_CSV));
  const matrix = [m.returns, m.returns.slice().reverse()];
  const s = overfitSummary(LONG_CSV, { paths: 100, folds: 3, trials: 2, pboMatrix: matrix, seed: 11 });
  assert.ok(s.pbo != null);
  assert.ok(s.pbo!.pbo >= 0 && s.pbo!.pbo <= 1);
  assert.equal(s.pbo!.nStrategies, 2);
  assert.equal(s.deflatedSharpe.trials, 2);
});
