import { Metrics, RegimeLabel, RegimePoint, RegimeStats, RegimeEquityBand, RegimeMCResult } from './types';
import { mulberry32 } from './rng';

export const REGIME_COLORS: Record<RegimeLabel, string> = {
  'Bull·Low Vol': '#2dd4bf',
  'Bull·High Vol': '#fbbf24',
  'Bear·Low Vol': '#38bdf8',
  'Bear·High Vol': '#fb7185',
};

export const REGIME_ORDER: RegimeLabel[] = ['Bull·Low Vol', 'Bull·High Vol', 'Bear·Low Vol', 'Bear·High Vol'];

const SHORT_WINDOW = 3;
const LONG_WINDOW_MIN = 8;

function rollingMean(arr: number[], i: number, w: number): number {
  const start = Math.max(0, i - w + 1);
  let sum = 0;
  let count = 0;
  for (let j = start; j <= i; j += 1) { sum += arr[j]; count += 1; }
  return count > 0 ? sum / count : arr[i];
}

function rollingStd(arr: number[], i: number, w: number): number {
  const start = Math.max(0, i - w + 1);
  let sum = 0;
  let count = 0;
  for (let j = start; j <= i; j += 1) { sum += arr[j]; count += 1; }
  const mean = count > 0 ? sum / count : 0;
  let variance = 0;
  for (let j = start; j <= i; j += 1) variance += (arr[j] - mean) ** 2;
  return count > 0 ? Math.sqrt(variance / count) : 0;
}

function median(arr: number[]): number {
  if (!arr.length) return 0;
  const sorted = arr.slice().sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

/** Detect market regimes from the actual backtest data. */
export function detectRegimes(metrics: Metrics): RegimePoint[] {
  const equity = metrics.equity;
  const returns = metrics.returns;
  const n = returns.length;
  if (n < 4) return [];

  const longWindow = Math.max(LONG_WINDOW_MIN, Math.floor(n / 3));

  // Compute short and long window rolling stds
  const shortStds: number[] = [];
  const longStds: number[] = [];
  for (let i = 0; i < n; i += 1) {
    shortStds.push(rollingStd(returns, i, SHORT_WINDOW));
    longStds.push(rollingStd(returns, i, longWindow));
  }
  const shortMedian = median(shortStds);
  const longMedian = median(longStds);

  const points: RegimePoint[] = [];
  for (let i = 0; i < n; i += 1) {
    // Short window (sensitive — entry/exit)
    const shortMean = rollingMean(equity, i, SHORT_WINDOW);
    const shortTrend = equity[i] >= shortMean ? 'bull' : 'bear';
    const shortVol = shortStds[i] > shortMedian ? 'high' : 'low';
    const shortRegime = `${shortTrend === 'bull' ? 'Bull' : 'Bear'}·${shortVol === 'high' ? 'High Vol' : 'Low Vol'}` as RegimeLabel;

    // Long window (broad context — dominant)
    const longMean = rollingMean(equity, i, longWindow);
    const longTrend = equity[i] >= longMean ? 'bull' : 'bear';
    const longVol = longStds[i] > longMedian ? 'high' : 'low';
    const longRegime = `${longTrend === 'bull' ? 'Bull' : 'Bear'}·${longVol === 'high' ? 'High Vol' : 'Low Vol'}` as RegimeLabel;

    points.push({
      index: i,
      trend: shortTrend,
      volatility: shortVol,
      regime: shortRegime,
      shortRegime,
      longRegime,
    });
  }
  return points;
}

export type AttributionMode = 'entry' | 'dominant' | 'exit';

/** Attribute a regime to each trade based on the selected mode. */
export function attributeRegimes(regimes: RegimePoint[], mode: AttributionMode): RegimeLabel[] {
  return regimes.map((rp, i) => {
    if (mode === 'entry') return rp.shortRegime;
    if (mode === 'dominant') return rp.longRegime;
    // exit: regime at the next trade (the market state when this trade closed)
    const next = regimes[i + 1];
    return next ? next.shortRegime : rp.shortRegime;
  });
}

/** Compute per-regime statistics. */
export function computeRegimeStats(returns: number[], attributed: RegimeLabel[]): RegimeStats[] {
  const total = returns.length;
  const groups: Record<RegimeLabel, number[]> = {
    'Bull·Low Vol': [], 'Bull·High Vol': [], 'Bear·Low Vol': [], 'Bear·High Vol': [],
  };
  attributed.forEach((regime, i) => { groups[regime].push(returns[i]); });

  return REGIME_ORDER.map((regime) => {
    const trades = groups[regime];
    const count = trades.length;
    const netPnl = trades.reduce((a, b) => a + b, 0);
    const wins = trades.filter((v) => v > 0).length;
    return {
      regime,
      color: REGIME_COLORS[regime],
      exposurePct: total > 0 ? (count / total) * 100 : 0,
      netPnl,
      winRate: count > 0 ? wins / count : 0,
      trades: count,
      avgTrade: count > 0 ? netPnl / count : 0,
    };
  });
}

/** Build contiguous bands for the equity chart background. */
export function regimeEquityBands(attributed: RegimeLabel[]): RegimeEquityBand[] {
  const bands: RegimeEquityBand[] = [];
  if (!attributed.length) return bands;
  let current = attributed[0];
  let start = 0;
  for (let i = 1; i < attributed.length; i += 1) {
    if (attributed[i] !== current) {
      bands.push({ start, end: i, regime: current, color: REGIME_COLORS[current] });
      current = attributed[i];
      start = i;
    }
  }
  bands.push({ start, end: attributed.length, regime: current, color: REGIME_COLORS[current] });
  return bands;
}

/** Regime-aware Monte Carlo: resample trades within their attributed regime (preserves the regime sequence). */
export function runRegimeAwareMC(
  returns: number[],
  attributed: RegimeLabel[],
  options: { paths: number; blockSize: number; seed: number; regimeAware: boolean }
): RegimeMCResult {
  const n = returns.length;
  if (n < 2) {
    return { paths: [], terminals: [], p5: 0, p50: 0, p95: 0, positivePathsPct: 0, underwaterPct: 0, drawdownPercentiles: { p5: 0, p50: 0, p95: 0 }, config: { ...options } };
  }
  const random = mulberry32(options.seed);
  const paths: number[][] = [];
  const terminals: number[] = [];
  const allMaxDrawdowns: number[] = [];

  // Group trade indices by regime for regime-aware resampling
  const regimeGroups: Record<RegimeLabel, number[]> = {
    'Bull·Low Vol': [], 'Bull·High Vol': [], 'Bear·Low Vol': [], 'Bear·High Vol': [],
  };
  attributed.forEach((regime, i) => regimeGroups[regime].push(i));
  const allIndices = returns.map((_, i) => i);

  function randomIndexFrom(arr: number[]): number {
    return arr[Math.floor(random() * arr.length)];
  }

  for (let p = 0; p < options.paths; p += 1) {
    let equity = 0;
    const path: number[] = [0];
    let peak = 0;
    let maxDrawdown = 0;
    let underwaterCount = 0;

    for (let i = 0; i < n; i += 1) {
      let idx: number;
      if (options.regimeAware) {
        const group = regimeGroups[attributed[i]];
        idx = group.length > 0 ? randomIndexFrom(group) : randomIndexFrom(allIndices);
      } else {
        idx = Math.floor(random() * n);
      }
      equity += returns[idx];
      path.push(equity);
      peak = Math.max(peak, equity);
      maxDrawdown = Math.max(maxDrawdown, peak - equity);
      if (equity < peak) underwaterCount += 1;
    }
    paths.push(path);
    terminals.push(equity);
    allMaxDrawdowns.push(maxDrawdown);
  }

  const sortedTerminals = terminals.slice().sort((a, b) => a - b);
  const p5 = sortedTerminals[Math.floor(sortedTerminals.length * 0.05)] || 0;
  const p50 = sortedTerminals[Math.floor(sortedTerminals.length * 0.5)] || 0;
  const p95 = sortedTerminals[Math.floor(sortedTerminals.length * 0.95)] || 0;
  const positivePaths = terminals.filter((t) => t >= 0).length;
  const sortedDD = allMaxDrawdowns.sort((a, b) => a - b);

  return {
    paths,
    terminals,
    p5,
    p50,
    p95,
    positivePathsPct: (positivePaths / terminals.length) * 100,
    underwaterPct: 0, // computed per-path average below
    drawdownPercentiles: {
      p5: sortedDD[Math.floor(sortedDD.length * 0.05)] || 0,
      p50: sortedDD[Math.floor(sortedDD.length * 0.5)] || 0,
      p95: sortedDD[Math.floor(sortedDD.length * 0.95)] || 0,
    },
    config: { ...options },
  };
}
