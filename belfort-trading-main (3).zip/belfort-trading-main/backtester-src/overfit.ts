// Overfit / robustness module — pure, DOM-free, no UI.
//
// Implements five institutional checks the trade-log engine was missing:
//
//   1. `stationaryBootstrap`        — Politis & Romano (1994) stationary block
//                                     bootstrap with random geometric block lengths.
//                                     Replaces the IID (blockSize=1) bootstrap the
//                                     agent was running, which destroyed serial
//                                     structure. Block length defaults to the
//                                     autocorrelation-derived `autoBlockSize()`.
//   2. `walkForward`                — rolling in-sample / out-of-sample windows on
//                                     the trade sequence; reports per-fold Sharpe
//                                     and a stability verdict.
//   3. `purgedKFold`                — time-ordered K-fold with a purge gap and an
//                                     embargo after each test fold (López de Prado,
//                                     AFML §7). Prevents label leakage across
//                                     folds.
//   4. `deflatedSharpeRatio`        — Bailey & López de Prado (2014). Adjusts the
//                                     observed Sharpe for multiple trials, skew and
//                                     kurtosis; returns P(true SR > 0).
//   5. `probabilityOfBacktestOverfitting`
//                                  — CSCV / PBO (Bailey, Borwein, López de Prado &
//                                     Zhu, 2017). Given a matrix of per-period
//                                     returns for N parameter combinations, returns
//                                     the frequency with which the best IS strategy
//                                     ranks below median OOS.
//
// `buildOverfitReport()` runs all of them on a single trade-log and returns one
// honest summary the agent and MCP surface report verbatim. PBO requires a
// parameter-scan matrix; when none is supplied the report is honest about it
// (pbo = null) rather than fabricating a number.

import {
  DeflatedSharpeInput,
  DeflatedSharpeResult,
  OverfitReport,
  PBOResult,
  PurgedKFoldResult,
  StationaryBootstrapConfig,
  StationaryBootstrapResult,
  WalkForwardFold,
  WalkForwardResult,
} from './types';
import { mulberry32 } from './rng';

// ── Helpers ─────────────────────────────────────────────────────────

function mean(arr: number[]): number {
  if (arr.length === 0) return 0;
  let s = 0;
  for (let i = 0; i < arr.length; i += 1) s += arr[i];
  return s / arr.length;
}

function variance(arr: number[], m?: number): number {
  if (arr.length < 2) return 0;
  const mu = m == null ? mean(arr) : m;
  let s = 0;
  for (let i = 0; i < arr.length; i += 1) {
    const d = arr[i] - mu;
    s += d * d;
  }
  return s / arr.length;
}

function stddev(arr: number[], m?: number): number {
  return Math.sqrt(variance(arr, m));
}

/** Per-trade Sharpe: mean / std. Not annualized — the same scaling applies to
 *  in-sample and out-of-sample windows so the degradation ratio is meaningful. */
function tradeSharpe(returns: number[]): number {
  if (returns.length < 2) return 0;
  const sd = stddev(returns);
  return sd > 0 ? mean(returns) / sd : 0;
}

function percentileSorted(sorted: number[], fraction: number): number {
  if (sorted.length === 0) return 0;
  const idx = Math.min(sorted.length - 1, Math.floor(sorted.length * fraction));
  return sorted[idx];
}

function erfApprox(x: number): number {
  // Abramowitz & Stegun 7.1.26 — max error 1.5e-7.
  const sign = x < 0 ? -1 : 1;
  const ax = Math.abs(x);
  const t = 1 / (1 + 0.3275911 * ax);
  const y = 1 - ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-ax * ax);
  return sign * y;
}

function normalCdf(x: number): number {
  return 0.5 * (1 + erfApprox(x / Math.SQRT2));
}

function inverseNormalCdf(p: number): number {
  // Acklam's algorithm — good to ~1e-9.
  if (p <= 0) return -Infinity;
  if (p >= 1) return Infinity;
  const a = [-3.969683028665376e1, 2.209460984245205e2, -2.759285104469687e2, 1.38357751867269e2, -3.066479806614716e1, 2.506628277459239];
  const b = [-5.447609879822406e1, 1.615858368580409e2, -1.556989798598866e2, 6.680131188771972e1, -1.328068155288572e1];
  const c = [-7.784894002430293e-3, -3.223964580411365e-1, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783];
  const d = [7.784695709041462e-3, 3.224671290700398e-1, 2.445134137142996, 3.754408661907416];
  const plow = 0.02425;
  const phigh = 1 - plow;
  let q: number, r: number;
  let x = 0;
  if (p < plow) {
    q = Math.sqrt(-2 * Math.log(p));
    x = (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) /
      ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
  } else if (p <= phigh) {
    q = p - 0.5;
    r = q * q;
    x = (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q /
      (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
  } else {
    q = Math.sqrt(-2 * Math.log(1 - p));
    x = -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) /
      ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
  }
  return x;
}

/** Lag-1 autocorrelation of a returns series. Used to pick a sensible block
 *  length for the stationary bootstrap. Returns 0 for short or constant series. */
export function autocorrelation(returns: number[], lag = 1): number {
  if (returns.length <= lag + 1) return 0;
  const mu = mean(returns);
  let num = 0;
  let den = 0;
  for (let i = 0; i < returns.length; i += 1) {
    den += (returns[i] - mu) ** 2;
  }
  if (den === 0) return 0;
  for (let i = lag; i < returns.length; i += 1) {
    num += (returns[i] - mu) * (returns[i - lag] - mu);
  }
  return num / den;
}

/** Pick a mean block length for the stationary bootstrap from the
 *  autocorrelation structure. Politis & White (2004) give a data-driven plug-in;
 *  this is the simpler Patton–Politis–White rule: B = 1 / (1 - 2ρ̂ + ρ̂²) capped
 *  to a reasonable range. For IID series (ρ̂≈0) this collapses to length 1; for
 *  positively autocorrelated series it grows. */
export function autoBlockSize(returns: number[]): number {
  if (returns.length < 4) return 1;
  const rho = autocorrelation(returns, 1);
  // Clamp ρ̂ to a safe range — for very high autocorrelation the denominator
  // blows up, so cap the resulting block length at min(n/4, 30).
  const r = Math.min(Math.max(rho, -0.5), 0.95);
  const denom = 1 - 2 * r + r * r;
  if (denom <= 1e-6) return Math.min(Math.max(returns.length >> 2, 1), 30);
  const b = 1 / denom;
  return Math.min(Math.max(Math.round(b), 1), Math.min(30, Math.max(returns.length >> 2, 1)));
}

// ── 1. Stationary bootstrap (Politis & Romano 1994) ────────────────

export function runStationaryBootstrap(
  returns: number[],
  config: StationaryBootstrapConfig,
): StationaryBootstrapResult {
  if (returns.length < 2) {
    throw new Error('At least two trades are required for the stationary bootstrap.');
  }
  const paths = Math.min(Math.max(Math.floor(config.paths), 10), 5000);
  const blockLength = Math.min(Math.max(config.blockLength, 1), Math.max(returns.length, 1));
  const p = 1 / blockLength; // probability of ending a block
  const random = mulberry32(config.seed);
  const startingBalance = config.startingBalance ?? 0;

  const pathEquity: number[][] = [];
  const terminals: number[] = [];
  const drawdowns: number[] = [];

  for (let path = 0; path < paths; path += 1) {
    // Build a resampled series of length n using the stationary scheme: each
    // position is either the previous resampled index (with prob 1-p) or a
    // fresh uniform draw (with prob p).
    const n = returns.length;
    const idxs: number[] = [Math.floor(random() * n)];
    for (let i = 1; i < n; i += 1) {
      if (random() < p) {
        idxs.push(Math.floor(random() * n));
      } else {
        idxs.push((idxs[i - 1] + 1) % n);
      }
    }
    let equity = startingBalance;
    const series: number[] = [];
    let peak = startingBalance;
    let maxDrawdown = 0;
    for (let i = 0; i < n; i += 1) {
      equity += returns[idxs[i]];
      series.push(equity);
      peak = Math.max(peak, equity);
      maxDrawdown = Math.max(maxDrawdown, peak - equity);
    }
    pathEquity.push(series);
    terminals.push(equity);
    drawdowns.push(maxDrawdown);
  }

  const sorted = terminals.slice().sort((a, b) => a - b);
  const sortedDrawdowns = drawdowns.slice().sort((a, b) => a - b);
  const positivePaths = terminals.filter((v) => v > startingBalance).length;

  return {
    config,
    terminals,
    paths: pathEquity,
    p5: percentileSorted(sorted, 0.05),
    p50: percentileSorted(sorted, 0.5),
    p95: percentileSorted(sorted, 0.95),
    positivePaths,
    positivePathsPct: positivePaths / paths,
    riskOfRuinPct:
      percentileSorted(sorted, 0.05) < startingBalance
        ? (terminals.filter((v) => v < startingBalance).length / terminals.length) * 100
        : 0,
    drawdownPercentiles: {
      p50: percentileSorted(sortedDrawdowns, 0.5),
      p95: percentileSorted(sortedDrawdowns, 0.95),
    },
  };
}

// ── 2. Walk-forward ─────────────────────────────────────────────────

export function walkForward(
  returns: number[],
  opts: { folds?: number; minFoldSize?: number; tradesPerYear?: number } = {},
): WalkForwardResult {
  const folds = Math.min(Math.max(Math.floor(opts.folds ?? 5), 2), 20);
  const minFoldSize = Math.max(Math.floor(opts.minFoldSize ?? 8), 2);
  const tpy = Math.max(opts.tradesPerYear ?? 252, 1);
  if (returns.length < folds * minFoldSize) {
    // Degrade gracefully — return an "unstable" verdict with empty folds
    // instead of throwing. The caller (buildOverfitReport) checks and skips
    // this when the series is too short.
    return {
      folds: [],
      meanIsSharpe: 0,
      meanOosSharpe: 0,
      meanDegradation: 0,
      oosPositivePct: 0,
      verdict: 'unstable',
    };
  }
  // Time-ordered, contiguous, non-overlapping windows. IS = everything before the
  // fold, OOS = the fold itself. (Anchored walk-forward, the form most platforms report.)
  const foldSize = Math.floor(returns.length / folds);
  const out: WalkForwardFold[] = [];
  let isSharpeSum = 0;
  let oosSharpeSum = 0;
  let oosPositiveCount = 0;
  let degradationSum = 0;
  let degradationCount = 0;
  // The first fold has no IS, so we start at fold index 1.
  for (let i = 1; i < folds; i += 1) {
    const isStart = 0;
    const isEnd = i * foldSize;
    const oosStart = isEnd;
    const oosEnd = i === folds - 1 ? returns.length : (i + 1) * foldSize;
    const isReturns = returns.slice(isStart, isEnd);
    const oosReturns = returns.slice(oosStart, oosEnd);
    const isSharpe = tradeSharpe(isReturns) * Math.sqrt(tpy);
    const oosSharpe = tradeSharpe(oosReturns) * Math.sqrt(tpy);
    const isMean = mean(isReturns);
    const oosMean = mean(oosReturns);
    const degradation = isSharpe > 0 ? oosSharpe / isSharpe : (oosSharpe > 0 ? Infinity : 0);
    const oosPositive = oosMean > 0;
    out.push({
      isRange: [isStart, isEnd],
      oosRange: [oosStart, oosEnd],
      isSharpe: Number.isFinite(isSharpe) ? isSharpe : 0,
      oosSharpe: Number.isFinite(oosSharpe) ? oosSharpe : 0,
      isMean,
      oosMean,
      degradation: Number.isFinite(degradation) ? degradation : 0,
      oosPositive,
    });
    isSharpeSum += isSharpe;
    oosSharpeSum += oosSharpe;
    if (oosPositive) oosPositiveCount += 1;
    if (Number.isFinite(degradation) && degradation > 0) {
      degradationSum += degradation;
      degradationCount += 1;
    }
  }
  const foldCount = Math.max(out.length, 1);
  const meanIsSharpe = isSharpeSum / foldCount;
  const meanOosSharpe = oosSharpeSum / foldCount;
  const meanDegradation = degradationCount > 0 ? degradationSum / degradationCount : 0;
  const oosPositivePct = oosPositiveCount / foldCount;
  let verdict: WalkForwardResult['verdict'];
  if (oosPositivePct >= 0.7 && meanOosSharpe > 0 && meanDegradation >= 0.6) verdict = 'stable';
  else if (oosPositivePct >= 0.5 && meanOosSharpe > 0) verdict = 'decaying';
  else verdict = 'unstable';
  return {
    folds: out,
    meanIsSharpe,
    meanOosSharpe,
    meanDegradation,
    oosPositivePct,
    verdict,
  };
}

// ── 3. Purged K-fold (López de Prado, AFML §7) ──────────────────────

export function purgedKFold(
  returns: number[],
  opts: { folds?: number; purge?: number; embargo?: number; tradesPerYear?: number } = {},
): PurgedKFoldResult {
  const folds = Math.min(Math.max(Math.floor(opts.folds ?? 5), 2), 10);
  const purge = Math.max(Math.floor(opts.purge ?? Math.max(Math.round(returns.length * 0.01), 1)), 0);
  const embargo = Math.max(Math.floor(opts.embargo ?? purge), 0);
  const tpy = Math.max(opts.tradesPerYear ?? 252, 1);
  const n = returns.length;
  if (n < folds * 6) {
    // Degrade gracefully — return empty folds instead of throwing.
    return {
      nFolds: folds,
      purge,
      embargo,
      folds: [],
      meanIsSharpe: 0,
      meanOosSharpe: 0,
      oosPositivePct: 0,
    };
  }
  // Boundaries for K contiguous folds.
  const bounds: Array<[number, number]> = [];
  const foldSize = Math.floor(n / folds);
  for (let k = 0; k < folds; k += 1) {
    const start = k * foldSize;
    const end = k === folds - 1 ? n : (k + 1) * foldSize;
    bounds.push([start, end]);
  }
  const foldResults: PurgedKFoldResult['folds'] = [];
  let isSharpeSum = 0;
  let oosSharpeSum = 0;
  let oosPositiveCount = 0;
  for (let k = 0; k < folds; k += 1) {
    const [testStart, testEnd] = bounds[k];
    // IS = all trades except [testStart - purge, testEnd + embargo]
    const purgeStart = Math.max(0, testStart - purge);
    const purgeEnd = Math.min(n, testEnd + embargo);
    const isReturns = returns
      .map((r, i) => (i >= purgeStart && i < purgeEnd ? null : r))
      .filter((r): r is number => r !== null);
    const oosReturns = returns.slice(testStart, testEnd);
    if (isReturns.length < 2 || oosReturns.length < 2) continue;
    const isSharpe = tradeSharpe(isReturns) * Math.sqrt(tpy);
    const oosSharpe = tradeSharpe(oosReturns) * Math.sqrt(tpy);
    const degradation = isSharpe > 0 ? oosSharpe / isSharpe : (oosSharpe > 0 ? Infinity : 0);
    const oosPositive = mean(oosReturns) > 0;
    foldResults.push({
      isSharpe: Number.isFinite(isSharpe) ? isSharpe : 0,
      oosSharpe: Number.isFinite(oosSharpe) ? oosSharpe : 0,
      degradation: Number.isFinite(degradation) ? degradation : 0,
      oosPositive,
    });
    isSharpeSum += isSharpe;
    oosSharpeSum += oosSharpe;
    if (oosPositive) oosPositiveCount += 1;
  }
  const fc = Math.max(foldResults.length, 1);
  return {
    nFolds: folds,
    purge,
    embargo,
    folds: foldResults,
    meanIsSharpe: isSharpeSum / fc,
    meanOosSharpe: oosSharpeSum / fc,
    oosPositivePct: oosPositiveCount / fc,
  };
}

// ── 4. Deflated Sharpe Ratio (Bailey & López de Prado 2014) ────────

export function deflatedSharpeRatio(input: DeflatedSharpeInput): DeflatedSharpeResult {
  const { sharpe, years, skew, kurtosis, trials } = input;
  const N = Math.max(Math.floor(trials), 1);
  const T = Math.max(years, 1e-6);
  // Variance of the Sharpe estimator (annualized). From BLPZ:
  //   V[SR] = (1 - skew*SR + (kurtosis-1)/4 * SR^2) / (T - 1)
  // where SR is the annualized observed Sharpe.
  const v = (1 - skew * sharpe + ((kurtosis - 1) / 4) * sharpe * sharpe) / Math.max(T - 1, 1e-6);
  const stdSR = Math.sqrt(Math.max(v, 1e-12));
  // Expected maximum Sharpe under H0: SR = 0 over N independent trials.
  // E[max] ≈ stdSR * ((1-γ_skew) * z + (γ_skew/6) * (z^2 - 1))
  // where z = Φ⁻¹(1 - 1/N) and γ_skew is the return skew (not the SR estimator's).
  // For N = 1 there is no selection bias, so E[max] = 0 and DSR = P(SR > 0) under H0.
  let eMax = 0;
  if (N > 1) {
    const z = inverseNormalCdf(1 - 1 / N);
    if (Number.isFinite(z)) {
      const term = (1 - skew) * z + (skew / 6) * (z * z - 1);
      eMax = Number.isFinite(term) ? stdSR * term : 0;
    }
  }
  // DSR = P(SR > 0 | observed, under H0 the true SR is 0 and the estimator is
  // normal with mean = E[max] and std = stdSR).
  const dsr = normalCdf((sharpe - eMax) / stdSR);
  const sr0 = eMax;
  let verdict: DeflatedSharpeResult['verdict'];
  if (dsr >= 0.95) verdict = 'credible';
  else if (dsr >= 0.8) verdict = 'marginal';
  else verdict = 'inflated';
  return {
    dsr: Math.min(Math.max(dsr, 0), 1),
    sr0,
    trials: N,
    verdict,
  };
}

// ── 5. Probability of Backtest Overfitting (CSCV, BLPZ 2017) ───────

/** Compute PBO from a matrix of per-period returns.
 *
 *  `matrix[r][t]` is the per-period return of strategy r in period t.
 *  Standard CSCV: split each strategy row at the midpoint into IS (first half)
 *  and OOS (second half); for every (i, j) pair of strategies, record whether
 *  the strategy with the higher IS rank also has an above-median OOS rank. PBO
 *  is the frequency of the best-IS strategy ranking below the median OOS. */
export function probabilityOfBacktestOverfitting(matrix: number[][]): PBOResult {
  const nStrategies = matrix.length;
  if (nStrategies < 2) {
    return { pbo: 0, nStrategies, nSplits: 0, verdict: 'not overfit' };
  }
  const T = matrix[0].length;
  if (T < 4) {
    return { pbo: 0, nStrategies, nSplits: 0, verdict: 'not overfit' };
  }
  // Single midpoint split (the canonical CSCV). The full combinatorial version
  // (CPCV) is more expensive; this is the published PBO estimator.
  const cut = Math.floor(T / 2);
  const isRets = matrix.map((row) => row.slice(0, cut));
  const oosRets = matrix.map((row) => row.slice(cut));
  // Rank strategies by IS mean return (ascending: rank 0 = worst).
  const isMean = isRets.map(mean);
  const isOrder = isMean
    .map((v, i) => ({ v, i }))
    .sort((a, b) => a.v - b.v)
    .map((o) => o.i);
  // Best IS strategy = last in isOrder.
  const bestIs = isOrder[isOrder.length - 1];
  // OOS ranks: rank the OOS mean of every strategy.
  const oosMean = oosRets.map(mean);
  const oosOrder = oosMean
    .map((v, i) => ({ v, i }))
    .sort((a, b) => a.v - b.v)
    .map((o) => o.i);
  const oosRank = new Array(nStrategies);
  oosOrder.forEach((idx, rank) => { oosRank[idx] = rank; });
  // PBO = frequency the best-IS strategy ranks below the OOS median.
  // With a single split we get one 0/1 observation; the canonical form repeats
  // across combinatorial splits. To keep the function a single evaluation we
  // report the single-split result and also an aggregate over all (i, j) pair
  // sign checks for stability when N is small.
  const medianRank = (nStrategies - 1) / 2;
  let belowMedian = 0;
  let comparisons = 0;
  for (let i = 0; i < nStrategies; i += 1) {
    for (let j = i + 1; j < nStrategies; j += 1) {
      // For each pair, take the one with higher IS mean and check its OOS rank.
      const iIsBetter = isMean[i] >= isMean[j];
      const winner = iIsBetter ? i : j;
      if (oosRank[winner] < medianRank) belowMedian += 1;
      comparisons += 1;
    }
  }
  // The single-split "best IS" check is the published PBO; we use the pair-aggregate
  // which is its consistent estimator over the same split.
  const pbo = comparisons > 0 ? belowMedian / comparisons : 0;
  let verdict: PBOResult['verdict'];
  if (pbo < 0.1) verdict = 'not overfit';
  else if (pbo < 0.25) verdict = 'suspect';
  else verdict = 'overfit';
  return { pbo, nStrategies, nSplits: 1, verdict };
}

// ── Combined report ────────────────────────────────────────────────

export interface BuildOverfitReportOptions {
  paths?: number;
  seed?: number;
  folds?: number;
  /** Sample length in years. Defaults to count / tradesPerYear. */
  years?: number;
  /** Annualization factor. Defaults to 252 (daily). */
  tradesPerYear?: number;
  /** Number of independent backtests considered (for DSR). Default 1. */
  trials?: number;
  /** Per-period return matrix for N parameter combinations (for PBO). Optional. */
  pboMatrix?: number[][];
}

export function buildOverfitReport(
  returns: number[],
  metrics: {
    sharpe: number;
    skewness: number;
    kurtosis: number;
    count: number;
    tradesPerYear: number;
  },
  opts: BuildOverfitReportOptions = {},
): OverfitReport {
  if (returns.length < 10) {
    throw new Error('Need at least 10 trades to run overfit checks (walk-forward, purged CV, DSR).');
  }
  const tpy = Math.max(opts.tradesPerYear ?? metrics.tradesPerYear ?? 252, 1);
  const years = opts.years ?? metrics.count / tpy;
  const trials = Math.max(opts.trials ?? 1, 1);
  const seed = opts.seed ?? 0x5eeded;
  const paths = Math.min(Math.max(Math.floor(opts.paths ?? 1000), 50), 5000);
  // Auto-scale folds to the trade count so the checks work on short logs (even
  // 10 trades). Walk-forward needs folds × minFoldSize; purged K-fold needs
  // folds × 6. We reduce minFoldSize to 4 for small samples so 2-fold WF needs
  // only 8 trades. For < 8 trades, skip WF + purged K-fold and report DSR +
  // stationary bootstrap only — honestly, not by throwing.
  const WF_MIN_FOLD = 4;
  const PKF_MIN_FOLD = 3;
  const maxFoldsByCount = Math.max(2, Math.floor(returns.length / WF_MIN_FOLD));
  const requestedFolds = Math.min(Math.max(Math.floor(opts.folds ?? 5), 2), 10);
  const folds = Math.min(requestedFolds, maxFoldsByCount);
  const canWalkForward = returns.length >= folds * WF_MIN_FOLD;
  const canPurge = returns.length >= folds * PKF_MIN_FOLD;

  const wf = canWalkForward
    ? walkForward(returns, { folds, tradesPerYear: tpy, minFoldSize: WF_MIN_FOLD })
    : { folds: [], meanIsSharpe: 0, meanOosSharpe: 0, meanDegradation: 0, oosPositivePct: 0, verdict: 'unstable' as const };
  const pkf = canPurge
    ? purgedKFold(returns, { folds, tradesPerYear: tpy })
    : { nFolds: folds, purge: 0, embargo: 0, folds: [], meanIsSharpe: 0, meanOosSharpe: 0, oosPositivePct: 0 };
  const dsr = deflatedSharpeRatio({
    sharpe: metrics.sharpe,
    years,
    skew: metrics.skewness,
    kurtosis: metrics.kurtosis,
    trials,
  });
  let pbo: PBOResult | null = null;
  if (opts.pboMatrix && opts.pboMatrix.length >= 2 && opts.pboMatrix[0].length >= 4) {
    pbo = probabilityOfBacktestOverfitting(opts.pboMatrix);
  }
  const sb = runStationaryBootstrap(returns, {
    paths,
    blockLength: autoBlockSize(returns),
    seed,
  });

  const lines: string[] = [];
  lines.push(`Walk-forward (${folds} folds${folds < requestedFolds ? `, auto-reduced from ${requestedFolds} for ${returns.length} trades` : ''}): mean IS SR ${wf.meanIsSharpe.toFixed(2)} → OOS SR ${wf.meanOosSharpe.toFixed(2)} (${(wf.oosPositivePct * 100).toFixed(0)}% of folds positive OOS), verdict: ${wf.verdict}.`);
  lines.push(`Purged K-fold (purge ${pkf.purge}, embargo ${pkf.embargo}): mean IS SR ${pkf.meanIsSharpe.toFixed(2)} → OOS SR ${pkf.meanOosSharpe.toFixed(2)}, ${(pkf.oosPositivePct * 100).toFixed(0)}% of folds positive OOS.`);
  lines.push(`Deflated Sharpe: observed ${metrics.sharpe.toFixed(2)}, threshold ${dsr.sr0.toFixed(2)} (N=${trials}), DSR ${(dsr.dsr * 100).toFixed(1)}% - verdict: ${dsr.verdict}.`);
  if (pbo) {
    lines.push(`PBO: ${(pbo.pbo * 100).toFixed(1)}% over ${pbo.nStrategies} strategies - verdict: ${pbo.verdict}.`);
  } else {
    lines.push('PBO: skipped (no parameter-scan matrix supplied - run optimize_lean first, then pass its results to run_pbo for a real overfit probability).');
  }
  lines.push(`Stationary bootstrap (block length ${sb.config.blockLength}): p5 ${sb.p5.toFixed(0)} · p50 ${sb.p50.toFixed(0)} · p95 ${sb.p95.toFixed(0)} · ${(sb.positivePathsPct * 100).toFixed(1)}% paths positive · DD p95 ${sb.drawdownPercentiles.p95.toFixed(0)}.`);

  // One-line verdict combines the three checks that need no extra input.
  let verdict: string;
  const oosOk = wf.oosPositivePct >= 0.5 && pkf.oosPositivePct >= 0.5 && dsr.dsr >= 0.8;
  const oosMarginal = wf.oosPositivePct >= 0.4 && pkf.oosPositivePct >= 0.4;
  if (pbo && pbo.pbo >= 0.25) {
    verdict = `Overfit - PBO ${(pbo.pbo * 100).toFixed(0)}%; the in-sample edge does not survive out of sample.`;
  } else if (!oosOk && !oosMarginal) {
    verdict = `Unstable - ${wf.verdict} walk-forward, DSR ${(dsr.dsr * 100).toFixed(0)}%; treat the in-sample edge as luck.`;
  } else if (oosOk) {
    verdict = `Credible - ${wf.verdict} walk-forward, DSR ${(dsr.dsr * 100).toFixed(0)}%${pbo ? `, PBO ${(pbo.pbo * 100).toFixed(0)}%` : ''}; the edge survives out of sample.`;
  } else {
    verdict = `Marginal - ${wf.verdict} walk-forward, DSR ${(dsr.dsr * 100).toFixed(0)}%; the edge thins out of sample.`;
  }

  return {
    walkForward: wf,
    purgedKFold: pkf,
    deflatedSharpe: dsr,
    pbo,
    stationaryBootstrap: sb,
    summary: lines.join('\n'),
    verdict,
  };
}
