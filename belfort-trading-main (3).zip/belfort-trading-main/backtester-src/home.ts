/* =====================================================================
   Belfort Trading — homepage driver (TypeScript)
   =====================================================================
   Replaces the scraped Next.js chunks. Imports the pure backtester engine,
   runs a real backtest on the sample log, and renders colourful Plotly
   charts (Monte Carlo bands, a 3D equity surface, a prop-firm pass donut)
   plus a GSAP-driven hero entrance. Plotly and GSAP are loaded as globals
   (vendored in js/vendor/), the same way the Strategy Validator loads them.
   ===================================================================== */

declare const Plotly: any;
declare const gsap: any;

import { buildTradeLog, computeMetrics, runMonteCarlo, runPropFirmSimulation, PROP_FIRM_PRESETS, SAMPLE_TRADE_LOG } from './engine';

// ── tiny helpers ────────────────────────────────────────────────────
function fmt(v: number, dec = 0, prefix = ''): string {
  const s = Math.abs(v).toFixed(dec).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return (v < 0 ? '−' : prefix) + s;
}
function pct(v: number, dec: number | null = 1): string {
  return (v * 100).toFixed(dec == null ? 1 : dec) + '%';
}
function setText(sel: string, value: string): void {
  document.querySelectorAll(sel).forEach((el) => { (el as HTMLElement).textContent = value; });
}
function gradeColor(g: string): string {
  return g === 'A' ? '#34d399' : g === 'B' ? '#a3e635' : g === 'C' ? '#fbbf24' : g === 'D' ? '#fb923c' : '#fb7185';
}

// ── Plotly theme (mirrors backtester-src/render.ts) ──────────────────
interface Theme { text: string; textSec: string; grid: string; gridSoft: string; blue: string; green: string; red: string; amber: string; accent: string; }
function theme(): Theme {
  const cs = getComputedStyle(document.documentElement);
  const raw = (n: string, fb: string) => cs.getPropertyValue(n).trim() || fb;
  const triplet = (n: string, fb: string) => `rgb(${raw(n, fb)})`;
  return {
    text: triplet('--color-text-primary', '242 242 242'),
    textSec: triplet('--color-text-secondary', '163 163 163'),
    grid: triplet('--color-border-primary', '34 34 34'),
    gridSoft: `rgba(${raw('--color-border-primary', '34 34 34').replace(/\s+/g, ',')},0.55)`,
    blue: '#7c83ff', green: '#34d399', red: '#fb7185', amber: '#fbbf24', accent: '#7c83ff',
  };
}
function baseLayout(t: Theme): Record<string, unknown> {
  return {
    paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, Archivo, system-ui, sans-serif', size: 12 },
    margin: { l: 48, r: 14, t: 10, b: 34 }, showlegend: false, hovermode: 'closest',
    hoverlabel: { bgcolor: '#0b1014', bordercolor: t.grid, font: { color: t.text, size: 12 } },
    xaxis: { gridcolor: t.gridSoft, zerolinecolor: t.grid, linecolor: t.gridSoft, tickfont: { color: t.textSec, size: 10 }, automargin: true },
    yaxis: { gridcolor: t.gridSoft, zerolinecolor: t.grid, linecolor: 'rgba(0,0,0,0)', tickfont: { color: t.textSec, size: 10 }, automargin: true },
  };
}
function sceneAxis(t: Theme, title: string): Record<string, unknown> {
  return { title: { text: title, font: { color: t.textSec, size: 10 } }, gridcolor: t.gridSoft, zerolinecolor: t.grid, showspikes: false, showbackground: true, backgroundcolor: 'rgba(0,0,0,0)', tickfont: { color: t.textSec, size: 10 } };
}
function plotInto(div: HTMLElement, data: unknown[], layout: Record<string, unknown>): void {
  if (typeof Plotly === 'undefined' || !Plotly || typeof Plotly.react !== 'function') {
    div.innerHTML = '<div class="plot-empty">Plotly failed to load. Check your connection and reload.</div>';
    return;
  }
  Plotly.react(div, data, layout, { displayModeBar: false, responsive: true });
}

// ── chart builders ──────────────────────────────────────────────────
// The "pass-rate Monte Carlo" from the backtester: each prop-firm sample
// run's equity path (green = pass, red = fail) with Start / Target / Max-DD
// lines and run endpoints. Mirrors renderPropSamplePaths in render.ts.
function propRunsData(t: Theme, pf: ReturnType<typeof runPropFirmSimulation>): { data: unknown[]; layout: Record<string, unknown> } {
  const runs = pf.sampleRuns || [];
  const data: unknown[] = [];
  const layout = baseLayout(t);
  if (!runs.length) return { data, layout };
  runs.forEach((run, i) => {
    data.push({
      x: run.equity.map((_, j) => j), y: run.equity, mode: 'lines',
      line: { color: run.outcome === 'pass' ? t.green : t.red, width: 1.6 }, opacity: 0.6, showlegend: false,
      hovertemplate: `Run ${i + 1} (${run.outcome.toUpperCase()}: ${run.reason})<br>Trade %{x}<br>Balance %{y:,.0f}<extra></extra>`,
    });
  });
  const maxX = Math.max(...runs.map((r) => r.equity.length));
  data.push({
    x: runs.map((r) => r.equity.length - 1), y: runs.map((r) => r.terminal), mode: 'markers',
    marker: { size: 8, color: runs.map((r) => (r.outcome === 'pass' ? t.green : t.red)), line: { color: '#0b1014', width: 1.5 } },
    hovertemplate: runs.map((r, i) => `Run ${i + 1} — ${r.outcome.toUpperCase()}<br>${r.reason}<br>Day ${r.days} · $${r.terminal.toFixed(0)}`),
    showlegend: false,
  });
  const targetLine = pf.config.accountSize + pf.config.profitTarget;
  const ddLimitLine = pf.config.accountSize - pf.config.maxTotalDrawdown;
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: { text: 'Trade #', font: { color: t.textSec, size: 10 } } },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: { text: 'Balance', font: { color: t.textSec, size: 10 } } },
    shapes: [
      { type: 'line', x0: 0, x1: maxX - 1, y0: pf.config.accountSize, y1: pf.config.accountSize, line: { color: t.textSec, width: 1, dash: 'dot' } },
      { type: 'line', x0: 0, x1: maxX - 1, y0: targetLine, y1: targetLine, line: { color: t.green, width: 1.5, dash: 'dash' } },
      { type: 'line', x0: 0, x1: maxX - 1, y0: ddLimitLine, y1: ddLimitLine, line: { color: t.red, width: 1.5, dash: 'dash' } },
    ],
    annotations: [
      { x: 0, y: pf.config.accountSize, text: 'Start', showarrow: false, yshift: 8, font: { color: t.textSec, size: 10 }, xanchor: 'left' },
      { x: 0, y: targetLine, text: 'Target', showarrow: false, yshift: 8, font: { color: t.green, size: 10 }, xanchor: 'left' },
      { x: 0, y: ddLimitLine, text: 'Max DD', showarrow: false, yshift: -10, font: { color: t.red, size: 10 }, xanchor: 'left' },
    ],
  });
  return { data, layout };
}

function surfaceData(t: Theme, paths0: number[][], n: number): { data: unknown[]; layout: Record<string, unknown> } {
  const sorted = paths0.slice().sort((a, b) => a[a.length - 1] - b[b.length - 1]);
  const limit = Math.min(sorted.length, 40);
  const z = sorted.slice(0, limit);
  const x = Array.from({ length: n + 1 }, (_, i) => i);
  const y = Array.from({ length: limit }, (_, i) => i);
  const data = [{
    type: 'surface', x, y, z,
    colorscale: [[0, t.red], [0.5, t.amber], [1, t.green]],
    showscale: false, opacity: 0.92,
    hovertemplate: 'Path %{y}<br>Trade %{x}<br>Equity %{z:,.0f}<extra></extra>',
  }];
  const layout = {
    paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, Archivo, system-ui, sans-serif', size: 11 },
    margin: { l: 0, r: 0, t: 0, b: 0 }, showlegend: false,
    scene: {
      xaxis: sceneAxis(t, 'Trade'), yaxis: sceneAxis(t, 'Path'), zaxis: sceneAxis(t, 'Equity'),
      camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } }, bgcolor: 'rgba(0,0,0,0)',
    },
  };
  return { data, layout };
}

function donutData(t: Theme, passCount: number, expired: number, breach: number, passPct: number): { data: unknown[]; layout: Record<string, unknown> } {
  const data = [{
    type: 'pie', hole: 0.62,
    labels: ['Passed', 'Period expired', 'Drawdown breach'],
    values: [passCount, expired, breach],
    marker: { colors: [t.green, t.amber, t.red] },
    textfont: { color: t.text, size: 11 },
    hovertemplate: '%{label}<br>%{value} (%{percent})<extra></extra>',
    sort: false, direction: 'clockwise', rotation: 90,
  }];
  const layout = {
    paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, Archivo, system-ui, sans-serif', size: 11 },
    margin: { l: 0, r: 0, t: 0, b: 0 }, showlegend: false,
    annotations: [{ text: `<b style="font-size:18px">${pct(passPct / 100, 0)}</b><br><span style="font-size:9px;color:${t.textSec}">PASS</span>`, showarrow: false, font: { color: t.text, family: 'IBM Plex Mono, monospace' } }],
  };
  return { data, layout };
}

// ── ambient background: a slow-rotating wireframe icosahedron ────────
function bgShape(): void {
  const cvEl = document.getElementById('bg-shape');
  if (!cvEl) return;
  const cv: HTMLCanvasElement = cvEl as HTMLCanvasElement;
  const ctx0 = cv.getContext('2d');
  if (!ctx0) return;
  const ctx: CanvasRenderingContext2D = ctx0;
  const reduce = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const phi = (1 + Math.sqrt(5)) / 2;
  const V: number[][] = [
    [0, 1, phi], [0, 1, -phi], [0, -1, phi], [0, -1, -phi],
    [1, phi, 0], [1, -phi, 0], [-1, phi, 0], [-1, -phi, 0],
    [phi, 0, 1], [phi, 0, -1], [-phi, 0, 1], [-phi, 0, -1],
  ];
  const E: number[][] = [];
  for (let i = 0; i < V.length; i += 1) {
    for (let j = i + 1; j < V.length; j += 1) {
      const d = Math.hypot(V[i][0] - V[j][0], V[i][1] - V[j][1], V[i][2] - V[j][2]);
      if (Math.abs(d - 2) < 1e-6) E.push([i, j]);
    }
  }
  let w = 0, h = 0;
  function resize(): void {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    w = cv.clientWidth; h = cv.clientHeight;
    cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  resize();
  window.addEventListener('resize', resize);
  let ay = 0;
  let scrollY = 0;
  window.addEventListener('scroll', () => { scrollY = window.scrollY || 0; }, { passive: true });
  function rot(p: number[], ayAng: number, axAng: number, cx: number, cyC: number, scale: number): { x: number; y: number; z: number } {
    const cy = Math.cos(ayAng), sy = Math.sin(ayAng);
    const x1 = p[0] * cy - p[2] * sy;
    const z1 = p[0] * sy + p[2] * cy;
    const cxr = Math.cos(axAng), sx = Math.sin(axAng);
    const y2 = p[1] * cxr - z1 * sx;
    const z2 = p[1] * sx + z1 * cxr;
    const persp = 6 / (6 - z2);
    return { x: cx + x1 * scale * persp, y: cyC + y2 * scale * persp, z: z2 };
  }
  function ico(cx: number, cyC: number, scale: number, ayAng: number, axAng: number, base: number, range: number): void {
    const P = V.map((v) => rot(v, ayAng, axAng, cx, cyC, scale));
    ctx.lineWidth = 1;
    for (const e of E) {
      const a = P[e[0]], b = P[e[1]];
      const dz = ((a.z + b.z) / 2 + 2) / 4;
      const al = Math.max(0.04, Math.min(base + range, base + range * dz));
      ctx.strokeStyle = `rgba(124,131,255,${al})`;
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    }
    for (const p of P) {
      const dz = (p.z + 2) / 4;
      const al = Math.max(0.06, Math.min(base + range + 0.05, base + range * dz + 0.05));
      ctx.fillStyle = `rgba(124,131,255,${al})`;
      ctx.beginPath(); ctx.arc(p.x, p.y, 1.6, 0, Math.PI * 2); ctx.fill();
    }
  }
  let t0 = performance.now();
  let raf = 0;
  function frame(now: number): void {
    const dt = Math.min(50, now - t0); t0 = now;
    if (!reduce) ay += dt * 0.00015;
    ctx.clearRect(0, 0, w, h);
    const cyC = h / 2 - scrollY * 0.04;
    // big — spans out to the sides, kept faint
    ico(w / 2, cyC, Math.max(w, h) * 0.45, ay, 0.35, 0.05, 0.10);
    // small — counter-rotating, sharper accent in the middle
    ico(w / 2, cyC, Math.min(w, h) * 0.26, -ay * 1.4 + 0.6, 0.5, 0.08, 0.14);
    raf = reduce ? 0 : requestAnimationFrame(frame);
  }
  raf = requestAnimationFrame(frame);
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { if (raf) { cancelAnimationFrame(raf); raf = 0; } }
    else if (!raf) { t0 = performance.now(); raf = requestAnimationFrame(frame); }
  });
}

// ── entrance ────────────────────────────────────────────────────────
function ready(fn: () => void): void {
  if (document.readyState !== 'loading') fn();
  else document.addEventListener('DOMContentLoaded', fn);
}

ready(() => {
  bgShape();
  const log = buildTradeLog(SAMPLE_TRADE_LOG);
  const m = computeMetrics(log);
  const mc = runMonteCarlo(m.returns, { paths: 1000, blockSize: 1, seed: 4060720449 }, 0);
  const pf = runPropFirmSimulation(log.trades, PROP_FIRM_PRESETS[0], { runs: 2000, seed: 20260820, strategyBaseline: 100000 });
  const n = m.count;

  // MC paths with a leading baseline 0 (engine omits it) so the 3D surface spans the full width.
  const paths0 = mc.paths.map((p) => [0].concat(p));

  let expiredCount = 0, breachCount = 0;
  (pf.failures || []).forEach((f) => { if (f.reason === 'Evaluation period expired') expiredCount += f.count; else breachCount += f.count; });
  const payout = pf.avgProfitAtPass ? pf.avgProfitAtPass * (pf.config.payoutPct / 100) : 0;
  const be = payout > 0 ? pf.config.challengeFee / payout : 0;

  // ── fill text nodes ───────────────────────────────────────────────
  setText('[data-m="count"]', String(n));
  setText('[data-m="net"]', fmt(m.netPnl, 0, '+'));
  setText('[data-m="pf"]', m.profitFactor.toFixed(2));
  setText('[data-m="maxdd"]', fmt(m.maxDrawdown));
  setText('[data-pf="avgt"]', pf.averageDaysToTarget != null ? pf.averageDaysToTarget.toFixed(1) : '—');
  setText('[data-pf="maxdd"]', fmt(pf.config.maxTotalDrawdown));
  setText('[data-pf="fee"]', 'fee ' + pf.config.challengeFee);
  setText('[data-pf="rate"]', pct(pf.passRatePct / 100, 0));
  setText('[data-pf="ev"]', (pf.expectedValue >= 0 ? '+' : '') + fmt(pf.expectedValue, 0));
  setText('[data-pf="be"]', pct(be));
  setText('[data-pf="pass"]', fmt(pf.passCount));
  setText('[data-pf="expired"]', fmt(expiredCount));
  setText('[data-pf="breach"]', fmt(breachCount));
  document.querySelectorAll('[data-pf="ev"]').forEach((el) => el.classList.add(pf.expectedValue >= 0 ? 'pos' : 'neg'));

  // grade
  setText('[data-grade] .g', m.grade);
  setText('[data-grade] .s', m.gradeScore + ' / 100');
  const gc = gradeColor(m.grade);
  document.querySelectorAll('[data-grade]').forEach((el) => { (el as HTMLElement).style.setProperty('--bar', gc); el.setAttribute('aria-label', 'Grade ' + m.grade + ', ' + m.gradeScore + ' of 100 — ' + m.gradeLabel); });

  // pillars
  const BLURB: Record<string, string> = {
    'Profitability': 'Expectancy, profit factor, payoff.',
    'Consistency': 'Monthly returns, win rate, streaks.',
    'Risk control': 'Drawdown depth, recovery, consecutive losses.',
    'Robustness': 'Survives resampling — Sharpe-like, R-expectancy.',
    'Sample size': 'More trades, more confidence.',
  };
  const PCOLOR = ['#34d399', '#7c83ff', '#fbbf24', '#fb923c', '#fb7185'];
  const ph = document.querySelector('[data-pillars]');
  if (ph) {
    ph.innerHTML = (m.gradeBreakdown || []).map((b, i) => {
      const w = (b.score / b.max) * 100;
      return `<div class="pillar rv" style="--i:${i};--bar:${PCOLOR[i % PCOLOR.length]}"><div class="label">${b.category}</div><div class="score">${b.score}<small> / ${b.max}</small></div><div class="bar"><i style="--w:${w}%"></i></div><p>${BLURB[b.category] || ''}</p></div>`;
    }).join('');
  }

  // ── render Plotly charts ─────────────────────────────────────────
  const hero3d = document.getElementById('hero-plot-3d') as HTMLDivElement;
  const heroMc = document.getElementById('hero-plot-mc') as HTMLDivElement;
  const heroPass = document.getElementById('hero-plot-pass') as HTMLDivElement;
  const stressMc = document.getElementById('stress-plot-mc') as HTMLDivElement;
  const stressPass = document.getElementById('stress-plot-pass') as HTMLDivElement;

  const renders: Array<() => void> = [];
  function renderAll(): void {
    const tt = theme();
    if (hero3d) { const d = surfaceData(tt, paths0, n); plotInto(hero3d, d.data, d.layout); }
    if (heroMc) { const d = propRunsData(tt, pf); plotInto(heroMc, d.data, d.layout); }
    if (heroPass) { const d = donutData(tt, pf.passCount, expiredCount, breachCount, pf.passRatePct); plotInto(heroPass, d.data, d.layout); }
    if (stressMc) { const d = propRunsData(tt, pf); plotInto(stressMc, d.data, d.layout); }
    if (stressPass) { const d = donutData(tt, pf.passCount, expiredCount, breachCount, pf.passRatePct); plotInto(stressPass, d.data, d.layout); }
  }
  renders.push(renderAll);
  renderAll();

  // ── hero tabs ─────────────────────────────────────────────────────
  const tabs = Array.from(document.querySelectorAll('.hero-tab')) as HTMLButtonElement[];
  const panels: Record<string, HTMLElement> = { '3d': hero3d, 'mc': heroMc, 'pass': heroPass };
  function showTab(name: string): void {
    tabs.forEach((b) => b.classList.toggle('on', b.dataset.htab === name));
    Object.keys(panels).forEach((k) => { if (panels[k]) (panels[k] as HTMLElement).hidden = k !== name; });
    const shown = panels[name];
    if (shown && typeof Plotly !== 'undefined') setTimeout(() => { try { Plotly.Plots.resize(shown); } catch { /* ignore */ } }, 30);
  }
  tabs.forEach((b) => b.addEventListener('click', () => showTab(b.dataset.htab || '3d')));
  showTab('3d');

  // ── hero counters (GSAP count-up) ─────────────────────────────────
  const COUNT: Record<string, { v: number; dec: number; prefix: string }> = {
    net: { v: m.netPnl, dec: 0, prefix: '+' }, pf: { v: m.profitFactor, dec: 2, prefix: '' }, maxdd: { v: m.maxDrawdown, dec: 0, prefix: '−' },
  };
  const counters = Array.from(document.querySelectorAll('[data-count]')) as HTMLElement[];
  counters.forEach((el) => { const c = COUNT[el.dataset.count || '']; if (c) el.textContent = fmt(0, c.dec, c.prefix); });
  if (typeof gsap !== 'undefined') {
    const state = { net: 0, pf: 0, maxdd: 0 };
    gsap.to(state, { net: COUNT.net.v, pf: COUNT.pf.v, maxdd: COUNT.maxdd.v, duration: 1.6, ease: 'power2.out', delay: 0.25,
      onUpdate: () => { counters.forEach((el) => { const c = COUNT[el.dataset.count || '']; if (c) el.textContent = fmt((state as any)[el.dataset.count!] * 1, c.dec, c.prefix); }); } });
  } else {
    counters.forEach((el) => { const c = COUNT[el.dataset.count || '']; if (c) el.textContent = fmt(c.v, c.dec, c.prefix); });
  }

  // ── reveal-on-scroll ─────────────────────────────────────────────
  const reveal = (el: Element): void => el.classList.add('in');
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((es) => {
      es.forEach((e) => { if (e.isIntersecting) { reveal(e.target); io.unobserve(e.target); } });
    }, { threshold: 0.15, rootMargin: '0px 0px -6% 0px' });
    document.querySelectorAll('.rv').forEach((el) => io.observe(el));
  } else {
    document.querySelectorAll('.rv').forEach(reveal);
  }

  // ── "Entry platform" CTA: workspace if signed in, sign-in otherwise ──
  const entryCta = document.getElementById('entry-cta');
  if (entryCta) {
    let authed = false;
    try { authed = !!localStorage.getItem('quantpad-authenticated'); } catch { /* ignore */ }
    entryCta.setAttribute('href', authed ? '/workspace/' : '/sign-up/');
  }

  // ── keep charts sized ────────────────────────────────────────────
  if ('ResizeObserver' in window && hero3d) {
    new ResizeObserver(() => { [hero3d, heroMc, heroPass, stressMc, stressPass].forEach((d) => { if (d && !d.hidden && typeof Plotly !== 'undefined') { try { Plotly.Plots.resize(d); } catch { /* ignore */ } } }); }).observe(hero3d);
  }
});
