import { Metrics, MonteCarloResult, PropFirmConfig, PropFirmResult, TradeDetail } from './types';
import { PROP_FIRM_PRESETS } from './propfirm';
import { armAutoplay, playAnimation, releaseAutoplay } from './animations';

declare const Plotly: any;

let lastData3D: ReportData | null = null;

export interface ReportData {
  log: { count: number; ignored: number; detected: string[]; derivedPnl: boolean; hasDates: boolean };
  metrics: Metrics;
  monteCarlo: MonteCarloResult;
  propFirm: PropFirmResult;
}

export interface DomRefs {
  csvInput: HTMLTextAreaElement;
  fileInput: HTMLInputElement;
  runButton: HTMLButtonElement;
  clearButton: HTMLButtonElement;
  sampleButton: HTMLButtonElement;
  status: HTMLParagraphElement;
  report: HTMLElement;
  mcPathsInput: HTMLInputElement;
  mcBlockInput: HTMLInputElement;
  mcSeedInput: HTMLInputElement;
  propPresetSelect: HTMLSelectElement;
  propFields: Record<string, HTMLInputElement>;
  tabs: HTMLElement;
  tabButtons: Record<string, HTMLButtonElement>;
  panels: Record<string, HTMLElement>;
  fanChart: HTMLDivElement;
  surfaceChart: HTMLDivElement;
  distributionChart: HTMLDivElement;
  tradeScatterChart: HTMLDivElement;
  equitySurfaceChart: HTMLDivElement;
  varChart: HTMLDivElement;
  rollingVarChart: HTMLDivElement;
  rollingDdChart: HTMLDivElement;
  riskScatterChart: HTMLDivElement;
  mcMaxDdChart: HTMLDivElement;
  mcRiskScatterChart: HTMLDivElement;
  mcPercentileChart: HTMLDivElement;
  sharpe3dChart: HTMLDivElement;
  sortino3dChart: HTMLDivElement;
  acf3dChart: HTMLDivElement;
  density3dChart: HTMLDivElement;
  calmar3dChart: HTMLDivElement;
  views3dDetail: HTMLDivElement;
  animateSelect: HTMLSelectElement;
  metricValue: (id: string, value: string) => void;
}

function element<K extends keyof HTMLElementTagNameMap>(
  tag: K,
  className?: string,
  text?: string
): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function number(value: number, digits = 2): string {
  return Number.isFinite(value) ? value.toLocaleString(undefined, { maximumFractionDigits: digits }) : '—';
}

function signed(value: number, digits = 2): string {
  if (!Number.isFinite(value)) return '—';
  return `${value >= 0 ? '+' : ''}${value.toLocaleString(undefined, { maximumFractionDigits: digits })}`;
}

function percent(value: number, digits = 1): string {
  return Number.isFinite(value) ? `${(value * 100).toFixed(digits)}%` : '—';
}

function toIsoDate(ms: number | null): string {
  if (ms === null || !Number.isFinite(ms)) return '—';
  const days = ms / 86_400_000;
  if (days >= 1) return `${days.toFixed(1)}d`;
  const hours = ms / 3_600_000;
  if (hours >= 1) return `${hours.toFixed(1)}h`;
  return `${(ms / 60_000).toFixed(0)}m`;
}

interface Theme {
  text: string;
  textSec: string;
  grid: string;
  gridSoft: string;
  blue: string;
  green: string;
  red: string;
  amber: string;
}

function theme(): Theme {
  const cs = getComputedStyle(document.documentElement);
  const raw = (name: string, fb: string) => cs.getPropertyValue(name).trim() || fb;
  const rgb = (name: string, fb: string) => `rgb(${raw(name, fb)})`;
  return {
    text: rgb('--color-text-primary', '229 231 235'),
    textSec: rgb('--color-text-secondary', '156 163 175'),
    grid: rgb('--color-border-primary', '31 41 55'),
    gridSoft: `rgba(${raw('--color-border-primary', '31 41 55').replace(/\s+/g, ',')},0.55)`,
    blue: '#7c83ff',
    green: '#34d399',
    red: '#fb7185',
    amber: '#fbbf24',
  };
}

function baseLayout(t: Theme): Record<string, unknown> {
  return {
    paper_bgcolor: 'rgba(0,0,0,0)',
    plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, system-ui, sans-serif', size: 12 },
    margin: { l: 52, r: 16, t: 12, b: 40 },
    showlegend: false,
    hovermode: 'closest',
    hoverlabel: { bgcolor: '#0b1014', bordercolor: t.grid, font: { color: t.text, size: 12 } },
    xaxis: {
      gridcolor: t.gridSoft,
      gridwidth: 1,
      zerolinecolor: t.grid,
      zerolinewidth: 1,
      linecolor: t.gridSoft,
      ticklen: 4,
      tickcolor: 'rgba(0,0,0,0)',
      automargin: true,
      tickfont: { color: t.textSec, size: 11 },
      title: { font: { color: t.textSec, size: 11 }, standoff: 10 },
    },
    yaxis: {
      gridcolor: t.gridSoft,
      gridwidth: 1,
      zerolinecolor: t.grid,
      zerolinewidth: 1,
      linecolor: 'rgba(0,0,0,0)',
      ticklen: 4,
      tickcolor: 'rgba(0,0,0,0)',
      automargin: true,
      tickfont: { color: t.textSec, size: 11 },
      title: { font: { color: t.textSec, size: 11 }, standoff: 12 },
    },
  };
}

function plotlyAvailable(): boolean {
  return typeof Plotly !== 'undefined' && Plotly && typeof Plotly.react === 'function';
}

function plotInto(div: HTMLDivElement, data: unknown[], layout: Record<string, unknown>): void {
  if (!plotlyAvailable()) {
    div.innerHTML = '';
    const note = element('div', 'plot-empty', 'Plotly failed to load from the CDN. Check your connection and reload.');
    div.appendChild(note);
    return;
  }
  Plotly.react(div, data, layout, { displayModeBar: false, responsive: true });
  armAutoplay(div);
}

function bindClick(div: HTMLDivElement, handler: (pt: PlotlyPoint) => void): void {
  if (!plotlyAvailable()) return;
  const plotDiv = div as unknown as { removeAllListeners?: (name: string) => void; on?: (name: string, fn: (e: PlotlyClickEvent) => void) => void };
  try {
    if (plotDiv.removeAllListeners) plotDiv.removeAllListeners('plotly_click');
  } catch {
    /* ignore */
  }
  if (plotDiv.on) {
    plotDiv.on('plotly_click', (event: PlotlyClickEvent) => {
      if (event && event.points && event.points.length) handler(event.points[0] as PlotlyPoint);
    });
  }
}

interface PlotlyPoint {
  curveNumber: number;
  pointNumber: number;
  x: number | string;
  y: number | string;
}
interface PlotlyClickEvent {
  points: PlotlyPoint[];
}

function detailPanel(id: string): HTMLDivElement {
  const d = element('div', 'path-detail', undefined) as HTMLDivElement;
  d.id = id;
  fillDetail(d, 'Click to inspect', [['Hint', 'Click any point or path on the chart above.']]);
  return d;
}

function fillDetail(panel: HTMLDivElement, title: string, rows: Array<[string, string]>): void {
  panel.textContent = '';
  panel.appendChild(element('div', 'path-detail-title', title));
  const grid = element('dl', 'path-detail-grid', undefined);
  for (const [key, value] of rows) {
    grid.appendChild(element('dt', undefined, key));
    grid.appendChild(element('dd', undefined, value));
  }
  panel.appendChild(grid);
}

function pct(sorted: number[], fraction: number): number {
  if (sorted.length === 0) return 0;
  const index = Math.min(sorted.length - 1, Math.floor(sorted.length * fraction));
  return sorted[index];
}

function varCvar(returns: number[], alpha: number): { varVal: number; cvar: number } {
  if (!returns.length) return { varVal: 0, cvar: 0 };
  const sorted = returns.slice().sort((a, b) => a - b);
  const idx = Math.max(0, Math.min(sorted.length - 1, Math.floor(sorted.length * alpha)));
  const varVal = -sorted[idx];
  const tail = sorted.slice(0, idx + 1);
  const cvar = tail.length ? -tail.reduce((a, b) => a + b, 0) / tail.length : varVal;
  return { varVal, cvar };
}

function payoutPerPassFor(propFirm: PropFirmResult): number {
  const profit = propFirm.avgProfitAtPass !== null ? propFirm.avgProfitAtPass : propFirm.config.profitTarget;
  return (profit * propFirm.config.payoutPct) / 100;
}

function playChart(div: HTMLDivElement): void {
  if (!plotlyAvailable()) return;
  playAnimation(div);
}

const CHART_INFO: Record<string, string> = {
  'equity-chart': 'Cumulative P&L over each trade. Dotted line = running peak. Markers are green (win) / red (loss). Click a marker for that trade’s detail.',
  'pnl-chart': 'Per-trade profit/loss as bars (green = win, red = loss). Click a bar for trade detail.',
  'pnl-vs-index-chart': 'Each trade’s P&L vs its number, with an OLS trend line. A flat/downward trend means the edge is decaying over time.',
  'returns-hist-chart': 'Histogram of per-trade P&L. Left tail (red) = losses, right (green) = wins. Shows the shape of your edge.',
  'underwater-chart': 'Drawdown from peak over time (red area). Deeper/longer = worse. A flat line near 0 = steadily making new highs.',
  'box-chart': 'Box plots of winning vs losing trades. The box = middle 50%, whiskers = range. Compare win size vs loss size.',
  'rolling-sharpe-chart': 'Rolling mean/std of returns (risk-adjusted return). Stable above 0 = consistent edge; dipping below 0 = trouble.',
  'rolling-chart': 'Rolling expectancy (left axis) and win rate (right axis) over a window. Shows if the strategy’s edge is stable or degrading.',
  'qq-chart': 'Q-Q plot vs a normal distribution. Points on the dashed line = normal returns. Fat tails = bigger wins/losses than normal predicts.',
  'monthly-heatmap-chart': 'Net P&L per calendar month (green = profit, red = loss). Reveals seasonality — which months carry or hurt the edge.',
  'cum-winrate-chart': 'Cumulative win rate over time. A line settling near your final win rate = stable; big swings = inconsistent edge.',
  'direction-chart': 'Total P&L split by long vs short trades. Shows which side carries the edge (or if one side is bleeding).',
  'dow-heatmap-chart': 'Net P&L by day-of-week × month. Reveals timing edges (e.g. strong Mondays, weak Fridays).',
  'weekly-heatmap-chart': 'Net P&L by week × weekday with a cold (loss) → hot (gain) scale. Spots recurring strong/weak days.',
  'acf-chart': 'Return autocorrelation at lags 1–12. Bars beyond the dashed band = significant clustering (momentum) or alternation (mean-reversion).',
  'duration-pnl-chart': 'Hold time (gap to next trade) vs P&L. If long holds are mostly losses, you’re letting losers run; if short holds are winners, you’re cutting winners early.',
  'loss-streaks-chart': 'Distribution of consecutive-loss run lengths. Long streaks = psychological & capital risk; size for the worst case.',
  'strategy-kelly-chart': 'Optimal risk-per-trade from your win rate & payoff (Kelly). Half/Quarter Kelly are safer in practice — full Kelly is volatile.',
  'monthly-bar-chart': 'P&L per month as bars. Quick view of which months are weak (red) so you can investigate seasonal causes.',
  'cum-wl-chart': 'Cumulative dollars from winners (green) and losers (red) separately. Shows if the edge is from many small wins or a few big ones.',
  'loss-recovery-chart': 'Trades to reach a new equity high after each drawdown. Short bars = resilient; tall bars = slow recovery (risk of giving up).',
  'direction-over-time-chart': 'Cumulative P&L of longs vs shorts over time. Diverging lines show which side is improving or degrading.',
  'mc-bands-chart': 'Monte Carlo equity percentile bands (p5–p95) across resampled paths. Wider band = more outcome uncertainty.',
  'mc-paths-chart': '24 sample Monte Carlo paths. Click a path for its terminal, max drawdown, and percentile rank.',
  'mc-dist-chart': 'Histogram of terminal equity across all paths, with p5 / median / p95 markers.',
  'mc-dd-dist-chart': 'Distribution of the worst drawdown each path endured. The right tail = worst-case drawdown risk.',
  'mc-sharpe-dist-chart': 'Distribution of per-path Sharpe-like ratios. A mass below 0 = many paths are unprofitable on a risk-adjusted basis.',
  'mc-calmar-dist-chart': 'Distribution of per-path Calmar (terminal / max drawdown). Higher = better return per unit of drawdown.',
  'mc-dd-duration-chart': 'How long paths stay underwater (below peak). Long durations = painful drawdowns even if they recover.',
  'mc-ror-chart': 'Probability the equity is below zero at each trade. Rising line = growing risk of ruin.',
  'mc-pop-chart': 'Probability the equity is above zero at each trade. Falling line = edge fading over the backtest.',
  'mc-cdf-chart': 'Cumulative distribution of terminal equity. Read off the percentile of any outcome (e.g. 50% of paths end below the median).',
  'mc-ttd-chart': 'Which trade index each path hits its max drawdown. A mass early = front-loaded risk.',
  'mc-underwater-chart': 'Average drawdown over time with a p5–p95 band. Shows when (not just if) drawdowns cluster.',
  'mc-extreme-chart': 'The single best and worst Monte Carlo paths vs the median. The gap = your best/worst plausible outcome.',
  'ev-waterfall-chart': 'Per-attempt expected value: payout (green) minus cost (red) = net EV. Hover each bar for its breakdown.',
  'avg-path-chart': 'Average sample-run balance over time with start / target / max-DD reference lines.',
  'prop-donut-chart': 'Share of simulated runs that passed vs failed the firm rules.',
  'prop-payout-donut-chart': 'Probability of getting a payout (pass) vs not. Center shows the pass %.',
  'prop-prob-chart': 'Probability of at least one pass as you attempt more accounts. Dashed line = 95%.',
  'prop-growth-chart': 'Expected cumulative net (your real money) over N account attempts, with a ±1σ band.',
  'prop-evpr-chart': 'EV per attempt across pass rates. Dashed = current pass rate; red = break-even pass rate (where EV = 0).',
  'prop-kelly-chart': 'Expected log-growth vs the fraction of fee risked. Peak = optimal (Kelly) fraction — betting more or less is sub-optimal.',
  'prop-ror-chart': 'Probability of losing every account as you attempt more (all fail). Decays toward 0 with more attempts.',
  'prop-payoff-chart': 'Payout per pass vs the challenge fee. The ratio = how many fees one payout covers.',
  'prop-pf-chart': 'Profit factor (expected payout / expected cost) across pass rates. Above 1 (dashed) = +EV.',
  'prop-runs-chart': 'Sample run equity paths (green = pass, red = fail) with start/target/max-DD lines. Click a path for its outcome detail.',
  'prop-terminal-chart': 'Distribution of run P&L, split pass (green) vs fail (red). Shows the spread of outcomes.',
  'prop-days-chart': 'How many days passing runs took to hit the target. Left = fast passers.',
  'prop-failures-chart': 'Count of each failure reason (daily loss / max DD / expired). Biggest bar = your main risk.',
  'fan-chart': '3D fan of Monte Carlo equity paths over time. Click a path for detail.',
  'surface-chart': '3D surface of drawdown across paths × trades. Peaks (red) = deepest drawdown zones.',
  'distribution-chart': '3D histogram of terminal outcomes across paths.',
  'trade-scatter-chart': '3D scatter of each trade: P&L vs gap-to-next, colored win/loss. Click a point for trade detail.',
  'equity-surface-chart': '3D surface of equity across paths × trades. Shows the full landscape of outcomes.',
  'var-chart': '3D histogram of trade returns with VaR-95 (amber) and VaR-99 (dark red) thresholds. Red tail = the worst 5%/1%.',
  'rolling-var-chart': 'Rolling 95% VaR across window sizes over time. Higher surface = worse tail risk in that window.',
  'rolling-dd-chart': 'Rolling max drawdown across window sizes. Peaks = where the deepest drawdowns cluster.',
  'risk-scatter-chart': '3D scatter of each trade’s P&L vs its drawdown-from-peak. Click for trade risk detail.',
  'mc-maxdd-chart': '3D histogram of max drawdown per Monte Carlo path. The right tail = worst-case drawdown.',
  'mc-risk-scatter-chart': '3D scatter of each path’s terminal equity vs its max drawdown. Click for path risk/return. Bottom-right = high-return, high-risk.',
  'mc-percentile-chart': '3D surface of equity percentiles (p5–p95) over time. The full risk envelope.',
  'sharpe3d-chart': 'Rolling Sharpe across window sizes over time. Stable green surface = consistent risk-adjusted edge.',
  'sortino3d-chart': 'Rolling Sortino (downside-only risk-adjusted) across windows. Penalizes only downside volatility.',
  'acf3d-chart': 'Autocorrelation across lags × window sizes. Reveals the serial structure of returns (trend vs reversal regime).',
  'density3d-chart': 'Where equity spends time: path-count per equity-bin per trade. Peaks = the most-likely equity range at each point.',
  'calmar3d-chart': 'Rolling Calmar (return / max drawdown) across windows. Higher = better return per unit of drawdown.',
};

function chartCard(
  title: string,
  chartId: string,
  variant: 'normal' | 'tall' | 'wide' = 'normal'
): { card: HTMLElement; div: HTMLDivElement } {
  const card = element('article', `bt-card chart-card${variant === 'wide' ? ' span-2' : ''}`, undefined);
  const head = element('div', 'card-head', undefined);
  head.appendChild(element('h3', undefined, title));
  const play = element('button', 'chart-play', '▶') as HTMLButtonElement;
  play.type = 'button';
  play.title = 'Play animation';
  play.setAttribute('aria-label', 'Play animation');
  const info = CHART_INFO[chartId];
  if (info) {
    const badge = element('span', 'chart-info', 'i');
    badge.appendChild(element('span', 'chart-info-tip', info));
    head.appendChild(badge);
  }
  head.appendChild(play);
  card.appendChild(head);
  const cls = variant === 'wide' ? 'plot-chart plot-wide' : variant === 'tall' ? 'plot-chart plot-tall' : 'plot-chart';
  const div = element('div', cls, undefined) as HTMLDivElement;
  div.id = chartId;
  card.appendChild(div);
  play.addEventListener('click', () => playChart(div));
  return { card, div };
}

function grid(): HTMLElement {
  return element('div', 'chart-grid', undefined);
}

function renderEquityChart(div: HTMLDivElement, metrics: Metrics, detail: HTMLDivElement): void {
  const t = theme();
  const x = metrics.equity.map((_, i) => i + 1);
  let runningPeak = 0;
  const peak = metrics.equity.map((v) => {
    runningPeak = Math.max(runningPeak, v);
    return runningPeak;
  });
  const markerColors = metrics.returns.map((v) => (v >= 0 ? t.green : t.red));
  let maxEquityIdx = 0;
  let maxEquity = -Infinity;
  metrics.equity.forEach((v, i) => {
    if (v > maxEquity) { maxEquity = v; maxEquityIdx = i; }
  });
  const data = [
    {
      x,
      y: peak,
      name: 'Peak',
      mode: 'lines',
      line: { color: t.grid, width: 1, dash: 'dot' },
      hovertemplate: 'Peak %{y:,.2f}<extra></extra>',
    },
    {
      x,
      y: metrics.equity,
      name: 'Equity',
      mode: 'lines+markers',
      line: { color: t.blue, width: 2.5, shape: 'linear' },
      marker: { color: markerColors, size: 5 },
      fill: 'tozeroy',
      fillcolor: 'rgba(124,131,255,0.14)',
      hovertemplate: 'Trade #%{x}<br>Equity %{y:,.2f}<extra></extra>',
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Trade #' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Equity' },
    shapes: [{ type: 'line', x0: 0, x1: x.length, y0: 0, y1: 0, line: { color: t.grid, width: 1 } }],
    annotations: [
      { x: maxEquityIdx + 1, y: maxEquity, xref: 'x', yref: 'y', text: 'peak', showarrow: true, arrowcolor: t.textSec, font: { color: t.textSec, size: 10 }, ay: -24 },
    ],
  });
  plotInto(div, data, layout);
  bindClick(div, (pt) => {
    const idx = pt.pointNumber;
    if (!Number.isInteger(idx) || idx < 0 || idx >= metrics.returns.length) return;
    const pnl = metrics.returns[idx];
    const eq = metrics.equity[idx];
    const dd = metrics.drawdownSeries[idx];
    fillDetail(detail, `Trade #${idx + 1}`, [
      ['P&L', signed(pnl)],
      ['Equity after', signed(eq)],
      ['Drawdown from peak', signed(dd)],
      ['Outcome', pnl > 0 ? 'Win' : pnl < 0 ? 'Loss' : 'Flat'],
      ['Progress', `${idx + 1} / ${metrics.returns.length}`],
    ]);
  });
}

function renderUnderwaterDrawdown(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const x = metrics.drawdownSeries.map((_, i) => i + 1);
  const data = [
    {
      x,
      y: metrics.drawdownSeries,
      type: 'scatter',
      mode: 'lines',
      line: { color: t.red, width: 1.8 },
      fill: 'tozeroy',
      fillcolor: 'rgba(251,113,133,0.22)',
      hovertemplate: 'Trade #%{x}<br>Drawdown %{y:,.2f}<extra></extra>',
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Trade #' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Drawdown' },
  });
  plotInto(div, data, layout);
}

function renderPnlBars(div: HTMLDivElement, metrics: Metrics, detail: HTMLDivElement): void {
  const t = theme();
  const x = metrics.returns.map((_, i) => i + 1);
  const colors = metrics.returns.map((v) => (v >= 0 ? t.green : t.red));
  const data = [
    {
      x,
      y: metrics.returns,
      type: 'bar',
      marker: { color: colors },
      hovertemplate: 'Trade #%{x}<br>P&L %{y:,.2f}<extra></extra>',
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Trade #' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'P&L' },
    bargap: 0.08,
  });
  plotInto(div, data, layout);
  bindClick(div, (pt) => {
    const idx = pt.pointNumber;
    if (!Number.isInteger(idx) || idx < 0 || idx >= metrics.returns.length) return;
    const pnl = metrics.returns[idx];
    const eq = metrics.equity[idx];
    const dd = metrics.drawdownSeries[idx];
    fillDetail(detail, `Trade #${idx + 1}`, [
      ['P&L', signed(pnl)],
      ['Equity after', signed(eq)],
      ['Drawdown from peak', signed(dd)],
      ['Outcome', pnl > 0 ? 'Win' : pnl < 0 ? 'Loss' : 'Flat'],
      ['Progress', `${idx + 1} / ${metrics.returns.length}`],
    ]);
  });
}

function renderMonteCarloBands(div: HTMLDivElement, mc: MonteCarloResult): void {
  const t = theme();
  const len = mc.paths[0]?.length || 0;
  if (!len) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const indices = Array.from({ length: len }, (_, i) => i + 1);
  const p5: number[] = [];
  const p25: number[] = [];
  const p50: number[] = [];
  const p75: number[] = [];
  const p95: number[] = [];
  for (let i = 0; i < len; i += 1) {
    const col = mc.paths.map((p) => p[i]).sort((a, b) => a - b);
    p5.push(pct(col, 0.05));
    p25.push(pct(col, 0.25));
    p50.push(pct(col, 0.5));
    p75.push(pct(col, 0.75));
    p95.push(pct(col, 0.95));
  }
  const data = [
    {
      x: indices, y: p95, name: 'p95', mode: 'lines',
      line: { color: t.green, width: 1 },
      hovertemplate: 'p95 %{y:,.2f}<extra></extra>',
    },
    {
      x: indices, y: p5, name: 'p5–p95', mode: 'lines',
      fill: 'tonexty', fillcolor: 'rgba(52,211,153,0.12)',
      line: { color: t.green, width: 1 },
      hovertemplate: 'p5 %{y:,.2f}<extra>p5–p95 band</extra>',
    },
    {
      x: indices, y: p75, name: 'p75', mode: 'lines',
      line: { color: t.blue, width: 1 },
      hovertemplate: 'p75 %{y:,.2f}<extra></extra>',
    },
    {
      x: indices, y: p25, name: 'p25–p75', mode: 'lines',
      fill: 'tonexty', fillcolor: 'rgba(124,131,255,0.20)',
      line: { color: t.blue, width: 1 },
      hovertemplate: 'p25 %{y:,.2f}<extra>p25–p75 band</extra>',
    },
    {
      x: indices, y: p50, name: 'Median', mode: 'lines',
      line: { color: t.text, width: 2.5 },
      hovertemplate: 'Median %{y:,.2f}<extra></extra>',
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Trade #' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Equity' },
    shapes: [
      { type: 'line', x0: 0, x1: len, y0: 0, y1: 0, line: { color: t.grid, width: 1 } },
    ],
  });
  plotInto(div, data, layout);
}

function renderMonteCarloPaths(
  div: HTMLDivElement,
  mc: MonteCarloResult,
  detail: HTMLDivElement
): void {
  const t = theme();
  const total = mc.paths.length;
  if (!total || !mc.paths[0]?.length) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const sampleCount = Math.min(24, total);
  const step = total / sampleCount;
  const sampled: Array<{ idx: number; path: number[] }> = [];
  const data: unknown[] = [];
  for (let i = 0; i < sampleCount; i += 1) {
    const idx = Math.min(total - 1, Math.round(i * step));
    const path = mc.paths[idx];
    sampled.push({ idx, path });
    const terminal = path[path.length - 1];
    data.push({
      x: path.map((_, j) => j + 1),
      y: path,
      mode: 'lines',
      line: { color: terminal >= 0 ? t.green : t.red, width: 1.6 },
      opacity: 0.6,
      hovertemplate: `Path ${idx + 1}<br>Trade %{x}<br>Equity %{y:,.2f}<extra></extra>`,
      name: `Path ${idx + 1}`,
    });
  }
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Trade #' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Equity' },
    shapes: [
      { type: 'line', x0: 0, x1: mc.paths[0].length, y0: 0, y1: 0, line: { color: t.grid, width: 1 } },
    ],
  });
  plotInto(div, data, layout);
  bindClick(div, (pt) => {
    const entry = sampled[pt.curveNumber];
    if (!entry) return;
    const path = entry.path;
    const terminal = path[path.length - 1];
    let peak = 0;
    let trough = 0;
    let runPeak = 0;
    let maxDd = 0;
    for (const v of path) {
      runPeak = Math.max(runPeak, v);
      maxDd = Math.max(maxDd, runPeak - v);
      peak = Math.max(peak, v);
      trough = Math.min(trough, v);
    }
    const rankBelow = mc.terminals.filter((value) => value <= terminal).length;
    const rankPct = (rankBelow / Math.max(mc.terminals.length, 1)) * 100;
    fillDetail(detail, `Monte Carlo path #${entry.idx + 1}`, [
      ['Terminal equity', signed(terminal)],
      ['Min equity', signed(trough)],
      ['Max equity', signed(peak)],
      ['Max drawdown', signed(-maxDd)],
      ['Rank (terminal)', `${rankPct.toFixed(0)}% at or below`],
      ['Outcome', terminal >= 0 ? 'Positive' : 'Negative'],
      ['Path length', `${path.length} trades`],
    ]);
  });
}

function renderTerminalDistribution(div: HTMLDivElement, mc: MonteCarloResult): void {
  const t = theme();
  if (!mc.terminals.length) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const data = [
    {
      x: mc.terminals,
      type: 'histogram',
      marker: { color: t.blue, line: { color: 'rgba(0,0,0,0)', width: 0 } },
      hovertemplate: 'Terminal %{x:,.2f}<br>Count %{y}<extra></extra>',
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Terminal equity' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Count' },
    shapes: [
      { type: 'line', x0: mc.p5, x1: mc.p5, y0: 0, y1: 1, yref: 'paper', line: { color: t.red, width: 1.5, dash: 'dash' } },
      { type: 'line', x0: mc.p50, x1: mc.p50, y0: 0, y1: 1, yref: 'paper', line: { color: t.text, width: 1.5 } },
      { type: 'line', x0: mc.p95, x1: mc.p95, y0: 0, y1: 1, yref: 'paper', line: { color: t.green, width: 1.5, dash: 'dash' } },
    ],
    annotations: [
      { x: mc.p5, y: 1, yref: 'paper', text: 'p5', showarrow: false, yshift: 10, font: { color: t.red, size: 10 } },
      { x: mc.p50, y: 1, yref: 'paper', text: 'median', showarrow: false, yshift: 10, font: { color: t.text, size: 10 } },
      { x: mc.p95, y: 1, yref: 'paper', text: 'p95', showarrow: false, yshift: 10, font: { color: t.green, size: 10 } },
    ],
  });
  plotInto(div, data, layout);
}

function mcPathStats(mc: MonteCarloResult): Array<{
  terminal: number; maxDd: number; min: number; max: number; sharpe: number; calmar: number; timeToDd: number; underwater: number;
}> {
  return mc.paths.map((path) => {
    let peak = 0;
    let maxDd = 0;
    let min = Infinity;
    let max = -Infinity;
    let maxDdIdx = 0;
    let underwater = 0;
    let curUnder = 0;
    for (let i = 0; i < path.length; i += 1) {
      const v = path[i];
      peak = Math.max(peak, v);
      min = Math.min(min, v);
      max = Math.max(max, v);
      const dd = peak - v;
      if (dd > maxDd) {
        maxDd = dd;
        maxDdIdx = i;
      }
      if (v < peak) {
        curUnder += 1;
        underwater = Math.max(underwater, curUnder);
      } else {
        curUnder = 0;
      }
    }
    const terminal = path[path.length - 1];
    let mean = 0;
    let variance = 0;
    if (path.length > 1) {
      const rets: number[] = [];
      for (let i = 1; i < path.length; i += 1) rets.push(path[i] - path[i - 1]);
      mean = rets.reduce((a, b) => a + b, 0) / rets.length;
      variance = rets.reduce((a, b) => a + (b - mean) ** 2, 0) / rets.length;
    }
    const std = Math.sqrt(variance);
    const sharpe = std > 0 ? mean / std : 0;
    const calmar = maxDd > 0 ? terminal / maxDd : terminal > 0 ? Infinity : 0;
    return { terminal, maxDd, min, max, sharpe, calmar, timeToDd: maxDdIdx, underwater };
  });
}

function renderMcDrawdownDistribution(div: HTMLDivElement, mc: MonteCarloResult): void {
  const t = theme();
  const stats = mcPathStats(mc);
  if (!stats.length) { plotInto(div, [], baseLayout(t)); return; }
  const data = [{ x: stats.map((s) => s.maxDd), type: 'histogram', marker: { color: t.red }, hovertemplate: 'Max DD %{x:,.2f}<br>Paths %{y}<extra></extra>' }];
  const layout = baseLayout(t);
  Object.assign(layout, { xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Max drawdown' }, yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Paths' } });
  plotInto(div, data, layout);
}

function renderMcRiskOfRuin(div: HTMLDivElement, mc: MonteCarloResult): void {
  const t = theme();
  const len = mc.paths[0]?.length || 0;
  if (!len) { plotInto(div, [], baseLayout(t)); return; }
  const x: number[] = [];
  const y: number[] = [];
  for (let i = 0; i < len; i += 1) {
    let below = 0;
    for (const p of mc.paths) if (p[i] < 0) below += 1;
    x.push(i + 1);
    y.push(below / mc.paths.length);
  }
  const data = [{ x, y, type: 'scatter', mode: 'lines', line: { color: t.red, width: 2.5 }, fill: 'tozeroy', fillcolor: 'rgba(251,113,133,0.15)', hovertemplate: 'Trade %{x}<br>Risk of ruin %{y:.1%}<extra></extra>' }];
  const layout = baseLayout(t);
  Object.assign(layout, { xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Trade #' }, yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'P(equity < 0)', range: [0, 1], tickformat: '.0%' } });
  plotInto(div, data, layout);
}

function renderMcProbOfProfit(div: HTMLDivElement, mc: MonteCarloResult): void {
  const t = theme();
  const len = mc.paths[0]?.length || 0;
  if (!len) { plotInto(div, [], baseLayout(t)); return; }
  const x: number[] = [];
  const y: number[] = [];
  for (let i = 0; i < len; i += 1) {
    let above = 0;
    for (const p of mc.paths) if (p[i] > 0) above += 1;
    x.push(i + 1);
    y.push(above / mc.paths.length);
  }
  const data = [{ x, y, type: 'scatter', mode: 'lines', line: { color: t.green, width: 2.5 }, fill: 'tozeroy', fillcolor: 'rgba(52,211,153,0.15)', hovertemplate: 'Trade %{x}<br>P(profit) %{y:.1%}<extra></extra>' }];
  const layout = baseLayout(t);
  Object.assign(layout, { xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Trade #' }, yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'P(equity > 0)', range: [0, 1], tickformat: '.0%' } });
  plotInto(div, data, layout);
}

function renderMcSharpeDistribution(div: HTMLDivElement, mc: MonteCarloResult): void {
  const t = theme();
  const stats = mcPathStats(mc).filter((s) => Number.isFinite(s.sharpe));
  if (!stats.length) { plotInto(div, [], baseLayout(t)); return; }
  const data = [{ x: stats.map((s) => s.sharpe), type: 'histogram', marker: { color: t.blue }, hovertemplate: 'Sharpe %{x:,.2f}<br>Paths %{y}<extra></extra>' }];
  const layout = baseLayout(t);
  Object.assign(layout, { xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Path Sharpe (mean / std)' }, yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Paths' } });
  plotInto(div, data, layout);
}

function renderMcTerminalCDF(div: HTMLDivElement, mc: MonteCarloResult): void {
  const t = theme();
  if (!mc.terminals.length) { plotInto(div, [], baseLayout(t)); return; }
  const sorted = mc.terminals.slice().sort((a, b) => a - b);
  const n = sorted.length;
  const x: number[] = [];
  const y: number[] = [];
  for (let i = 0; i < n; i += 1) {
    x.push(sorted[i]);
    y.push((i + 1) / n);
  }
  const data = [{ x, y, type: 'scatter', mode: 'lines', line: { color: t.blue, width: 2.5, shape: 'hv' }, hovertemplate: 'Terminal ≥ %{x:,.2f}<br>P %{y:.1%}<extra></extra>' }];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Terminal equity' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Cumulative probability', range: [0, 1], tickformat: '.0%' },
    shapes: [{ type: 'line', x0: 0, x1: 1, xref: 'paper', y0: 0.5, y1: 0.5, line: { color: t.grid, width: 1, dash: 'dot' } }],
    annotations: [{ x: 1, y: 0.5, xref: 'paper', yref: 'y', text: 'median', showarrow: false, xanchor: 'right', yshift: 8, font: { color: t.textSec, size: 10 } }],
  });
  plotInto(div, data, layout);
}

function renderMcUnderwaterEnvelope(div: HTMLDivElement, mc: MonteCarloResult): void {
  const t = theme();
  const len = mc.paths[0]?.length || 0;
  if (!len) { plotInto(div, [], baseLayout(t)); return; }
  const x = Array.from({ length: len }, (_, i) => i + 1);
  const cols: number[][] = [];
  for (let i = 0; i < len; i += 1) {
    const col = mc.paths.map((p) => {
      let peak = 0;
      let dd = 0;
      for (let j = 0; j <= i; j += 1) {
        peak = Math.max(peak, p[j]);
        dd = peak - p[j];
      }
      return dd;
    }).sort((a, b) => a - b);
    cols.push(col);
  }
  const avg = cols.map((c) => c.reduce((a, b) => a + b, 0) / c.length);
  const p95 = cols.map((c) => pct(c, 0.95));
  const p5 = cols.map((c) => pct(c, 0.05));
  const data = [
    { x, y: p95, type: 'scatter', mode: 'lines', line: { color: t.red, width: 1 }, hoverinfo: 'skip', showlegend: false },
    { x, y: p5, type: 'scatter', mode: 'lines', line: { color: t.red, width: 1 }, fill: 'tonexty', fillcolor: 'rgba(251,113,133,0.12)', hovertemplate: 'p95 DD %{y:,.2f}<extra></extra>', name: 'p5–p95 DD' },
    { x, y: avg, type: 'scatter', mode: 'lines', line: { color: t.amber, width: 2.5 }, hovertemplate: 'Trade %{x}<br>Avg DD %{y:,.2f}<extra></extra>', name: 'Avg drawdown' },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, { xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Trade #' }, yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Drawdown' } });
  plotInto(div, data, layout);
}

function renderMcDrawdownDuration(div: HTMLDivElement, mc: MonteCarloResult): void {
  const t = theme();
  const stats = mcPathStats(mc);
  if (!stats.length) { plotInto(div, [], baseLayout(t)); return; }
  const data = [{ x: stats.map((s) => s.underwater), type: 'histogram', marker: { color: t.amber }, hovertemplate: 'Underwater %{x} trades<br>Paths %{y}<extra></extra>' }];
  const layout = baseLayout(t);
  Object.assign(layout, { xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Max trades underwater' }, yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Paths' } });
  plotInto(div, data, layout);
}

function renderMcCalmarDistribution(div: HTMLDivElement, mc: MonteCarloResult): void {
  const t = theme();
  const stats = mcPathStats(mc).filter((s) => Number.isFinite(s.calmar));
  if (!stats.length) { plotInto(div, [], baseLayout(t)); return; }
  const data = [{ x: stats.map((s) => s.calmar), type: 'histogram', marker: { color: t.green }, hovertemplate: 'Calmar %{x:,.2f}<br>Paths %{y}<extra></extra>' }];
  const layout = baseLayout(t);
  Object.assign(layout, { xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Calmar (terminal / max DD)' }, yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Paths' } });
  plotInto(div, data, layout);
}

function renderMcExtremePaths(div: HTMLDivElement, mc: MonteCarloResult): void {
  const t = theme();
  if (!mc.paths.length) { plotInto(div, [], baseLayout(t)); return; }
  const len = mc.paths[0].length;
  const x = Array.from({ length: len }, (_, i) => i + 1);
  let worstIdx = 0;
  let bestIdx = 0;
  for (let i = 0; i < mc.paths.length; i += 1) {
    const term = mc.paths[i][len - 1];
    if (term < mc.paths[worstIdx][len - 1]) worstIdx = i;
    if (term > mc.paths[bestIdx][len - 1]) bestIdx = i;
  }
  const p50: number[] = [];
  for (let i = 0; i < len; i += 1) {
    const col = mc.paths.map((p) => p[i]).sort((a, b) => a - b);
    p50.push(pct(col, 0.5));
  }
  const data = [
    { x, y: mc.paths[bestIdx], type: 'scatter', mode: 'lines', line: { color: t.green, width: 2.5 }, hovertemplate: 'Best path #%{text}<extra></extra>', text: [String(bestIdx + 1)], name: 'Best' },
    { x, y: mc.paths[worstIdx], type: 'scatter', mode: 'lines', line: { color: t.red, width: 2.5 }, hovertemplate: 'Worst path #%{text}<extra></extra>', text: [String(worstIdx + 1)], name: 'Worst' },
    { x, y: p50, type: 'scatter', mode: 'lines', line: { color: t.textSec, width: 1.5, dash: 'dash' }, hovertemplate: 'Median %{y:,.2f}<extra></extra>', name: 'Median' },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, { xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Trade #' }, yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Equity' } });
  plotInto(div, data, layout);
}

function renderMcTimeToDrawdown(div: HTMLDivElement, mc: MonteCarloResult): void {
  const t = theme();
  const stats = mcPathStats(mc);
  if (!stats.length) { plotInto(div, [], baseLayout(t)); return; }
  const data = [{ x: stats.map((s) => s.timeToDd + 1), type: 'histogram', marker: { color: t.blue }, hovertemplate: 'Max DD at trade %{x}<br>Paths %{y}<extra></extra>' }];
  const layout = baseLayout(t);
  Object.assign(layout, { xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Trade # at max drawdown' }, yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Paths' } });
  plotInto(div, data, layout);
}

function renderPropDonut(div: HTMLDivElement, propFirm: PropFirmResult): void {
  const t = theme();
  const data = [
    {
      values: [propFirm.passRatePct, propFirm.failRatePct],
      labels: ['Pass', 'Fail'],
      type: 'pie',
      hole: 0.62,
      marker: { colors: [t.green, t.red], line: { color: 'rgba(0,0,0,0)', width: 0 } },
      textinfo: 'percent',
      textfont: { color: t.text, size: 13 },
      hovertemplate: '%{label}: %{value:.1f}%<extra></extra>',
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    annotations: [
      {
        text: `<b>${propFirm.passRatePct.toFixed(0)}%</b><br>pass`,
        showarrow: false,
        font: { color: t.text, size: 18 },
      },
    ],
    margin: { l: 18, r: 18, t: 18, b: 18 },
  });
  plotInto(div, data, layout);
}

function renderFailureBar(div: HTMLDivElement, propFirm: PropFirmResult): void {
  const t = theme();
  if (!propFirm.failures.length) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const data = [
    {
      x: propFirm.failures.map((f) => f.reason),
      y: propFirm.failures.map((f) => f.count),
      type: 'bar',
      marker: { color: t.red },
      hovertemplate: '%{x}<br>Count %{y}<extra></extra>',
      text: propFirm.failures.map((f) => `${(f.pct * 100).toFixed(0)}%`),
      textposition: 'outside',
      textfont: { color: t.textSec, size: 11 },
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: '', tickangle: -12 },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Count' },
    bargap: 0.25,
  });
  plotInto(div, data, layout);
}

function renderPropSamplePaths(
  div: HTMLDivElement,
  propFirm: PropFirmResult,
  detail: HTMLDivElement
): void {
  const t = theme();
  const runs = propFirm.sampleRuns || [];
  if (!runs.length) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const data: unknown[] = runs.map((run, i) => ({
    x: run.equity.map((_, j) => j),
    y: run.equity,
    mode: 'lines',
    line: { color: run.outcome === 'pass' ? t.green : t.red, width: 1.6 },
    opacity: 0.6,
    hovertemplate: `Run ${i + 1} (${run.outcome.toUpperCase()}: ${run.reason})<br>Trade %{x}<br>Balance %{y:,.2f}<extra></extra>`,
    name: `Run ${i + 1}`,
  }));
  const maxX = Math.max(...runs.map((r) => r.equity.length));
  data.push({
    x: runs.map((r) => r.equity.length - 1),
    y: runs.map((r) => r.terminal),
    mode: 'markers',
    marker: {
      size: 9,
      color: runs.map((r) => (r.outcome === 'pass' ? t.green : t.red)),
      line: { color: 'rgb(11,16,20)', width: 1.5 },
    },
    hovertemplate: runs.map((r, i) => `Run ${i + 1} — ${r.outcome.toUpperCase()}<br>${r.reason}<br>Day ${r.days} · $${r.terminal.toFixed(0)}`),
    name: 'Endpoints',
    showlegend: false,
  });
  const targetLine = propFirm.config.accountSize + propFirm.config.profitTarget;
  const ddLimitLine = propFirm.config.accountSize - propFirm.config.maxTotalDrawdown;
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Trade #' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Balance' },
    shapes: [
      { type: 'line', x0: 0, x1: maxX - 1, y0: propFirm.config.accountSize, y1: propFirm.config.accountSize, line: { color: t.textSec, width: 1, dash: 'dot' } },
      { type: 'line', x0: 0, x1: maxX - 1, y0: targetLine, y1: targetLine, line: { color: t.green, width: 1.5, dash: 'dash' } },
      { type: 'line', x0: 0, x1: maxX - 1, y0: ddLimitLine, y1: ddLimitLine, line: { color: t.red, width: 1.5, dash: 'dash' } },
    ],
    annotations: [
      { x: 0, y: propFirm.config.accountSize, text: 'Start', showarrow: false, yshift: 8, font: { color: t.textSec, size: 10 }, xanchor: 'left' },
      { x: 0, y: targetLine, text: 'Target', showarrow: false, yshift: 8, font: { color: t.green, size: 10 }, xanchor: 'left' },
      { x: 0, y: ddLimitLine, text: 'Max DD', showarrow: false, yshift: -10, font: { color: t.red, size: 10 }, xanchor: 'left' },
    ],
  });
  plotInto(div, data, layout);
  bindClick(div, (pt) => {
    const run = runs[pt.curveNumber];
    if (!run) return;
    const pnl = run.terminal - run.accountSize;
    const maxDd = run.peak - run.trough;
    fillDetail(detail, `Prop run #${pt.curveNumber + 1} — ${run.outcome === 'pass' ? 'PASSED' : 'FAILED'}`, [
      ['Outcome', run.outcome === 'pass' ? 'Passed' : 'Failed'],
      ['Reason', run.reason],
      ['Days', run.outcome === 'pass' ? `${run.days} to target` : `Failed on day ${run.days}`],
      ['P&L', signed(pnl)],
      ['Terminal balance', number(run.terminal, 2)],
      ['Peak balance', number(run.peak, 2)],
      ['Trough balance', number(run.trough, 2)],
      ['Max drawdown', signed(-maxDd)],
      ['Account', number(run.accountSize, 0)],
      ['Target', `${number(run.profitTarget, 0)} (+${percent(run.profitTarget / run.accountSize, 1)})`],
      ['Max DD limit', number(run.maxDrawdown, 0)],
    ]);
  });
}

function renderReturnHistogram(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const wins = metrics.returns.filter((v) => v >= 0);
  const losses = metrics.returns.filter((v) => v < 0);
  const data = [
    {
      x: wins, type: 'histogram', marker: { color: t.green }, opacity: 0.78,
      hovertemplate: 'Win %{x:,.2f}<br>Count %{y}<extra></extra>', name: 'Wins',
    },
    {
      x: losses, type: 'histogram', marker: { color: t.red }, opacity: 0.78,
      hovertemplate: 'Loss %{x:,.2f}<br>Count %{y}<extra></extra>', name: 'Losses',
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    barmode: 'overlay',
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Trade P&L' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Count' },
  });
  plotInto(div, data, layout);
}

function renderMonthlyHeatmap(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  if (!metrics.monthlyReturns.length) {
    plotInto(div, [], baseLayout(t));
    const note = element('div', 'plot-empty', 'No dates in this trade log — monthly returns heatmap needs dated trades.');
    div.appendChild(note);
    return;
  }
  const years = Array.from(new Set(metrics.monthlyReturns.map((m) => m.year))).sort((a, b) => a - b);
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const z: (number | null)[][] = years.map((year) =>
    Array.from({ length: 12 }, (_, month) => {
      const entry = metrics.monthlyReturns.find((m) => m.year === year && m.month === month);
      return entry ? entry.pnl : null;
    })
  );
  const data = [
    {
      type: 'heatmap',
      z,
      x: monthNames,
      y: years.map(String),
      colorscale: [
        [0, t.red],
        [0.5, '#11161c'],
        [1, t.green],
      ],
      zmid: 0,
      hovertemplate: '%{x} %{y}<br>P&L %{z:,.2f}<extra></extra>',
      showscale: false,
      xgap: 2,
      ygap: 2,
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    margin: { l: 50, r: 18, t: 10, b: 34 },
    xaxis: { gridcolor: 'rgba(0,0,0,0)', zerolinecolor: 'rgba(0,0,0,0)', tickfont: { color: t.textSec }, side: 'bottom' },
    yaxis: { gridcolor: 'rgba(0,0,0,0)', zerolinecolor: 'rgba(0,0,0,0)', tickfont: { color: t.textSec }, automargin: true },
  });
  plotInto(div, data, layout);
}

function renderRollingMetrics(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const r = metrics.returns;
  const window = Math.max(5, Math.floor(r.length / 4));
  if (r.length < window) {
    plotInto(div, [], baseLayout(t));
    const note = element('div', 'plot-empty', `Need at least ${window} trades for a rolling window of ${window}.`);
    div.appendChild(note);
    return;
  }
  const x: number[] = [];
  const exp: number[] = [];
  const wr: number[] = [];
  for (let i = window - 1; i < r.length; i += 1) {
    const slice = r.slice(i - window + 1, i + 1);
    const mean = slice.reduce((a, b) => a + b, 0) / slice.length;
    const wins = slice.filter((v) => v > 0).length;
    x.push(i + 1);
    exp.push(mean);
    wr.push(wins / slice.length);
  }
  const data = [
    {
      x, y: exp, type: 'scatter', mode: 'lines', line: { color: t.blue, width: 2 }, yaxis: 'y',
      hovertemplate: 'Trade #%{x}<br>Expectancy %{y:,.2f}<extra></extra>', name: 'Expectancy',
    },
    {
      x, y: wr, type: 'scatter', mode: 'lines', line: { color: t.amber, width: 2 }, yaxis: 'y2',
      hovertemplate: 'Trade #%{x}<br>Win rate %{y:.0%}<extra></extra>', name: 'Win rate',
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Trade #' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Expectancy' },
    yaxis2: {
      gridcolor: 'rgba(0,0,0,0)',
      zerolinecolor: 'rgba(0,0,0,0)',
      tickfont: { color: t.amber },
      title: { text: 'Win rate', font: { color: t.amber, size: 11 } },
      overlaying: 'y',
      side: 'right',
      range: [0, 1],
    },
  });
  plotInto(div, data, layout);
}

function renderTradingCalendar(container: HTMLElement, metrics: Metrics, detail: HTMLDivElement): void {
  container.textContent = '';
  if (!metrics.tradeDetails.length || !metrics.tradeDetails.some((t) => t.date)) {
    const note = element('div', 'plot-empty', 'No dates in this trade log — the trading calendar needs dated trades.');
    container.appendChild(note);
    return;
  }
  const byDay = new Map<string, { pnl: number; trades: TradeDetail[] }>();
  for (const t of metrics.tradeDetails) {
    if (!t.date) continue;
    const key = t.date.slice(0, 10);
    if (!byDay.has(key)) byDay.set(key, { pnl: 0, trades: [] });
    const entry = byDay.get(key)!;
    entry.pnl += t.pnl;
    entry.trades.push(t);
  }
  const months = new Map<string, Map<string, { pnl: number; trades: TradeDetail[] }>>();
  byDay.forEach((val, key) => {
    const monthKey = key.slice(0, 7);
    if (!months.has(monthKey)) months.set(monthKey, new Map());
    months.get(monthKey)!.set(key, val);
  });
  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  let maxAbs = 1;
  byDay.forEach((v) => {
    maxAbs = Math.max(maxAbs, Math.abs(v.pnl));
  });
  const sortedMonths = Array.from(months.keys()).sort();
  for (const monthKey of sortedMonths) {
    const [y, m] = monthKey.split('-').map(Number);
    const days = months.get(monthKey)!;
    let monthTotal = 0;
    days.forEach((v) => (monthTotal += v.pnl));
    const monthHeader = element('div', 'cal-month-header', undefined);
    monthHeader.appendChild(element('span', undefined, `${monthNames[m]} ${y}`));
    monthHeader.appendChild(element('span', `cal-month-total ${monthTotal >= 0 ? 'pos' : 'neg'}`, signed(monthTotal, 0)));
    container.appendChild(monthHeader);
    const grid = element('div', 'cal-grid', undefined);
    ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].forEach((d) =>
      grid.appendChild(element('div', 'cal-dow', d))
    );
    const firstDay = new Date(y, m, 1).getDay();
    const daysInMonth = new Date(y, m + 1, 0).getDate();
    for (let i = 0; i < firstDay; i += 1) grid.appendChild(element('div', 'cal-cell cal-empty', ''));
    for (let d = 1; d <= daysInMonth; d += 1) {
      const dateStr = `${monthKey}-${String(d).padStart(2, '0')}`;
      const entry = days.get(dateStr);
      const cell = element('div', 'cal-cell', undefined) as HTMLDivElement;
      if (entry) {
        cell.classList.add('cal-active');
        const intensity = Math.min(1, Math.abs(entry.pnl) / maxAbs);
        const color = entry.pnl >= 0 ? '52,211,153' : '251,113,133';
        cell.style.background = `rgba(${color}, ${(0.16 + intensity * 0.6).toFixed(3)})`;
        cell.appendChild(element('span', 'cal-day', String(d)));
        cell.appendChild(element('span', `cal-pnl ${entry.pnl >= 0 ? 'pos' : 'neg'}`, signed(entry.pnl, 0)));
        cell.title = `${dateStr}: ${signed(entry.pnl)} (${entry.trades.length} trade${entry.trades.length > 1 ? 's' : ''})`;
        cell.addEventListener('click', () => {
          const rows: Array<[string, string]> = [
            ['Date', dateStr],
            ['Day P&L', signed(entry.pnl)],
            ['Trades', String(entry.trades.length)],
          ];
          entry.trades.forEach((tr) => {
            rows.push([`#${tr.index} ${tr.direction}`, `${signed(tr.pnl)} → ${signed(tr.equity)}`]);
          });
          fillDetail(detail, `Trading day — ${dateStr}`, rows);
        });
      } else {
        cell.classList.add('cal-inactive');
        cell.appendChild(element('span', 'cal-day', String(d)));
      }
      grid.appendChild(cell);
    }
    container.appendChild(grid);
  }
}

function renderTradeLogTable(container: HTMLElement, metrics: Metrics): void {
  container.textContent = '';
  const wrap = element('div', 'trade-table-wrap', undefined);
  const table = element('table', 'backtest-table', undefined);
  const thead = element('thead', undefined, undefined);
  const headRow = element('tr', undefined, undefined);
  ['#', 'Date', 'Dir', 'Entry', 'Exit', 'Size', 'P&L', 'Equity', 'DD'].forEach((h) =>
    headRow.appendChild(element('th', undefined, h))
  );
  thead.appendChild(headRow);
  table.appendChild(thead);
  const tbody = element('tbody', undefined, undefined);
  for (const t of metrics.tradeDetails) {
    const row = element('tr', undefined, undefined);
    row.appendChild(element('td', undefined, String(t.index)));
    row.appendChild(element('td', undefined, t.date ? new Date(t.date).toLocaleDateString() : '—'));
    row.appendChild(element('td', `dir-${t.direction}`, t.direction));
    row.appendChild(element('td', undefined, t.entry !== null ? number(t.entry, 2) : '—'));
    row.appendChild(element('td', undefined, t.exit !== null ? number(t.exit, 2) : '—'));
    row.appendChild(element('td', undefined, t.size !== null ? number(t.size, 0) : '—'));
    row.appendChild(element('td', `pnl ${t.pnl >= 0 ? 'pos' : 'neg'}`, signed(t.pnl)));
    row.appendChild(element('td', undefined, signed(t.equity)));
    row.appendChild(element('td', t.drawdown < 0 ? 'pnl neg' : '', signed(t.drawdown)));
    tbody.appendChild(row);
  }
  table.appendChild(tbody);
  wrap.appendChild(table);
  container.appendChild(wrap);
}

function renderPassProbabilityCurve(div: HTMLDivElement, propFirm: PropFirmResult): void {
  const t = theme();
  const p = propFirm.passRatePct / 100;
  const x = Array.from({ length: 10 }, (_, i) => i + 1);
  const y = x.map((n) => 1 - Math.pow(1 - p, n));
  const data = [
    {
      x, y, type: 'scatter', mode: 'lines+markers',
      line: { color: t.blue, width: 2.5 }, marker: { color: t.blue, size: 8 },
      hovertemplate: '%{x} accounts<br>%{y:.1%} chance of ≥1 pass<extra></extra>',
      name: 'P(≥1 pass)',
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Accounts attempted', dtick: 1 },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Probability', range: [0, 1], tickformat: '.0%' },
    shapes: [{ type: 'line', x0: 0, x1: 10, y0: 0.95, y1: 0.95, line: { color: t.green, width: 1, dash: 'dash' } }],
    annotations: [{ x: 10, y: 0.95, xref: 'x', yref: 'y', text: '95%', showarrow: false, xanchor: 'right', yshift: 8, font: { color: t.green, size: 10 } }],
  });
  plotInto(div, data, layout);
}

function renderPayoutDonut(div: HTMLDivElement, propFirm: PropFirmResult): void {
  const t = theme();
  const passRate = propFirm.passRatePct / 100;
  const payoutPerPass = payoutPerPassFor(propFirm);
  const data = [
    {
      values: [propFirm.passRatePct, propFirm.failRatePct],
      labels: ['Payout', 'No payout'],
      type: 'pie',
      hole: 0.62,
      marker: { colors: [t.green, t.red], line: { color: 'rgba(0,0,0,0)', width: 0 } },
      textinfo: 'percent',
      textfont: { color: t.text, size: 13 },
      hovertemplate: '%{label}: %{value:.1f}%<extra></extra>',
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    annotations: [
      {
        text: `<b>${propFirm.passRatePct.toFixed(0)}%</b><br>payout`,
        showarrow: false,
        font: { color: t.text, size: 18 },
      },
    ],
    margin: { l: 18, r: 18, t: 18, b: 18 },
  });
  plotInto(div, data, layout);
}

function renderAccountGrowth(div: HTMLDivElement, propFirm: PropFirmResult): void {
  const t = theme();
  const passRate = propFirm.passRatePct / 100;
  const payoutPerPass = payoutPerPassFor(propFirm);
  const fee = propFirm.config.challengeFee;
  const ev = passRate * payoutPerPass - (1 - passRate) * fee;
  const sd1 = Math.sqrt(passRate * (1 - passRate)) * (payoutPerPass + fee);
  const N = 20;
  const xs = Array.from({ length: N }, (_, i) => i + 1);
  const mean = xs.map((n) => n * ev);
  const upper = xs.map((n) => n * ev + Math.sqrt(n) * sd1);
  const lower = xs.map((n) => n * ev - Math.sqrt(n) * sd1);
  const data = [
    {
      x: xs, y: upper, type: 'scatter', mode: 'lines',
      line: { color: t.green, width: 0 }, hoverinfo: 'skip', showlegend: false,
    },
    {
      x: xs, y: lower, type: 'scatter', mode: 'lines',
      line: { color: t.green, width: 0 }, fill: 'tonexty', fillcolor: 'rgba(52,211,153,0.12)',
      hovertemplate: '−1σ %{y:,.0f}<extra>±1σ band</extra>', name: '±1σ',
    },
    {
      x: xs, y: mean, type: 'scatter', mode: 'lines+markers',
      line: { color: t.blue, width: 2.5 }, marker: { color: t.blue, size: 6 },
      hovertemplate: '%{x} accounts<br>Expected %{y:,.0f}<extra></extra>', name: 'Expected',
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Accounts attempted', dtick: 2 },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Cumulative net ($)' },
    shapes: [{ type: 'line', x0: 0, x1: N, y0: 0, y1: 0, line: { color: t.grid, width: 1 } }],
    annotations: [
      { x: N, y: ev * N, xref: 'x', yref: 'y', text: `EV $${(ev * N).toLocaleString(undefined, { maximumFractionDigits: 0 })}`, showarrow: true, arrowcolor: t.blue, font: { color: t.blue, size: 10 }, ax: -30, ay: -20 },
    ],
  });
  plotInto(div, data, layout);
}

function renderEvVsPassRate(div: HTMLDivElement, propFirm: PropFirmResult): void {
  const t = theme();
  const passRate = propFirm.passRatePct / 100;
  const payoutPerPass = payoutPerPassFor(propFirm);
  const fee = propFirm.config.challengeFee;
  const breakEven = fee > 0 ? fee / (fee + payoutPerPass) : 0;
  const xs: number[] = [];
  const ys: number[] = [];
  for (let i = 0; i <= 100; i += 1) {
    const p = i / 100;
    xs.push(p);
    ys.push(p * payoutPerPass - (1 - p) * fee);
  }
  const data = [
    { x: xs, y: ys, type: 'scatter', mode: 'lines', line: { color: t.blue, width: 2.5 }, hovertemplate: 'Pass rate %{x:.0%}<br>EV %{y:,.0f}<extra></extra>' },
    { x: [passRate, passRate], y: [ys[0], ys[ys.length - 1]], type: 'scatter', mode: 'lines', line: { color: t.amber, width: 1.5, dash: 'dash' }, hoverinfo: 'skip', showlegend: false },
    { x: [breakEven, breakEven], y: [ys[0], ys[ys.length - 1]], type: 'scatter', mode: 'lines', line: { color: t.red, width: 1.5, dash: 'dash' }, hoverinfo: 'skip', showlegend: false },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Pass rate', tickformat: '.0%' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'EV per attempt ($)' },
    shapes: [{ type: 'line', x0: 0, x1: 1, xref: 'paper', y0: 0, y1: 0, line: { color: t.grid, width: 1 } }],
    annotations: [
      { x: passRate, y: 1, xref: 'x', yref: 'paper', text: `current ${percent(passRate)}`, showarrow: false, yshift: 8, font: { color: t.amber, size: 10 }, xanchor: 'center' },
      { x: breakEven, y: 1, xref: 'x', yref: 'paper', text: `break-even ${percent(breakEven)}`, showarrow: false, yshift: 22, font: { color: t.red, size: 10 }, xanchor: 'center' },
    ],
  });
  plotInto(div, data, layout);
}

function renderKellyGrowth(div: HTMLDivElement, propFirm: PropFirmResult): void {
  const t = theme();
  const passRate = propFirm.passRatePct / 100;
  const payoutPerPass = payoutPerPassFor(propFirm);
  const fee = propFirm.config.challengeFee;
  const b = fee > 0 ? payoutPerPass / fee : 0;
  const kelly = b > 0 ? (passRate * b - (1 - passRate)) / b : 0;
  const xs: number[] = [];
  const ys: number[] = [];
  for (let i = 0; i <= 100; i += 1) {
    const f = i / 100;
    xs.push(f);
    const g = passRate * Math.log(1 + f * b) + (1 - passRate) * Math.log(1 - f);
    ys.push(Number.isFinite(g) ? g : NaN);
  }
  const data = [
    { x: xs, y: ys, type: 'scatter', mode: 'lines', line: { color: t.blue, width: 2.5 }, hovertemplate: 'Fraction %{x:.0%}<br>Log-growth %{y:,.4f}<extra></extra>' },
    { x: [Math.max(0, Math.min(1, kelly)), Math.max(0, Math.min(1, kelly))], y: [Math.min(...ys.filter((v) => Number.isFinite(v))), Math.max(...ys.filter((v) => Number.isFinite(v)))], type: 'scatter', mode: 'lines', line: { color: t.green, width: 1.5, dash: 'dash' }, hoverinfo: 'skip', showlegend: false },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Fraction of fee risked', tickformat: '.0%' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Expected log-growth' },
    annotations: [{ x: Math.max(0, Math.min(1, kelly)), y: 1, xref: 'x', yref: 'paper', text: `Kelly ${percent(Math.max(0, kelly))}`, showarrow: false, yshift: 8, font: { color: t.green, size: 10 }, xanchor: 'center' }],
  });
  plotInto(div, data, layout);
}

function renderRiskOfRuinAccounts(div: HTMLDivElement, propFirm: PropFirmResult): void {
  const t = theme();
  const passRate = propFirm.passRatePct / 100;
  const N = 15;
  const xs = Array.from({ length: N }, (_, i) => i + 1);
  const ys = xs.map((n) => Math.pow(1 - passRate, n));
  const data = [{ x: xs, y: ys, type: 'scatter', mode: 'lines+markers', line: { color: t.red, width: 2.5 }, marker: { color: t.red, size: 7 }, fill: 'tozeroy', fillcolor: 'rgba(251,113,133,0.12)', hovertemplate: '%{x} accounts<br>P(all fail) %{y:.1%}<extra></extra>' }];
  const layout = baseLayout(t);
  Object.assign(layout, { xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Accounts attempted', dtick: 2 }, yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'P(lose all)', range: [0, 1], tickformat: '.0%' } });
  plotInto(div, data, layout);
}

function renderPayoffRatioBar(div: HTMLDivElement, propFirm: PropFirmResult): void {
  const t = theme();
  const payoutPerPass = payoutPerPassFor(propFirm);
  const fee = propFirm.config.challengeFee;
  const data = [{
    x: ['Payout per pass', 'Challenge fee'],
    y: [payoutPerPass, fee],
    type: 'bar',
    marker: { color: [t.green, t.red] },
    text: [`×${(payoutPerPass / Math.max(fee, 1)).toFixed(1)} fee`, '1× fee'],
    textposition: 'outside',
    textfont: { color: t.textSec, size: 11 },
    hovertemplate: '%{x}<br>$%{y:,.0f}<extra></extra>',
  }];
  const layout = baseLayout(t);
  Object.assign(layout, { yaxis: { ...(layout.yaxis as Record<string, unknown>), title: '$' }, bargap: 0.3 });
  plotInto(div, data, layout);
}

function renderProfitFactorVsPassRate(div: HTMLDivElement, propFirm: PropFirmResult): void {
  const t = theme();
  const passRate = propFirm.passRatePct / 100;
  const payoutPerPass = payoutPerPassFor(propFirm);
  const fee = propFirm.config.challengeFee;
  const xs: number[] = [];
  const ys: number[] = [];
  for (let i = 1; i <= 100; i += 1) {
    const p = i / 100;
    xs.push(p);
    const cost = (1 - p) * fee;
    ys.push(cost > 0 ? (p * payoutPerPass) / cost : Infinity);
  }
  const data = [
    { x: xs, y: ys.map((v) => (Number.isFinite(v) ? v : null)), type: 'scatter', mode: 'lines', line: { color: t.blue, width: 2.5 }, hovertemplate: 'Pass rate %{x:.0%}<br>Profit factor %{y:,.2f}<extra></extra>' },
    { x: [passRate, passRate], y: [0, Math.max(...ys.filter((v) => Number.isFinite(v)))], type: 'scatter', mode: 'lines', line: { color: t.amber, width: 1.5, dash: 'dash' }, hoverinfo: 'skip', showlegend: false },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Pass rate', tickformat: '.0%' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Profit factor (payout / cost)' },
    shapes: [{ type: 'line', x0: 0, x1: 1, xref: 'paper', y0: 1, y1: 1, line: { color: t.grid, width: 1, dash: 'dot' } }],
    annotations: [{ x: 1, y: 1, xref: 'paper', yref: 'y', text: 'PF = 1 (break-even)', showarrow: false, xanchor: 'right', yshift: 8, font: { color: t.textSec, size: 10 } }],
  });
  plotInto(div, data, layout);
}

function renderDaysToTarget(div: HTMLDivElement, propFirm: PropFirmResult): void {
  const t = theme();
  const passing = (propFirm.sampleRuns || []).filter((r) => r.outcome === 'pass').map((r) => r.days);
  if (!passing.length) {
    plotInto(div, [], baseLayout(t));
    const note = element('div', 'plot-empty', 'No passing runs in the sample — try reshuffling.');
    div.appendChild(note);
    return;
  }
  const data = [
    {
      x: passing, type: 'histogram', marker: { color: t.green },
      hovertemplate: '%{x} days<br>%{y} runs<extra></extra>',
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Days to target' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Runs' },
  });
  plotInto(div, data, layout);
}

function renderPropTerminalDistribution(div: HTMLDivElement, propFirm: PropFirmResult): void {
  const t = theme();
  const runs = propFirm.sampleRuns || [];
  if (!runs.length) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const pass = runs.filter((r) => r.outcome === 'pass').map((r) => r.terminal - r.accountSize);
  const fail = runs.filter((r) => r.outcome === 'fail').map((r) => r.terminal - r.accountSize);
  const data = [
    { x: pass, type: 'histogram', marker: { color: t.green }, opacity: 0.78, hovertemplate: 'Pass %{x:,.2f}<br>%{y} runs<extra></extra>', name: 'Pass' },
    { x: fail, type: 'histogram', marker: { color: t.red }, opacity: 0.78, hovertemplate: 'Fail %{x:,.2f}<br>%{y} runs<extra></extra>', name: 'Fail' },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    barmode: 'overlay',
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Run P&L' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Runs' },
  });
  plotInto(div, data, layout);
}

function renderEvWaterfall(div: HTMLDivElement, propFirm: PropFirmResult): void {
  const t = theme();
  const passRate = propFirm.passRatePct / 100;
  const payoutPerPass = payoutPerPassFor(propFirm);
  const expPayout = passRate * payoutPerPass;
  const expCost = (1 - passRate) * propFirm.config.challengeFee;
  const data = [
    {
      type: 'waterfall',
      x: ['Expected payout', 'Expected cost', 'Net EV / attempt'],
      y: [expPayout, -expCost, 0],
      measure: ['relative', 'relative', 'total'],
      connector: { line: { color: t.grid, width: 1 } },
      increasing: { marker: { color: t.green }, xaxis: 'x' },
      decreasing: { marker: { color: t.red } },
      totals: { marker: { color: t.blue } },
      hovertext: [
        `Payout: ${percent(passRate)} pass × $${number(payoutPerPass, 0)} payout = +$${number(expPayout, 0)}`,
        `Cost: ${percent(1 - passRate)} fail × $${number(propFirm.config.challengeFee, 0)} fee = −$${number(expCost, 0)}`,
        `Net EV per attempt = $${number(propFirm.expectedValue, 0)}`,
      ],
      hovertemplate: '%{hovertext}<extra></extra>',
      textposition: 'outside',
      text: [`+${number(expPayout, 0)}`, `-${number(expCost, 0)}`, number(propFirm.expectedValue, 0)],
      textfont: { color: t.textSec, size: 11 },
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Per attempt ($)' },
    margin: { l: 60, r: 18, t: 18, b: 42 },
  });
  plotInto(div, data, layout);
}

function renderAverageEquityPath(div: HTMLDivElement, propFirm: PropFirmResult): void {
  const t = theme();
  const runs = propFirm.sampleRuns || [];
  if (!runs.length) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const maxLen = Math.max(...runs.map((r) => r.equity.length));
  const padded = runs.map((r) => {
    const last = r.equity[r.equity.length - 1];
    const arr = r.equity.slice();
    while (arr.length < maxLen) arr.push(last);
    return arr;
  });
  const x = Array.from({ length: maxLen }, (_, i) => i);
  const avg = x.map((_, i) => padded.reduce((s, p) => s + p[i], 0) / padded.length);
  const data = [
    {
      x,
      y: avg,
      type: 'scatter',
      mode: 'lines',
      line: { color: t.blue, width: 2.5 },
      hovertemplate: 'Trade %{x}<br>Avg balance %{y:,.2f}<extra></extra>',
      name: 'Average path',
    },
  ];
  const targetLine = propFirm.config.accountSize + propFirm.config.profitTarget;
  const ddLimitLine = propFirm.config.accountSize - propFirm.config.maxTotalDrawdown;
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Trade #' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Balance' },
    shapes: [
      { type: 'line', x0: 0, x1: maxLen - 1, y0: propFirm.config.accountSize, y1: propFirm.config.accountSize, line: { color: t.textSec, width: 1, dash: 'dot' } },
      { type: 'line', x0: 0, x1: maxLen - 1, y0: targetLine, y1: targetLine, line: { color: t.green, width: 1.5, dash: 'dash' } },
      { type: 'line', x0: 0, x1: maxLen - 1, y0: ddLimitLine, y1: ddLimitLine, line: { color: t.red, width: 1.5, dash: 'dash' } },
    ],
    annotations: [
      { x: 0, y: propFirm.config.accountSize, text: 'Start', showarrow: false, yshift: 8, font: { color: t.textSec, size: 10 }, xanchor: 'left' },
      { x: 0, y: targetLine, text: 'Target', showarrow: false, yshift: 8, font: { color: t.green, size: 10 }, xanchor: 'left' },
      { x: 0, y: ddLimitLine, text: 'Max DD', showarrow: false, yshift: -10, font: { color: t.red, size: 10 }, xanchor: 'left' },
    ],
  });
  plotInto(div, data, layout);
}

function sectionTitle(text: string): HTMLElement {
  return element('h2', 'section-title', text);
}

function invNormal(p: number): number {
  const a = [-3.969683028665376e1, 2.209460984245205e2, -2.759285104469687e2, 1.38357751867269e2, -3.066479806614716e1, 2.506628277459239];
  const b = [-5.447609879822406e1, 1.615858368580409e2, -1.556989798598866e2, 6.680131188771972e1, -1.328068155288572e1];
  const c = [-7.784894002430293e-3, -3.223964458411511e-1, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783];
  const d = [7.784695709041462e-3, 3.224671290700398e-1, 2.445134137142996, 3.754408661907416];
  const plow = 0.02425;
  const phigh = 1 - plow;
  if (p < plow) {
    const q = Math.sqrt(-2 * Math.log(p));
    return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
  }
  if (p <= phigh) {
    const q = p - 0.5;
    const r = q * q;
    return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
  }
  const q = Math.sqrt(-2 * Math.log(1 - p));
  return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
}

function renderReturnsBox(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const wins = metrics.returns.filter((v) => v > 0);
  const losses = metrics.returns.filter((v) => v < 0);
  const data = [
    {
      y: wins, type: 'box', name: 'Wins', boxpoints: 'all', jitter: 0.3, pointpos: 0,
      marker: { color: t.green, size: 4 }, line: { color: t.green }, fillcolor: 'rgba(52,211,153,0.16)',
      hovertemplate: 'Win %{y:,.2f}<extra></extra>',
    },
    {
      y: losses, type: 'box', name: 'Losses', boxpoints: 'all', jitter: 0.3, pointpos: 0,
      marker: { color: t.red, size: 4 }, line: { color: t.red }, fillcolor: 'rgba(251,113,133,0.16)',
      hovertemplate: 'Loss %{y:,.2f}<extra></extra>',
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'P&L' },
    boxmode: 'group',
  });
  plotInto(div, data, layout);
}

function renderRollingSharpe(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const r = metrics.returns;
  const w = Math.max(10, Math.floor(r.length / 3));
  if (r.length < w) {
    plotInto(div, [], baseLayout(t));
    const note = element('div', 'plot-empty', `Need at least ${w} trades for a rolling window of ${w}.`);
    div.appendChild(note);
    return;
  }
  const x: number[] = [];
  const s: number[] = [];
  for (let i = w - 1; i < r.length; i += 1) {
    const slice = r.slice(i - w + 1, i + 1);
    const mean = slice.reduce((a, b) => a + b, 0) / slice.length;
    const variance = slice.reduce((a, b) => a + (b - mean) ** 2, 0) / slice.length;
    const std = Math.sqrt(variance);
    x.push(i + 1);
    s.push(std > 0 ? mean / std : 0);
  }
  const data = [
    {
      x, y: s, type: 'scatter', mode: 'lines', line: { color: t.blue, width: 2 },
      hovertemplate: 'Trade #%{x}<br>Sharpe %{y:,.2f}<extra></extra>',
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Trade #' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Rolling Sharpe' },
    shapes: [{ type: 'line', x0: 0, x1: r.length, y0: 0, y1: 0, line: { color: t.grid, width: 1 } }],
  });
  plotInto(div, data, layout);
}

function renderQQ(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const r = metrics.returns.slice().sort((a, b) => a - b);
  const n = r.length;
  if (n < 3) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const mean = r.reduce((a, b) => a + b, 0) / n;
  const std = Math.sqrt(r.reduce((a, b) => a + (b - mean) ** 2, 0) / n) || 1;
  const qx: number[] = [];
  for (let i = 0; i < n; i += 1) qx.push(invNormal((i + 0.5) / n) * std + mean);
  const lo = Math.min(qx[0], r[0]);
  const hi = Math.max(qx[n - 1], r[n - 1]);
  const data = [
    {
      x: qx, y: r, type: 'scatter', mode: 'markers', marker: { color: t.blue, size: 5 },
      hovertemplate: 'Observed %{y:,.2f}<br>Normal %{x:,.2f}<extra></extra>', name: 'Returns',
    },
    {
      x: [lo, hi], y: [lo, hi], type: 'scatter', mode: 'lines',
      line: { color: t.grid, dash: 'dash', width: 1.5 }, hoverinfo: 'skip', name: 'Normal',
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Normal quantile' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Observed return' },
  });
  plotInto(div, data, layout);
}

function renderCumulativeWinRate(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const r = metrics.returns;
  const x: number[] = [];
  const y: number[] = [];
  let wins = 0;
  for (let i = 0; i < r.length; i += 1) {
    if (r[i] > 0) wins += 1;
    x.push(i + 1);
    y.push(wins / (i + 1));
  }
  const data = [
    {
      x, y, type: 'scatter', mode: 'lines', line: { color: t.amber, width: 2.5 },
      hovertemplate: 'Trade #%{x}<br>Win rate %{y:.1%}<extra></extra>',
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Trade #' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Cumulative win rate', range: [0, 1] },
    shapes: [{ type: 'line', x0: 0, x1: r.length, y0: 0.5, y1: 0.5, line: { color: t.grid, width: 1, dash: 'dot' } }],
  });
  plotInto(div, data, layout);
}

function renderPnlVsIndex(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const y = metrics.returns;
  const n = y.length;
  const x = y.map((_, i) => i + 1);
  const colors = y.map((v) => (v >= 0 ? t.green : t.red));
  const mx = (n + 1) / 2;
  const my = y.reduce((a, b) => a + b, 0) / n;
  let cov = 0;
  let varx = 0;
  for (let i = 0; i < n; i += 1) {
    cov += (x[i] - mx) * (y[i] - my);
    varx += (x[i] - mx) ** 2;
  }
  const slope = varx > 0 ? cov / varx : 0;
  const intercept = my - slope * mx;
  const trendY = x.map((xi) => intercept + slope * xi);
  const data = [
    {
      x, y, type: 'scatter', mode: 'markers', marker: { color: colors, size: 6 },
      hovertemplate: 'Trade #%{x}<br>P&L %{y:,.2f}<extra></extra>', name: 'Trades',
    },
    {
      x, y: trendY, type: 'scatter', mode: 'lines',
      line: { color: t.amber, width: 2, dash: 'dash' },
      hovertemplate: 'Trend %{y:,.2f}<extra></extra>', name: 'OLS trend',
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Trade #' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'P&L' },
    shapes: [{ type: 'line', x0: 0, x1: n, y0: 0, y1: 0, line: { color: t.grid, width: 1 } }],
  });
  plotInto(div, data, layout);
}

function renderDirectionBreakdown(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const longs = metrics.tradeDetails.filter((td) => td.direction === 'long');
  const shorts = metrics.tradeDetails.filter((td) => td.direction === 'short');
  if (!longs.length && !shorts.length) {
    plotInto(div, [], baseLayout(t));
    const note = element('div', 'plot-empty', 'No direction data in this trade log — long/short breakdown needs a direction column.');
    div.appendChild(note);
    return;
  }
  const longPnl = longs.reduce((a, td) => a + td.pnl, 0);
  const shortPnl = shorts.reduce((a, td) => a + td.pnl, 0);
  const longWinRate = longs.length ? (longs.filter((td) => td.pnl > 0).length / longs.length) * 100 : 0;
  const shortWinRate = shorts.length ? (shorts.filter((td) => td.pnl > 0).length / shorts.length) * 100 : 0;
  const data = [
    {
      x: ['Long', 'Short'],
      y: [longPnl, shortPnl],
      type: 'bar',
      marker: { color: [t.green, t.red] },
      text: [
        `${longs.length} trades · ${longWinRate.toFixed(0)}% win`,
        `${shorts.length} trades · ${shortWinRate.toFixed(0)}% win`,
      ],
      textposition: 'outside',
      textfont: { color: t.textSec, size: 11 },
      hovertemplate: '%{x}<br>P&L %{y:,.2f}<extra></extra>',
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Total P&L' },
    bargap: 0.3,
  });
  plotInto(div, data, layout);
}

function renderDayOfWeekHeatmap(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const dated = metrics.tradeDetails.filter((td) => td.date);
  if (!dated.length) {
    plotInto(div, [], baseLayout(t));
    const note = element('div', 'plot-empty', 'No dates in this trade log — day-of-week heatmap needs dated trades.');
    div.appendChild(note);
    return;
  }
  const dow = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const months = new Map<string, number[]>();
  for (const td of dated) {
    const d = new Date(td.date!);
    if (Number.isNaN(d.getTime())) continue;
    const mk = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    const di = (d.getDay() + 6) % 7;
    if (!months.has(mk)) months.set(mk, new Array(7).fill(0));
    months.get(mk)![di] += td.pnl;
  }
  const sortedMonths = Array.from(months.keys()).sort();
  const z = sortedMonths.map((mk) => months.get(mk)!);
  const data = [
    {
      type: 'heatmap',
      z,
      x: dow,
      y: sortedMonths,
      colorscale: [[0, t.red], [0.5, '#11161c'], [1, t.green]],
      zmid: 0,
      text: z.map((row) => row.map((v) => (v === 0 ? '—' : signed(v, 0)))),
      texttemplate: '%{text}',
      textfont: { size: 10, color: t.text },
      hovertemplate: '%{x} %{y}<br>P&L %{z:,.2f}<extra></extra>',
      showscale: false,
      xgap: 3,
      ygap: 3,
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    margin: { l: 60, r: 18, t: 10, b: 34 },
    xaxis: { gridcolor: 'rgba(0,0,0,0)', zerolinecolor: 'rgba(0,0,0,0)', tickfont: { color: t.textSec, size: 11 }, side: 'bottom' },
    yaxis: { gridcolor: 'rgba(0,0,0,0)', zerolinecolor: 'rgba(0,0,0,0)', tickfont: { color: t.textSec }, automargin: true },
  });
  plotInto(div, data, layout);
}

function renderWeeklyHeatmap(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const dated = metrics.tradeDetails.filter((td) => td.date);
  if (!dated.length) {
    plotInto(div, [], baseLayout(t));
    const note = element('div', 'plot-empty', 'No dates in this trade log — weekly returns heatmap needs dated trades.');
    div.appendChild(note);
    return;
  }
  const dow = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  let firstMs = Infinity;
  for (const td of dated) {
    const ms = new Date(td.date!).getTime();
    if (Number.isFinite(ms)) firstMs = Math.min(firstMs, ms);
  }
  if (!Number.isFinite(firstMs)) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const weekMap = new Map<number, number[]>();
  for (const td of dated) {
    const ms = new Date(td.date!).getTime();
    if (!Number.isFinite(ms)) continue;
    const week = Math.floor((ms - firstMs) / 86_400_000 / 7);
    const di = (new Date(td.date!).getDay() + 6) % 7;
    if (!weekMap.has(week)) weekMap.set(week, new Array(7).fill(0));
    weekMap.get(week)![di] += td.pnl;
  }
  const weeks = Array.from(weekMap.keys()).sort((a, b) => a - b);
  const z = weeks.map((w) => weekMap.get(w)!);
  const yLabels = weeks.map((w) => `W${w + 1}`);
  const data = [
    {
      type: 'heatmap',
      z,
      x: dow,
      y: yLabels,
      colorscale: [
        [0, '#1e3a8a'],
        [0.5, '#11161c'],
        [1, '#dc2626'],
      ],
      zmid: 0,
      text: z.map((row) => row.map((v) => (v === 0 ? '' : signed(v, 0)))),
      texttemplate: '%{text}',
      textfont: { size: 10, color: t.text },
      hovertemplate: '%{x} %{y}<br>P&L %{z:,.2f}<extra></extra>',
      showscale: true,
      colorbar: { title: 'P&L', thickness: 8, tickfont: { color: t.textSec, size: 9 }, titlefont: { color: t.textSec, size: 10 } },
      xgap: 3,
      ygap: 3,
    },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    margin: { l: 50, r: 50, t: 10, b: 34 },
    xaxis: { gridcolor: 'rgba(0,0,0,0)', zerolinecolor: 'rgba(0,0,0,0)', tickfont: { color: t.textSec, size: 11 }, side: 'bottom' },
    yaxis: { gridcolor: 'rgba(0,0,0,0)', zerolinecolor: 'rgba(0,0,0,0)', tickfont: { color: t.textSec }, automargin: true },
  });
  plotInto(div, data, layout);
}

function renderAutocorrelation(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const r = metrics.returns;
  const maxLag = Math.min(12, r.length - 1);
  if (maxLag < 1) { plotInto(div, [], baseLayout(t)); return; }
  const mean = r.reduce((a, b) => a + b, 0) / r.length;
  const variance = r.reduce((a, b) => a + (b - mean) ** 2, 0) / r.length || 1;
  const lags: number[] = [];
  const acf: number[] = [];
  for (let k = 1; k <= maxLag; k += 1) {
    let cov = 0;
    for (let i = 0; i < r.length - k; i += 1) cov += (r[i] - mean) * (r[i + k] - mean);
    cov /= r.length - k;
    lags.push(k);
    acf.push(cov / variance);
  }
  const ci = 1.96 / Math.sqrt(r.length);
  const data = [{
    x: lags, y: acf, type: 'bar',
    marker: { color: acf.map((v) => (Math.abs(v) > ci ? t.amber : t.blue)) },
    hovertemplate: 'Lag %{x}<br>ACF %{y:,.3f}<extra></extra>',
  }];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Lag', dtick: 1 },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Autocorrelation' },
    shapes: [
      { type: 'line', x0: 0.5, x1: maxLag + 0.5, y0: ci, y1: ci, line: { color: t.grid, width: 1, dash: 'dash' } },
      { type: 'line', x0: 0.5, x1: maxLag + 0.5, y0: -ci, y1: -ci, line: { color: t.grid, width: 1, dash: 'dash' } },
      { type: 'line', x0: 0.5, x1: maxLag + 0.5, y0: 0, y1: 0, line: { color: t.grid, width: 1 } },
    ],
  });
  plotInto(div, data, layout);
}

function renderDurationVsPnl(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const r = metrics.returns;
  const dates = metrics.tradeDates;
  if (!dates.some((d) => d)) {
    plotInto(div, [], baseLayout(t));
    const note = element('div', 'plot-empty', 'No dates — hold time needs dated trades.');
    div.appendChild(note);
    return;
  }
  const x: number[] = [];
  const y: number[] = [];
  const colors: string[] = [];
  for (let i = 0; i < r.length; i += 1) {
    const cur = dates[i];
    const nxt = dates[i + 1];
    let gap = 0;
    if (cur && nxt) {
      const ms = new Date(nxt).getTime() - new Date(cur).getTime();
      if (Number.isFinite(ms)) gap = ms / 86_400_000;
    }
    x.push(gap);
    y.push(r[i]);
    colors.push(r[i] >= 0 ? t.green : t.red);
  }
  const data = [{ x, y, type: 'scatter', mode: 'markers', marker: { color: colors, size: 7 }, hovertemplate: 'Hold %{x}d<br>P&L %{y:,.2f}<extra></extra>' }];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Gap to next trade (days)' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'P&L' },
    shapes: [{ type: 'line', x0: 0, x1: Math.max(...x, 1), y0: 0, y1: 0, line: { color: t.grid, width: 1 } }],
  });
  plotInto(div, data, layout);
}

function renderLossStreaks(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const r = metrics.returns;
  const lengths: number[] = [];
  let cur = 0;
  for (const v of r) {
    if (v < 0) cur += 1;
    else if (cur > 0) { lengths.push(cur); cur = 0; }
  }
  if (cur > 0) lengths.push(cur);
  if (!lengths.length) {
    plotInto(div, [], baseLayout(t));
    const note = element('div', 'plot-empty', 'No losing streaks in this log.');
    div.appendChild(note);
    return;
  }
  const data = [{ x: lengths, type: 'histogram', marker: { color: t.red }, hovertemplate: '%{x} losses in a row<br>%{y} streaks<extra></extra>' }];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Consecutive losses', dtick: 1 },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Streak count' },
  });
  plotInto(div, data, layout);
}

function renderMonthlyReturnsBar(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  if (!metrics.monthlyReturns.length) {
    plotInto(div, [], baseLayout(t));
    const note = element('div', 'plot-empty', 'No dates — monthly returns need dated trades.');
    div.appendChild(note);
    return;
  }
  const labels = metrics.monthlyReturns.map((m) => `${m.year}-${String(m.month + 1).padStart(2, '0')}`);
  const pnls = metrics.monthlyReturns.map((m) => m.pnl);
  const data = [{ x: labels, y: pnls, type: 'bar', marker: { color: pnls.map((v) => (v >= 0 ? t.green : t.red)) }, hovertemplate: '%{x}<br>%{y:,.2f}<extra></extra>' }];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: '' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'P&L' },
  });
  plotInto(div, data, layout);
}

function renderCumWinLoss(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const r = metrics.returns;
  const x = r.map((_, i) => i + 1);
  let cw = 0;
  let cl = 0;
  const win: number[] = [];
  const loss: number[] = [];
  for (const v of r) {
    if (v > 0) cw += v;
    else cl += Math.abs(v);
    win.push(cw);
    loss.push(-cl);
  }
  const data = [
    { x, y: win, type: 'scatter', mode: 'lines', line: { color: t.green, width: 2 }, fill: 'tozeroy', fillcolor: 'rgba(52,211,153,0.12)', hovertemplate: 'Cum wins %{y:,.2f}<extra></extra>' },
    { x, y: loss, type: 'scatter', mode: 'lines', line: { color: t.red, width: 2 }, fill: 'tozeroy', fillcolor: 'rgba(251,113,133,0.12)', hovertemplate: 'Cum losses %{y:,.2f}<extra></extra>' },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Trade #' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Cumulative $' },
  });
  plotInto(div, data, layout);
}

function renderStrategyKelly(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const p = metrics.winRate;
  const avgWin = metrics.winCount > 0 ? metrics.grossWins / metrics.winCount : 0;
  const avgLoss = metrics.lossCount > 0 ? metrics.grossLosses / metrics.lossCount : 0;
  const b = avgLoss > 0 ? avgWin / avgLoss : avgWin > 0 ? Infinity : 0;
  const kelly = b > 0 && Number.isFinite(b) ? (p * b - (1 - p)) / b : 0;
  const full = Math.max(0, Math.min(1, kelly));
  const data = [{
    x: ['Full Kelly', 'Half Kelly', 'Quarter Kelly'],
    y: [full, full / 2, full / 4],
    type: 'bar',
    marker: { color: [t.amber, t.blue, t.green] },
    text: [percent(full), percent(full / 2), percent(full / 4)],
    textposition: 'outside',
    textfont: { color: t.textSec, size: 11 },
    hovertemplate: '%{x}<br>%{y:.1%} of account per trade<extra></extra>',
  }];
  const layout = baseLayout(t);
  Object.assign(layout, {
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Risk per trade', tickformat: '.0%', range: [0, Math.max(1, full * 1.2)] },
    bargap: 0.3,
  });
  plotInto(div, data, layout);
}

function renderLossRecovery(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const eq = metrics.equity;
  if (eq.length < 2) { plotInto(div, [], baseLayout(t)); return; }
  let peak = eq[0];
  let inDd = false;
  let ddStart = 0;
  const recoveries: number[] = [];
  for (let i = 0; i < eq.length; i += 1) {
    if (eq[i] > peak) {
      if (inDd) { recoveries.push(i - ddStart); inDd = false; }
      peak = eq[i];
    } else if (!inDd) { inDd = true; ddStart = i; }
  }
  if (inDd) recoveries.push(eq.length - 1 - ddStart);
  if (!recoveries.length) {
    plotInto(div, [], baseLayout(t));
    const note = element('div', 'plot-empty', 'No drawdowns to recover from.');
    div.appendChild(note);
    return;
  }
  const data = [{ x: recoveries.map((_, i) => i + 1), y: recoveries, type: 'bar', marker: { color: t.amber }, hovertemplate: 'DD #%{x}<br>%{y} trades to recover<extra></extra>' }];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Drawdown event', dtick: 1 },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Trades to new high' },
  });
  plotInto(div, data, layout);
}

function renderDirectionOverTime(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const r = metrics.returns;
  const td = metrics.tradeDetails;
  const x = r.map((_, i) => i + 1);
  let cl = 0;
  let cs = 0;
  const L: number[] = [];
  const S: number[] = [];
  for (let i = 0; i < r.length; i += 1) {
    if (td[i].direction === 'long') cl += r[i];
    else if (td[i].direction === 'short') cs += r[i];
    L.push(cl);
    S.push(cs);
  }
  const data = [
    { x, y: L, type: 'scatter', mode: 'lines', line: { color: t.green, width: 2 }, hovertemplate: 'Long cum %{y:,.2f}<extra></extra>' },
    { x, y: S, type: 'scatter', mode: 'lines', line: { color: t.red, width: 2 }, hovertemplate: 'Short cum %{y:,.2f}<extra></extra>' },
  ];
  const layout = baseLayout(t);
  Object.assign(layout, {
    xaxis: { ...(layout.xaxis as Record<string, unknown>), title: 'Trade #' },
    yaxis: { ...(layout.yaxis as Record<string, unknown>), title: 'Cumulative P&L' },
  });
  plotInto(div, data, layout);
}

function sceneAxis(t: Theme, title: string): Record<string, unknown> {
  return {
    title: { text: title, font: { color: t.textSec, size: 10 } },
    gridcolor: t.gridSoft,
    zerolinecolor: t.grid,
    showspikes: false,
    showbackground: true,
    backgroundcolor: 'rgba(0,0,0,0)',
    tickfont: { color: t.textSec, size: 10 },
  };
}

function renderFan3D(div: HTMLDivElement, mc: MonteCarloResult): void {
  const t = theme();
  const limit = Math.min(mc.paths.length, 30);
  if (!limit || !mc.paths[0]?.length) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const data = [];
  for (let p = 0; p < limit; p += 1) {
    const path = mc.paths[p];
    data.push({
      type: 'scatter3d',
      mode: 'lines',
      x: path.map((_, i) => i),
      y: path,
      z: Array(path.length).fill(p),
      line: { color: t.blue, width: 2 },
      opacity: 0.45 + (p / Math.max(limit, 1)) * 0.35,
      hovertemplate: `Path ${p + 1}<br>Trade %{x}<br>Equity %{y:,.2f}<extra></extra>`,
      name: `Path ${p + 1}`,
      showlegend: false,
    });
  }
  const layout = {
    paper_bgcolor: 'rgba(0,0,0,0)',
    plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, system-ui, sans-serif', size: 11 },
    margin: { l: 0, r: 0, t: 8, b: 0 },
    showlegend: false,
    scene: {
      xaxis: sceneAxis(t, 'Trade'),
      yaxis: sceneAxis(t, 'Equity'),
      zaxis: sceneAxis(t, 'Path'),
      camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
      bgcolor: 'rgba(0,0,0,0)',
    },
  };
  plotInto(div, data, layout);
}

function renderSurface3D(div: HTMLDivElement, mc: MonteCarloResult): void {
  const t = theme();
  const limit = Math.min(mc.paths.length, 40);
  const len = mc.paths[0]?.length || 0;
  if (!limit || !len) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const z: number[][] = [];
  for (let p = 0; p < limit; p += 1) {
    const path = mc.paths[p];
    const row: number[] = [];
    let peak = 0;
    for (const v of path) {
      peak = Math.max(peak, v);
      row.push(peak - v);
    }
    z.push(row);
  }
  const x = Array.from({ length: len }, (_, i) => i);
  const y = Array.from({ length: limit }, (_, i) => i);
  const data = [
    {
      type: 'surface',
      x,
      y,
      z,
      colorscale: [[0, t.green], [0.5, t.amber], [1, t.red]],
      showscale: false,
      hovertemplate: 'Path %{y}<br>Trade %{x}<br>Drawdown %{z:,.2f}<extra></extra>',
      opacity: 0.92,
    },
  ];
  const layout = {
    paper_bgcolor: 'rgba(0,0,0,0)',
    plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, system-ui, sans-serif', size: 11 },
    margin: { l: 0, r: 0, t: 8, b: 0 },
    showlegend: false,
    scene: {
      xaxis: sceneAxis(t, 'Trade'),
      yaxis: sceneAxis(t, 'Path'),
      zaxis: sceneAxis(t, 'Drawdown'),
      camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
      bgcolor: 'rgba(0,0,0,0)',
    },
  };
  plotInto(div, data, layout);
}

function renderDistribution3D(div: HTMLDivElement, mc: MonteCarloResult): void {
  const t = theme();
  if (!mc.terminals.length) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const min = Math.min(...mc.terminals);
  const max = Math.max(...mc.terminals);
  const range = max - min || 1;
  const binCount = Math.min(24, Math.max(8, Math.floor(Math.sqrt(mc.terminals.length))));
  const counts = new Array<number>(binCount).fill(0);
  for (const terminal of mc.terminals) {
    const bin = Math.min(binCount - 1, Math.max(0, Math.floor(((terminal - min) / range) * binCount)));
    counts[bin] += 1;
  }
  const maxCount = Math.max(...counts) || 1;
  const binCenters = counts.map((_, i) => min + ((i + 0.5) / binCount) * range);
  const stemX: (number | null)[] = [];
  const stemY: (number | null)[] = [];
  const stemZ: (number | null)[] = [];
  for (let i = 0; i < binCount; i += 1) {
    stemX.push(binCenters[i], binCenters[i], null);
    stemY.push(0, counts[i], null);
    stemZ.push(i, i, null);
  }
  const data = [
    {
      type: 'scatter3d',
      mode: 'lines',
      x: stemX,
      y: stemY,
      z: stemZ,
      line: { color: t.blue, width: 6 },
      hovertemplate: 'Bin %{z}<br>Outcome %{x:,.2f}<br>Count %{y}<extra></extra>',
      showlegend: false,
    },
    {
      type: 'scatter3d',
      mode: 'markers',
      x: binCenters,
      y: counts,
      z: counts.map((_, i) => i),
      marker: {
        size: counts.map((c) => 8 + (c / maxCount) * 18),
        color: counts,
        colorscale: [[0, t.blue], [1, t.amber]],
        opacity: 0.85,
        line: { color: 'rgba(0,0,0,0)', width: 0 },
      },
      hovertemplate: 'Outcome %{x:,.2f}<br>Count %{y}<extra></extra>',
      showlegend: false,
    },
  ];
  const layout = {
    paper_bgcolor: 'rgba(0,0,0,0)',
    plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, system-ui, sans-serif', size: 11 },
    margin: { l: 0, r: 0, t: 8, b: 0 },
    showlegend: false,
    scene: {
      xaxis: sceneAxis(t, 'Outcome'),
      yaxis: sceneAxis(t, 'Frequency'),
      zaxis: sceneAxis(t, 'Bin'),
      camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
      bgcolor: 'rgba(0,0,0,0)',
    },
  };
  plotInto(div, data, layout);
}

function renderTradeScatter3D(div: HTMLDivElement, metrics: Metrics, detail: HTMLDivElement): void {
  const t = theme();
  const r = metrics.returns;
  if (!r.length) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const x = r.map((_, i) => i + 1);
  const y = r;
  const z = r.map((_, i) => {
    const cur = metrics.tradeDates[i];
    const nxt = metrics.tradeDates[i + 1];
    if (cur && nxt) {
      const d1 = new Date(cur).getTime();
      const d2 = new Date(nxt).getTime();
      if (Number.isFinite(d1) && Number.isFinite(d2)) return (d2 - d1) / 86_400_000;
    }
    return 0;
  });
  const colors = r.map((v) => (v >= 0 ? t.green : t.red));
  const data = [
    {
      type: 'scatter3d',
      mode: 'markers',
      x,
      y,
      z,
      marker: { size: 7, color: colors, line: { color: 'rgba(0,0,0,0)', width: 0 } },
      hovertemplate: 'Trade #%{x}<br>P&L %{y:,.2f}<br>Gap %{z:.1f}d<extra></extra>',
      name: 'Trades',
    },
  ];
  const layout = {
    paper_bgcolor: 'rgba(0,0,0,0)',
    plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, system-ui, sans-serif', size: 11 },
    margin: { l: 0, r: 0, t: 8, b: 0 },
    showlegend: false,
    scene: {
      xaxis: sceneAxis(t, 'Trade #'),
      yaxis: sceneAxis(t, 'P&L'),
      zaxis: sceneAxis(t, 'Gap to next (days)'),
      camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
      bgcolor: 'rgba(0,0,0,0)',
    },
  };
  plotInto(div, data, layout);
  bindClick(div, (pt) => {
    const idx = pt.pointNumber;
    if (!Number.isInteger(idx) || idx < 0 || idx >= r.length) return;
    const pnl = r[idx];
    const eq = metrics.equity[idx];
    const dd = metrics.drawdownSeries[idx];
    const date = metrics.tradeDates[idx];
    fillDetail(detail, `Trade #${idx + 1}`, [
      ['P&L', signed(pnl)],
      ['Equity after', signed(eq)],
      ['Drawdown from peak', signed(dd)],
      ['Outcome', pnl > 0 ? 'Win' : pnl < 0 ? 'Loss' : 'Flat'],
      ['Date', date ? new Date(date).toLocaleDateString() : '—'],
      ['Gap to next', `${z[idx].toFixed(1)}d`],
    ]);
  });
}

function renderEquitySurface3D(div: HTMLDivElement, mc: MonteCarloResult): void {
  const t = theme();
  const limit = Math.min(mc.paths.length, 40);
  const len = mc.paths[0]?.length || 0;
  if (!limit || !len) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const z: number[][] = [];
  for (let p = 0; p < limit; p += 1) z.push(mc.paths[p].slice());
  const x = Array.from({ length: len }, (_, i) => i);
  const y = Array.from({ length: limit }, (_, i) => i);
  const data = [
    {
      type: 'surface',
      x,
      y,
      z,
      colorscale: [
        [0, t.red],
        [0.5, t.amber],
        [1, t.green],
      ],
      showscale: false,
      hovertemplate: 'Path %{y}<br>Trade %{x}<br>Equity %{z:,.2f}<extra></extra>',
      opacity: 0.92,
    },
  ];
  const layout = {
    paper_bgcolor: 'rgba(0,0,0,0)',
    plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, system-ui, sans-serif', size: 11 },
    margin: { l: 0, r: 0, t: 8, b: 0 },
    showlegend: false,
    scene: {
      xaxis: sceneAxis(t, 'Trade'),
      yaxis: sceneAxis(t, 'Path'),
      zaxis: sceneAxis(t, 'Equity'),
      camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
      bgcolor: 'rgba(0,0,0,0)',
    },
  };
  plotInto(div, data, layout);
}

function renderReturnDist3D(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const r = metrics.returns;
  if (!r.length) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const min = Math.min(...r);
  const max = Math.max(...r);
  const range = max - min || 1;
  const bins = Math.min(20, Math.max(8, Math.floor(Math.sqrt(r.length))));
  const counts = new Array<number>(bins).fill(0);
  for (const v of r) {
    const b = Math.min(bins - 1, Math.max(0, Math.floor(((v - min) / range) * bins)));
    counts[b] += 1;
  }
  const maxC = Math.max(...counts) || 1;
  const centers = counts.map((_, i) => min + ((i + 0.5) / bins) * range);
  const v95ret = -varCvar(r, 0.05).varVal;
  const v99ret = -varCvar(r, 0.01).varVal;
  const stemX: (number | null)[] = [];
  const stemY: (number | null)[] = [];
  const stemZ: (number | null)[] = [];
  for (let i = 0; i < bins; i += 1) {
    stemX.push(centers[i], centers[i], null);
    stemY.push(0, counts[i], null);
    stemZ.push(i, i, null);
  }
  const data: unknown[] = [
    {
      type: 'scatter3d',
      mode: 'lines',
      x: stemX, y: stemY, z: stemZ,
      line: { color: t.blue, width: 5 },
      hovertemplate: 'Return %{x:,.2f}<br>Count %{y}<extra></extra>',
      showlegend: false,
    },
    {
      type: 'scatter3d',
      mode: 'markers',
      x: centers, y: counts, z: counts.map((_, i) => i),
      marker: {
        size: counts.map((c) => 8 + (c / maxC) * 18),
        color: centers.map((c) => (c <= v99ret ? '#7f1d1d' : c <= v95ret ? t.red : t.blue)),
        line: { color: 'rgba(0,0,0,0)', width: 0 },
      },
      hovertemplate: 'Return %{x:,.2f}<br>Count %{y}<extra></extra>',
      showlegend: false,
    },
    {
      type: 'scatter3d',
      mode: 'lines',
      x: [v95ret, v95ret], y: [0, maxC * 1.1], z: [0, bins - 1],
      line: { color: t.amber, width: 4 },
      hovertemplate: `VaR 95% %{x:,.2f}<extra></extra>`,
      showlegend: false,
    },
    {
      type: 'scatter3d',
      mode: 'lines',
      x: [v99ret, v99ret], y: [0, maxC * 1.1], z: [0, bins - 1],
      line: { color: '#7f1d1d', width: 4 },
      hovertemplate: `VaR 99% %{x:,.2f}<extra></extra>`,
      showlegend: false,
    },
  ];
  const layout = {
    paper_bgcolor: 'rgba(0,0,0,0)',
    plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, system-ui, sans-serif', size: 11 },
    margin: { l: 0, r: 0, t: 8, b: 0 },
    showlegend: false,
    scene: {
      xaxis: sceneAxis(t, 'Return'),
      yaxis: sceneAxis(t, 'Frequency'),
      zaxis: sceneAxis(t, 'Bin'),
      camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
      bgcolor: 'rgba(0,0,0,0)',
    },
  };
  plotInto(div, data, layout);
}

function renderRollingVar3D(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const r = metrics.returns;
  if (r.length < 5) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const windows = [10, 20, 30, 50].filter((w) => w <= r.length * 2);
  if (!windows.length) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const x = r.map((_, i) => i + 1);
  const z: number[][] = windows.map((w) =>
    r.map((_, i) => {
      const slice = r.slice(Math.max(0, i - w + 1), i + 1);
      const sorted = slice.slice().sort((a, b) => a - b);
      return sorted[Math.max(0, Math.floor(sorted.length * 0.05) - 1)];
    })
  );
  const data = [
    {
      type: 'surface',
      x,
      y: windows.map(String),
      z,
      colorscale: [
        [0, t.green],
        [0.5, t.amber],
        [1, t.red],
      ],
      showscale: false,
      hovertemplate: 'Trade %{x}<br>Window %{y}<br>VaR %{z:,.2f}<extra></extra>',
      opacity: 0.9,
    },
  ];
  const layout = {
    paper_bgcolor: 'rgba(0,0,0,0)',
    plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, system-ui, sans-serif', size: 11 },
    margin: { l: 0, r: 0, t: 8, b: 0 },
    showlegend: false,
    scene: {
      xaxis: sceneAxis(t, 'Trade #'),
      yaxis: sceneAxis(t, 'Window'),
      zaxis: sceneAxis(t, 'VaR (95%)'),
      camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
      bgcolor: 'rgba(0,0,0,0)',
    },
  };
  plotInto(div, data, layout);
}

function renderRollingDd3D(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const eq = metrics.equity;
  if (eq.length < 5) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const windows = [10, 20, 30, 50].filter((w) => w <= eq.length * 2);
  if (!windows.length) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const x = eq.map((_, i) => i + 1);
  const z: number[][] = windows.map((w) =>
    eq.map((_, i) => {
      const start = Math.max(0, i - w + 1);
      let peak = eq[start];
      let maxDd = 0;
      for (let j = start; j <= i; j += 1) {
        peak = Math.max(peak, eq[j]);
        maxDd = Math.max(maxDd, peak - eq[j]);
      }
      return maxDd;
    })
  );
  const data = [
    {
      type: 'surface',
      x,
      y: windows.map(String),
      z,
      colorscale: [
        [0, t.green],
        [0.5, t.amber],
        [1, t.red],
      ],
      showscale: false,
      hovertemplate: 'Trade %{x}<br>Window %{y}<br>Max DD %{z:,.2f}<extra></extra>',
      opacity: 0.9,
    },
  ];
  const layout = {
    paper_bgcolor: 'rgba(0,0,0,0)',
    plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, system-ui, sans-serif', size: 11 },
    margin: { l: 0, r: 0, t: 8, b: 0 },
    showlegend: false,
    scene: {
      xaxis: sceneAxis(t, 'Trade #'),
      yaxis: sceneAxis(t, 'Window'),
      zaxis: sceneAxis(t, 'Max drawdown'),
      camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
      bgcolor: 'rgba(0,0,0,0)',
    },
  };
  plotInto(div, data, layout);
}

function renderRiskScatter3D(div: HTMLDivElement, metrics: Metrics, detail: HTMLDivElement): void {
  const t = theme();
  const r = metrics.returns;
  if (!r.length) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const x = r.map((_, i) => i + 1);
  const y = r;
  const z = metrics.drawdownSeries;
  const colors = r.map((v) => (v >= 0 ? t.green : t.red));
  const data = [
    {
      type: 'scatter3d',
      mode: 'markers',
      x,
      y,
      z,
      marker: { size: 7, color: colors, line: { color: 'rgba(0,0,0,0)', width: 0 } },
      hovertemplate: 'Trade #%{x}<br>P&L %{y:,.2f}<br>Drawdown %{z:,.2f}<extra></extra>',
      name: 'Trades',
    },
  ];
  const layout = {
    paper_bgcolor: 'rgba(0,0,0,0)',
    plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, system-ui, sans-serif', size: 11 },
    margin: { l: 0, r: 0, t: 8, b: 0 },
    showlegend: false,
    scene: {
      xaxis: sceneAxis(t, 'Trade #'),
      yaxis: sceneAxis(t, 'P&L'),
      zaxis: sceneAxis(t, 'Drawdown'),
      camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
      bgcolor: 'rgba(0,0,0,0)',
    },
  };
  plotInto(div, data, layout);
  bindClick(div, (pt) => {
    const idx = pt.pointNumber;
    if (!Number.isInteger(idx) || idx < 0 || idx >= r.length) return;
    const pnl = r[idx];
    const dd = metrics.drawdownSeries[idx];
    const eq = metrics.equity[idx];
    const date = metrics.tradeDates[idx];
    fillDetail(detail, `Trade #${idx + 1} — risk`, [
      ['P&L', signed(pnl)],
      ['Equity after', signed(eq)],
      ['Drawdown from peak', signed(dd)],
      ['Outcome', pnl > 0 ? 'Win' : pnl < 0 ? 'Loss' : 'Flat'],
      ['Date', date ? new Date(date).toLocaleDateString() : '—'],
      ['Progress', `${idx + 1} / ${r.length}`],
    ]);
  });
}

function pathMaxDrawdown(path: number[]): number {
  let peak = 0;
  let maxDd = 0;
  for (const v of path) {
    peak = Math.max(peak, v);
    maxDd = Math.max(maxDd, peak - v);
  }
  return maxDd;
}

function renderMcMaxDd3D(div: HTMLDivElement, mc: MonteCarloResult): void {
  const t = theme();
  if (!mc.paths.length) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const maxDds = mc.paths.map(pathMaxDrawdown);
  const min = Math.min(...maxDds);
  const max = Math.max(...maxDds);
  const range = max - min || 1;
  const binCount = Math.min(20, Math.max(8, Math.floor(Math.sqrt(maxDds.length))));
  const counts = new Array<number>(binCount).fill(0);
  for (const dd of maxDds) {
    const b = Math.min(binCount - 1, Math.max(0, Math.floor(((dd - min) / range) * binCount)));
    counts[b] += 1;
  }
  const maxC = Math.max(...counts) || 1;
  const centers = counts.map((_, i) => min + ((i + 0.5) / binCount) * range);
  const stemX: (number | null)[] = [];
  const stemY: (number | null)[] = [];
  const stemZ: (number | null)[] = [];
  for (let i = 0; i < binCount; i += 1) {
    stemX.push(centers[i], centers[i], null);
    stemY.push(0, counts[i], null);
    stemZ.push(i, i, null);
  }
  const data = [
    {
      type: 'scatter3d', mode: 'lines', x: stemX, y: stemY, z: stemZ,
      line: { color: t.red, width: 5 },
      hovertemplate: 'Max DD %{x:,.2f}<br>Count %{y}<extra></extra>', showlegend: false,
    },
    {
      type: 'scatter3d', mode: 'markers', x: centers, y: counts, z: counts.map((_, i) => i),
      marker: {
        size: counts.map((c) => 8 + (c / maxC) * 18),
        color: counts, colorscale: [[0, t.amber], [1, t.red]],
        line: { color: 'rgba(0,0,0,0)', width: 0 },
      },
      hovertemplate: 'Max DD %{x:,.2f}<br>Paths %{y}<extra></extra>', showlegend: false,
    },
  ];
  const layout = {
    paper_bgcolor: 'rgba(0,0,0,0)',
    plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, system-ui, sans-serif', size: 11 },
    margin: { l: 0, r: 0, t: 8, b: 0 },
    showlegend: false,
    scene: {
      xaxis: sceneAxis(t, 'Max drawdown'),
      yaxis: sceneAxis(t, 'Path count'),
      zaxis: sceneAxis(t, 'Bin'),
      camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
      bgcolor: 'rgba(0,0,0,0)',
    },
  };
  plotInto(div, data, layout);
}

function renderMcRiskScatter3D(div: HTMLDivElement, mc: MonteCarloResult, detail: HTMLDivElement): void {
  const t = theme();
  const limit = Math.min(mc.paths.length, 400);
  if (!limit) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const sampled: Array<{ idx: number; terminal: number; maxDd: number; min: number; max: number }> = [];
  const step = Math.max(1, Math.floor(mc.paths.length / limit));
  const x: number[] = [];
  const y: number[] = [];
  const z: number[] = [];
  const colors: string[] = [];
  for (let p = 0; p < mc.paths.length; p += step) {
    const path = mc.paths[p];
    const terminal = path[path.length - 1];
    const maxDd = pathMaxDrawdown(path);
    let mn = Infinity;
    let mx = -Infinity;
    for (const v of path) {
      mn = Math.min(mn, v);
      mx = Math.max(mx, v);
    }
    sampled.push({ idx: p, terminal, maxDd, min: mn, max: mx });
    x.push(terminal);
    y.push(maxDd);
    z.push(p);
    colors.push(terminal >= 0 ? t.green : t.red);
  }
  const data = [
    {
      type: 'scatter3d', mode: 'markers', x, y, z,
      marker: { size: 5, color: colors, line: { color: 'rgba(0,0,0,0)', width: 0 } },
      hovertemplate: 'Path %{z}<br>Terminal %{x:,.2f}<br>Max DD %{y:,.2f}<extra></extra>',
      name: 'Paths',
    },
  ];
  const layout = {
    paper_bgcolor: 'rgba(0,0,0,0)',
    plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, system-ui, sans-serif', size: 11 },
    margin: { l: 0, r: 0, t: 8, b: 0 },
    showlegend: false,
    scene: {
      xaxis: sceneAxis(t, 'Terminal equity'),
      yaxis: sceneAxis(t, 'Max drawdown'),
      zaxis: sceneAxis(t, 'Path #'),
      camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
      bgcolor: 'rgba(0,0,0,0)',
    },
  };
  plotInto(div, data, layout);
  bindClick(div, (pt) => {
    const entry = sampled[pt.pointNumber];
    if (!entry) return;
    const rankBelow = mc.terminals.filter((v) => v <= entry.terminal).length;
    const rankPct = (rankBelow / Math.max(mc.terminals.length, 1)) * 100;
    fillDetail(detail, `MC path #${entry.idx + 1} — risk`, [
      ['Terminal equity', signed(entry.terminal)],
      ['Max drawdown', signed(-entry.maxDd)],
      ['Min equity', signed(entry.min)],
      ['Max equity', signed(entry.max)],
      ['Rank (terminal)', `${rankPct.toFixed(0)}% at or below`],
      ['Outcome', entry.terminal >= 0 ? 'Positive' : 'Negative'],
    ]);
  });
}

function renderMcPercentile3D(div: HTMLDivElement, mc: MonteCarloResult): void {
  const t = theme();
  const len = mc.paths[0]?.length || 0;
  if (!len || !mc.paths.length) {
    plotInto(div, [], baseLayout(t));
    return;
  }
  const percentiles = [5, 10, 25, 50, 75, 90, 95];
  const x = Array.from({ length: len }, (_, i) => i + 1);
  const z: number[][] = percentiles.map((p) => {
    const fraction = p / 100;
    const row: number[] = [];
    for (let i = 0; i < len; i += 1) {
      const col = mc.paths.map((path) => path[i]).sort((a, b) => a - b);
      row.push(pct(col, fraction));
    }
    return row;
  });
  const data = [
    {
      type: 'surface',
      x,
      y: percentiles.map((p) => `p${p}`),
      z,
      colorscale: [
        [0, t.red],
        [0.5, t.amber],
        [1, t.green],
      ],
      showscale: false,
      hovertemplate: 'Trade %{x}<br>%{y}<br>Equity %{z:,.2f}<extra></extra>',
      opacity: 0.92,
    },
  ];
  const layout = {
    paper_bgcolor: 'rgba(0,0,0,0)',
    plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, system-ui, sans-serif', size: 11 },
    margin: { l: 0, r: 0, t: 8, b: 0 },
    showlegend: false,
    scene: {
      xaxis: sceneAxis(t, 'Trade #'),
      yaxis: sceneAxis(t, 'Percentile'),
      zaxis: sceneAxis(t, 'Equity'),
      camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
      bgcolor: 'rgba(0,0,0,0)',
    },
  };
  plotInto(div, data, layout);
}

function renderRollingSharpe3D(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const r = metrics.returns;
  const windows = [10, 20, 30, 50].filter((w) => w <= r.length * 2);
  if (!windows.length || r.length < 5) { plotInto(div, [], baseLayout(t)); return; }
  const x = r.map((_, i) => i + 1);
  const z = windows.map((w) =>
    r.map((_, i) => {
      const slice = r.slice(Math.max(0, i - w + 1), i + 1);
      const mean = slice.reduce((a, b) => a + b, 0) / slice.length;
      const variance = slice.reduce((a, b) => a + (b - mean) ** 2, 0) / slice.length;
      const std = Math.sqrt(variance);
      return std > 0 ? mean / std : 0;
    })
  );
  const data = [{
    type: 'surface', x, y: windows.map(String), z,
    colorscale: [[0, t.red], [0.5, t.amber], [1, t.green]], showscale: false,
    hovertemplate: 'Trade %{x}<br>Window %{y}<br>Sharpe %{z:,.2f}<extra></extra>', opacity: 0.9,
  }];
  const layout = {
    paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, system-ui, sans-serif', size: 11 },
    margin: { l: 0, r: 0, t: 8, b: 0 }, showlegend: false,
    scene: { xaxis: sceneAxis(t, 'Trade #'), yaxis: sceneAxis(t, 'Window'), zaxis: sceneAxis(t, 'Rolling Sharpe'), camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } }, bgcolor: 'rgba(0,0,0,0)' },
  };
  plotInto(div, data, layout);
}

function renderRollingSortino3D(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const r = metrics.returns;
  const windows = [10, 20, 30, 50].filter((w) => w <= r.length * 2);
  if (!windows.length || r.length < 5) { plotInto(div, [], baseLayout(t)); return; }
  const x = r.map((_, i) => i + 1);
  const z = windows.map((w) =>
    r.map((_, i) => {
      const slice = r.slice(Math.max(0, i - w + 1), i + 1);
      const mean = slice.reduce((a, b) => a + b, 0) / slice.length;
      const downside = slice.filter((v) => v < 0);
      if (!downside.length) return mean > 0 ? 5 : 0;
      const dd = Math.sqrt(downside.reduce((a, b) => a + b * b, 0) / slice.length);
      return dd > 0 ? mean / dd : 0;
    })
  );
  const data = [{
    type: 'surface', x, y: windows.map(String), z,
    colorscale: [[0, t.red], [0.5, t.amber], [1, t.green]], showscale: false,
    hovertemplate: 'Trade %{x}<br>Window %{y}<br>Sortino %{z:,.2f}<extra></extra>', opacity: 0.9,
  }];
  const layout = {
    paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, system-ui, sans-serif', size: 11 },
    margin: { l: 0, r: 0, t: 8, b: 0 }, showlegend: false,
    scene: { xaxis: sceneAxis(t, 'Trade #'), yaxis: sceneAxis(t, 'Window'), zaxis: sceneAxis(t, 'Rolling Sortino'), camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } }, bgcolor: 'rgba(0,0,0,0)' },
  };
  plotInto(div, data, layout);
}

function renderAcAutocorrelation3D(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const r = metrics.returns;
  if (r.length < 10) { plotInto(div, [], baseLayout(t)); return; }
  const n = r.length;
  const windows = Array.from(new Set([Math.max(5, Math.floor(n * 0.4)), Math.max(8, Math.floor(n * 0.6)), Math.max(10, Math.floor(n * 0.8)), n - 1].filter((w) => w >= 5 && w < n))).sort((a, b) => a - b);
  const maxLag = Math.min(8, Math.max(2, Math.floor(n / 4)));
  const lags = Array.from({ length: maxLag }, (_, i) => i + 1);
  const z = windows.map((w) => {
    const row: number[] = [];
    for (let k = 1; k <= maxLag; k += 1) {
      let cov = 0;
      let count = 0;
      for (let i = 0; i + w <= r.length; i += 1) {
        const slice = r.slice(i, i + w);
        const mean = slice.reduce((a, b) => a + b, 0) / slice.length;
        const variance = slice.reduce((a, b) => a + (b - mean) ** 2, 0) / slice.length || 1;
        let c = 0;
        for (let j = 0; j < slice.length - k; j += 1) c += (slice[j] - mean) * (slice[j + k] - mean);
        c /= slice.length - k;
        cov += c / variance;
        count += 1;
      }
      row.push(count > 0 ? cov / count : 0);
    }
    return row;
  });
  const data = [{
    type: 'surface', x: lags, y: windows.map(String), z,
    colorscale: [[0, t.blue], [0.5, t.amber], [1, t.red]], showscale: false,
    hovertemplate: 'Lag %{x}<br>Window %{y}<br>ACF %{z:,.3f}<extra></extra>', opacity: 0.9,
  }];
  const layout = {
    paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, system-ui, sans-serif', size: 11 },
    margin: { l: 0, r: 0, t: 8, b: 0 }, showlegend: false,
    scene: { xaxis: sceneAxis(t, 'Lag'), yaxis: sceneAxis(t, 'Window'), zaxis: sceneAxis(t, 'Autocorrelation'), camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } }, bgcolor: 'rgba(0,0,0,0)' },
  };
  plotInto(div, data, layout);
}

function renderEquityDensity3D(div: HTMLDivElement, mc: MonteCarloResult): void {
  const t = theme();
  const len = mc.paths[0]?.length || 0;
  if (!len || !mc.paths.length) { plotInto(div, [], baseLayout(t)); return; }
  const allVals: number[] = [];
  for (const p of mc.paths) for (const v of p) allVals.push(v);
  const min = Math.min(...allVals);
  const max = Math.max(...allVals);
  const range = max - min || 1;
  const binCount = Math.min(24, Math.max(8, Math.floor(Math.sqrt(allVals.length))));
  const bins = Array.from({ length: binCount }, (_, b) => min + ((b + 0.5) / binCount) * range);
  const z: number[][] = bins.map(() => new Array(len).fill(0));
  for (const p of mc.paths) {
    for (let i = 0; i < len; i += 1) {
      const v = p[i];
      const b = Math.min(binCount - 1, Math.max(0, Math.floor(((v - min) / range) * binCount)));
      z[b][i] += 1;
    }
  }
  const x = Array.from({ length: len }, (_, i) => i + 1);
  const data = [{
    type: 'surface', x, y: bins.map((b) => Math.round(b)), z,
    colorscale: [[0, '#11161c'], [0.5, t.blue], [1, t.amber]], showscale: false,
    hovertemplate: 'Trade %{x}<br>Equity %{y}<br>Paths %{z}<extra></extra>', opacity: 0.92,
  }];
  const layout = {
    paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, system-ui, sans-serif', size: 11 },
    margin: { l: 0, r: 0, t: 8, b: 0 }, showlegend: false,
    scene: { xaxis: sceneAxis(t, 'Trade #'), yaxis: sceneAxis(t, 'Equity'), zaxis: sceneAxis(t, 'Path count'), camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } }, bgcolor: 'rgba(0,0,0,0)' },
  };
  plotInto(div, data, layout);
}

function renderRollingCalmar3D(div: HTMLDivElement, metrics: Metrics): void {
  const t = theme();
  const eq = metrics.equity;
  const windows = [10, 20, 30, 50].filter((w) => w <= eq.length * 2);
  if (!windows.length || eq.length < 5) { plotInto(div, [], baseLayout(t)); return; }
  const x = eq.map((_, i) => i + 1);
  const z = windows.map((w) =>
    eq.map((_, i) => {
      const start = Math.max(0, i - w + 1);
      let peak = eq[start];
      let maxDd = 0;
      for (let j = start; j <= i; j += 1) {
        peak = Math.max(peak, eq[j]);
        maxDd = Math.max(maxDd, peak - eq[j]);
      }
      const ret = eq[i] - eq[start];
      return maxDd > 0 ? ret / maxDd : ret > 0 ? 5 : 0;
    })
  );
  const data = [{
    type: 'surface', x, y: windows.map(String), z,
    colorscale: [[0, t.red], [0.5, t.amber], [1, t.green]], showscale: false,
    hovertemplate: 'Trade %{x}<br>Window %{y}<br>Calmar %{z:,.2f}<extra></extra>', opacity: 0.9,
  }];
  const layout = {
    paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: 'rgba(0,0,0,0)',
    font: { color: t.text, family: 'Inter, system-ui, sans-serif', size: 11 },
    margin: { l: 0, r: 0, t: 8, b: 0 }, showlegend: false,
    scene: { xaxis: sceneAxis(t, 'Trade #'), yaxis: sceneAxis(t, 'Window'), zaxis: sceneAxis(t, 'Rolling Calmar'), camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } }, bgcolor: 'rgba(0,0,0,0)' },
  };
  plotInto(div, data, layout);
}

export function createDomRefs(): DomRefs {
  const $ = (id: string): HTMLElement => {
    const node = document.getElementById(id);
    if (!node) throw new Error(`Missing element #${id}`);
    return node;
  };
  const csvInput = $('csv-input') as HTMLTextAreaElement;
  const fileInput = $('file-input') as HTMLInputElement;
  const runButton = $('run-button') as HTMLButtonElement;
  const clearButton = $('clear-button') as HTMLButtonElement;
  const sampleButton = $('sample-button') as HTMLButtonElement;
  const status = $('status') as HTMLParagraphElement;
  const report = $('report');

  const mcPathsInput = $('mc-paths') as HTMLInputElement;
  const mcBlockInput = $('mc-block') as HTMLInputElement;
  const mcSeedInput = $('mc-seed') as HTMLInputElement;
  const propPresetSelect = $('prop-preset') as HTMLSelectElement;
  const propFields: Record<string, HTMLInputElement> = {
    name: $('prop-name') as HTMLInputElement,
    accountSize: $('prop-account') as HTMLInputElement,
    profitTarget: $('prop-target') as HTMLInputElement,
    maxDailyLoss: $('prop-daily') as HTMLInputElement,
    maxTotalDrawdown: $('prop-drawdown') as HTMLInputElement,
    evaluationDays: $('prop-days') as HTMLInputElement,
    payoutPct: $('prop-payout') as HTMLInputElement,
    challengeFee: $('prop-fee') as HTMLInputElement,
    minPayout: $('prop-min-payout') as HTMLInputElement,
    payoutDays: $('prop-payout-days') as HTMLInputElement,
    trailingDrawdown: $('prop-trailing') as HTMLInputElement,
    resetFee: $('prop-reset-fee') as HTMLInputElement,
    scaling: $('prop-scaling') as HTMLInputElement,
    phases: $('prop-phases') as HTMLInputElement,
    consistencyPct: $('prop-consistency') as HTMLInputElement,
  };

  const tabButtons: Record<string, HTMLButtonElement> = {
    performance: $('tab-performance') as HTMLButtonElement,
    montecarlo: $('tab-montecarlo') as HTMLButtonElement,
    propfirm: $('tab-propfirm') as HTMLButtonElement,
    views3d: $('tab-views3d') as HTMLButtonElement,
  };
  const panels: Record<string, HTMLElement> = {
    performance: $('panel-performance'),
    montecarlo: $('panel-montecarlo'),
    propfirm: $('panel-propfirm'),
    views3d: $('panel-views3d'),
  };

  document.querySelectorAll<HTMLElement>('#panel-views3d .bt-card').forEach((card) => {
    const chartEl = card.querySelector<HTMLElement>('[id]');
    const id = chartEl?.id;
    const title = card.querySelector('h3')?.textContent || '';
    if (id) enhanceCardHead(card, id, title);
  });

  return {
    csvInput,
    fileInput,
    runButton,
    clearButton,
    sampleButton,
    status,
    report,
    mcPathsInput,
    mcBlockInput,
    mcSeedInput,
    propPresetSelect,
    propFields,
    tabs: $('tabs'),
    tabButtons,
    panels,
    fanChart: $('fan-chart') as HTMLDivElement,
    surfaceChart: $('surface-chart') as HTMLDivElement,
    distributionChart: $('distribution-chart') as HTMLDivElement,
    tradeScatterChart: $('trade-scatter-chart') as HTMLDivElement,
    equitySurfaceChart: $('equity-surface-chart') as HTMLDivElement,
    varChart: $('var-chart') as HTMLDivElement,
    rollingVarChart: $('rolling-var-chart') as HTMLDivElement,
    rollingDdChart: $('rolling-dd-chart') as HTMLDivElement,
    riskScatterChart: $('risk-scatter-chart') as HTMLDivElement,
    mcMaxDdChart: $('mc-maxdd-chart') as HTMLDivElement,
    mcRiskScatterChart: $('mc-risk-scatter-chart') as HTMLDivElement,
    mcPercentileChart: $('mc-percentile-chart') as HTMLDivElement,
    sharpe3dChart: $('sharpe3d-chart') as HTMLDivElement,
    sortino3dChart: $('sortino3d-chart') as HTMLDivElement,
    acf3dChart: $('acf3d-chart') as HTMLDivElement,
    density3dChart: $('density3d-chart') as HTMLDivElement,
    calmar3dChart: $('calmar3d-chart') as HTMLDivElement,
    views3dDetail: $('views3d-detail') as HTMLDivElement,
    animateSelect: $('animate-3d') as HTMLSelectElement,
    metricValue: () => undefined,
  };
}

function enhanceCardHead(card: HTMLElement, chartId: string, title: string): void {
  if (card.querySelector('.chart-play')) return;
  const oldH3 = card.querySelector('h3');
  const head = element('div', 'card-head', undefined);
  head.appendChild(element('h3', undefined, title));
  const info = CHART_INFO[chartId];
  if (info) head.appendChild(infoBadge(info));
  const play = element('button', 'chart-play', '▶') as HTMLButtonElement;
  play.type = 'button';
  play.title = 'Play animation';
  head.appendChild(play);
  if (oldH3) card.replaceChild(head, oldH3);
  else card.insertBefore(head, card.firstChild);
  play.addEventListener('click', () => {
    const target = document.getElementById(chartId) as HTMLDivElement | null;
    if (target) playChart(target);
  });
}

export function bindTabs(refs: DomRefs): void {
  const resizeChartsInPanel = (panel: HTMLElement) => {
    if (!plotlyAvailable()) return;
    panel.querySelectorAll<HTMLDivElement>('.plot-chart').forEach((d) => {
      try {
        Plotly.Plots.resize(d);
      } catch {
        /* ignore */
      }
    });
  };
  Object.entries(refs.tabButtons).forEach(([key, button]) => {
    button.addEventListener('click', () => {
      Object.entries(refs.tabButtons).forEach(([otherKey, other]) => {
        other.classList.toggle('active', otherKey === key);
        other.setAttribute('aria-selected', otherKey === key ? 'true' : 'false');
      });
      Object.entries(refs.panels).forEach(([otherKey, panel]) => {
        panel.classList.toggle('visible', otherKey === key);
      });
      const panel = refs.panels[key];
      if (panel) {
        if (key === 'views3d' && lastData3D) {
          requestAnimationFrame(() => render3DViews(refs, lastData3D!));
        } else {
          requestAnimationFrame(() => resizeChartsInPanel(panel));
        }
      }
    });
  });
}

export function renderReport(refs: DomRefs, data: ReportData): void {
  const { metrics, monteCarlo, propFirm } = data;
  refs.report.classList.add('visible');

  const performance = refs.panels.performance;
  performance.textContent = '';

  {
    const gradeRow = element('div', 'grade-row', undefined);
    gradeRow.appendChild(element('div', 'grade', metrics.grade));
    const copy = element('div', 'grade-copy', undefined);
    copy.appendChild(element('strong', undefined, metrics.gradeLabel));
    copy.appendChild(
      element(
        'span',
        undefined,
        metrics.count >= 50
          ? 'Enough trades to take the breakdown seriously — but a higher grade needs strength on every pillar, not just a positive expectancy.'
          : metrics.count >= 20
          ? 'A modest sample — the grade is directional, not conclusive. Add more trades to harden it.'
          : 'A very small sample — the grade is barely indicative. Collect more trades before trusting it.'
      )
    );
    gradeRow.appendChild(copy);

    const breakdownHost = element('div', 'grade-breakdown', undefined);
    for (const sub of metrics.gradeBreakdown) {
      const row = element('div', 'grade-bar-row', undefined);
      row.appendChild(element('span', 'grade-bar-label', `${sub.category} · ${sub.score}/${sub.max}`));
      const bar = element('div', 'grade-bar-track', undefined);
      const fill = element('div', 'grade-bar-fill', undefined) as HTMLDivElement;
      const ratio = sub.max > 0 ? sub.score / sub.max : 0;
      fill.style.width = `${ratio * 100}%`;
      fill.style.background =
        ratio >= 0.75 ? 'var(--bt-green)' : ratio >= 0.45 ? 'var(--bt-amber)' : 'var(--bt-red)';
      bar.appendChild(fill);
      row.appendChild(bar);
      breakdownHost.appendChild(row);
    }

    const adviceList = element('ul', 'grade-advice', undefined);
    if (metrics.gradeAdvice.length === 0) {
      adviceList.appendChild(element('li', undefined, 'No weak pillars — the strategy scores well on profitability, consistency, risk control, robustness, and sample size.'));
    } else {
      for (const tip of metrics.gradeAdvice) adviceList.appendChild(element('li', undefined, tip));
    }

    performance.appendChild(
      buildCard('verdict-card', 'QuantPad verdict', [
        gradeRow,
        element('p', 'summary', `${metrics.gradeLabel} — ${metrics.gradeScore}/100 evidence score (${metrics.grade}).`),
        breakdownHost,
        element('h4', 'grade-advice-title', 'How to improve'),
        adviceList,
      ])
    );
  }

  const perfDetail = detailPanel('perf-detail');

  performance.appendChild(sectionTitle('Equity & P&L'));
  {
    const g = grid();
    const eq = chartCard('Equity curve', 'equity-chart', 'wide');
    g.appendChild(eq.card);
    renderEquityChart(eq.div, metrics, perfDetail);
    const pnl = chartCard('Per-trade P&L', 'pnl-chart', 'tall');
    g.appendChild(pnl.card);
    renderPnlBars(pnl.div, metrics, perfDetail);
    const vsidx = chartCard('P&L vs trade # (edge decay)', 'pnl-vs-index-chart');
    g.appendChild(vsidx.card);
    renderPnlVsIndex(vsidx.div, metrics);
    const hist = chartCard('Per-trade return distribution', 'returns-hist-chart');
    g.appendChild(hist.card);
    renderReturnHistogram(hist.div, metrics);
    const uwater = chartCard('Underwater drawdown', 'underwater-chart');
    g.appendChild(uwater.card);
    renderUnderwaterDrawdown(uwater.div, metrics);
    performance.appendChild(g);
  }
  performance.appendChild(perfDetail);

  performance.appendChild(sectionTitle('Risk & distribution'));
  {
    const g = grid();
    const box = chartCard('Returns box plot (wins vs losses)', 'box-chart');
    g.appendChild(box.card);
    renderReturnsBox(box.div, metrics);
    const rsharpe = chartCard('Rolling Sharpe', 'rolling-sharpe-chart');
    g.appendChild(rsharpe.card);
    renderRollingSharpe(rsharpe.div, metrics);
    const roll = chartCard('Rolling expectancy & win rate', 'rolling-chart');
    g.appendChild(roll.card);
    renderRollingMetrics(roll.div, metrics);
    const qq = chartCard('Q-Q plot vs normal', 'qq-chart');
    g.appendChild(qq.card);
    renderQQ(qq.div, metrics);
    performance.appendChild(g);
  }
  {
    const g = grid();
    const mh = chartCard('Monthly returns', 'monthly-heatmap-chart', 'wide');
    g.appendChild(mh.card);
    renderMonthlyHeatmap(mh.div, metrics);
    performance.appendChild(g);
  }

  performance.appendChild(sectionTitle('Streaks & relationships'));
  {
    const g = grid();
    const cwr = chartCard('Cumulative win rate', 'cum-winrate-chart');
    g.appendChild(cwr.card);
    renderCumulativeWinRate(cwr.div, metrics);
    const dir = chartCard('Long vs short performance', 'direction-chart');
    g.appendChild(dir.card);
    renderDirectionBreakdown(dir.div, metrics);
    const dow = chartCard('P&L by day of week', 'dow-heatmap-chart', 'wide');
    g.appendChild(dow.card);
    renderDayOfWeekHeatmap(dow.div, metrics);
    const weekly = chartCard('Weekly returns heatmap (cold → hot)', 'weekly-heatmap-chart', 'wide');
    g.appendChild(weekly.card);
    renderWeeklyHeatmap(weekly.div, metrics);
    performance.appendChild(g);
  }

  performance.appendChild(sectionTitle('Strategy improvement'));
  {
    const g = grid();
    const acf = chartCard('Return autocorrelation (entry timing)', 'acf-chart');
    g.appendChild(acf.card);
    renderAutocorrelation(acf.div, metrics);
    const dur = chartCard('Hold time vs P&L (cut winners/losers?)', 'duration-pnl-chart');
    g.appendChild(dur.card);
    renderDurationVsPnl(dur.div, metrics);
    const streaks = chartCard('Losing-streak distribution (sizing)', 'loss-streaks-chart');
    g.appendChild(streaks.card);
    renderLossStreaks(streaks.div, metrics);
    const kelly = chartCard('Position sizing (Kelly)', 'strategy-kelly-chart');
    g.appendChild(kelly.card);
    renderStrategyKelly(kelly.div, metrics);
    performance.appendChild(g);
  }
  {
    const g = grid();
    const monthly = chartCard('Monthly returns bar (seasonality)', 'monthly-bar-chart');
    g.appendChild(monthly.card);
    renderMonthlyReturnsBar(monthly.div, metrics);
    const cumwl = chartCard('Cumulative winners vs losers', 'cum-wl-chart');
    g.appendChild(cumwl.card);
    renderCumWinLoss(cumwl.div, metrics);
    const rec = chartCard('Loss recovery time (resilience)', 'loss-recovery-chart');
    g.appendChild(rec.card);
    renderLossRecovery(rec.div, metrics);
    const dir = chartCard('Long vs short cumulative', 'direction-over-time-chart');
    g.appendChild(dir.card);
    renderDirectionOverTime(dir.div, metrics);
    performance.appendChild(g);
  }

  performance.appendChild(sectionTitle('Summary'));
  const metricGrid = element('div', 'metric-grid', undefined);
  metricGrid.append(
    metric('Trades', String(metrics.count)),
    metric('Win rate', percent(metrics.winRate)),
    metric('Expectancy', signed(metrics.expectancy)),
    metric('Profit factor', Number.isFinite(metrics.profitFactor) ? number(metrics.profitFactor) : '∞'),
    metric('Net result', signed(metrics.netPnl)),
    metric('Max drawdown', signed(-metrics.maxDrawdown)),
    metric('Avg hold time', toIsoDate(metrics.avgHoldMs)),
    metric('Best / worst', `${signed(metrics.bestTrade)} / ${signed(metrics.worstTrade)}`)
  );
  const riskList = element('ul', 'risk-list', undefined);
  riskList.append(
    riskRow('Max drawdown', `${signed(-metrics.maxDrawdown)} (${percent(metrics.maxDrawdownPct)} from peak)`),
    riskRow('Outcome dispersion', number(metrics.standardDeviation)),
    riskRow('Sharpe-like ratio', number(metrics.sharpeLike)),
    riskRow('Max consecutive wins', String(metrics.maxConsecutiveWins)),
    riskRow('Max consecutive losses', String(metrics.maxConsecutiveLosses))
  );
  const avgWin = metrics.winCount > 0 ? metrics.grossWins / metrics.winCount : 0;
  const avgLoss = metrics.lossCount > 0 ? metrics.grossLosses / metrics.lossCount : 0;
  const payoff = avgLoss > 0 ? avgWin / avgLoss : avgWin > 0 ? Infinity : 0;
  const tradeStatsGrid = element('div', 'metric-grid', undefined);
  tradeStatsGrid.append(
    metric('Avg win', signed(avgWin)),
    metric('Avg loss', signed(-avgLoss)),
    metric('Payoff ratio', Number.isFinite(payoff) ? number(payoff, 2) : '∞'),
    metric('Largest win', signed(metrics.bestTrade)),
    metric('Largest loss', signed(metrics.worstTrade)),
    metric('R-expectancy', number(metrics.rExpectancy, 2)),
    metric('Win / loss count', `${metrics.winCount} / ${metrics.lossCount}`),
    metric('Std deviation', number(metrics.standardDeviation))
  );
  {
    const g = grid();
    g.appendChild(buildCard('metrics-card', 'Performance summary', [metricGrid]));
    g.appendChild(buildCard('metrics-card', 'Risk and robustness', [riskList]));
    g.appendChild(buildCard('metrics-card', 'Trade statistics', [tradeStatsGrid]));
    performance.appendChild(g);
  }

  {
    const v95 = varCvar(metrics.returns, 0.05);
    const v99 = varCvar(metrics.returns, 0.01);
    const varGrid = element('div', 'metric-grid', undefined);
    varGrid.append(
      metric('VaR 95%', signed(-v95.varVal)),
      metric('CVaR 95%', signed(-v95.cvar)),
      metric('VaR 99%', signed(-v99.varVal)),
      metric('CVaR 99%', signed(-v99.cvar)),
      metric('Worst trade', signed(metrics.worstTrade)),
      metric('Max drawdown', signed(-metrics.maxDrawdown))
    );
    const g = grid();
    g.appendChild(buildCard('metrics-card', 'Value at Risk (per trade)', [varGrid]));
    performance.appendChild(g);
  }

  performance.appendChild(sectionTitle('Calendar & trade log'));
  {
    const calDetail = detailPanel('cal-detail');
    const card = element('article', 'bt-card metrics-card', undefined);
    const head = element('div', 'card-head', undefined);
    head.appendChild(element('h3', undefined, 'Trading calendar — click a day to inspect'));
    head.appendChild(infoBadge('Each day colored by its net P&L (green = profit, red = loss). Click a day to see that day’s trades. Months flow 2-per-row.'));
    card.appendChild(head);
    const calHost = element('div', 'cal-host', undefined);
    card.appendChild(calHost);
    card.appendChild(calDetail);
    performance.appendChild(card);
    renderTradingCalendar(calHost, metrics, calDetail);
  }

  {
    const card = element('article', 'bt-card metrics-card', undefined);
    const head = element('div', 'card-head', undefined);
    head.appendChild(element('h3', undefined, 'Trade log'));
    head.appendChild(infoBadge('Every parsed trade in order: direction, entry/exit, size, P&L, cumulative equity, and drawdown at that point.'));
    card.appendChild(head);
    const host = element('div', undefined, undefined);
    card.appendChild(host);
    performance.appendChild(card);
    renderTradeLogTable(host, metrics);
  }

  const montePanel = refs.panels.montecarlo;
  montePanel.textContent = '';
  const mcGrid = element('div', 'metric-grid', undefined);
  mcGrid.append(
    metric('Terminal p5', signed(monteCarlo.p5)),
    metric('Median terminal', signed(monteCarlo.p50)),
    metric('Terminal p95', signed(monteCarlo.p95)),
    metric('Positive paths', percent(monteCarlo.positivePathsPct)),
    metric('Risk of ruin', percent(monteCarlo.riskOfRuinPct / 100)),
    metric('DD p95', signed(-monteCarlo.drawdownPercentiles.p95))
  );
  montePanel.appendChild(buildCard('metrics-card', 'Monte Carlo summary', [mcGrid]));

  {
    const g = grid();
    const bands = chartCard('Equity percentile bands', 'mc-bands-chart');
    g.appendChild(bands.card);
    renderMonteCarloBands(bands.div, monteCarlo);
    const dist = chartCard('Terminal outcome distribution', 'mc-dist-chart');
    g.appendChild(dist.card);
    renderTerminalDistribution(dist.div, monteCarlo);
    montePanel.appendChild(g);
  }
  {
    const mcDetail = detailPanel('mc-detail');
    const g = grid();
    const paths = chartCard('Individual paths — click to inspect', 'mc-paths-chart', 'wide');
    g.appendChild(paths.card);
    renderMonteCarloPaths(paths.div, monteCarlo, mcDetail);
    montePanel.appendChild(g);
    montePanel.appendChild(mcDetail);
  }

  montePanel.appendChild(sectionTitle('Monte Carlo analytics'));
  {
    const g = grid();
    const ddDist = chartCard('Max drawdown distribution', 'mc-dd-dist-chart');
    g.appendChild(ddDist.card);
    renderMcDrawdownDistribution(ddDist.div, monteCarlo);
    const sharpeDist = chartCard('Path Sharpe distribution', 'mc-sharpe-dist-chart');
    g.appendChild(sharpeDist.card);
    renderMcSharpeDistribution(sharpeDist.div, monteCarlo);
    const calmarDist = chartCard('Path Calmar distribution', 'mc-calmar-dist-chart');
    g.appendChild(calmarDist.card);
    renderMcCalmarDistribution(calmarDist.div, monteCarlo);
    const durDist = chartCard('Underwater duration distribution', 'mc-dd-duration-chart');
    g.appendChild(durDist.card);
    renderMcDrawdownDuration(durDist.div, monteCarlo);
    montePanel.appendChild(g);
  }
  {
    const g = grid();
    const ror = chartCard('Risk of ruin over time', 'mc-ror-chart');
    g.appendChild(ror.card);
    renderMcRiskOfRuin(ror.div, monteCarlo);
    const pop = chartCard('Probability of profit over time', 'mc-pop-chart');
    g.appendChild(pop.card);
    renderMcProbOfProfit(pop.div, monteCarlo);
    const cdf = chartCard('Terminal equity CDF', 'mc-cdf-chart');
    g.appendChild(cdf.card);
    renderMcTerminalCDF(cdf.div, monteCarlo);
    const ttd = chartCard('Time-to-max-drawdown', 'mc-ttd-chart');
    g.appendChild(ttd.card);
    renderMcTimeToDrawdown(ttd.div, monteCarlo);
    montePanel.appendChild(g);
  }
  {
    const g = grid();
    const uwater = chartCard('Underwater envelope (avg drawdown over time)', 'mc-underwater-chart', 'wide');
    g.appendChild(uwater.card);
    renderMcUnderwaterEnvelope(uwater.div, monteCarlo);
    montePanel.appendChild(g);
  }
  {
    const g = grid();
    const extreme = chartCard('Best / worst / median paths', 'mc-extreme-chart', 'wide');
    g.appendChild(extreme.card);
    renderMcExtremePaths(extreme.div, monteCarlo);
    montePanel.appendChild(g);
  }

  const footnote = element(
    'p',
    'footnote',
    `${monteCarlo.config.paths} paths, block size ${monteCarlo.config.blockSize}, seed ${monteCarlo.config.seed}.`
  );
  montePanel.appendChild(footnote);

  const propPanel = refs.panels.propfirm;
  propPanel.textContent = '';
  propPanel.appendChild(sectionTitle('Prop firm simulation'));
  const propGrid = element('div', 'metric-grid', undefined);
  propGrid.append(
    metric('Pass rate', percent(propFirm.passRatePct / 100)),
    metric('Fail rate', percent(propFirm.failRatePct / 100)),
    metric('Avg days to target', propFirm.averageDaysToTarget === null ? '—' : number(propFirm.averageDaysToTarget, 1)),
    metric('Expected value', signed(propFirm.expectedValue)),
    metric('Payout probability', percent(propFirm.payoutProbabilityPct / 100)),
    metric('Simulations', String(propFirm.runs))
  );
  propPanel.appendChild(buildCard('metrics-card', `${propFirm.config.name} — simulation`, [propGrid]));

  const passRate = propFirm.passRatePct / 100;
  const accountsToOnePass = passRate > 0 ? 1 / passRate : Infinity;
  const pAtLeast1in3 = 1 - Math.pow(1 - passRate, 3);
  const pAtLeast1in5 = 1 - Math.pow(1 - passRate, 5);
  const payoutPerPass = payoutPerPassFor(propFirm);
  const meetsMinPayout = payoutPerPass >= propFirm.config.minPayout;
  const effectivePayout = meetsMinPayout ? payoutPerPass : 0;
  const phasesPassRate = Math.pow(passRate, propFirm.config.phases);
  const payoutPerAttempt = passRate * payoutPerPass;
  const costPerFail = propFirm.config.challengeFee;
  const expPayout = passRate * effectivePayout;
  const expCost = (1 - passRate) * costPerFail;
  const breakEvenPassRate = costPerFail > 0 ? costPerFail / (costPerFail + effectivePayout) : 0;
  const profitFactorProp = expCost > 0 ? expPayout / expCost : expPayout > 0 ? Infinity : 0;
  const payoffRatio = costPerFail > 0 ? payoutPerPass / costPerFail : Infinity;
  const kellyFraction = effectivePayout > 0 ? propFirm.expectedValue / effectivePayout : 0;
  const edgePerFee = costPerFail > 0 ? (propFirm.expectedValue / costPerFail) * 100 : 0;
  const costToOnePass = Number.isFinite(accountsToOnePass)
    ? propFirm.config.challengeFee + Math.max(0, Math.ceil(accountsToOnePass) - 1) * propFirm.config.resetFee
    : Infinity;
  const netPerPass = payoutPerPass - (Number.isFinite(costToOnePass) ? costToOnePass : 0);
  const econGrid = element('div', 'metric-grid', undefined);
  econGrid.append(
    metric('Pass rate', percent(passRate)),
    metric('Avg profit at pass', propFirm.avgProfitAtPass === null ? '—' : signed(propFirm.avgProfitAtPass, 0)),
    metric('Profit split', percent(propFirm.config.payoutPct / 100)),
    metric('Payout per pass', signed(payoutPerPass, 0)),
    metric('Meets min payout', meetsMinPayout ? `yes (≥ ${number(propFirm.config.minPayout, 0)})` : `no (< ${number(propFirm.config.minPayout, 0)})`),
    metric('Net EV / attempt', signed(propFirm.expectedValue, 0)),
    metric('Expected payout / attempt', signed(payoutPerAttempt, 0)),
    metric('Challenge fee (per fail)', signed(-costPerFail, 0)),
    metric('Reset fee', signed(-propFirm.config.resetFee, 0)),
    metric('Accounts to one pass', Number.isFinite(accountsToOnePass) ? number(accountsToOnePass, 2) : '∞'),
    metric('Expected cost to one pass', Number.isFinite(costToOnePass) ? signed(-costToOnePass, 0) : '∞'),
    metric('Net per pass (after fees)', signed(netPerPass, 0)),
    metric('Phases pass rate', `×${propFirm.config.phases} = ${percent(phasesPassRate)}`),
    metric('Break-even pass rate', percent(breakEvenPassRate)),
    metric('Profit factor (prop)', Number.isFinite(profitFactorProp) ? number(profitFactorProp, 2) : '∞'),
    metric('Payoff ratio (payout/fee)', Number.isFinite(payoffRatio) ? number(payoffRatio, 1) : '∞'),
    metric('Kelly fraction', percent(Math.max(0, kellyFraction))),
    metric('Edge per fee', `${edgePerFee >= 0 ? '+' : ''}${edgePerFee.toFixed(0)}%`),
    metric('P(≥1 pass · 3 accts)', percent(pAtLeast1in3)),
    metric('P(≥1 pass · 5 accts)', percent(pAtLeast1in5)),
    metric('Target / account', percent(propFirm.config.profitTarget / propFirm.config.accountSize)),
    metric('Scaling on pass', `×${propFirm.config.scaling}`),
    metric('Drawdown type', propFirm.config.trailingDrawdown ? 'trailing' : 'static'),
    metric('Consistency rule', propFirm.config.consistencyPct > 0 ? `max ${propFirm.config.consistencyPct}%/day` : 'disabled'),
    metric('Payout frequency', `every ${propFirm.config.payoutDays}d`),
    metric('Avg days to target', propFirm.averageDaysToTarget === null ? '—' : number(propFirm.averageDaysToTarget, 1))
  );
  propPanel.appendChild(buildCard('metrics-card', 'Prop firm economics (your real money)', [econGrid]));
  propPanel.appendChild(
    element(
      'p',
      'footnote',
      `Payout per pass is computed from the average profit actually earned when passing (${propFirm.avgProfitAtPass === null ? 'target' : number(propFirm.avgProfitAtPass, 0)}) × the ${propFirm.config.payoutPct}% profit split${meetsMinPayout ? '' : ' — below the minimum withdrawal, so it is held until it accumulates'}. Prop balance is the firm’s money; you only risk the fee from your real balance (lost on fail, refunded on pass).`
    )
  );

  {
    const g = grid();
    const ev = chartCard('Expected value breakdown (per attempt)', 'ev-waterfall-chart');
    g.appendChild(ev.card);
    renderEvWaterfall(ev.div, propFirm);
    const avg = chartCard('Average equity path vs target', 'avg-path-chart');
    g.appendChild(avg.card);
    renderAverageEquityPath(avg.div, propFirm);
    propPanel.appendChild(g);
  }

  {
    const g = grid();
    const donut = chartCard('Pass / fail outcome', 'prop-donut-chart', 'tall');
    g.appendChild(donut.card);
    renderPropDonut(donut.div, propFirm);
    const payout = chartCard('Payout probability', 'prop-payout-donut-chart', 'tall');
    g.appendChild(payout.card);
    renderPayoutDonut(payout.div, propFirm);
    propPanel.appendChild(g);
  }

  {
    const g = grid();
    const prob = chartCard('Pass probability (≥1 pass in N accounts)', 'prop-prob-chart');
    g.appendChild(prob.card);
    renderPassProbabilityCurve(prob.div, propFirm);
    const growth = chartCard('Real balance growth over N accounts', 'prop-growth-chart');
    g.appendChild(growth.card);
    renderAccountGrowth(growth.div, propFirm);
    propPanel.appendChild(g);
  }

  propPanel.appendChild(sectionTitle('Economics analysis'));
  {
    const g = grid();
    const evpr = chartCard('EV vs pass rate (break-even)', 'prop-evpr-chart');
    g.appendChild(evpr.card);
    renderEvVsPassRate(evpr.div, propFirm);
    const kelly = chartCard('Kelly growth vs bet fraction', 'prop-kelly-chart');
    g.appendChild(kelly.card);
    renderKellyGrowth(kelly.div, propFirm);
    const ror = chartCard('Risk of ruin over N accounts', 'prop-ror-chart');
    g.appendChild(ror.card);
    renderRiskOfRuinAccounts(ror.div, propFirm);
    const payoff = chartCard('Payoff ratio (payout vs fee)', 'prop-payoff-chart', 'tall');
    g.appendChild(payoff.card);
    renderPayoffRatioBar(payoff.div, propFirm);
    const pf = chartCard('Profit factor vs pass rate', 'prop-pf-chart');
    g.appendChild(pf.card);
    renderProfitFactorVsPassRate(pf.div, propFirm);
    propPanel.appendChild(g);
  }

  propPanel.appendChild(sectionTitle('Run outcomes'));
  {
    const propDetail = detailPanel('prop-detail');
    const g = grid();
    const runs = chartCard('Sample run equity paths — click to inspect', 'prop-runs-chart', 'wide');
    g.appendChild(runs.card);
    renderPropSamplePaths(runs.div, propFirm, propDetail);
    propPanel.appendChild(g);
    propPanel.appendChild(propDetail);
  }
  {
    const g = grid();
    const term = chartCard('Run P&L distribution (pass vs fail)', 'prop-terminal-chart');
    g.appendChild(term.card);
    renderPropTerminalDistribution(term.div, propFirm);
    const days = chartCard('Days to target (passing runs)', 'prop-days-chart', 'tall');
    g.appendChild(days.card);
    renderDaysToTarget(days.div, propFirm);
    const fail = chartCard('Failure modes', 'prop-failures-chart', 'tall');
    g.appendChild(fail.card);
    renderFailureBar(fail.div, propFirm);
    propPanel.appendChild(g);
  }

  const failureList = element('ul', 'risk-list', undefined);
  if (propFirm.failures.length === 0) {
    failureList.appendChild(element('li', undefined, 'No failures recorded in this run.'));
  } else {
    for (const failure of propFirm.failures) {
      failureList.appendChild(
        riskRow(failure.reason, `${failure.count} (${percent(failure.pct)})`)
      );
    }
  }
  propPanel.appendChild(buildCard('metrics-card', 'Failure modes', [failureList]));

  refs.metricValue = () => undefined;

  lastData3D = data;
  if (refs.panels.views3d.classList.contains('visible')) {
    render3DViews(refs, data);
  }

  requestAnimationFrame(() => {
    if (!plotlyAvailable()) return;
    document.querySelectorAll<HTMLElement>('.plot-chart').forEach((d) => {
      if (d.clientWidth > 0 && d.clientHeight > 0) {
        try {
          Plotly.Plots.resize(d);
        } catch {
          /* ignore */
        }
      }
    });
  });
}

const METRIC_INFO: Record<string, string> = {
  Trades: 'Number of usable trades parsed from your log. More trades = more confidence in every other metric.',
  'Win rate': 'Share of trades that closed in profit.',
  Expectancy: 'Average P&L per trade. Positive = the edge pays you per trade over the long run.',
  'Profit factor': 'Gross wins ÷ gross losses. Above 1 = profitable; above 1.5 = solid.',
  'Net result': 'Total P&L across all trades.',
  'Max drawdown': 'Worst peak-to-trough drop in the equity curve.',
  'Avg hold time': 'Average time a position was held (from dated trades).',
  'Best / worst': 'Largest single win and largest single loss.',
  'Avg win': 'Average profit on a winning trade.',
  'Avg loss': 'Average loss on a losing trade.',
  'Payoff ratio': 'Avg win ÷ avg loss. How big winners are vs losers.',
  'Largest win': 'Single biggest winning trade.',
  'Largest loss': 'Single biggest losing trade.',
  'R-expectancy': 'Expectancy in units of risk (return per unit of std deviation).',
  'Win / loss count': 'Number of winning trades vs losing trades.',
  'Std deviation': 'Dispersion of per-trade returns. Higher = more volatile P&L.',
  'VaR 95%': 'Value at Risk — the loss you’d exceed only 5% of the time per trade.',
  'CVaR 95%': 'Conditional VaR (expected shortfall) — the average loss in the worst 5%.',
  'VaR 99%': 'The loss exceeded only 1% of the time.',
  'CVaR 99%': 'Average loss in the worst 1%.',
  'Terminal p5': '5th-percentile ending equity across Monte Carlo paths (worst plausible).',
  'Median terminal': '50th-percentile ending equity (typical outcome).',
  'Terminal p95': '95th-percentile ending equity (best plausible).',
  'Positive paths': 'Share of Monte Carlo paths that ended in profit.',
  'Risk of ruin': 'Share of paths that ended below zero.',
  'DD p95': '95th-percentile drawdown across paths (worst-case drawdown).',
  'Pass rate': 'Share of simulated attempts that passed the firm rules.',
  'Fail rate': 'Share of attempts that failed (breached a limit or ran out of time).',
  'Avg days to target': 'Mean days passing runs took to reach the profit target.',
  'Expected value': 'Net expected $ per attempt (payout on pass − fee on fail).',
  'Payout probability': 'Probability of getting a payout = pass rate per attempt.',
  Simulations: 'Number of bootstrapped runs simulated.',
  'Payout per pass': 'Dollars you receive on a pass = profit target × payout %.',
  'Challenge fee (per fail)': 'The fee you lose from your real balance when an attempt fails.',
  'Net EV / attempt': 'Expected change to your real balance per attempt.',
  'Expected payout / attempt': 'Pass rate × payout per pass.',
  'Accounts to one pass': 'Expected attempts needed for one pass = 1 ÷ pass rate.',
  'Expected cost to one pass': 'Fees you’d pay to get one pass = accounts to pass × fee.',
  'Net per pass (after fees)': 'Payout per pass minus the fees spent to get there.',
  'Break-even pass rate': 'The pass rate at which EV = 0. Below this, the firm is not worth trying.',
  'Profit factor (prop)': 'Expected payout ÷ expected cost per attempt.',
  'Payoff ratio (payout/fee)': 'Payout per pass ÷ fee. How many fees one payout covers.',
  'Kelly fraction': 'Optimal share of your bankroll to risk per attempt (full Kelly).',
  'Edge per fee': 'EV as a % of the fee — return per dollar of fee paid.',
  'P(≥1 pass · 3 accts)': 'Probability of at least one pass in 3 attempts.',
  'P(≥1 pass · 5 accts)': 'Probability of at least one pass in 5 attempts.',
  'Target / account': 'Profit target as a % of the firm’s balance.',
  'Consistency rule': 'Max profit a single day can contribute as % of the target. A run that hits the target on one big day fails this rule.',
  'Drawdown type': 'Static = the loss limit is fixed; trailing = it tightens as your balance rises (harder).',
  'Payout frequency': 'How often you can withdraw from the funded account (informational).',
  'Scaling on pass': 'Account-size multiplier applied after passing (scaling plan); affects future payouts.',
  'Phases pass rate': 'Combined pass rate across all phases = single-phase pass rate raised to the phase count.',
};

function metric(label: string, value: string): HTMLElement {
  const card = element('div', 'metric-card', undefined);
  card.appendChild(element('div', 'metric-label', label));
  card.appendChild(element('div', 'metric-value', value));
  const hint = METRIC_INFO[label];
  if (hint) card.appendChild(element('div', 'metric-hint', hint));
  return card;
}

function riskRow(label: string, value: string): HTMLElement {
  const row = element('li', undefined, undefined);
  row.appendChild(element('span', undefined, label));
  row.appendChild(element('strong', undefined, value));
  return row;
}

const CARD_INFO: Record<string, string> = {
  'QuantPad verdict': 'An overall grade built from 5 pillars (profitability, consistency, risk control, robustness, sample size). It’s only as strong as the weakest pillar — a positive expectancy alone won’t earn an A.',
  'Performance summary': 'The headline numbers for the backtest. Hover any tile for what it means.',
  'Risk and robustness': 'How volatile and how reliable the edge is — drawdown, dispersion, Sharpe-like ratio, and worst winning/losing streaks.',
  'Trade statistics': 'Per-trade shape of the edge — average win/loss, payoff ratio, largest win/loss, and R-expectancy.',
  'Value at Risk (per trade)': 'Tail-risk per trade. VaR is the loss exceeded only X% of the time; CVaR is the average loss in that worst tail.',
  'Monte Carlo summary': 'Outcome distribution from bootstrapped resampling. p5/p50/p95 = the worst / typical / best plausible ending equity.',
  'Prop firm economics (your real money)': 'Your real-balance economics: you pay the fee (lost on fail, refunded on pass) and receive the payout on pass. The prop balance is the firm’s money, not yours.',
  'Failure modes': 'Why attempts failed — daily-loss breach, max-drawdown breach, or running out of evaluation days.',
};

function infoBadge(text: string): HTMLElement {
  const badge = element('span', 'chart-info', 'i');
  badge.appendChild(element('span', 'chart-info-tip', text));
  return badge;
}

function buildCard(className: string, title: string, children: HTMLElement[]): HTMLElement {
  const card = element('article', `report-card ${className}`, undefined);
  const head = element('div', 'card-head', undefined);
  head.appendChild(element('h3', undefined, title));
  const info = CARD_INFO[title] || (title.endsWith('— simulation') ? 'Pass/fail results from simulating the firm rules (target, daily loss, max drawdown, evaluation days) on resampled trades sized to the firm’s balance.' : '');
  if (info) head.appendChild(infoBadge(info));
  card.appendChild(head);
  children.forEach((child) => card.appendChild(child));
  return card;
}

let threeDObserver: IntersectionObserver | null = null;
const threeDState = new Map<HTMLDivElement, { render: () => void; rendered: boolean }>();

export function setup3DLazy(refs: DomRefs, data: ReportData): void {
  if (!plotlyAvailable()) return;
  fillDetail(refs.views3dDetail, 'Click to inspect', [['Hint', 'Click any point on the trade scatter above.']]);
  const items: Array<{ div: HTMLDivElement; render: () => void }> = [
    { div: refs.fanChart, render: () => renderFan3D(refs.fanChart, data.monteCarlo) },
    { div: refs.surfaceChart, render: () => renderSurface3D(refs.surfaceChart, data.monteCarlo) },
    { div: refs.distributionChart, render: () => renderDistribution3D(refs.distributionChart, data.monteCarlo) },
    { div: refs.tradeScatterChart, render: () => renderTradeScatter3D(refs.tradeScatterChart, data.metrics, refs.views3dDetail) },
    { div: refs.equitySurfaceChart, render: () => renderEquitySurface3D(refs.equitySurfaceChart, data.monteCarlo) },
    { div: refs.varChart, render: () => renderReturnDist3D(refs.varChart, data.metrics) },
    { div: refs.rollingVarChart, render: () => renderRollingVar3D(refs.rollingVarChart, data.metrics) },
    { div: refs.rollingDdChart, render: () => renderRollingDd3D(refs.rollingDdChart, data.metrics) },
    { div: refs.riskScatterChart, render: () => renderRiskScatter3D(refs.riskScatterChart, data.metrics, refs.views3dDetail) },
    { div: refs.mcMaxDdChart, render: () => renderMcMaxDd3D(refs.mcMaxDdChart, data.monteCarlo) },
    { div: refs.mcRiskScatterChart, render: () => renderMcRiskScatter3D(refs.mcRiskScatterChart, data.monteCarlo, refs.views3dDetail) },
    { div: refs.mcPercentileChart, render: () => renderMcPercentile3D(refs.mcPercentileChart, data.monteCarlo) },
    { div: refs.sharpe3dChart, render: () => renderRollingSharpe3D(refs.sharpe3dChart, data.metrics) },
    { div: refs.sortino3dChart, render: () => renderRollingSortino3D(refs.sortino3dChart, data.metrics) },
    { div: refs.acf3dChart, render: () => renderAcAutocorrelation3D(refs.acf3dChart, data.metrics) },
    { div: refs.density3dChart, render: () => renderEquityDensity3D(refs.density3dChart, data.monteCarlo) },
    { div: refs.calmar3dChart, render: () => renderRollingCalmar3D(refs.calmar3dChart, data.metrics) },
  ];
  threeDState.clear();
  items.forEach((it) => {
    releaseAutoplay(it.div);
    try { Plotly.purge(it.div); } catch { /* ignore */ }
    threeDState.set(it.div, { render: it.render, rendered: false });
  });
  if (threeDObserver) threeDObserver.disconnect();
  threeDObserver = new IntersectionObserver(
    (entries) => {
      for (const e of entries) {
        const st = threeDState.get(e.target as HTMLDivElement);
        if (!st) continue;
        if (e.isIntersecting && !st.rendered) {
          st.render();
          st.rendered = true;
        } else if (!e.isIntersecting && st.rendered) {
          releaseAutoplay(e.target as HTMLDivElement);
          try { Plotly.purge(e.target as HTMLDivElement); } catch { /* ignore */ }
          st.rendered = false;
        }
      }
    },
    { rootMargin: '300px 0px', threshold: 0.01 }
  );
  items.forEach((it) => threeDObserver!.observe(it.div));
}

export function render3DViews(refs: DomRefs, data: ReportData): void {
  setup3DLazy(refs, data);
}

export function populatePropPresets(refs: DomRefs): void {
  refs.propPresetSelect.textContent = '';
  for (const preset of PROP_FIRM_PRESETS) {
    const option = element('option', undefined, preset.name);
    option.value = preset.name;
    refs.propPresetSelect.appendChild(option);
  }
  refs.propPresetSelect.value = PROP_FIRM_PRESETS[0].name;
  applyPropConfig(refs, PROP_FIRM_PRESETS[0]);
}

export function applyPropConfig(refs: DomRefs, config: PropFirmConfig): void {
  refs.propFields.name.value = config.name;
  refs.propFields.accountSize.value = String(config.accountSize);
  refs.propFields.profitTarget.value = String(config.profitTarget);
  refs.propFields.maxDailyLoss.value = String(config.maxDailyLoss);
  refs.propFields.maxTotalDrawdown.value = String(config.maxTotalDrawdown);
  refs.propFields.evaluationDays.value = String(config.evaluationDays);
  refs.propFields.payoutPct.value = String(config.payoutPct);
  refs.propFields.challengeFee.value = String(config.challengeFee);
  refs.propFields.minPayout.value = String(config.minPayout);
  refs.propFields.payoutDays.value = String(config.payoutDays);
  refs.propFields.trailingDrawdown.value = String(config.trailingDrawdown ? 1 : 0);
  refs.propFields.resetFee.value = String(config.resetFee);
  refs.propFields.scaling.value = String(config.scaling);
  refs.propFields.phases.value = String(config.phases);
  refs.propFields.consistencyPct.value = String(config.consistencyPct);
}

export function readPropConfig(refs: DomRefs): PropFirmConfig {
  const read = (key: string, fallback: number): number => {
    const parsed = Number(refs.propFields[key].value);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
  };
  const readNonNeg = (key: string, fallback: number): number => {
    const parsed = Number(refs.propFields[key].value);
    return Number.isFinite(parsed) && parsed >= 0 ? parsed : fallback;
  };
  return {
    name: refs.propFields.name.value.trim() || 'Custom firm',
    accountSize: read('accountSize', 100000),
    profitTarget: read('profitTarget', 10000),
    maxDailyLoss: read('maxDailyLoss', 5000),
    maxTotalDrawdown: read('maxTotalDrawdown', 10000),
    evaluationDays: Math.round(read('evaluationDays', 30)),
    payoutPct: Math.min(100, Math.max(0, read('payoutPct', 80))),
    challengeFee: readNonNeg('challengeFee', 549),
    minPayout: readNonNeg('minPayout', 1000),
    payoutDays: Math.round(read('payoutDays', 14)),
    trailingDrawdown: Number(refs.propFields.trailingDrawdown.value) >= 1,
    resetFee: readNonNeg('resetFee', 549),
    scaling: Math.max(1, read('scaling', 1)),
    phases: Math.min(3, Math.max(1, Math.round(read('phases', 1)))),
    consistencyPct: Math.min(100, Math.max(0, readNonNeg('consistencyPct', 50))),
  };
}
