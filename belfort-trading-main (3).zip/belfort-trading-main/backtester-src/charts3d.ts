export interface ThreeDPoint {
  x: number;
  y: number;
  z: number;
}

export interface ThreeDSeries {
  label: string;
  points: ThreeDPoint[];
}

export interface ThreeDChartData {
  type: 'fan' | 'surface' | 'distribution';
  title: string;
  /** x, y, z labels for the axes. */
  axes: [string, string, string];
  series: ThreeDSeries[];
}

function project(
  point: ThreeDPoint,
  rotationY: number,
  rotationX: number,
  centerX: number,
  centerY: number,
  scale: number,
  distance: number
): { x: number; y: number; z: number; depth: number } {
  const cosY = Math.cos(rotationY);
  const sinY = Math.sin(rotationY);
  const cosX = Math.cos(rotationX);
  const sinX = Math.sin(rotationX);

  const x1 = point.x * cosY - point.z * sinY;
  const z1 = point.x * sinY + point.z * cosY;
  const y1 = point.y;

  const y2 = y1 * cosX - z1 * sinX;
  const z2 = y1 * sinX + z1 * cosX;

  const perspective = distance / (distance - z2);
  return {
    x: centerX + x1 * scale * perspective,
    y: centerY - y2 * scale * perspective,
    z: z2,
    depth: z2,
  };
}

interface ProjectedPoint {
  x: number;
  y: number;
  depth: number;
}

function drawAxes(
  context: CanvasRenderingContext2D,
  corners: ProjectedPoint[],
  labels: [string, string, string],
  color: string,
  fontSize: number
): void {
  context.strokeStyle = color;
  context.lineWidth = 1;
  context.beginPath();
  corners.forEach((corner, index) => {
    if (index === 0) context.moveTo(corner.x, corner.y);
    else context.lineTo(corner.x, corner.y);
  });
  context.closePath();
  context.stroke();

  context.fillStyle = color;
  context.font = `${fontSize}px Inter, system-ui, sans-serif`;
  context.textAlign = 'center';
  const midX = (corners[0].x + corners[1].x) / 2;
  const midZ = (corners[2].x + corners[3].x) / 2;
  context.fillText(labels[0], (midX + corners[0].x) / 2, corners[0].y - 6);
  context.fillText(labels[1], (corners[0].x + corners[2].x) / 2, corners[0].y + 14);
  context.fillText(labels[2], (midZ + corners[3].x) / 2, corners[3].y - 6);
}

export function render3DChart(
  canvas: HTMLCanvasElement,
  data: ThreeDChartData,
  palette: string[],
  reducedMotion: boolean
): void {
  const context = canvas.getContext('2d');
  if (!context || data.series.length === 0) return;

  const width = canvas.clientWidth || 640;
  const height = canvas.clientHeight || 400;
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.round(width * dpr);
  canvas.height = Math.round(height * dpr);
  context.setTransform(dpr, 0, 0, dpr, 0, 0);
  context.clearRect(0, 0, width, height);

  const colors = getComputedStyle(canvas);
  const axisColor = colors.color || '#9ca3af';

  const values = data.series.flatMap((series) => series.points);
  if (values.length === 0) {
    context.fillStyle = axisColor;
    context.font = '13px Inter, system-ui, sans-serif';
    context.textAlign = 'center';
    context.fillText('No data to render yet.', width / 2, height / 2);
    return;
  }

  const minX = Math.min(...values.map((point) => point.x));
  const maxX = Math.max(...values.map((point) => point.x));
  const minY = Math.min(...values.map((point) => point.y));
  const maxY = Math.max(...values.map((point) => point.y));
  const minZ = Math.min(...values.map((point) => point.z));
  const maxZ = Math.max(...values.map((point) => point.z));
  const rangeX = maxX - minX || 1;
  const rangeY = maxY - minY || 1;
  const rangeZ = maxZ - minZ || 1;

  const scale = Math.min(width, height) * 0.34;
  const centerX = width / 2;
  const centerY = height / 2 + 12;
  const distance = 5;

  const normalize = (point: ThreeDPoint): ThreeDPoint => ({
    x: (point.x - minX) / rangeX - 0.5,
    y: (point.y - minY) / rangeY - 0.5,
    z: (point.z - minZ) / rangeZ - 0.5,
  });

  const rotationY = reducedMotion ? Math.PI / 4.2 : Math.PI / 4.2 + Math.sin(performance.now() / 5000) * 0.22;
  const rotationX = 0.42;

  const boxCorners: ProjectedPoint[] = [
    { x: -0.5, y: -0.5, z: -0.5 },
    { x: 0.5, y: -0.5, z: -0.5 },
    { x: 0.5, y: -0.5, z: 0.5 },
    { x: -0.5, y: -0.5, z: 0.5 },
  ].map((corner) => project(corner, rotationY, rotationX, centerX, centerY, scale, distance));

  const projected = data.series.map((series) => ({
    label: series.label,
    points: series.points.map((point) =>
      project(normalize(point), rotationY, rotationX, centerX, centerY, scale, distance)
    ),
  }));

  drawAxes(context, boxCorners, data.axes, axisColor, 11);

  const sorted = projected.slice().sort((a, b) => {
    const aDepth = a.points.reduce((sum, point) => sum + point.depth, 0) / a.points.length;
    const bDepth = b.points.reduce((sum, point) => sum + point.depth, 0) / b.points.length;
    return aDepth - bDepth;
  });

  if (data.type === 'distribution') {
    for (let seriesIndex = 0; seriesIndex < sorted.length; seriesIndex += 1) {
      const series = sorted[seriesIndex];
      context.fillStyle = palette[seriesIndex % palette.length];
      context.globalAlpha = 0.65;
      series.points.forEach((point, index) => {
        if (index % 2 !== 0) return;
        const top = point;
        const bottom = project(
          normalize({ x: 0, y: 0, z: 0 }),
          rotationY,
          rotationX,
          centerX,
          centerY,
          scale,
          distance
        );
        context.fillRect(top.x - 3, top.y, 6, bottom.y - top.y);
      });
      context.globalAlpha = 1;
    }
  } else {
    for (let seriesIndex = 0; seriesIndex < sorted.length; seriesIndex += 1) {
      const series = sorted[seriesIndex];
      context.strokeStyle = palette[seriesIndex % palette.length];
      context.lineWidth = 1.4;
      context.globalAlpha = 0.85;
      context.beginPath();
      series.points.forEach((point, index) => {
        if (index === 0) context.moveTo(point.x, point.y);
        else context.lineTo(point.x, point.y);
      });
      context.stroke();
      context.globalAlpha = 1;
    }
  }

  context.globalAlpha = 1;
  context.fillStyle = axisColor;
  context.font = '11px Inter, system-ui, sans-serif';
  context.textAlign = 'center';
  context.fillText(data.title, width / 2, 16);
}
