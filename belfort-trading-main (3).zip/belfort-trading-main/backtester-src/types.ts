export interface Trade {
  /** Raw index in the source log (1-based row). */
  row: number;
  /** ISO-ish string if the log provided a date, otherwise null. */
  date: string | null;
  /** Trade direction: long, short, or unknown. */
  direction: 'long' | 'short' | 'unknown';
  /** Entry price, if provided. */
  entry: number | null;
  /** Exit price, if provided. */
  exit: number | null;
  /** Quantity/size, if provided. */
  size: number | null;
  /** Fee paid for this trade, if provided. */
  fee: number;
  /** Net P&L for the trade (includes fee when applicable). */
  pnl: number;
}

export interface TradeLog {
  trades: Trade[];
  /** How many source rows were skipped because they were unusable. */
  ignored: number;
  /** Which fields were detected in the source CSV. */
  detected: string[];
  /** True when the P&L column was derived from entry/exit/size. */
  derivedPnl: boolean;
  /** True when the log carried a usable date column. */
  hasDates: boolean;
}

export interface TradeDetail {
  index: number;
  date: string | null;
  direction: 'long' | 'short' | 'unknown';
  entry: number | null;
  exit: number | null;
  size: number | null;
  pnl: number;
  equity: number;
  drawdown: number;
}

export type RegimeLabel = 'Bull·Low Vol' | 'Bull·High Vol' | 'Bear·Low Vol' | 'Bear·High Vol';

export interface RegimePoint {
  index: number;
  trend: 'bull' | 'bear';
  volatility: 'low' | 'high';
  regime: RegimeLabel;
  /** Short-window regime (entry/exit attribution). */
  shortRegime: RegimeLabel;
  /** Long-window regime (dominant attribution). */
  longRegime: RegimeLabel;
}

export interface RegimeStats {
  regime: RegimeLabel;
  color: string;
  exposurePct: number;
  netPnl: number;
  winRate: number;
  trades: number;
  avgTrade: number;
}

export interface RegimeEquityBand {
  start: number;
  end: number;
  regime: RegimeLabel;
  color: string;
}

export interface RegimeMCResult {
  paths: number[][];
  terminals: number[];
  p5: number;
  p50: number;
  p95: number;
  positivePathsPct: number;
  underwaterPct: number;
  drawdownPercentiles: { p5: number; p50: number; p95: number };
  config: { paths: number; blockSize: number; seed: number; regimeAware: boolean };
}

export interface Metrics {
  count: number;
  winCount: number;
  lossCount: number;
  winRate: number;
  grossWins: number;
  grossLosses: number;
  profitFactor: number;
  netPnl: number;
  expectancy: number;
  rExpectancy: number;
  standardDeviation: number;
  sharpeLike: number;
  maxDrawdown: number;
  maxDrawdownPct: number;
  maxConsecutiveWins: number;
  maxConsecutiveLosses: number;
  avgHoldMs: number | null;
  bestTrade: number;
  worstTrade: number;
  equity: number[];
  drawdownSeries: number[];
  /** P&L of each trade in chronological order. */
  returns: number[];
  /** ISO date per trade (null when the log has no date for that trade). */
  tradeDates: (string | null)[];
  /** Net P&L bucketed by calendar month (only when the log has dates). */
  monthlyReturns: Array<{ year: number; month: number; pnl: number }>;
  /** Per-trade detail aligned with returns/equity (used by calendar + trade table). */
  tradeDetails: TradeDetail[];
  grade: string;
  gradeLabel: string;
  gradeScore: number;
  gradeBreakdown: Array<{ category: string; score: number; max: number }>;
  gradeAdvice: string[];
  // ── Institutional extensions (added; existing fields above stay compatible) ──
  /** Annualization factor used to scale per-trade stats. Derived from avgHoldMs
   *  when the log has dates; otherwise 252 (the daily default). */
  tradesPerYear: number;
  /** Per-trade mean × tradesPerYear. CAGR-like when the log spans dates; otherwise the
   *  arithmetic annualization of the per-trade expectancy. */
  annualizedReturn: number;
  /** Per-trade standard deviation × sqrt(tradesPerYear). */
  annualizedVolatility: number;
  /** Annualized Sharpe ratio (rf = 0). The old `sharpeLike` is kept for back-compat. */
  sharpe: number;
  /** Annualized Sortino ratio — uses downside deviation (returns < 0). */
  sortino: number;
  /** Annualized return / |maxDrawdown|. */
  calmar: number;
  /** Omega ratio at threshold 0: sum(wins) / |sum(losses)|. */
  omega: number;
  /** |p95| / |p5| of the per-trade return distribution (tail asymmetry). */
  tailRatio: number;
  /** Historical 95% Value at Risk per trade (a loss; reported as a positive number). */
  valueAtRisk95: number;
  /** Conditional VaR (expected shortfall) at 95% — the mean of losses beyond VaR. */
  cvar95: number;
  /** Longest drawdown duration, in trades. */
  maxDrawdownDuration: number;
  /** Longest drawdown duration in days (only when the log has dates; null otherwise). */
  maxDrawdownDurationDays: number | null;
  /** Net P&L / |maxDrawdown|. */
  recoveryFactor: number;
  /** Ulcer index: sqrt(mean(drawdown%^2)) over the equity path. */
  ulcerIndex: number;
  /** Sum of wins / |sum of losses| (gain-to-pain). */
  gainPain: number;
  /** Mean of winning trades. */
  avgWin: number;
  /** Mean of losing trades (a negative number). */
  avgLoss: number;
  /** avgWin / |avgLoss|. */
  winLossRatio: number;
  /** Sample skewness of the per-trade returns. */
  skewness: number;
  /** Sample excess kurtosis of the per-trade returns. */
  kurtosis: number;
  /** Benchmark name when one was supplied; null otherwise. */
  benchmark: string | null;
  /** Beta vs the benchmark (cov / var_bench). Null without a benchmark. */
  beta: number | null;
  /** Per-trade alpha vs the benchmark (mean_y − beta × mean_bench). Null without one. */
  alpha: number | null;
  /** Information ratio vs the benchmark: mean(active) / std(active) × sqrt(tpy). Null without one. */
  informationRatio: number | null;
  /** Sum of |entry × size| across trades / starting capital, when entry and size are
   *  present; null otherwise. A rough single-sided turnover proxy. */
  turnover: number | null;
}

export interface ComputeMetricsOptions {
  /** Optional benchmark to compute beta/alpha/information ratio. The benchmark
   *  returns must be per-period (not per-trade) and align roughly in time with the
   *  trade log; the engine aligns by index when lengths differ. */
  benchmark?: { name: string; returns: number[] };
}

// ── Overfit / robustness module (overfit.ts) ──

export interface StationaryBootstrapConfig {
  paths: number;
  /** Mean block length for the Politis–Romano stationary bootstrap. Use
   *  `autoBlockSize()` to choose from the autocorrelation structure. */
  blockLength: number;
  seed: number;
  /** Optional starting balance for equity paths (default 0). */
  startingBalance?: number;
}

export interface StationaryBootstrapResult {
  config: StationaryBootstrapConfig;
  terminals: number[];
  paths: number[][];
  p5: number;
  p50: number;
  p95: number;
  positivePaths: number;
  positivePathsPct: number;
  riskOfRuinPct: number;
  drawdownPercentiles: { p50: number; p95: number };
}

export interface WalkForwardFold {
  /** Index range of the in-sample window: [start, end). */
  isRange: [number, number];
  /** Index range of the out-of-sample window. */
  oosRange: [number, number];
  isSharpe: number;
  oosSharpe: number;
  isMean: number;
  oosMean: number;
  /** OOS Sharpe / IS Sharpe. < 0 when IS is non-positive. */
  degradation: number;
  /** True when the OOS window has a positive mean return. */
  oosPositive: boolean;
}

export interface WalkForwardResult {
  folds: WalkForwardFold[];
  meanIsSharpe: number;
  meanOosSharpe: number;
  /** Mean degradation across folds. < 1 means the edge thins out of sample. */
  meanDegradation: number;
  /** Share of folds with a positive OOS mean. */
  oosPositivePct: number;
  /** Verdict: 'stable' | 'decaying' | 'unstable'. */
  verdict: 'stable' | 'decaying' | 'unstable';
}

export interface PurgedKFoldResult {
  nFolds: number;
  purge: number;
  embargo: number;
  folds: Array<{ isSharpe: number; oosSharpe: number; degradation: number; oosPositive: boolean }>;
  meanIsSharpe: number;
  meanOosSharpe: number;
  oosPositivePct: number;
}

export interface DeflatedSharpeInput {
  /** The observed (annualized) Sharpe ratio. */
  sharpe: number;
  /** Sample length in years (T). When the log spans N trades at tpy/year, T = N/tpy. */
  years: number;
  /** Sample skewness of the returns. */
  skew: number;
  /** Sample kurtosis of the returns (raw, not excess). */
  kurtosis: number;
  /** Number of independent backtests (parameter combinations) considered. Default 1. */
  trials: number;
}

export interface DeflatedSharpeResult {
  /** The Deflated Sharpe Ratio — probability that the true Sharpe is > 0 after
   *  accounting for the best-of-N selection, skew, and kurtosis. In [0, 1]. */
  dsr: number;
  /** The Sharpe threshold above which the observed SR is statistically credible. */
  sr0: number;
  /** Number of trials used. */
  trials: number;
  /** Verdict: 'credible' | 'marginal' | 'inflated'. */
  verdict: 'credible' | 'marginal' | 'inflated';
}

export interface PBOResult {
  /** Probability of Backtest Overfitting — frequency with which the best in-sample
   *  strategy ranks below the median out of sample. In [0, 1]. Higher = more overfit. */
  pbo: number;
  /** Number of strategies (parameter combinations). */
  nStrategies: number;
  /** Number of combinatorial splits used. */
  nSplits: number;
  /** Verdict: 'not overfit' | 'suspect' | 'overfit'. */
  verdict: 'not overfit' | 'suspect' | 'overfit';
}

export interface OverfitReport {
  walkForward: WalkForwardResult;
  purgedKFold: PurgedKFoldResult;
  deflatedSharpe: DeflatedSharpeResult;
  /** PBO is null when no parameter-scan matrix is supplied. */
  pbo: PBOResult | null;
  stationaryBootstrap: StationaryBootstrapResult;
  /** Honest summary the agent and MCP surface report verbatim. */
  summary: string;
  /** One-line verdict usable in a chat bubble. */
  verdict: string;
}

export interface MonteCarloConfig {
  paths: number;
  blockSize: number;
  seed: number;
}

export interface MonteCarloResult {
  config: MonteCarloConfig;
  /** One terminal balance per path. */
  terminals: number[];
  /** Equity series for every path (used for the 3D fan). */
  paths: number[][];
  p5: number;
  p50: number;
  p95: number;
  positivePaths: number;
  positivePathsPct: number;
  riskOfRuinPct: number;
  drawdownPercentiles: { p50: number; p95: number };
}

export interface PropFirmConfig {
  name: string;
  accountSize: number;
  profitTarget: number;
  maxDailyLoss: number;
  maxTotalDrawdown: number;
  /** Evaluated trading days when the trade log carries dates; estimated otherwise. */
  evaluationDays: number;
  /** Profit split: the share of profit you keep on a payout (0–100). */
  payoutPct: number;
  /** One-time challenge/evaluation fee paid per failed attempt. */
  challengeFee: number;
  /** Minimum withdrawal amount; a payout below this is held until it accumulates. */
  minPayout: number;
  /** How often you can withdraw, in days (informational). */
  payoutDays: number;
  /** True if the max drawdown is trailing (tightens as balance rises). */
  trailingDrawdown: boolean;
  /** Cost to reset/retry after a fail (often equal to the challenge fee). */
  resetFee: number;
  /** Account-size multiplier applied on pass (scaling plan), e.g. 2 = account doubles. */
  scaling: number;
  /** Number of evaluation phases (1 = one-step, 2 = two-step). */
  phases: number;
  /** Consistency rule: a single day's profit must not exceed this % of the profit target. 0 = rule disabled. */
  consistencyPct: number;
}

export interface PropFirmResult {
  config: PropFirmConfig;
  passRatePct: number;
  failRatePct: number;
  averageDaysToTarget: number | null;
  /** Median trading days to reach the target across passing runs. */
  medianDaysToTarget: number | null;
  /** Mean trading days an attempt lasts, pass or fail. */
  avgDaysPerAttempt: number;
  /** Average profit at the moment of passing (balance − account size), across passing runs. */
  avgProfitAtPass: number | null;
  /** Payout kept per pass after the profit split, 0 when below the minimum. */
  effectivePayout: number;
  expectedValue: number;
  payoutProbabilityPct: number;
  /** Attempts you can run in a year, bounded by average attempt length. */
  attemptsPerYear: number;
  /** Funded accounts earned per year: attemptsPerYear × pass rate. */
  evalsPassedPerYear: number;
  /** Expected paid attempts to a first pass (geometric: 1/passRate). */
  expectedAttemptsToPass: number;
  /** Expected total fees to a first pass (challenge fee + reset fees on retries). */
  expectedCostToPass: number;
  /** EV per attempt projected over a year of repeated attempts. */
  annualExpectedValue: number;
  /** Expected payout collected over a year. */
  annualExpectedPayout: number;
  /** Expected value per attempt as a multiple of the challenge fee. */
  roiPerAttempt: number;
  failures: PropFirmFailure[];
  /** Number of simulations run. */
  runs: number;
  /** Pass rate when the profit target is met before any limit breach. */
  passCount: number;
  /** A representative set of run equity paths (up to 24, mixed pass/fail) for visualization. */
  sampleRuns: PropFirmSampleRun[];
}

export interface PropFirmFailure {
  reason: string;
  count: number;
  pct: number;
}

export interface PropFirmSampleRun {
  /** Equity path of the run, starting at accountSize. */
  equity: number[];
  outcome: 'pass' | 'fail';
  /** Reason for the outcome: 'Target reached' on pass, or the breach name on fail. */
  reason: string;
  /** Day index reached when the run ended. */
  days: number;
  /** Highest balance during the run. */
  peak: number;
  /** Lowest balance during the run. */
  trough: number;
  /** Final balance. */
  terminal: number;
  accountSize: number;
  profitTarget: number;
  maxDrawdown: number;
}
