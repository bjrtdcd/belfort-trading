import { buildTradeLog } from './csv';
import { computeMetrics } from './metrics';
import { runMonteCarlo } from './montecarlo';
import { PROP_FIRM_PRESETS, runPropFirmSimulation } from './propfirm';
import {
  applyPropConfig,
  bindTabs,
  createDomRefs,
  populatePropPresets,
  readPropConfig,
  renderReport,
  ReportData,
} from './render';
import { hashSeed } from './rng';
import { animationsAreEnabled, rearmAll, setAnimationsEnabled, setAutoRotateEnabled } from './animations';
import { SAMPLE_TRADE_LOG as SAMPLE_TV } from './sample';

function init(): void {
  const refs = createDomRefs();
  bindTabs(refs);
  populatePropPresets(refs);
  refs.report.classList.remove('visible');

  const reshuffleButton = document.getElementById('reshuffle-button') as HTMLButtonElement | null;
  if (reshuffleButton) reshuffleButton.disabled = true;

  const animSelect = document.getElementById('anim-charts') as HTMLSelectElement | null;
  const rotateSelect = document.getElementById('animate-3d') as HTMLSelectElement | null;
  const animToggle = document.getElementById('anim-toggle') as HTMLButtonElement | null;

  // The tab-bar button and the settings dropdown drive the same switch, so they
  // are always redrawn from the animation layer's own state.
  const syncAnimationUi = (): void => {
    const on = animationsAreEnabled();
    if (animSelect) animSelect.value = on ? 'on' : 'off';
    if (animToggle) {
      animToggle.textContent = on ? 'Stop animations' : 'Start animations';
      animToggle.setAttribute('aria-pressed', on ? 'false' : 'true');
      animToggle.classList.toggle('is-off', !on);
    }
  };

  const applyAnimationSettings = (): void => {
    const wasOn = animationsAreEnabled();
    const on = !animSelect || animSelect.value === 'on';
    setAnimationsEnabled(on);
    setAutoRotateEnabled(!rotateSelect || rotateSelect.value === 'on');
    if (on && !wasOn) rearmAll();
    syncAnimationUi();
  };

  applyAnimationSettings();
  if (animSelect) animSelect.addEventListener('change', applyAnimationSettings);
  if (rotateSelect) rotateSelect.addEventListener('change', applyAnimationSettings);
  if (animToggle) {
    animToggle.addEventListener('click', () => {
      if (animSelect) animSelect.value = animationsAreEnabled() ? 'off' : 'on';
      applyAnimationSettings();
    });
  }

  refs.propPresetSelect.addEventListener('change', () => {
    const preset = PROP_FIRM_PRESETS.find((item) => item.name === refs.propPresetSelect.value);
    if (preset) applyPropConfig(refs, preset);
  });

  refs.fileInput.addEventListener('change', () => {
    const file = refs.fileInput.files && refs.fileInput.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      refs.csvInput.value = String(reader.result || '');
      refs.status.className = 'status';
      refs.status.textContent = `${file.name} loaded. Run the backtest when ready.`;
    };
    reader.readAsText(file);
  });

  const dropZone = document.getElementById('drop-zone');
  if (dropZone) {
    dropZone.addEventListener('click', () => refs.fileInput.click());
    dropZone.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        refs.fileInput.click();
      }
    });
    ['dragenter', 'dragover'].forEach((name) =>
      dropZone.addEventListener(name, (event) => {
        event.preventDefault();
        dropZone.classList.add('dragging');
      })
    );
    ['dragleave', 'drop'].forEach((name) =>
      dropZone.addEventListener(name, (event) => {
        event.preventDefault();
        dropZone.classList.remove('dragging');
      })
    );
    dropZone.addEventListener('drop', (event) => {
      const file = event.dataTransfer && event.dataTransfer.files && event.dataTransfer.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        refs.csvInput.value = String(reader.result || '');
        run({ reveal: true });
      };
      reader.readAsText(file);
    });
  }

  refs.runButton.addEventListener('click', () => run({ reveal: true }));
  refs.sampleButton.addEventListener('click', () => {
    refs.csvInput.value = SAMPLE_TV;
    refs.fileInput.value = '';
    run({ reveal: true });
  });
  refs.clearButton.addEventListener('click', () => {
    refs.csvInput.value = '';
    refs.fileInput.value = '';
    refs.report.classList.remove('visible');
    refs.status.className = 'status';
    refs.status.textContent = '';
    if (reshuffleButton) reshuffleButton.disabled = true;
  });

  let lastData: ReportData | null = null;
  let lastContext: { returns: number[]; trades: ReturnType<typeof buildTradeLog>['trades']; propConfig: ReturnType<typeof readPropConfig> } | null = null;

  function run(options: { reveal?: boolean } = {}): void {
    refs.status.className = 'status';
    refs.report.classList.remove('visible');
    try {
      const log = buildTradeLog(refs.csvInput.value);
      const metrics = computeMetrics(log);
      const paths = Math.min(Math.max(Number(refs.mcPathsInput.value) || 1000, 10), 5000);
      const blockSize = Math.min(Math.max(Number(refs.mcBlockInput.value) || 1, 1), log.trades.length);
      const seed = Number(refs.mcSeedInput.value) || hashSeed(log.trades.map((trade) => trade.pnl));
      const monteCarlo = runMonteCarlo(metrics.returns, { paths, blockSize, seed });
      const propConfig = readPropConfig(refs);
      const strategyBaseline = Math.max(1, Number((document.getElementById('strategy-baseline') as HTMLInputElement)?.value) || 100000);
      const propFirm = runPropFirmSimulation(log.trades, propConfig, { runs: 2000, seed, strategyBaseline });
      lastData = {
        log: {
          count: log.trades.length,
          ignored: log.ignored,
          detected: log.detected,
          derivedPnl: log.derivedPnl,
          hasDates: log.hasDates,
        },
        metrics,
        monteCarlo,
        propFirm,
      };
      lastContext = { returns: metrics.returns, trades: log.trades, propConfig };
      renderReport(refs, lastData);
      const platforms = ['tradingview', 'ninjatrader', 'multicharts', 'metatrader', 'tradestation'];
      const platform = (log.detected || []).find((d) => platforms.includes(d));
      refs.status.textContent = `Backtest complete — ${log.trades.length} trades analyzed${log.ignored ? `, ${log.ignored} rows skipped` : ''}${platform ? `. Detected: ${platform[0].toUpperCase()}${platform.slice(1)}` : ''}.`;
      if (reshuffleButton) reshuffleButton.disabled = false;
      // Bring the report into view so its charts animate straight away.
      if (options.reveal) {
        requestAnimationFrame(() => refs.report.scrollIntoView({ behavior: 'smooth', block: 'start' }));
      }
    } catch (error) {
      refs.status.className = 'status error';
      refs.status.textContent = error instanceof Error ? error.message : String(error);
      if (reshuffleButton) reshuffleButton.disabled = true;
    }
  }

  function reshuffle(): void {
    if (!lastData || !lastContext) return;
    refs.status.className = 'status';
    try {
      const seed = Math.floor(Math.random() * 1_000_000_000);
      const paths = Math.min(Math.max(Number(refs.mcPathsInput.value) || 1000, 10), 5000);
      const blockSize = Math.min(Math.max(Number(refs.mcBlockInput.value) || 1, 1), lastContext.returns.length);
      const monteCarlo = runMonteCarlo(lastContext.returns, { paths, blockSize, seed });
      const strategyBaseline = Math.max(1, Number((document.getElementById('strategy-baseline') as HTMLInputElement)?.value) || 100000);
      const propFirm = runPropFirmSimulation(lastContext.trades, lastContext.propConfig, { runs: 2000, seed, strategyBaseline });
      lastData = { ...lastData, monteCarlo, propFirm };
      renderReport(refs, lastData);
      refs.mcSeedInput.value = String(seed);
      refs.status.textContent = `Reshuffled — seed ${seed}. ${lastContext.returns.length} trades, ${paths} paths.`;
    } catch (error) {
      refs.status.className = 'status error';
      refs.status.textContent = error instanceof Error ? error.message : String(error);
    }
  }

  if (reshuffleButton) reshuffleButton.addEventListener('click', reshuffle);

  // Charts play their entry animation the first time they scroll into view;
  // the ▶ button on each card replays it (see render.ts / animations.ts).

  refs.csvInput.value = SAMPLE_TV;
  run();
}

declare global {
  interface Window {
    quantpadBacktesterInit?: () => void;
  }
}

window.quantpadBacktesterInit = init;

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
