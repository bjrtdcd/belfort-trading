// Per-chart animations driven by GSAP + Plotly.
// GSAP is loaded from CDN (global `gsap`); Plotly is the global chart lib.
//
// Charts animate themselves: every chart registers with an IntersectionObserver
// when it is drawn, and plays its entry animation the first time it scrolls into
// view. The play button on each card replays it on demand, and the stop button
// halts everything and snaps every chart to its finished state.

declare const gsap: any;
declare const Plotly: any;

type PlotDiv = HTMLDivElement & {
  data?: any[];
  layout?: any;
  __anim?: any;
  __fade?: any;
  __idle?: any;
  __restore?: (() => void) | undefined;
};

type AnimKind =
  | 'line'
  | 'bar'
  | 'histogram'
  | 'scatter'
  | 'pie'
  | 'heatmap'
  | 'box'
  | 'surface3d'
  | 'scatter3d';

/* One vocabulary for every chart: same length, same curve, so a grid of charts
   reads as a single motion rather than a dozen competing ones. */
const ENTRY_DURATION = 0.9;
const ENTRY_EASE = 'power2.out';
const INTRO_3D_DURATION = 1.4;
const FADE_DURATION = 0.45;
const STAGGER_MS = 70;
/** Plotly relayout/restyle is expensive; cap tween-driven redraws at ~40fps. */
const FRAME_MS = 25;

let animationsEnabled = true;
let autoRotateEnabled = true;

function prefersReducedMotion(): boolean {
  return typeof window.matchMedia === 'function' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

/** Master switch for entry animations and idle orbit. */
export function setAnimationsEnabled(value: boolean): void {
  animationsEnabled = value;
  if (!value) stopAllAnimations();
}

export function animationsAreEnabled(): boolean {
  return animationsEnabled;
}

/** Continuous slow orbit on 3D charts once their entry animation finishes. */
export function setAutoRotateEnabled(value: boolean): void {
  autoRotateEnabled = value;
  if (!value) stopIdleOrbits();
}

function detectKind(div: PlotDiv): AnimKind {
  const data = div.data || [];
  const first = data[0] || {};
  if (first.type === 'pie') return 'pie';
  if (first.type === 'surface' || first.type === 'mesh3d') return 'surface3d';
  if (first.type === 'scatter3d') return 'scatter3d';
  if (first.type === 'heatmap') return 'heatmap';
  if (first.type === 'histogram') return 'histogram';
  if (first.type === 'bar') return 'bar';
  if (first.type === 'box') return 'box';
  return 'line';
}

function dataRangeY(div: PlotDiv): [number, number] | null {
  let yMin = Infinity;
  let yMax = -Infinity;
  for (const tr of div.data || []) {
    if (!tr.y) continue;
    for (const v of tr.y as (number | null)[]) {
      if (Number.isFinite(v as number)) {
        yMin = Math.min(yMin, v as number);
        yMax = Math.max(yMax, v as number);
      }
    }
  }
  return Number.isFinite(yMin) && Number.isFinite(yMax) ? [yMin, yMax] : null;
}

function relayout(div: PlotDiv, update: Record<string, unknown>): void {
  try {
    Plotly.relayout(div, update);
  } catch {
    /* ignore */
  }
}

function restyle(div: PlotDiv, update: Record<string, unknown>, traces?: number[]): void {
  try {
    Plotly.restyle(div, update, traces);
  } catch {
    /* ignore */
  }
}

function hasGsap(): boolean {
  return typeof gsap !== 'undefined' && gsap && typeof gsap.to === 'function';
}

/** Frame limiter shared by every tween that drives Plotly. */
function throttled(fn: () => void): () => void {
  let last = 0;
  return () => {
    const now = performance.now();
    if (now - last < FRAME_MS) return;
    last = now;
    fn();
  };
}

/**
 * Stop the tweens on one chart and put it in its finished state. Every animator
 * registers a `__restore` so an interrupted animation never leaves a chart with
 * flattened bars, zero-size markers or a clipped axis.
 */
function finalize(div: PlotDiv): void {
  for (const tween of [div.__anim, div.__fade, div.__idle]) {
    if (!tween) continue;
    try {
      tween.kill();
    } catch {
      /* ignore */
    }
  }
  div.__anim = undefined;
  div.__fade = undefined;
  div.__idle = undefined;
  idleDivs.delete(div);
  const restore = div.__restore;
  div.__restore = undefined;
  if (restore) restore();
  div.style.opacity = '';
}

/** Fade the chart in alongside whatever its data animation is doing. */
function fadeIn(div: PlotDiv): void {
  if (!hasGsap()) return;
  div.style.opacity = '0';
  div.__fade = gsap.to(div, {
    opacity: 1,
    duration: FADE_DURATION,
    ease: 'power1.out',
    onComplete: () => {
      div.__fade = undefined;
      div.style.opacity = '';
    },
  });
}

/* ---------------------------------------------------------------- 3D camera */

const ORBIT_RADIUS = 1.75;
const ORBIT_HEIGHT = 0.85;
const START_ANGLE = -Math.PI / 4;

function setCamera(div: PlotDiv, angle: number, radius: number): void {
  relayout(div, {
    'scene.camera.eye': { x: radius * Math.cos(angle), y: radius * Math.sin(angle), z: ORBIT_HEIGHT },
  });
}

/** Slow continuous orbit; kept only while the chart is on screen. */
function startIdleOrbit(div: PlotDiv, fromAngle: number): void {
  if (!animationsEnabled || !autoRotateEnabled || prefersReducedMotion() || !hasGsap()) return;
  const obj = { a: fromAngle };
  div.__idle = gsap.to(obj, {
    a: fromAngle + 2 * Math.PI,
    duration: 44,
    ease: 'none',
    repeat: -1,
    onUpdate: throttled(() => setCamera(div, obj.a, ORBIT_RADIUS)),
  });
  idleDivs.add(div);
}

/** Entry move for 3D charts: pull the camera in from a wide angle. */
function animateCameraIntro(div: PlotDiv): void {
  const obj = { a: START_ANGLE - 0.7, r: ORBIT_RADIUS * 1.6 };
  div.__restore = () => setCamera(div, START_ANGLE, ORBIT_RADIUS);
  setCamera(div, obj.a, obj.r);
  div.__anim = gsap.to(obj, {
    a: START_ANGLE,
    r: ORBIT_RADIUS,
    duration: INTRO_3D_DURATION,
    ease: ENTRY_EASE,
    onUpdate: throttled(() => setCamera(div, obj.a, obj.r)),
    onComplete: () => {
      setCamera(div, START_ANGLE, ORBIT_RADIUS);
      div.__anim = undefined;
      div.__restore = undefined;
      startIdleOrbit(div, START_ANGLE);
    },
  });
}

/* ------------------------------------------------------------------- 2D set */

/** Left-to-right x-reveal (line, scatter, bar, histogram, heatmap, box). */
function animateXReveal(div: PlotDiv): void {
  const xa = div.layout?.xaxis || {};
  const range = xa.range || [0, 1];
  const lo = Number(range[0]);
  const hi = Number(range[1]);
  if (!Number.isFinite(lo) || !Number.isFinite(hi) || hi <= lo) return;
  // Pin y for the whole reveal so the plot does not rescale on every frame.
  const yRange = dataRangeY(div);
  const settle = (): void => {
    const fin: Record<string, unknown> = { 'xaxis.range': [lo, hi] };
    if (yRange) fin['yaxis.range'] = yRange;
    relayout(div, fin);
  };
  div.__restore = settle;
  const obj = { t: 0 };
  div.__anim = gsap.to(obj, {
    t: 1,
    duration: ENTRY_DURATION,
    ease: ENTRY_EASE,
    onUpdate: throttled(() => {
      const upd: Record<string, unknown> = { 'xaxis.range': [lo, lo + obj.t * (hi - lo)] };
      if (yRange) upd['yaxis.range'] = yRange;
      relayout(div, upd);
    }),
    onComplete: () => {
      settle();
      div.__anim = undefined;
      div.__restore = undefined;
    },
  });
}

/** Bars grow up from 0. */
function animateBarGrow(div: PlotDiv): void {
  const origY: (number[] | null)[] = (div.data || []).map((tr) => (tr.y ? tr.y.slice() : null));
  const yRange = dataRangeY(div);
  const settle = (): void => {
    restyle(div, { y: origY });
    if (yRange) relayout(div, { 'yaxis.range': yRange });
  };
  div.__restore = settle;
  const baseline = yRange ? Math.min(0, yRange[0]) : 0;
  relayout(div, { 'yaxis.range': [baseline, yRange ? yRange[1] : 1] });
  const obj = { t: 0 };
  div.__anim = gsap.to(obj, {
    t: 1,
    duration: ENTRY_DURATION,
    ease: ENTRY_EASE,
    onUpdate: throttled(() => {
      restyle(div, { y: origY.map((y) => (y ? y.map((v) => v * obj.t) : null)) });
    }),
    onComplete: () => {
      settle();
      div.__anim = undefined;
      div.__restore = undefined;
    },
  });
}

/** Pie/donut sweep. */
function animatePieSweep(div: PlotDiv): void {
  const tr = (div.data || [])[0];
  if (!tr || !tr.values) return;
  const finalValues = tr.values.slice();
  const settle = (): void => {
    tr.values = finalValues;
    restyle(div, { values: [finalValues] }, [0]);
  };
  div.__restore = settle;
  const obj = { t: 0 };
  div.__anim = gsap.to(obj, {
    t: 1,
    duration: ENTRY_DURATION,
    ease: ENTRY_EASE,
    onUpdate: throttled(() => {
      tr.values = finalValues.map((v: number) => v * obj.t);
      restyle(div, { values: [tr.values] }, [0]);
    }),
    onComplete: () => {
      settle();
      div.__anim = undefined;
      div.__restore = undefined;
    },
  });
}

/** Scatter points grow in from a smaller marker size. */
function animateScatterPop(div: PlotDiv): void {
  const origSizes: any[] = (div.data || []).map((tr) => (tr.marker && tr.marker.size != null ? tr.marker.size : null));
  const settle = (): void => {
    restyle(div, { 'marker.size': origSizes });
  };
  div.__restore = settle;
  const scale = (factor: number): any[] =>
    origSizes.map((s) => {
      if (s == null) return 8 * factor;
      if (Array.isArray(s)) return s.map((v: number) => v * factor);
      return s * factor;
    });
  const obj = { t: 0.25 };
  restyle(div, { 'marker.size': scale(obj.t) });
  div.__anim = gsap.to(obj, {
    t: 1,
    duration: ENTRY_DURATION,
    ease: ENTRY_EASE,
    onUpdate: throttled(() => {
      restyle(div, { 'marker.size': scale(obj.t) });
    }),
    onComplete: () => {
      settle();
      div.__anim = undefined;
      div.__restore = undefined;
    },
  });
}

/* ---------------------------------------------------------- no-GSAP fallback */

function fallbackReveal(div: PlotDiv): void {
  const xa = div.layout?.xaxis || {};
  const range = xa.range || [0, 1];
  const lo = Number(range[0]);
  const hi = Number(range[1]);
  if (!Number.isFinite(lo) || !Number.isFinite(hi) || hi <= lo) return;
  const yRange = dataRangeY(div);
  const N = 36;
  let i = 1;
  const tick = () => {
    if (!animationsEnabled) return;
    const k = lo + (i / N) * (hi - lo);
    const upd: Record<string, unknown> = { 'xaxis.range': [lo, k] };
    if (yRange) upd['yaxis.range'] = yRange;
    relayout(div, upd);
    i += 1;
    if (i <= N) requestAnimationFrame(tick);
    else {
      const fin: Record<string, unknown> = { 'xaxis.range': [lo, hi] };
      if (yRange) fin['yaxis.range'] = yRange;
      relayout(div, fin);
    }
  };
  requestAnimationFrame(tick);
}

function fallbackOrbit(div: PlotDiv): void {
  const N = 48;
  let i = 0;
  const tick = () => {
    if (!animationsEnabled) {
      setCamera(div, START_ANGLE, ORBIT_RADIUS);
      return;
    }
    const t = i / N;
    setCamera(div, START_ANGLE - 0.7 * (1 - t), ORBIT_RADIUS * (1.6 - 0.6 * t));
    i += 1;
    if (i <= N) requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}

/* -------------------------------------------------------------------- play */

/** Play the animation appropriate to the chart in `div`. */
export function playAnimation(div: HTMLDivElement): void {
  const plot = div as PlotDiv;
  if (!plot.data || !plot.layout) return;
  finalize(plot);
  if (!hasGsap()) {
    if (plot.layout.scene) fallbackOrbit(plot);
    else fallbackReveal(plot);
    return;
  }
  const kind = detectKind(plot);
  if (kind !== 'surface3d' && kind !== 'scatter3d') fadeIn(plot);
  switch (kind) {
    case 'scatter3d':
    case 'surface3d':
      animateCameraIntro(plot);
      break;
    case 'pie':
      animatePieSweep(plot);
      break;
    case 'bar':
      animateBarGrow(plot);
      break;
    case 'scatter':
      animateScatterPop(plot);
      break;
    case 'histogram':
    case 'heatmap':
    case 'box':
    case 'line':
    default:
      animateXReveal(plot);
      break;
  }
}

/* ---------------------------------------------------------------- autoplay */

interface AutoState {
  armed: boolean;
}

const autoState = new WeakMap<Element, AutoState>();
const idleDivs = new Set<PlotDiv>();
const liveDivs = new Set<PlotDiv>();
let autoObserver: IntersectionObserver | null = null;
let pending: PlotDiv[] = [];
let flushTimer = 0;

function stopIdleOrbits(): void {
  for (const div of Array.from(idleDivs)) {
    if (div.__idle) {
      try {
        div.__idle.kill();
      } catch {
        /* ignore */
      }
      div.__idle = undefined;
    }
  }
  idleDivs.clear();
}

/**
 * Halt every animation on the page and leave each chart in its finished state.
 * Also drops any queued entry animations that have not started yet.
 */
export function stopAllAnimations(): void {
  pending = [];
  if (flushTimer) {
    window.clearTimeout(flushTimer);
    flushTimer = 0;
  }
  for (const div of Array.from(liveDivs)) finalize(div);
  stopIdleOrbits();
}

function flushPending(): void {
  flushTimer = 0;
  const batch = pending;
  pending = [];
  batch.forEach((div, index) => {
    window.setTimeout(() => {
      if (!animationsEnabled) return;
      playAnimation(div);
    }, index * STAGGER_MS);
  });
}

function enqueue(div: PlotDiv): void {
  pending.push(div);
  if (!flushTimer) flushTimer = window.setTimeout(flushPending, 40);
}

function ensureObserver(): IntersectionObserver | null {
  if (autoObserver) return autoObserver;
  if (typeof IntersectionObserver === 'undefined') return null;
  autoObserver = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        const div = entry.target as PlotDiv;
        const state = autoState.get(div);
        if (!state) continue;
        if (entry.isIntersecting) {
          if (state.armed && animationsEnabled) {
            state.armed = false;
            enqueue(div);
          }
        } else if (div.__idle) {
          // Off-screen charts do not need to keep spinning.
          try {
            div.__idle.kill();
          } catch {
            /* ignore */
          }
          div.__idle = undefined;
          idleDivs.delete(div);
        }
      }
    },
    { threshold: 0.2 }
  );
  return autoObserver;
}

/**
 * Arm a freshly drawn chart so it animates the next time it is on screen.
 * Safe to call on every redraw.
 */
export function armAutoplay(div: HTMLDivElement): void {
  const plot = div as PlotDiv;
  liveDivs.add(plot);
  if (!animationsEnabled || prefersReducedMotion()) return;
  const observer = ensureObserver();
  if (!observer) return;
  autoState.set(plot, { armed: true });
  observer.unobserve(plot);
  observer.observe(plot);
}

/** Re-arm every live chart, e.g. after animations are switched back on. */
export function rearmAll(): void {
  if (!animationsEnabled) return;
  for (const div of Array.from(liveDivs)) armAutoplay(div);
}

/** Drop a chart from the autoplay set (used before Plotly.purge). */
export function releaseAutoplay(div: HTMLDivElement): void {
  const plot = div as PlotDiv;
  finalize(plot);
  liveDivs.delete(plot);
  autoState.delete(plot);
  if (autoObserver) autoObserver.unobserve(plot);
}
