export function mulberry32(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) >>> 0;
    let value = state;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

export function hashSeed(values: number[]): number {
  let seed = 2166136261;
  for (let i = 0; i < values.length; i += 1) {
    const bits = Math.round(values[i] * 100) | 0;
    seed = ((seed ^ bits) * 16777619) >>> 0;
    seed = ((seed ^ (i * 2654435761)) >>> 0);
  }
  return seed >>> 0;
}

export function shuffle<T>(array: T[], random: () => number): T[] {
  const copy = array.slice();
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(random() * (i + 1));
    const swap = copy[i];
    copy[i] = copy[j];
    copy[j] = swap;
  }
  return copy;
}
