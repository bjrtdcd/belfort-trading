import { Trade, TradeLog } from './types';

const normalize = (value: string): string =>
  String(value || '')
    .trim()
    .toLowerCase()
    .replace(/[%$£€]/g, '')
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_|_$/g, '');

const RESULT_ALIASES = [
  'pnl', 'profit', 'profit_loss', 'profitloss', 'net_pnl', 'net_profit', 'net_return',
  'return', 'returns', 'ret', 'r', 'r_multiple', 'r_multiple_points',
  'profit_pct', 'return_pct', 'pnl_pct', 'net', 'realized_pnl', 'pl', 'gain', 'gains',
];

const DATE_ALIASES = [
  'date', 'datetime', 'date_time', 'date_time_1', 'timestamp', 'time', 'trade_date',
  'entry_date', 'entry_time', 'exit_date', 'exit_time', 'open_time', 'close_time',
  'opened_at', 'closed_at', 'open_date', 'close_date',
];

const ENTRY_ALIASES = ['entry', 'entry_price', 'avg_entry_price', 'open', 'open_price', 'entry_price_1', 'price_1', 'buy_price', 'entry_fill_price'];
const EXIT_ALIASES = ['exit', 'exit_price', 'avg_exit_price', 'close', 'close_price', 'exit_price_1', 'price_2', 'sell_price', 'exit_fill_price'];
const SIZE_ALIASES = ['size', 'quantity', 'qty', 'shares', 'contracts', 'units', 'lots', 'volume', 'position'];
const DIRECTION_ALIASES = ['direction', 'side', 'position', 'type', 'action', 'signal', 'b_s', 'long_short'];
const FEE_ALIASES = ['fee', 'fees', 'commission', 'commissions', 'comm', 'cost', 'slippage', 'swap'];

const QUANTITY_RE = /^([0-9.]+)(m|k|klote|lot)?$/i;
const SHORT_RE = /^(short|sell|s|bajista|put)$/i;
const LONG_RE = /^(long|buy|l|call)$/i;

function parseNumber(raw: string): number {
  const value = String(raw ?? '').trim();
  if (!value) return NaN;
  const negative = /^\(.*\)$/.test(value);
  let cleaned = value.replace(/[()$£€,%\s]/g, '');
  cleaned = cleaned.replace(/(\d)[,.](\d)/g, '$1.$2');
  const parsed = Number(cleaned);
  if (Number.isNaN(parsed)) {
    const match = value.replace(/[()$£€,\s]/g, '').match(/^[+-]?(\d+)$/);
    return match ? (negative ? -Number(match[1]) : Number(match[1])) : NaN;
  }
  return negative ? -parsed : parsed;
}

function parseSize(raw: string): number | null {
  const value = String(raw ?? '').trim();
  if (!value) return null;
  const match = value.match(QUANTITY_RE);
  if (!match) return null;
  let number = parseFloat(match[1]);
  if (Number.isNaN(number)) return null;
  const suffix = (match[2] || '').toLowerCase();
  if (suffix === 'k') number *= 1000;
  else if (suffix === 'm') number *= 1_000_000;
  return number;
}

// Robust date/time parser across platform export formats. Handles ISO,
// `YYYY-MM-DD HH:mm:ss`, `YYYY.MM.DD HH:mm`, US `M/D/YYYY h:mm:ss AM/PM`,
// EU `D.M.YYYY HH:mm`, and date-only variants. Returns an ISO string or null.
// Falls back to `new Date(raw)` first so existing behaviour is unchanged.
function parseDate(raw: string): string | null {
  const s = String(raw ?? '').trim();
  if (!s) return null;
  const base = new Date(s);
  if (!Number.isNaN(base.getTime())) return base.toISOString();

  // YYYY[.-/]MM[.-/]DD [T ]HH:mm[:ss][ AM/PM]  (year-first; e.g. MetaTrader `2024.05.01 10:00:00`)
  let m = s.match(/^(\d{4})[.\/-](\d{1,2})[.\/-](\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?)?$/i);
  if (m) {
    let h = m[4] ? +m[4] : 0;
    if (m[7]) h = h % 12 + (/PM/i.test(m[7]) ? 12 : 0);
    const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], h, m[5] ? +m[5] : 0, m[6] ? +m[6] : 0));
    if (!Number.isNaN(d.getTime())) return d.toISOString();
  }

  // M/D/YYYY [h:mm[:ss][ AM/PM]] or D.M.YYYY (ambiguous; assume M/D, swap if month>12)
  m = s.match(/^(\d{1,2})[\/.](\d{1,2})[\/.](\d{2,4})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?)?$/i);
  if (m) {
    let yr = +m[3]; if (yr < 100) yr += 2000;
    let mo = +m[1], da = +m[2];
    if (mo > 12) { const t = mo; mo = da; da = t; } // was D/M/Y
    let h = m[4] ? +m[4] : 0;
    if (m[7]) h = h % 12 + (/PM/i.test(m[7]) ? 12 : 0);
    const d = new Date(Date.UTC(yr, mo - 1, da, h, m[5] ? +m[5] : 0, m[6] ? +m[6] : 0));
    if (!Number.isNaN(d.getTime())) return d.toISOString();
  }
  return null;
}

// Recognise a platform from its export header signature. Conservative: only
// claims a platform on a fairly unique column, so it never mislabels a generic
// list. Used only to annotate `detected`, not to change parsing.
function detectPlatform(headers: string[]): string | null {
  if (headers.includes('instrument')) return 'ninjatrader';
  if (headers.includes('swap') || (headers.includes('volume') && headers.includes('commission'))) return 'metatrader';
  if (headers.includes('contracts') && (headers.includes('signal') || headers.includes('profit_loss') || headers.includes('profitloss'))) return 'multicharts';
  if (headers.includes('type') && headers.includes('price') && headers.includes('date_time')) return 'tradingview';
  if (headers.includes('order_id') || headers.includes('ticket')) return 'metatrader';
  return null;
}

export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];
    const next = text[i + 1];
    if (char === '"' && quoted && next === '"') {
      cell += '"';
      i += 1;
      continue;
    }
    if (char === '"') {
      quoted = !quoted;
      continue;
    }
    if (char === ',' && !quoted) {
      row.push(cell);
      cell = '';
      continue;
    }
    if ((char === '\n' || char === '\r') && !quoted) {
      if (char === '\r' && next === '\n') i += 1;
      row.push(cell);
      if (row.some((v) => v.trim())) rows.push(row);
      row = [];
      cell = '';
      continue;
    }
    cell += char;
  }
  if (cell.length || row.length) {
    row.push(cell);
    if (row.some((v) => v.trim())) rows.push(row);
  }
  return rows;
}

function findIndex(headers: string[], aliases: string[]): number {
  for (const alias of aliases) {
    const index = headers.indexOf(alias);
    if (index >= 0) return index;
  }
  return -1;
}

function isTradingViewFormat(headers: string[]): boolean {
  return headers.includes('type') && headers.includes('price') && headers.includes('date_time');
}

function parseTradingViewTradeList(rows: string[][]): Trade[] | null {
  const headers = rows[0].map(normalize);
  const typeIdx = headers.indexOf('type');
  const dateIdx = headers.indexOf('date_time');
  const priceIdx = headers.indexOf('price');
  const qtyIdx = headers.indexOf('qty') >= 0 ? headers.indexOf('qty') : headers.indexOf('quantity');
  const pnlIdx = headers.indexOf('p_l');
  const tradeNumIdx = headers.indexOf('trade');

  if (typeIdx < 0 || priceIdx < 0 || dateIdx < 0) return null;

  const groups = new Map<string, string[][]>();
  for (let r = 1; r < rows.length; r += 1) {
    const row = rows[r];
    if (!row.some((v) => v.trim())) continue;
    const key = tradeNumIdx >= 0 && row[tradeNumIdx] ? row[tradeNumIdx].trim() : String(r);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)!.push(row);
  }

  const trades: Trade[] = [];
  groups.forEach((group) => {
    let entry = group.find((row) => /entry/i.test(row[typeIdx] || ''));
    let exit = group.find((row) => /exit/i.test(row[typeIdx] || ''));
    if (!entry && !exit) {
      entry = group[0];
      exit = group[group.length - 1];
    }
    if (!entry || !exit) return;

    const typeStr = (entry[typeIdx] || '').toLowerCase();
    const direction: Trade['direction'] = /short/.test(typeStr)
      ? 'short'
      : /long/.test(typeStr)
      ? 'long'
      : 'unknown';

    const entryPrice = parseNumber(entry[priceIdx]);
    const exitPrice = parseNumber(exit[priceIdx]);
    const qty = qtyIdx >= 0 ? parseSize((entry[qtyIdx] || exit[qtyIdx] || '').trim()) : null;
    const size = qty ?? 1;

    let pnl = pnlIdx >= 0 ? parseNumber(exit[pnlIdx] || '') : NaN;
    if (!Number.isFinite(pnl) && Number.isFinite(entryPrice) && Number.isFinite(exitPrice)) {
      const sign = direction === 'short' ? -1 : 1;
      pnl = (exitPrice - entryPrice) * sign * size;
    }
    if (!Number.isFinite(pnl)) return;

    const rawDate = (exit[dateIdx] || '').trim();
    const date: string | null = parseDate(rawDate);

    trades.push({
      row: 0,
      date,
      direction,
      entry: Number.isFinite(entryPrice) ? entryPrice : null,
      exit: Number.isFinite(exitPrice) ? exitPrice : null,
      size: qtyIdx >= 0 ? qty : null,
      fee: 0,
      pnl,
    });
  });

  trades.sort((a, b) => {
    if (a.date && b.date) return new Date(a.date).getTime() - new Date(b.date).getTime();
    return 0;
  });
  trades.forEach((trade, index) => {
    trade.row = index + 2;
  });
  return trades;
}

export function buildTradeLog(text: string): TradeLog {
  const rows = parseCsv(text);
  if (rows.length < 2) {
    throw new Error('Add a header row and at least two trade rows to run a backtest.');
  }
  const headers = rows[0].map(normalize);

  if (isTradingViewFormat(headers)) {
    const tvTrades = parseTradingViewTradeList(rows);
    if (tvTrades && tvTrades.length >= 2) {
      const platform = detectPlatform(headers) || 'tradingview';
      return {
        trades: tvTrades,
        ignored: 0,
        detected: [platform, 'date', 'entry', 'exit', 'size', 'direction'],
        derivedPnl: false,
        hasDates: tvTrades.some((trade) => trade.date !== null),
      };
    }
    throw new Error(
      'TradingView trade list detected but fewer than two complete trades were found. Each trade needs both an Entry and an Exit fill.'
    );
  }

  const resultIndex = findIndex(headers, RESULT_ALIASES);
  const dateIndex = findIndex(headers, DATE_ALIASES);
  const entryIndex = findIndex(headers, ENTRY_ALIASES);
  const exitIndex = findIndex(headers, EXIT_ALIASES);
  const sizeIndex = findIndex(headers, SIZE_ALIASES);
  const directionIndex = findIndex(headers, DIRECTION_ALIASES);
  const feeIndex = findIndex(headers, FEE_ALIASES);

  if (resultIndex < 0 && (entryIndex < 0 || exitIndex < 0)) {
    throw new Error(
      'No usable result column. Include pnl/profit/return, or entry and exit price columns.'
    );
  }

  const trades: Trade[] = [];
  let ignored = 0;
  let derived = false;
  const detected: string[] = [];
  const platform = detectPlatform(headers);
  if (platform) detected.push(platform);
  if (resultIndex >= 0) detected.push(headers[resultIndex]);
  if (dateIndex >= 0) detected.push('date');
  if (entryIndex >= 0) detected.push('entry');
  if (exitIndex >= 0) detected.push('exit');
  if (sizeIndex >= 0) detected.push('size');
  if (directionIndex >= 0) detected.push('direction');
  if (feeIndex >= 0) detected.push('fee');

  for (let r = 1; r < rows.length; r += 1) {
    const values = rows[r];
    const read = (index: number): string => (index >= 0 && index < values.length ? values[index] : '');
    let pnl = NaN;

    if (resultIndex >= 0) {
      pnl = parseNumber(read(resultIndex));
    }
    if (!Number.isFinite(pnl) && entryIndex >= 0 && exitIndex >= 0) {
      const entry = parseNumber(read(entryIndex));
      const exit = parseNumber(read(exitIndex));
      const size = sizeIndex >= 0 ? parseSize(read(sizeIndex)) : 1;
      if (Number.isFinite(entry) && Number.isFinite(exit)) {
        const directionRaw = read(directionIndex);
        const direction = SHORT_RE.test(directionRaw) ? -1 : 1;
        pnl = (exit - entry) * direction * (size ?? 1);
        derived = true;
      }
    }
    if (!Number.isFinite(pnl)) {
      ignored += 1;
      continue;
    }

    const rawDate = read(dateIndex).trim();
    const date: string | null = parseDate(rawDate);

    const fee = feeIndex >= 0 ? parseNumber(read(feeIndex)) : 0;
    const directionRaw = read(directionIndex);
    let direction: Trade['direction'] = 'unknown';
    if (directionRaw) {
      if (LONG_RE.test(directionRaw)) direction = 'long';
      else if (SHORT_RE.test(directionRaw)) direction = 'short';
    }

    const entry = entryIndex >= 0 ? parseNumber(read(entryIndex)) : null;
    const exit = exitIndex >= 0 ? parseNumber(read(exitIndex)) : null;
    const size = sizeIndex >= 0 ? parseSize(read(sizeIndex)) : null;

    trades.push({
      row: r + 1,
      date,
      direction,
      entry: Number.isFinite(entry) ? entry : null,
      exit: Number.isFinite(exit) ? exit : null,
      size,
      fee: Number.isFinite(fee) ? fee : 0,
      pnl: pnl - (Number.isFinite(fee) ? fee : 0),
    });
  }

  if (trades.length < 2) {
    throw new Error('At least two valid trade rows are required after parsing.');
  }

  return {
    trades,
    ignored,
    detected,
    derivedPnl: derived,
    hasDates: trades.some((trade) => trade.date !== null),
  };
}
