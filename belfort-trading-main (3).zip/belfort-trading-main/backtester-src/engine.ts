// Pure backtester engine re-exports — no DOM, no UI. This is the shared
// engine both the in-browser Quant Copilot agent (bundled to
// backtester/engine.js as window.BelfortEngine) and the MCP server
// (imported directly) build on. Keep it free of render/animations/charts3d.

export { parseCsv, buildTradeLog } from './csv';
export { computeMetrics } from './metrics';
export { runMonteCarlo } from './montecarlo';
export { runPropFirmSimulation, PROP_FIRM_PRESETS, defaultPropFirmConfig } from './propfirm';
export { mulberry32, hashSeed } from './rng';
export { SAMPLE_TRADE_LOG } from './sample';
// ── Market regime module (Bull/Bear × Low/High Vol detection, attribution, regime-aware Monte Carlo) ──
export {
  detectRegimes,
  attributeRegimes,
  computeRegimeStats,
  regimeEquityBands,
  runRegimeAwareMC,
  REGIME_COLORS,
  REGIME_ORDER,
} from './regimes';
// ── Overfit / robustness module (walk-forward, purged K-fold, deflated Sharpe, PBO, stationary bootstrap) ──
export {
  runStationaryBootstrap,
  walkForward,
  purgedKFold,
  deflatedSharpeRatio,
  probabilityOfBacktestOverfitting,
  buildOverfitReport,
  autoBlockSize,
  autocorrelation,
} from './overfit';
