import { ComputeMetricsOptions, Metrics, TradeDetail, TradeLog } from './types';

function percentileSorted(sorted: number[], fraction: number): number {
  if (sorted.length === 0) return 0;
  const idx = Math.min(sorted.length - 1, Math.floor(sorted.length * fraction));
  return sorted[idx];
}

function mean(arr: number[]): number {
  if (arr.length === 0) return 0;
  let s = 0;
  for (let i = 0; i < arr.length; i += 1) s += arr[i];
  return s / arr.length;
}

function variance(arr: number[], m?: number): number {
  if (arr.length < 2) return 0;
  const mu = m == null ? mean(arr) : m;
  let s = 0;
  for (let i = 0; i < arr.length; i += 1) {
    const d = arr[i] - mu;
    s += d * d;
  }
  return s / arr.length;
}

function stddev(arr: number[], m?: number): number {
  return Math.sqrt(variance(arr, m));
}

function sampleSkew(arr: number[], m: number): number {
  if (arr.length < 3) return 0;
  const sd = stddev(arr, m);
  if (sd === 0) return 0;
  let s = 0;
  for (let i = 0; i < arr.length; i += 1) {
    const d = (arr[i] - m) / sd;
    s += d * d * d;
  }
  // Sample skewness (adjusted): G1 = sqrt(n(n-1))/(n-2) * m3
  const n = arr.length;
  const g1 = (Math.sqrt(n * (n - 1)) / (n - 2)) * (s / n);
  return Number.isFinite(g1) ? g1 : 0;
}

function sampleKurtosis(arr: number[], m: number): number {
  if (arr.length < 4) return 0;
  const sd = stddev(arr, m);
  if (sd === 0) return 0;
  let s = 0;
  for (let i = 0; i < arr.length; i += 1) {
    const d = (arr[i] - m) / sd;
    s += d * d * d * d;
  }
  // Sample excess kurtosis (G2): ((n-1)/((n-2)(n-3))) * ((n+1) * m4 - 3(n-1))
  const n = arr.length;
  const m4 = s / n;
  const g2 = ((n - 1) / ((n - 2) * (n - 3))) * ((n + 1) * m4 - 3 * (n - 1));
  return Number.isFinite(g2) ? g2 : 0;
}

export function computeMetrics(log: TradeLog, opts: ComputeMetricsOptions = {}): Metrics {
  const trades = log.trades;
  const returns = trades.map((trade) => trade.pnl);
  const wins = returns.filter((value) => value > 0);
  const losses = returns.filter((value) => value < 0);
  const count = returns.length;
  const winCount = wins.length;
  const lossCount = losses.length;
  const winRate = count > 0 ? winCount / count : 0;
  const grossWins = wins.reduce((total, value) => total + value, 0);
  const grossLosses = Math.abs(losses.reduce((total, value) => total + value, 0));
  const netPnl = returns.reduce((total, value) => total + value, 0);
  const expectancy = count > 0 ? netPnl / count : 0;

  let equity = 0;
  const equitySeries: number[] = [];
  const drawdownSeries: number[] = [];
  const drawdownPctSeries: number[] = [];
  const tradeDates: (string | null)[] = [];
  const monthlyMap = new Map<string, number>();
  let peak = 0;
  let maxDrawdown = 0;
  let currentDdDuration = 0;
  let maxDrawdownDuration = 0;
  let longestDdStartIdx = -1;
  let longestDdEndIdx = -1;
  let ulcerSqSum = 0;
  for (let i = 0; i < returns.length; i += 1) {
    const value = returns[i];
    equity += value;
    equitySeries.push(equity);
    const prevPeak = peak;
    peak = Math.max(peak, equity);
    const drawdown = equity - peak;
    drawdownSeries.push(drawdown);
    const ddPct = peak > 0 ? (drawdown / peak) * 100 : 0;
    drawdownPctSeries.push(ddPct);
    ulcerSqSum += ddPct * ddPct;
    maxDrawdown = Math.min(maxDrawdown, drawdown);
    if (drawdown < 0) {
      if (prevPeak === peak) {
        currentDdDuration += 1;
      } else {
        currentDdDuration = 1;
      }
      if (currentDdDuration > maxDrawdownDuration) {
        maxDrawdownDuration = currentDdDuration;
        longestDdEndIdx = i;
        longestDdStartIdx = i - currentDdDuration + 1;
      }
    } else {
      currentDdDuration = 0;
    }

    const trade = trades[i];
    const iso = trade.date ?? null;
    tradeDates.push(iso);
    if (iso) {
      const parsed = new Date(iso);
      if (!Number.isNaN(parsed.getTime())) {
        const key = `${parsed.getFullYear()}-${parsed.getMonth()}`;
        monthlyMap.set(key, (monthlyMap.get(key) || 0) + value);
      }
    }
  }

  const monthlyReturns = Array.from(monthlyMap.entries())
    .map(([key, pnl]) => {
      const [year, month] = key.split('-').map(Number);
      return { year, month, pnl };
    })
    .sort((a, b) => (a.year !== b.year ? a.year - b.year : a.month - b.month));

  const tradeDetails: TradeDetail[] = trades.map((trade, i) => ({
    index: i + 1,
    date: trade.date,
    direction: trade.direction,
    entry: trade.entry,
    exit: trade.exit,
    size: trade.size,
    pnl: returns[i],
    equity: equitySeries[i],
    drawdown: drawdownSeries[i],
  }));

  let maxConsecutiveWins = 0;
  let maxConsecutiveLosses = 0;
  let currentWins = 0;
  let currentLosses = 0;
  for (const value of returns) {
    if (value > 0) {
      currentWins += 1;
      currentLosses = 0;
      maxConsecutiveWins = Math.max(maxConsecutiveWins, currentWins);
    } else if (value < 0) {
      currentLosses += 1;
      currentWins = 0;
      maxConsecutiveLosses = Math.max(maxConsecutiveLosses, currentLosses);
    }
  }

  const mean = expectancy;
  const variance =
    count > 0 ? returns.reduce((total, value) => total + ((value - mean) ** 2), 0) / count : 0;
  const standardDeviation = Math.sqrt(variance);

  const dated = trades.filter((trade) => trade.date !== null).sort(
    (a, b) => new Date(a.date as string).getTime() - new Date(b.date as string).getTime()
  );
  let avgHoldMs: number | null = null;
  if (dated.length > 1) {
    let totalHold = 0;
    let pairs = 0;
    for (let i = 1; i < dated.length; i += 1) {
      const current = new Date(dated[i].date as string).getTime();
      const previous = new Date(dated[i - 1].date as string).getTime();
      if (Number.isFinite(current) && Number.isFinite(previous)) {
        totalHold += current - previous;
        pairs += 1;
      }
    }
    if (pairs > 0) avgHoldMs = totalHold / pairs;
  }

  const bestTrade = returns.length > 0 ? Math.max(...returns) : 0;
  const worstTrade = returns.length > 0 ? Math.min(...returns) : 0;

  const positivePathsPct = winRate;
  const sharpeLike = standardDeviation > 0 ? (mean / standardDeviation) * Math.sqrt(Math.max(count, 1)) : 0;
  const rExpectancy = standardDeviation > 0 ? expectancy / standardDeviation : 0;
  const score = gradeScore({
    expectancy,
    profitFactor: grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? 3 : 0,
    winRate,
    maxDrawdownAbs: Math.abs(maxDrawdown),
    grossWins,
    count,
    positivePathsPct,
    sharpeLike,
    rExpectancy,
    maxConsecutiveLosses,
  });

  // ── Institutional extensions ──
  const MS_PER_YEAR = 365.25 * 24 * 3600 * 1000;
  let tradesPerYear = 252; // daily default
  if (avgHoldMs && avgHoldMs > 0) {
    tradesPerYear = Math.min(Math.max(MS_PER_YEAR / avgHoldMs, 1), 250000);
  }
  const annualizedReturn = expectancy * tradesPerYear;
  const annualizedVolatility = standardDeviation * Math.sqrt(tradesPerYear);
  const sharpe = standardDeviation > 0 ? (expectancy / standardDeviation) * Math.sqrt(tradesPerYear) : 0;

  // Downside deviation for Sortino: only returns below 0 (MAR = 0)
  const downsideReturns = returns.filter((r) => r < 0);
  const downsideDeviation = downsideReturns.length > 0
    ? Math.sqrt(downsideReturns.reduce((s, r) => s + r * r, 0) / Math.max(count, 1))
    : 0;
  const sortino = downsideDeviation > 0 ? (expectancy / downsideDeviation) * Math.sqrt(tradesPerYear) : 0;

  const maxDrawdownAbs = Math.abs(maxDrawdown);
  const calmar = maxDrawdownAbs > 0 ? annualizedReturn / maxDrawdownAbs : 0;
  const omega = grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? Infinity : 0;
  const recoveryFactor = maxDrawdownAbs > 0 ? netPnl / maxDrawdownAbs : 0;
  const gainPain = grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? Infinity : 0;
  const ulcerIndex = count > 0 ? Math.sqrt(ulcerSqSum / count) : 0;

  // Tail / VaR
  const sortedReturns = returns.slice().sort((a, b) => a - b);
  const p5 = percentileSorted(sortedReturns, 0.05);
  const p95 = percentileSorted(sortedReturns, 0.95);
  const tailRatio = p5 < 0 ? Math.abs(p95) / Math.abs(p5) : 0;
  // Historical 95% VaR (a loss expressed as a positive number)
  const valueAtRisk95 = Math.abs(p5);
  // CVaR — mean of the returns at or below the 5th percentile
  const tailCount = Math.max(1, Math.floor(count * 0.05));
  let cvarSum = 0;
  for (let i = 0; i < tailCount; i += 1) cvarSum += sortedReturns[i] || 0;
  const cvar95 = Math.abs(cvarSum / tailCount);

  // Longest drawdown duration in days (only when we have dates for the start/end)
  let maxDrawdownDurationDays: number | null = null;
  if (longestDdStartIdx >= 0 && longestDdEndIdx >= longestDdStartIdx) {
    const startIso = tradeDates[longestDdStartIdx];
    const endIso = tradeDates[longestDdEndIdx];
    if (startIso && endIso) {
      const t0 = new Date(startIso).getTime();
      const t1 = new Date(endIso).getTime();
      if (Number.isFinite(t0) && Number.isFinite(t1) && t1 >= t0) {
        maxDrawdownDurationDays = (t1 - t0) / (24 * 3600 * 1000);
      }
    }
  }

  const avgWin = winCount > 0 ? grossWins / winCount : 0;
  const avgLoss = lossCount > 0 ? -(grossLosses / lossCount) : 0;
  const winLossRatio = avgLoss < 0 ? avgWin / Math.abs(avgLoss) : 0;
  const skewness = sampleSkew(returns, mean);
  // sampleKurtosis returns EXCESS kurtosis (G2). For DSR we want raw kurtosis = excess + 3.
  const kurtosis = sampleKurtosis(returns, mean) + 3;

  // Benchmark (optional): beta, alpha, information ratio
  let benchmark: string | null = null;
  let beta: number | null = null;
  let alpha: number | null = null;
  let informationRatio: number | null = null;
  if (opts.benchmark && opts.benchmark.returns && opts.benchmark.returns.length > 1) {
    benchmark = opts.benchmark.name;
    const br = opts.benchmark.returns;
    const n = Math.min(returns.length, br.length);
    if (n > 2) {
      // NOTE: a local `const mean = expectancy` shadowed the module helper above,
      // so we inline the sums here instead of calling mean()/variance()/stddev().
      let bmSum = 0;
      for (let i = 0; i < n; i += 1) bmSum += br[i];
      const bmMean = bmSum / n;
      let bmVarSum = 0;
      for (let i = 0; i < n; i += 1) bmVarSum += (br[i] - bmMean) ** 2;
      const bmVar = bmVarSum / n;
      if (bmVar > 0) {
        let cov = 0;
        for (let i = 0; i < n; i += 1) cov += (returns[i] - expectancy) * (br[i] - bmMean);
        cov /= n;
        beta = cov / bmVar;
        alpha = expectancy - beta * bmMean;
        // Active returns and information ratio
        const active: number[] = [];
        for (let i = 0; i < n; i += 1) active.push(returns[i] - br[i]);
        let activeSum = 0;
        for (let i = 0; i < active.length; i += 1) activeSum += active[i];
        const activeMean = activeSum / active.length;
        let activeVarSum = 0;
        for (let i = 0; i < active.length; i += 1) activeVarSum += (active[i] - activeMean) ** 2;
        const activeStd = Math.sqrt(activeVarSum / Math.max(active.length, 1));
        informationRatio = activeStd > 0 ? (activeMean / activeStd) * Math.sqrt(tradesPerYear) : 0;
      }
    }
  }

  // Turnover: rough proxy = sum(|entry * size|) / starting capital. Without a stated
  // starting balance we use peak equity as the denominator. Null when no entry/size.
  let turnover: number | null = null;
  const sizedTrades = trades.filter((t) => t.entry != null && t.size != null);
  if (sizedTrades.length > 0 && peak > 0) {
    let notional = 0;
    for (const t of sizedTrades) {
      const sz = Math.abs(t.size as number);
      const px = Math.abs(t.entry as number);
      notional += sz * px;
    }
    turnover = notional / peak;
  }

  return {
    count,
    winCount,
    lossCount,
    winRate,
    grossWins,
    grossLosses,
    profitFactor: grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? Infinity : 0,
    netPnl,
    expectancy,
    rExpectancy: standardDeviation > 0 ? expectancy / standardDeviation : 0,
    standardDeviation,
    sharpeLike: standardDeviation > 0 ? (mean / standardDeviation) * Math.sqrt(Math.max(count, 1)) : 0,
    maxDrawdown: Math.abs(maxDrawdown),
    maxDrawdownPct: peak > 0 ? Math.abs(maxDrawdown) / peak : 0,
    maxConsecutiveWins,
    maxConsecutiveLosses,
    avgHoldMs,
    bestTrade,
    worstTrade,
    equity: equitySeries,
    drawdownSeries,
    returns,
    tradeDates,
    monthlyReturns,
    tradeDetails,
    grade: score.grade,
    gradeLabel: score.label,
    gradeScore: score.score,
    gradeBreakdown: score.breakdown,
    gradeAdvice: score.advice,
    tradesPerYear,
    annualizedReturn,
    annualizedVolatility,
    sharpe,
    sortino,
    calmar,
    omega,
    tailRatio,
    valueAtRisk95,
    cvar95,
    maxDrawdownDuration,
    maxDrawdownDurationDays,
    recoveryFactor,
    ulcerIndex,
    gainPain,
    avgWin,
    avgLoss,
    winLossRatio,
    skewness,
    kurtosis,
    benchmark,
    beta,
    alpha,
    informationRatio,
    turnover,
  };
}

function gradeScore(metrics: {
  expectancy: number;
  profitFactor: number;
  winRate: number;
  maxDrawdownAbs: number;
  grossWins: number;
  count: number;
  positivePathsPct: number;
  sharpeLike: number;
  rExpectancy: number;
  maxConsecutiveLosses: number;
}): { score: number; grade: string; label: string; breakdown: Array<{ category: string; score: number; max: number }>; advice: string[] } {
  const subs: Array<{ category: string; score: number; max: number }> = [];

  let prof = 0;
  if (metrics.expectancy > 0) prof += 10;
  if (metrics.profitFactor >= 2) prof += 15;
  else if (metrics.profitFactor >= 1.5) prof += 10;
  else if (metrics.profitFactor >= 1.15) prof += 4;
  subs.push({ category: 'Profitability', score: prof, max: 25 });

  let cons = 0;
  if (metrics.winRate >= 0.55) cons += 10;
  else if (metrics.winRate >= 0.45) cons += 6;
  else if (metrics.winRate >= 0.35) cons += 3;
  if (metrics.positivePathsPct >= 0.7) cons += 10;
  else if (metrics.positivePathsPct >= 0.55) cons += 6;
  else if (metrics.positivePathsPct >= 0.4) cons += 3;
  subs.push({ category: 'Consistency', score: cons, max: 20 });

  let risk = 0;
  if (metrics.grossWins > 0) {
    if (metrics.maxDrawdownAbs <= metrics.grossWins * 0.25) risk += 15;
    else if (metrics.maxDrawdownAbs <= metrics.grossWins * 0.5) risk += 10;
    else if (metrics.maxDrawdownAbs <= metrics.grossWins) risk += 4;
  }
  if (metrics.maxConsecutiveLosses <= 3) risk += 10;
  else if (metrics.maxConsecutiveLosses <= 5) risk += 6;
  else if (metrics.maxConsecutiveLosses <= 8) risk += 2;
  subs.push({ category: 'Risk control', score: risk, max: 25 });

  let rob = 0;
  if (metrics.sharpeLike >= 2) rob += 10;
  else if (metrics.sharpeLike >= 1.2) rob += 7;
  else if (metrics.sharpeLike >= 0.6) rob += 3;
  if (metrics.rExpectancy >= 0.3) rob += 10;
  else if (metrics.rExpectancy >= 0.15) rob += 6;
  else if (metrics.rExpectancy >= 0.05) rob += 2;
  subs.push({ category: 'Robustness', score: rob, max: 20 });

  let samp = 0;
  if (metrics.count >= 200) samp += 10;
  else if (metrics.count >= 100) samp += 8;
  else if (metrics.count >= 50) samp += 5;
  else if (metrics.count >= 20) samp += 3;
  else if (metrics.count >= 5) samp += 1;
  subs.push({ category: 'Sample size', score: samp, max: 10 });

  const score = subs.reduce((a, s) => a + s.score, 0);
  const grade = score >= 88 ? 'A' : score >= 74 ? 'B' : score >= 58 ? 'C' : score >= 40 ? 'D' : 'F';
  const labels: Record<string, string> = {
    A: 'Strong evidence',
    B: 'Promising evidence',
    C: 'Mixed evidence',
    D: 'Weak evidence',
    F: 'Needs work',
  };

  const advice: string[] = [];
  if (prof < 15) advice.push('Improve profitability: filter trades with weak edge or tighten stops to lift profit factor above 1.5.');
  if (cons < 12) advice.push('Raise consistency: review losing streaks and entry timing (see autocorrelation) to push the win rate above 50%.');
  if (risk < 15) advice.push('Tighten risk control: reduce position size or add a hard stop to cap drawdown and consecutive losses.');
  if (rob < 12) advice.push('Strengthen robustness: the risk-adjusted return is thin — favor higher-expectancy setups to improve the Sharpe-like ratio.');
  if (samp < 5) advice.push('Gather more trades: the sample is small, so every metric here carries low confidence.');

  return { score, grade, label: labels[grade], breakdown: subs, advice };
}
