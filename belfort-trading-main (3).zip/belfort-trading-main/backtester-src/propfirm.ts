import { PropFirmConfig, PropFirmFailure, PropFirmResult, PropFirmSampleRun, Trade } from './types';
import { mulberry32, shuffle } from './rng';

export const PROP_FIRM_PRESETS: PropFirmConfig[] = [
  {
    name: 'FTMO 100k',
    accountSize: 100000, profitTarget: 10000, maxDailyLoss: 5000, maxTotalDrawdown: 10000,
    evaluationDays: 30, payoutPct: 80, challengeFee: 549,
    minPayout: 1000, payoutDays: 14, trailingDrawdown: false, resetFee: 549, scaling: 1, phases: 1,
    consistencyPct: 50,
  },
  {
    name: 'FTMO 50k',
    accountSize: 50000, profitTarget: 5000, maxDailyLoss: 2500, maxTotalDrawdown: 5000,
    evaluationDays: 30, payoutPct: 80, challengeFee: 299,
    minPayout: 500, payoutDays: 14, trailingDrawdown: false, resetFee: 299, scaling: 1, phases: 1,
    consistencyPct: 50,
  },
  {
    name: 'Apex 100k',
    accountSize: 100000, profitTarget: 6000, maxDailyLoss: 4500, maxTotalDrawdown: 5000,
    evaluationDays: 30, payoutPct: 90, challengeFee: 150,
    minPayout: 500, payoutDays: 1, trailingDrawdown: false, resetFee: 150, scaling: 1, phases: 1,
    consistencyPct: 0,
  },
  {
    name: 'Topstep 50k',
    accountSize: 50000, profitTarget: 3000, maxDailyLoss: 2000, maxTotalDrawdown: 2000,
    evaluationDays: 15, payoutPct: 100, challengeFee: 165,
    minPayout: 500, payoutDays: 5, trailingDrawdown: true, resetFee: 165, scaling: 1, phases: 1,
    consistencyPct: 50,
  },
  {
    name: 'E8 100k',
    accountSize: 100000, profitTarget: 8000, maxDailyLoss: 3000, maxTotalDrawdown: 6000,
    evaluationDays: 30, payoutPct: 100, challengeFee: 599,
    minPayout: 500, payoutDays: 7, trailingDrawdown: false, resetFee: 599, scaling: 2, phases: 1,
    consistencyPct: 50,
  },
];

export function defaultPropFirmConfig(): PropFirmConfig {
  return { ...PROP_FIRM_PRESETS[0] };
}

export interface PropSimOptions {
  runs: number;
  seed: number;
  /** Account size the trade log is originally sized for. Trades are scaled to `config.accountSize / strategyBaseline`. */
  strategyBaseline?: number;
}

function tradesPerDay(trades: Trade[]): number {
  const days = new Set<string>();
  for (const trade of trades) {
    if (trade.date) days.add(trade.date.slice(0, 10));
  }
  return Math.max(days.size, 1);
}

export function runPropFirmSimulation(
  trades: Trade[],
  config: PropFirmConfig,
  options: PropSimOptions
): PropFirmResult {
  const runs = Math.min(Math.max(options.runs, 10), 10000);
  const random = mulberry32(options.seed);
  const baseline = options.strategyBaseline && options.strategyBaseline > 0 ? options.strategyBaseline : config.accountSize;
  const scale = config.accountSize / baseline;
  const pnl = trades.map((trade) => trade.pnl * scale);
  const actualDays = tradesPerDay(trades);
  const tradesPerDayCount = pnl.length / actualDays;
  const dailyLossLimit = config.maxDailyLoss;
  const totalDrawdownLimit = config.maxTotalDrawdown;
  const target = config.profitTarget;

  let passCount = 0;
  let daysToTargetTotal = 0;
  let daysToTargetCount = 0;
  let profitAtPassTotal = 0;
  // Days spent on every attempt (pass or fail), plus the passing days for a median.
  let daysPerAttemptTotal = 0;
  const passDaysList: number[] = [];
  const failures: Record<string, number> = {
    'Daily loss breach': 0,
    'Max total drawdown breach': 0,
    'Consistency rule breach': 0,
    'Evaluation period expired': 0,
  };
  const consistencyLimit = config.consistencyPct > 0 && config.consistencyPct < 100
    ? (config.consistencyPct / 100) * config.profitTarget
    : Infinity;

  const sampleRuns: PropFirmSampleRun[] = [];
  let passSamples = 0;
  const failByReason: Record<string, number> = {};
  const MAX_PASS_SAMPLES = 12;
  const MAX_FAIL_PER_REASON = 4;

  const SAFETY_CAP = config.evaluationDays * Math.max(1, Math.ceil(tradesPerDayCount)) * 50;

  for (let run = 0; run < runs; run += 1) {
    let order = shuffle(pnl, random);
    let cursor = 0;
    let balance = config.accountSize;
    let peak = config.accountSize;
    let trough = config.accountSize;
    let dailyNet = 0;
    let maxDailyProfit = 0;
    let tradesToday = 0;
    let day = 1;
    let result: 'pass' | 'fail' = 'fail';
    let failureReason = 'Evaluation period expired';
    const runEquity: number[] = [config.accountSize];

    for (let iter = 0; iter < SAFETY_CAP; iter += 1) {
      if (cursor >= order.length) {
        order = shuffle(pnl, random);
        cursor = 0;
      }
      if (tradesToday >= tradesPerDayCount && day < config.evaluationDays) {
        day += 1;
        dailyNet = 0;
        tradesToday = 0;
      }
      const pnlThisTrade = order[cursor];
      cursor += 1;
      tradesToday += 1;
      balance += pnlThisTrade;
      dailyNet += pnlThisTrade;
      if (dailyNet > maxDailyProfit) maxDailyProfit = dailyNet;
      runEquity.push(balance);
      peak = Math.max(peak, balance);
      trough = Math.min(trough, balance);

      if (dailyNet <= -dailyLossLimit) {
        result = 'fail';
        failureReason = 'Daily loss breach';
        break;
      }
      // Total drawdown: trailing (from running peak) when configured, otherwise a
      // fixed floor from the starting balance — which is what FTMO's evaluation uses.
      const totalBreach = config.trailingDrawdown
        ? peak - balance >= totalDrawdownLimit
        : balance <= config.accountSize - totalDrawdownLimit;
      if (totalBreach) {
        result = 'fail';
        failureReason = 'Max total drawdown breach';
        break;
      }
      if (balance - config.accountSize >= target) {
        if (maxDailyProfit > consistencyLimit) {
          result = 'fail';
          failureReason = 'Consistency rule breach';
        } else {
          result = 'pass';
        }
        break;
      }
      if (day >= config.evaluationDays && tradesToday >= tradesPerDayCount) {
        result = 'fail';
        failureReason = 'Evaluation period expired';
        break;
      }
    }

    daysPerAttemptTotal += day;
    if (result === 'pass') {
      passCount += 1;
      daysToTargetTotal += day;
      daysToTargetCount += 1;
      passDaysList.push(day);
      profitAtPassTotal += balance - config.accountSize;
    } else {
      failures[failureReason] = (failures[failureReason] || 0) + 1;
    }

    const wantSample =
      (result === 'pass' && passSamples < MAX_PASS_SAMPLES) ||
      (result === 'fail' && (failByReason[failureReason] || 0) < MAX_FAIL_PER_REASON);
    if (wantSample) {
      sampleRuns.push({
        equity: runEquity,
        outcome: result,
        reason: result === 'pass' ? 'Target reached' : failureReason,
        days: day,
        peak,
        trough,
        terminal: balance,
        accountSize: config.accountSize,
        profitTarget: target,
        maxDrawdown: config.maxTotalDrawdown,
      });
      if (result === 'pass') passSamples += 1;
      else failByReason[failureReason] = (failByReason[failureReason] || 0) + 1;
    }
  }

  const passRate = passCount / runs;
  const avgProfitAtPass = passCount > 0 ? profitAtPassTotal / passCount : null;
  const profitAtPass = avgProfitAtPass !== null ? avgProfitAtPass : config.profitTarget;
  const payoutPerPass = (profitAtPass * config.payoutPct) / 100;
  const effectivePayout = payoutPerPass >= config.minPayout ? payoutPerPass : 0;
  const expectedValue = passRate * effectivePayout - (1 - passRate) * config.challengeFee;

  // ── Attempt economics, projected over a year ──────────────────────────
  // Evaluation days are trading days; a year is ~252 of them. The number of
  // attempts you can run in a year is bounded by how long each one takes.
  const TRADING_DAYS_PER_YEAR = 252;
  const averageDaysToTarget = daysToTargetCount > 0 ? daysToTargetTotal / daysToTargetCount : null;
  const medianDaysToTarget = passDaysList.length
    ? passDaysList.slice().sort((a, b) => a - b)[Math.floor(passDaysList.length / 2)]
    : null;
  const avgDaysPerAttempt = daysPerAttemptTotal / runs;
  const attemptsPerYear = avgDaysPerAttempt > 0 ? TRADING_DAYS_PER_YEAR / avgDaysPerAttempt : 0;
  const evalsPassedPerYear = attemptsPerYear * passRate;

  // Expected number of paid attempts to a first pass follows a geometric
  // distribution: 1/passRate. The first attempt costs the challenge fee, each
  // retry the reset fee.
  const expectedAttemptsToPass = passRate > 0 ? 1 / passRate : Infinity;
  const expectedCostToPass = Number.isFinite(expectedAttemptsToPass)
    ? config.challengeFee + (expectedAttemptsToPass - 1) * config.resetFee
    : Infinity;

  // A full year of running this evaluation on repeat, fees included.
  const annualExpectedValue = attemptsPerYear * expectedValue;
  const annualExpectedPayout = evalsPassedPerYear * effectivePayout;
  const roiPerAttempt = config.challengeFee > 0 ? expectedValue / config.challengeFee : 0;

  const failureList: PropFirmFailure[] = Object.entries(failures)
    .map(([reason, count]) => ({ reason, count, pct: count / runs }))
    .filter((failure) => failure.count > 0)
    .sort((a, b) => b.count - a.count);

  return {
    config,
    passRatePct: passRate * 100,
    failRatePct: (1 - passRate) * 100,
    averageDaysToTarget,
    medianDaysToTarget,
    avgDaysPerAttempt,
    avgProfitAtPass,
    effectivePayout,
    expectedValue,
    payoutProbabilityPct: passRate * 100,
    attemptsPerYear,
    evalsPassedPerYear,
    expectedAttemptsToPass,
    expectedCostToPass,
    annualExpectedValue,
    annualExpectedPayout,
    roiPerAttempt,
    failures: failureList,
    runs,
    passCount,
    sampleRuns,
  };
}
