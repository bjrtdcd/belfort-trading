import { MonteCarloConfig, MonteCarloResult } from './types';
import { mulberry32 } from './rng';

export function runMonteCarlo(
  returns: number[],
  config: MonteCarloConfig,
  startingBalance = 0
): MonteCarloResult {
  if (returns.length < 2) {
    throw new Error('At least two trades are required for Monte Carlo.');
  }
  const paths = Math.min(Math.max(config.paths, 10), 5000);
  const blockSize = Math.min(Math.max(config.blockSize, 1), Math.max(returns.length, 1));
  const random = mulberry32(config.seed);

  const numberOfBlocks = Math.ceil(returns.length / blockSize);
  const pathEquity: number[][] = [];
  const terminals: number[] = [];
  const drawdowns: number[] = [];

  for (let path = 0; path < paths; path += 1) {
    const blocks: number[] = [];
    for (let block = 0; block < numberOfBlocks; block += 1) {
      const start = Math.floor(random() * returns.length);
      for (let offset = 0; offset < blockSize; offset += 1) {
        blocks.push(returns[(start + offset) % returns.length]);
      }
    }
    const sampled = blocks.slice(0, returns.length);

    let equity = startingBalance;
    const series: number[] = [];
    let peak = startingBalance;
    let maxDrawdown = 0;
    for (const value of sampled) {
      equity += value;
      series.push(equity);
      peak = Math.max(peak, equity);
      maxDrawdown = Math.max(maxDrawdown, peak - equity);
    }
    pathEquity.push(series);
    terminals.push(equity);
    drawdowns.push(maxDrawdown);
  }

  const sorted = terminals.slice().sort((a, b) => a - b);
  const sortedDrawdowns = drawdowns.slice().sort((a, b) => a - b);
  const positivePaths = terminals.filter((value) => value > startingBalance).length;

  return {
    config,
    terminals,
    paths: pathEquity,
    p5: percentile(sorted, 0.05),
    p50: percentile(sorted, 0.5),
    p95: percentile(sorted, 0.95),
    positivePaths,
    positivePathsPct: positivePaths / paths,
    riskOfRuinPct: percentile(sorted, 0.05) < startingBalance ? lowTailRisk(terminals, startingBalance) : 0,
    drawdownPercentiles: {
      p50: percentile(sortedDrawdowns, 0.5),
      p95: percentile(sortedDrawdowns, 0.95),
    },
  };
}

function percentile(sorted: number[], fraction: number): number {
  if (sorted.length === 0) return 0;
  const index = Math.min(sorted.length - 1, Math.floor(sorted.length * fraction));
  return sorted[index];
}

function lowTailRisk(terminals: number[], startingBalance: number): number {
  const loss = terminals.filter((value) => value < startingBalance).length;
  return (loss / terminals.length) * 100;
}
