// Bundled sample trade log (TradingView "List of Trades" export format) so the
// Copilot and the MCP server can run a real backtest without a user file. The
// data is the same 24-trade fictional log the Strategy Validator ships with.

export const SAMPLE_TRADE_LOG: string = (() => {
  const header =
    'Trade #,Type,Signal,Date/Time,Price,Qty,P&L,Cumulative P&L,Drawdown,Run-up,Cumulative P&L %,Buy & Hold %,Trade #';
  const rows: string[] = [header];
  const data: Array<[number, 'long' | 'short', string, string, number, number, number]> = [
    [1, 'long', '2025-01-03 09:30', '2025-01-05 16:00', 4200.50, 15, 2400],
    [2, 'short', '2025-01-07 10:00', '2025-01-08 11:00', 4300.00, 15, -285],
    [3, 'long', '2025-01-10 09:30', '2025-01-12 15:00', 4250.00, 15, 690],
    [4, 'long', '2025-01-14 10:00', '2025-01-15 14:00', 4280.00, 8, 488],
    [5, 'short', '2025-01-17 10:00', '2025-01-17 15:00', 4310.00, 15, -3500],
    [6, 'long', '2025-01-22 09:30', '2025-01-24 16:00', 4260.00, 15, 885],
    [7, 'short', '2025-01-27 10:00', '2025-01-28 11:00', 4340.00, 15, -195],
    [8, 'long', '2025-01-31 09:30', '2025-02-03 15:00', 4270.00, 8, 672],
    [9, 'long', '2025-02-04 09:30', '2025-02-06 16:00', 4290.00, 15, 2300],
    [10, 'short', '2025-02-07 10:00', '2025-02-10 11:00', 4380.00, 15, -435],
    [11, 'long', '2025-02-12 09:30', '2025-02-14 15:00', 4300.00, 8, 608],
    [12, 'long', '2025-02-18 09:30', '2025-02-20 16:00', 4310.00, 15, 773],
    [13, 'short', '2025-02-21 10:00', '2025-02-24 11:00', 4400.00, 15, -308],
    [14, 'long', '2025-02-26 09:30', '2025-02-28 15:00', 4320.00, 8, 536],
    [15, 'long', '2025-03-03 09:30', '2025-03-05 16:00', 4300.00, 15, 2200],
    [16, 'short', '2025-03-06 10:00', '2025-03-07 11:00', 4450.00, 15, -3500],
    [17, 'long', '2025-03-11 09:30', '2025-03-13 15:00', 4340.00, 8, 704],
    [18, 'long', '2025-03-17 09:30', '2025-03-19 16:00', 4360.00, 15, 2200],
    [19, 'short', '2025-03-20 10:00', '2025-03-21 11:00', 4420.00, 15, -263],
    [20, 'long', '2025-03-26 09:30', '2025-03-28 15:00', 4350.00, 8, 392],
    [21, 'long', '2025-04-02 09:30', '2025-04-04 16:00', 4380.00, 15, 2200],
    [22, 'short', '2025-04-08 10:00', '2025-04-09 11:00', 4480.00, 15, -3500],
    [23, 'long', '2025-04-15 09:30', '2025-04-17 15:00', 4400.00, 8, 760],
    [24, 'long', '2025-04-22 09:30', '2025-04-24 16:00', 4410.00, 8, 584],
  ];
  let cum = 0;
  for (const [num, dir, entryDate, exitDate, entry, qty, pnl] of data) {
    const exit = dir === 'long' ? entry + pnl / qty : entry - pnl / qty;
    const entryType = dir === 'long' ? 'Entry long' : 'Entry short';
    const exitType = dir === 'long' ? 'Exit long' : 'Exit short';
    rows.push(`${num},${entryType},,${entryDate},${entry},${qty},,,,,,, ,${num}`);
    cum += pnl;
    rows.push(`${num},${exitType},,${exitDate},${exit.toFixed(2)},${qty},${pnl.toFixed(2)},${cum.toFixed(2)},,,,, ,${num}`);
  }
  return rows.join('\n');
})();
