# Belfort backend

The control plane: authentication, users, projects, and the AI provider
registry. A modular monolith (FastAPI + SQLAlchemy + PostgreSQL) — logical
modules inside one app, per the master plan. No UI is served from here.

## What exists today

| Module | Endpoints | Status |
| --- | --- | --- |
| `auth` | `POST /auth/register`, `/auth/login`, `/auth/refresh`, `/auth/logout` | Working |
| `users` | `GET /users/me` | Working |
| `projects` | CRUD on `/projects` — an owner-scoped JSON blob per project, so the UI can evolve freely | Working |
| `ai` | `GET /ai/providers` — provider registry with honest configured/not status | Working (registry only; Groq adapter ready, needs a key) |
| `knowledge` | `GET /knowledge/search`, `GET /knowledge/status` — hybrid retrieval over the private library | Working (keyword now; vectors light up when embeddings are configured) |
| meta | `GET /health` | Working |

Security decisions baked in:

- Passwords: bcrypt, per-password salt, 10-char minimum, 72-byte cap
  (bcrypt's limit) rejected up front rather than silently truncated.
- Access tokens: 15-minute JWTs carrying only the user id.
- Refresh tokens: opaque 256-bit values; only a SHA-256 digest is stored, so
  a database leak leaks no usable session. Rotation on every refresh; reuse
  of a rotated token fails. Logout revokes.
- Login failure is one identical 401 for wrong-password and unknown-email,
  with comparable timing — no user enumeration.
- Cross-user access to a project returns the same 404 as a missing one.
- `BELFORT_JWT_SECRET` is mandatory in prod (refuses to boot without it);
  in dev a throwaway per-process secret is generated.

## Run it locally

```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8791
```

SQLite by default (`belfort.db`, gitignored). Interactive docs at
`http://127.0.0.1:8791/docs` in dev.

Tests:

```bash
python -m pytest tests/ -q
```

## Deploy (VPS)

```bash
cd backend
cp .env.example .env    # fill in JWT secret + Postgres password
docker compose up -d --build
```

Postgres 17 + the API, bound to `127.0.0.1:8791` for nginx/Caddy to proxy.
Secrets live in `backend/.env`, never in git.

## Knowledge base (Phase 2)

Ingest licensed material (papers, books, transcripts, notes) from plain
text/Markdown:

```bash
python scripts/ingest.py path/to/folder --source-type paper --license "owned copy"
```

- Chunking is paragraph-aware; Markdown headings become section labels so
  provenance (document, section, license) survives to every search hit.
- Duplicate content (SHA-256) is skipped; re-running is safe.
- Retrieval is hybrid with reciprocal-rank fusion: keyword search always
  (Postgres `websearch_to_tsquery` in prod, SQLite FTS5 in dev, one
  interface), plus vector search when an embedding provider is configured
  (`BELFORT_EMBEDDINGS_BASE_URL/_API_KEY/_MODEL` — any OpenAI-compatible
  `/embeddings` endpoint). Unconfigured embeddings = honest keyword-only,
  reported by `/knowledge/status`.
- Embeddings are stored as JSON and scored brute-force for now — correct
  and fast at small corpus size. When the corpus grows, the swap is a
  pgvector column + index behind `_vector_ranking()`; nothing above the
  service layer changes.

## What is deliberately NOT here yet

- pgvector index (brute-force cosine is the V1 vector path; see above)
- PDF extraction (ingest CLI covers .txt/.md; a proper extraction worker
  comes with the Redis/Dramatiq phase)
- Data catalog / Databento ingestion — Phase 3 (the Databento master key
  will live server-side only)
- Backtest orchestration — Phase 4+
- Rate limiting / Redis, billing, marketplace — when their phase arrives

Adding an AI provider = one adapter in `app/ai/` + one line in
`registry.py`. Nothing else changes.
