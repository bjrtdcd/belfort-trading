"""Auth business logic, kept out of the router so it can be tested directly
and reused (CLI tooling, admin scripts) without HTTP."""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.auth.models import RefreshToken, User
from app.core import security


class AuthError(Exception):
    """Raised for any credential failure. The router maps every instance to
    the same 401 so responses don't reveal which part failed."""


def register_user(db: Session, email: str, password: str, display_name: str = "") -> User:
    email = email.strip().lower()
    existing = db.scalar(select(User).where(User.email == email))
    if existing is not None:
        # Same message as a policy failure would be too revealing; a distinct
        # 409 for "taken" is standard and acceptable for V1.
        raise ValueError("An account with this email already exists.")
    user = User(
        email=email,
        password_hash=security.hash_password(password),
        display_name=display_name.strip(),
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def authenticate(db: Session, email: str, password: str) -> User:
    email = email.strip().lower()
    user = db.scalar(select(User).where(User.email == email))
    if user is None:
        # Burn comparable time so missing-vs-wrong is not timeable.
        security.verify_password(password, security.hash_password("timing-equalizer"))
        raise AuthError()
    if not user.is_active or not security.verify_password(password, user.password_hash):
        raise AuthError()
    return user


def issue_tokens(db: Session, user: User) -> tuple[str, str]:
    """Return (access_jwt, raw_refresh_token)."""
    raw, digest = security.new_refresh_token()
    db.add(
        RefreshToken(
            user_id=user.id, token_hash=digest, expires_at=security.refresh_expiry()
        )
    )
    db.commit()
    return security.create_access_token(user.id), raw


def rotate_refresh_token(db: Session, raw: str) -> tuple[str, str]:
    """Validate a refresh token, revoke it, and issue a fresh pair."""
    digest = security.hash_refresh_token(raw)
    row = db.scalar(select(RefreshToken).where(RefreshToken.token_hash == digest))
    now = datetime.now(timezone.utc)
    if row is None or row.revoked_at is not None:
        raise AuthError()
    expires = row.expires_at
    if expires.tzinfo is None:  # SQLite drops tzinfo
        expires = expires.replace(tzinfo=timezone.utc)
    if expires < now:
        raise AuthError()
    user = db.get(User, row.user_id)
    if user is None or not user.is_active:
        raise AuthError()
    row.revoked_at = now
    db.commit()
    return issue_tokens(db, user)


def revoke_refresh_token(db: Session, raw: str) -> None:
    """Logout: revoke the presented refresh token. Idempotent."""
    digest = security.hash_refresh_token(raw)
    row = db.scalar(select(RefreshToken).where(RefreshToken.token_hash == digest))
    if row is not None and row.revoked_at is None:
        row.revoked_at = datetime.now(timezone.utc)
        db.commit()
