"""Provider abstraction: the Belfort agent talks to this interface, never to
a vendor SDK directly. Swapping or adding an LLM provider means writing one
adapter — nothing else in Belfort changes.

Kept deliberately small for V1: chat in, text out, with token accounting.
Tool-calling and streaming land here later as the agent needs them.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class ChatMessage:
    role: str  # "system" | "user" | "assistant"
    content: str


@dataclass
class ChatResult:
    text: str
    model: str
    input_tokens: int = 0
    output_tokens: int = 0
    raw: dict = field(default_factory=dict)


class AIProvider(ABC):
    """One concrete subclass per vendor."""

    name: str = "base"

    @abstractmethod
    def available(self) -> bool:
        """True when this provider is configured (key present) and usable."""

    @abstractmethod
    async def chat(
        self,
        messages: list[ChatMessage],
        *,
        model: str | None = None,
        max_tokens: int = 1024,
        temperature: float = 0.3,
    ) -> ChatResult:
        """Run one chat completion. Raise ProviderError on failure."""


class ProviderError(RuntimeError):
    pass


class ProviderNotConfigured(ProviderError):
    pass
