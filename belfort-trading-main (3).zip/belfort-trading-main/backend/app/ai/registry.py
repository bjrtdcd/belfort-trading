"""Provider registry: one place that knows which providers exist.

Adding Claude/OpenAI/Gemini later = one adapter file + one line here.
"""

from __future__ import annotations

from app.ai.base import AIProvider
from app.ai.groq import GroqProvider

_PROVIDERS: dict[str, AIProvider] = {
    "groq": GroqProvider(),
}


def get_provider(name: str = "groq") -> AIProvider:
    provider = _PROVIDERS.get(name)
    if provider is None:
        raise KeyError(f"Unknown AI provider: {name}")
    return provider


def provider_status() -> list[dict]:
    return [
        {"name": p.name, "available": p.available()} for p in _PROVIDERS.values()
    ]
