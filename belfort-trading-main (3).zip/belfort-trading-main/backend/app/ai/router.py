from __future__ import annotations

from fastapi import APIRouter, Depends

from app.ai.registry import provider_status
from app.auth.deps import get_current_user

router = APIRouter(prefix="/ai", tags=["ai"])


@router.get("/providers")
def providers(user=Depends(get_current_user)):
    """Which AI providers this server offers and whether each is configured.
    Honest status only — no chat endpoint until the agent work lands."""
    return provider_status()
