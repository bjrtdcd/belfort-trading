"""Groq adapter — the included/free tier provider.

Uses Groq's OpenAI-compatible chat completions endpoint over plain httpx, so
there is no vendor SDK to track. The server-side key comes from
BELFORT_GROQ_API_KEY and never reaches the browser.
"""

from __future__ import annotations

import httpx

from app.ai.base import AIProvider, ChatMessage, ChatResult, ProviderError, ProviderNotConfigured
from app.core.config import get_settings

GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
DEFAULT_MODEL = "llama-3.3-70b-versatile"


class GroqProvider(AIProvider):
    name = "groq"

    def available(self) -> bool:
        return bool(get_settings().groq_api_key)

    async def chat(
        self,
        messages: list[ChatMessage],
        *,
        model: str | None = None,
        max_tokens: int = 1024,
        temperature: float = 0.3,
    ) -> ChatResult:
        settings = get_settings()
        if not settings.groq_api_key:
            raise ProviderNotConfigured("Groq is not configured on this server.")
        payload = {
            "model": model or DEFAULT_MODEL,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        headers = {"Authorization": f"Bearer {settings.groq_api_key}"}
        async with httpx.AsyncClient(timeout=60) as client:
            resp = await client.post(GROQ_URL, json=payload, headers=headers)
        if resp.status_code != 200:
            raise ProviderError(f"Groq returned {resp.status_code}: {resp.text[:300]}")
        data = resp.json()
        usage = data.get("usage", {})
        return ChatResult(
            text=data["choices"][0]["message"]["content"],
            model=data.get("model", model or DEFAULT_MODEL),
            input_tokens=usage.get("prompt_tokens", 0),
            output_tokens=usage.get("completion_tokens", 0),
            raw=data,
        )
