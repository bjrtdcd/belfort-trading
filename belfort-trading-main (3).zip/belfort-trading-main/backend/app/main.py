"""Belfort backend — the control plane.

A modular monolith: auth, users, projects and the AI provider registry are
logical modules inside one FastAPI app. No UI is served from here; the
frontend talks to it over JSON.
"""

from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.ai.router import router as ai_router
from app.auth.router import router as auth_router
from app.core.config import get_settings
from app.core.db import create_all
from app.knowledge.fts import ensure_fts
from app.knowledge.router import router as knowledge_router
from app.projects.router import router as projects_router
from app.users.router import router as users_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    create_all()
    ensure_fts()
    yield


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(
        title="Belfort API",
        version="0.1.0",
        lifespan=lifespan,
        # Docs on in dev; off in prod until there's a reason to expose them.
        docs_url="/docs" if settings.env == "dev" else None,
        redoc_url=None,
    )
    app.include_router(auth_router)
    app.include_router(users_router)
    app.include_router(projects_router)
    app.include_router(ai_router)
    app.include_router(knowledge_router)

    @app.get("/health", tags=["meta"])
    def health():
        return {"status": "ok"}

    return app


app = create_app()
