from __future__ import annotations

import json

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.auth.deps import get_current_user
from app.auth.models import User
from app.core.db import get_db
from app.projects.models import Project

router = APIRouter(prefix="/projects", tags=["projects"])

MAX_CONTENT_BYTES = 1_000_000  # 1 MB per project blob for V1


class ProjectIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    kind: str = Field(default="strategy", max_length=40)
    content: dict = Field(default_factory=dict)


class ProjectOut(BaseModel):
    id: int
    name: str
    kind: str
    content: dict
    created_at: str
    updated_at: str


def _serialize(p: Project) -> ProjectOut:
    return ProjectOut(
        id=p.id,
        name=p.name,
        kind=p.kind,
        content=json.loads(p.content or "{}"),
        created_at=p.created_at.isoformat(),
        updated_at=p.updated_at.isoformat(),
    )


def _content_or_413(content: dict) -> str:
    raw = json.dumps(content, separators=(",", ":"))
    if len(raw.encode("utf-8")) > MAX_CONTENT_BYTES:
        raise HTTPException(status_code=413, detail="Project content is over 1 MB.")
    return raw


def _owned_project(db: Session, user: User, project_id: int) -> Project:
    project = db.get(Project, project_id)
    if project is None or project.owner_id != user.id:
        # 404 either way: don't reveal that someone else's id exists.
        raise HTTPException(status_code=404, detail="Project not found.")
    return project


@router.get("", response_model=list[ProjectOut])
def list_projects(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.scalars(
        select(Project).where(Project.owner_id == user.id).order_by(Project.updated_at.desc())
    ).all()
    return [_serialize(p) for p in rows]


@router.post("", response_model=ProjectOut, status_code=status.HTTP_201_CREATED)
def create_project(
    body: ProjectIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    project = Project(
        owner_id=user.id, name=body.name, kind=body.kind, content=_content_or_413(body.content)
    )
    db.add(project)
    db.commit()
    db.refresh(project)
    return _serialize(project)


@router.get("/{project_id}", response_model=ProjectOut)
def get_project(
    project_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    return _serialize(_owned_project(db, user, project_id))


@router.put("/{project_id}", response_model=ProjectOut)
def update_project(
    project_id: int,
    body: ProjectIn,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    project = _owned_project(db, user, project_id)
    project.name = body.name
    project.kind = body.kind
    project.content = _content_or_413(body.content)
    db.commit()
    db.refresh(project)
    return _serialize(project)


@router.delete("/{project_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_project(
    project_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    project = _owned_project(db, user, project_id)
    db.delete(project)
    db.commit()
    return None
