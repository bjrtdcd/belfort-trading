"""Knowledge ingestion and retrieval.

Retrieval is the hybrid described in the master plan:

    query -> keyword search (always)
          -> vector search (when embeddings are configured)
          -> reciprocal-rank fusion
          -> top passages with provenance

Every result carries document id, title, section and license metadata so a
future "show sources" feature — and internal verification — costs nothing.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.knowledge import embeddings, fts
from app.knowledge.chunking import chunk_text
from app.knowledge.models import Chunk, Document

RRF_K = 60  # standard reciprocal-rank-fusion constant


@dataclass
class SearchHit:
    chunk_id: int
    document_id: int
    title: str
    section: str
    source_type: str
    license_note: str
    text: str
    score: float


async def ingest_document(
    db: Session,
    *,
    title: str,
    text: str,
    source_type: str = "doc",
    author: str = "",
    license_note: str = "",
    origin: str = "",
) -> Document | None:
    """Chunk, store, index and (when configured) embed one document.
    Returns None when an identical document is already ingested."""
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
    existing = db.scalar(select(Document).where(Document.content_hash == digest))
    if existing is not None:
        return None

    doc = Document(
        title=title.strip(),
        source_type=source_type,
        author=author.strip(),
        license_note=license_note.strip(),
        origin=origin,
        content_hash=digest,
    )
    db.add(doc)
    db.flush()

    pieces = chunk_text(text)
    vectors: list[list[float]] | None = None
    if embeddings.available() and pieces:
        vectors = await embeddings.embed([p.text for p in pieces])

    from app.core.config import get_settings

    model_name = get_settings().embeddings_model if vectors else ""
    for i, piece in enumerate(pieces):
        chunk = Chunk(
            document_id=doc.id,
            ordinal=piece.ordinal,
            section=piece.section,
            text=piece.text,
            embedding=json.dumps(vectors[i]) if vectors else None,
            embedding_model=model_name,
        )
        db.add(chunk)
        db.flush()
        fts.index_chunk(db, chunk.id, chunk.text)

    db.commit()
    db.refresh(doc)
    return doc


def delete_document(db: Session, document_id: int) -> bool:
    doc = db.get(Document, document_id)
    if doc is None:
        return False
    fts.deindex_document(db, document_id)
    db.delete(doc)
    db.commit()
    return True


def _rrf(rankings: list[list[int]]) -> dict[int, float]:
    """Fuse ranked id lists: score(id) = sum over lists of 1/(K + rank)."""
    fused: dict[int, float] = {}
    for ranking in rankings:
        for rank, chunk_id in enumerate(ranking):
            fused[chunk_id] = fused.get(chunk_id, 0.0) + 1.0 / (RRF_K + rank + 1)
    return fused


async def _vector_ranking(db: Session, query: str, limit: int) -> list[int]:
    """Brute-force cosine over stored embeddings. Fine for a small corpus;
    swaps to pgvector behind this same function when scale demands it."""
    query_vec = (await embeddings.embed([query]))[0]
    rows = db.execute(
        select(Chunk.id, Chunk.embedding).where(Chunk.embedding.is_not(None))
    ).all()
    scored = []
    for chunk_id, blob in rows:
        vec = json.loads(blob)
        scored.append((chunk_id, embeddings.cosine(query_vec, vec)))
    scored.sort(key=lambda t: t[1], reverse=True)
    return [chunk_id for chunk_id, _ in scored[:limit]]


async def search(db: Session, query: str, *, limit: int = 8) -> list[SearchHit]:
    pool = max(limit * 3, 20)
    keyword_ranking = [cid for cid, _ in fts.search_keywords(db, query, pool)]
    rankings = [keyword_ranking]
    if embeddings.available():
        rankings.append(await _vector_ranking(db, query, pool))

    fused = _rrf(rankings)
    top_ids = sorted(fused, key=fused.get, reverse=True)[:limit]
    if not top_ids:
        return []

    rows = db.execute(
        select(Chunk, Document)
        .join(Document, Chunk.document_id == Document.id)
        .where(Chunk.id.in_(top_ids))
    ).all()
    by_id = {chunk.id: (chunk, doc) for chunk, doc in rows}
    hits = []
    for cid in top_ids:
        if cid not in by_id:
            continue
        chunk, doc = by_id[cid]
        hits.append(
            SearchHit(
                chunk_id=chunk.id,
                document_id=doc.id,
                title=doc.title,
                section=chunk.section,
                source_type=doc.source_type,
                license_note=doc.license_note,
                text=chunk.text,
                score=round(fused[cid], 6),
            )
        )
    return hits
