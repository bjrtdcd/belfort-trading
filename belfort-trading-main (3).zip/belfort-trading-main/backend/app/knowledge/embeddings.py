"""Embedding provider — same abstraction philosophy as the chat providers.

One generic OpenAI-compatible adapter covers OpenAI, Voyage-style hosts and
self-hosted TEI servers: point BELFORT_EMBEDDINGS_BASE_URL at any of them.
Unconfigured is an honest, first-class state: retrieval simply runs
keyword-only until a provider exists. Nothing fakes a vector.
"""

from __future__ import annotations

import httpx

from app.core.config import get_settings


class EmbeddingsNotConfigured(RuntimeError):
    pass


class EmbeddingsError(RuntimeError):
    pass


def available() -> bool:
    s = get_settings()
    return bool(s.embeddings_base_url and s.embeddings_model)


async def embed(texts: list[str]) -> list[list[float]]:
    """Embed a batch of texts via the configured OpenAI-compatible endpoint."""
    s = get_settings()
    if not available():
        raise EmbeddingsNotConfigured("No embedding provider configured.")
    headers = {}
    if s.embeddings_api_key:
        headers["Authorization"] = f"Bearer {s.embeddings_api_key}"
    url = s.embeddings_base_url.rstrip("/") + "/embeddings"
    async with httpx.AsyncClient(timeout=120) as client:
        resp = await client.post(
            url, json={"model": s.embeddings_model, "input": texts}, headers=headers
        )
    if resp.status_code != 200:
        raise EmbeddingsError(f"Embeddings endpoint returned {resp.status_code}: {resp.text[:300]}")
    data = resp.json()["data"]
    # The API may return out of order; sort by index.
    data.sort(key=lambda d: d["index"])
    return [d["embedding"] for d in data]


def cosine(a: list[float], b: list[float]) -> float:
    dot = num_a = num_b = 0.0
    for x, y in zip(a, b):
        dot += x * y
        num_a += x * x
        num_b += y * y
    if num_a == 0.0 or num_b == 0.0:
        return 0.0
    return dot / (num_a**0.5 * num_b**0.5)
