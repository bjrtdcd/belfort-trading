"""Paragraph-aware chunking.

Splits on blank lines, packs paragraphs into chunks of roughly `target`
characters with `overlap` characters carried between neighbours, and treats
Markdown-style headings as section labels so provenance survives chunking.
Character counts, not tokens: model-agnostic and good enough for retrieval.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

HEADING_RE = re.compile(r"^(#{1,6}\s+|[A-Z][A-Z0-9 ,.&\-]{4,80}$)")


@dataclass
class TextChunk:
    ordinal: int
    section: str
    text: str


def _is_heading(paragraph: str) -> bool:
    line = paragraph.strip()
    if "\n" in line or len(line) > 90:
        return False
    return bool(HEADING_RE.match(line))


def chunk_text(text: str, *, target: int = 1400, overlap: int = 200) -> list[TextChunk]:
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    chunks: list[TextChunk] = []
    section = ""
    buf: list[str] = []
    size = 0

    def flush() -> None:
        nonlocal buf, size
        if not buf:
            return
        body = "\n\n".join(buf)
        chunks.append(TextChunk(ordinal=len(chunks), section=section, text=body))
        # Carry a tail of the finished chunk into the next for continuity.
        tail = body[-overlap:] if overlap and len(body) > overlap else ""
        buf = [tail] if tail else []
        size = len(tail)

    for paragraph in paragraphs:
        if _is_heading(paragraph):
            flush()
            buf = []
            size = 0
            section = paragraph.lstrip("# ").strip()
            continue
        if size + len(paragraph) > target and size > 0:
            flush()
        buf.append(paragraph)
        size += len(paragraph)

    flush()
    return chunks
