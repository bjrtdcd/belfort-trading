"""Keyword search behind one interface, dialect-aware.

- PostgreSQL: tsvector/plainto_tsquery with ts_rank. The expression index is
  created by ensure_fts(); no extra column to keep in sync.
- SQLite (dev/tests): an FTS5 shadow table maintained here on ingest/delete.

Callers only see search_keywords(db, query, limit) -> [(chunk_id, score)].
"""

from __future__ import annotations

from sqlalchemy import text as sql
from sqlalchemy.orm import Session

from app.core.db import engine


def _is_postgres() -> bool:
    return engine.dialect.name.startswith("postgres")


def ensure_fts() -> None:
    """Create the search structures that CREATE TABLE alone doesn't cover."""
    with engine.begin() as conn:
        if _is_postgres():
            conn.execute(sql(
                "CREATE INDEX IF NOT EXISTS chunks_fts_idx ON chunks "
                "USING GIN (to_tsvector('english', text))"
            ))
        else:
            conn.execute(sql(
                "CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5("
                "text, content='chunks', content_rowid='id')"
            ))


def index_chunk(db: Session, chunk_id: int, chunk_text: str) -> None:
    if not _is_postgres():
        db.execute(
            sql("INSERT INTO chunks_fts(rowid, text) VALUES (:id, :t)"),
            {"id": chunk_id, "t": chunk_text},
        )


def deindex_document(db: Session, document_id: int) -> None:
    if not _is_postgres():
        db.execute(
            sql(
                "INSERT INTO chunks_fts(chunks_fts, rowid, text) "
                "SELECT 'delete', id, text FROM chunks WHERE document_id = :d"
            ),
            {"d": document_id},
        )


def search_keywords(db: Session, query: str, limit: int = 20) -> list[tuple[int, float]]:
    query = query.strip()
    if not query:
        return []
    if _is_postgres():
        # OR semantics for recall (matches the SQLite path); ts_rank still
        # scores multi-term matches higher. websearch_to_tsquery parses the
        # OR keywords and treats user input as plain terms otherwise.
        or_query = " OR ".join(query.replace('"', " ").split())
        rows = db.execute(
            sql(
                "SELECT id, ts_rank(to_tsvector('english', text), q) AS score "
                "FROM chunks, websearch_to_tsquery('english', :q) q "
                "WHERE to_tsvector('english', text) @@ q "
                "ORDER BY score DESC LIMIT :k"
            ),
            {"q": or_query, "k": limit},
        ).all()
    else:
        # FTS5: quote each term to disable query syntax from user input.
        # OR semantics for recall — bm25 still ranks multi-term matches first.
        terms = " OR ".join(f'"{t}"' for t in query.replace('"', " ").split())
        if not terms:
            return []
        rows = db.execute(
            sql(
                "SELECT rowid, bm25(chunks_fts) AS score FROM chunks_fts "
                "WHERE chunks_fts MATCH :q ORDER BY score LIMIT :k"
            ),
            {"q": terms, "k": limit},
        ).all()
        # bm25 is lower-is-better; flip sign so callers always see higher-is-better.
        return [(int(r[0]), -float(r[1])) for r in rows]
    return [(int(r[0]), float(r[1])) for r in rows]
