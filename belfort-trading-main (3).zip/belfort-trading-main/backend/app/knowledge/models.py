"""Knowledge base models.

A Document is one licensed source (paper, book, transcript, note). Chunks are
the retrieval units. Provenance lives on both levels so any answer can be
traced back to document, section and license — even though the user-facing
response does not need to show citations.

Embeddings are stored as JSON float arrays on the chunk. That is deliberate
for V1: the corpus starts small, brute-force cosine is milliseconds, and it
keeps dev (SQLite) and prod (Postgres) on one code path. When the corpus
outgrows it, the upgrade is a pgvector column + index behind the same search
interface — nothing above the service layer changes.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.auth.models import utcnow
from app.core.db import Base


class Document(Base):
    __tablename__ = "documents"

    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(300))
    # paper | book | transcript | note | doc
    source_type: Mapped[str] = mapped_column(String(30), default="doc")
    author: Mapped[str] = mapped_column(String(200), default="")
    # Free-text license/permission note: how we are allowed to use this.
    license_note: Mapped[str] = mapped_column(String(300), default="")
    # Where the file came from (path, DOI, URL) for re-ingestion.
    origin: Mapped[str] = mapped_column(String(500), default="")
    # SHA-256 of the ingested text; skips duplicate ingests.
    content_hash: Mapped[str] = mapped_column(String(64), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    chunks: Mapped[list["Chunk"]] = relationship(
        back_populates="document", cascade="all, delete-orphan"
    )


class Chunk(Base):
    __tablename__ = "chunks"

    id: Mapped[int] = mapped_column(primary_key=True)
    document_id: Mapped[int] = mapped_column(ForeignKey("documents.id"), index=True)
    # Position within the document, 0-based.
    ordinal: Mapped[int] = mapped_column(Integer)
    # Heading / section label when the source had one.
    section: Mapped[str] = mapped_column(String(300), default="")
    text: Mapped[str] = mapped_column(Text)
    # JSON array of floats, or NULL until an embedding provider is configured.
    embedding: Mapped[str | None] = mapped_column(Text, default=None)
    embedding_model: Mapped[str] = mapped_column(String(100), default="")

    document: Mapped[Document] = relationship(back_populates="chunks")
