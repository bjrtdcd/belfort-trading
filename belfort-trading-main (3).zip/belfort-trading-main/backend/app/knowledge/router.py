from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.auth.deps import get_current_user
from app.core.db import get_db
from app.knowledge import embeddings, service
from app.knowledge.models import Chunk, Document

router = APIRouter(prefix="/knowledge", tags=["knowledge"])


class HitOut(BaseModel):
    chunk_id: int
    document_id: int
    title: str
    section: str
    source_type: str
    text: str
    score: float


class StatusOut(BaseModel):
    documents: int
    chunks: int
    embedded_chunks: int
    vector_search: bool


@router.get("/search", response_model=list[HitOut])
async def search(
    q: str = Query(min_length=2, max_length=300),
    limit: int = Query(default=8, ge=1, le=25),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    hits = await service.search(db, q, limit=limit)
    return [
        HitOut(
            chunk_id=h.chunk_id,
            document_id=h.document_id,
            title=h.title,
            section=h.section,
            source_type=h.source_type,
            text=h.text,
            score=h.score,
        )
        for h in hits
    ]


@router.get("/status", response_model=StatusOut)
def status(user=Depends(get_current_user), db: Session = Depends(get_db)):
    return StatusOut(
        documents=db.scalar(select(func.count(Document.id))) or 0,
        chunks=db.scalar(select(func.count(Chunk.id))) or 0,
        embedded_chunks=db.scalar(
            select(func.count(Chunk.id)).where(Chunk.embedding.is_not(None))
        )
        or 0,
        vector_search=embeddings.available(),
    )
