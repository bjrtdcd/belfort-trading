"""Belfort backend configuration.

Every deploy-specific value comes from the environment (or a .env file that
never enters git). Defaults are safe for local development only: SQLite on
disk, and a generated throwaway JWT secret that changes each boot unless
BELFORT_JWT_SECRET is set.
"""

from __future__ import annotations

import secrets
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="BELFORT_", env_file=".env", extra="ignore"
    )

    # Runtime
    env: str = "dev"  # dev | prod
    debug: bool = False

    # Database. SQLite for local dev; Postgres in prod, e.g.
    # postgresql+psycopg://belfort:...@localhost:5432/belfort
    database_url: str = "sqlite:///./belfort.db"

    # Auth
    jwt_secret: str = ""
    access_token_minutes: int = 15
    refresh_token_days: int = 30
    bcrypt_rounds: int = 12

    # AI providers. The server-side Groq key is optional; without it the
    # included AI is simply "not configured" and the API says so honestly.
    groq_api_key: str = ""

    # Embeddings: any OpenAI-compatible /embeddings endpoint (OpenAI, TEI,
    # etc). All three unset = keyword-only retrieval, honestly reported.
    embeddings_base_url: str = ""
    embeddings_api_key: str = ""
    embeddings_model: str = ""

    def model_post_init(self, __context) -> None:
        if not self.jwt_secret:
            if self.env == "prod":
                raise RuntimeError(
                    "BELFORT_JWT_SECRET must be set in production. "
                    "Generate one with: python -c \"import secrets; print(secrets.token_urlsafe(48))\""
                )
            # Dev convenience: random per-process secret. Tokens die on restart.
            object.__setattr__(self, "jwt_secret", secrets.token_urlsafe(48))


@lru_cache
def get_settings() -> Settings:
    return Settings()
