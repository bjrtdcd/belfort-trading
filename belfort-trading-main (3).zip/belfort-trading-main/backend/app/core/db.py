"""Database session and base model.

SQLAlchemy 2.0 style. One engine per process; sessions are handed to request
handlers through the get_db dependency and always closed.
"""

from __future__ import annotations

from collections.abc import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.core.config import get_settings


class Base(DeclarativeBase):
    pass


def _make_engine():
    settings = get_settings()
    kwargs: dict = {"pool_pre_ping": True}
    if settings.database_url.startswith("sqlite"):
        # SQLite needs this for FastAPI's threaded request handling.
        kwargs["connect_args"] = {"check_same_thread": False}
    return create_engine(settings.database_url, **kwargs)


engine = _make_engine()
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def create_all() -> None:
    """Create tables that don't exist yet. Fine for V1; Alembic comes when
    the schema starts changing under real users."""
    # Import models so they register on Base.metadata.
    from app.auth import models as _auth_models  # noqa: F401
    from app.knowledge import models as _knowledge_models  # noqa: F401
    from app.projects import models as _project_models  # noqa: F401

    Base.metadata.create_all(bind=engine)
