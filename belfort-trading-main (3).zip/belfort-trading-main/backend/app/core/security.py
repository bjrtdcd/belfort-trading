"""Password hashing and token primitives.

- Passwords: bcrypt with a per-password salt. bcrypt truncates at 72 bytes,
  so longer passwords are rejected up front rather than silently truncated.
- Access tokens: short-lived JWTs (HS256) carrying only the user id.
- Refresh tokens: opaque 256-bit random strings. Only a SHA-256 digest is
  stored server-side, so a database leak does not leak usable tokens.
"""

from __future__ import annotations

import hashlib
import secrets
from datetime import datetime, timedelta, timezone

import bcrypt
import jwt

from app.core.config import get_settings

MAX_PASSWORD_BYTES = 72
MIN_PASSWORD_CHARS = 10


class PasswordPolicyError(ValueError):
    pass


def validate_password(password: str) -> None:
    if len(password) < MIN_PASSWORD_CHARS:
        raise PasswordPolicyError(
            f"Password must be at least {MIN_PASSWORD_CHARS} characters."
        )
    if len(password.encode("utf-8")) > MAX_PASSWORD_BYTES:
        raise PasswordPolicyError("Password is too long (over 72 bytes).")


def hash_password(password: str) -> str:
    validate_password(password)
    settings = get_settings()
    salt = bcrypt.gensalt(rounds=settings.bcrypt_rounds)
    return bcrypt.hashpw(password.encode("utf-8"), salt).decode("ascii")


def verify_password(password: str, hashed: str) -> bool:
    if len(password.encode("utf-8")) > MAX_PASSWORD_BYTES:
        return False
    try:
        return bcrypt.checkpw(password.encode("utf-8"), hashed.encode("ascii"))
    except ValueError:
        return False


def create_access_token(user_id: int) -> str:
    settings = get_settings()
    now = datetime.now(timezone.utc)
    payload = {
        "sub": str(user_id),
        "iat": now,
        "exp": now + timedelta(minutes=settings.access_token_minutes),
        "type": "access",
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm="HS256")


def decode_access_token(token: str) -> int:
    """Return the user id, or raise jwt exceptions on any problem."""
    settings = get_settings()
    payload = jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])
    if payload.get("type") != "access":
        raise jwt.InvalidTokenError("Not an access token")
    return int(payload["sub"])


def new_refresh_token() -> tuple[str, str]:
    """Return (raw_token, sha256_hex). The raw token goes to the client once;
    only the digest is stored."""
    raw = secrets.token_urlsafe(48)
    return raw, hashlib.sha256(raw.encode("ascii")).hexdigest()


def hash_refresh_token(raw: str) -> str:
    return hashlib.sha256(raw.encode("ascii")).hexdigest()


def refresh_expiry() -> datetime:
    settings = get_settings()
    return datetime.now(timezone.utc) + timedelta(days=settings.refresh_token_days)
