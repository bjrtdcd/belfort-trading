"""Knowledge base tests: chunking, ingestion, keyword search, hybrid fusion
with a stubbed embedder, and the HTTP endpoints."""

from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("BELFORT_DATABASE_URL", "sqlite:///./test_belfort.db")
os.environ.setdefault("BELFORT_BCRYPT_ROUNDS", "4")

import pytest
from fastapi.testclient import TestClient

from app.core.db import Base, SessionLocal, engine
from app.knowledge import embeddings, service
from app.knowledge.chunking import chunk_text
from app.knowledge.fts import ensure_fts
from app.main import app

PAPER = """MEAN REVERSION IN INDEX FUTURES

Short-term liquidity shocks in equity index futures are followed by partial
price reversals. We measure reversal strength on NQ using depth imbalance.

METHODOLOGY

We use MBP-10 order book snapshots sampled at one-second intervals. Depth
imbalance is the size-weighted difference between bid and ask levels.

RESULTS

Reversal magnitude grows with shock size. Transaction costs erase the edge
below two ticks of expected move; slippage assumptions dominate the result.
"""

BOOK = """POSITION SIZING

The fraction of capital risked per trade determines both growth rate and
risk of ruin. Kelly-optimal sizing maximizes log growth but the variance is
brutal in practice; half-Kelly keeps most of the growth at far less pain.

DRAWDOWNS

Expected maximum drawdown scales with the square of position size, which is
why doubling risk more than doubles the pain of the worst stretch.
"""


@pytest.fixture()
def db():
    Base.metadata.drop_all(bind=engine)
    with engine.begin() as conn:
        conn.exec_driver_sql("DROP TABLE IF EXISTS chunks_fts")
    Base.metadata.create_all(bind=engine)
    ensure_fts()
    session = SessionLocal()
    yield session
    session.close()


@pytest.fixture()
def client(db):
    with TestClient(app) as c:
        c.post("/auth/register", json={"email": "t@example.com", "password": "long-enough-pass"})
        tokens = c.post(
            "/auth/login", json={"email": "t@example.com", "password": "long-enough-pass"}
        ).json()
        c.headers["Authorization"] = f"Bearer {tokens['access_token']}"
        yield c


def test_chunking_sections_and_overlap():
    chunks = chunk_text(PAPER, target=200, overlap=40)
    assert len(chunks) >= 3
    sections = {c.section for c in chunks}
    assert "METHODOLOGY" in sections and "RESULTS" in sections
    assert all(c.text.strip() for c in chunks)


@pytest.mark.anyio
async def test_ingest_dedupe_and_keyword_search(db):
    doc = await service.ingest_document(
        db, title="Mean reversion paper", text=PAPER,
        source_type="paper", license_note="owned copy",
    )
    assert doc is not None and len(doc.chunks) >= 1
    dup = await service.ingest_document(db, title="Same again", text=PAPER)
    assert dup is None  # content-hash dedupe

    await service.ingest_document(db, title="Sizing book", text=BOOK, source_type="book")

    hits = await service.search(db, "liquidity shocks reversal")
    assert hits and hits[0].title == "Mean reversion paper"
    assert hits[0].license_note == "owned copy"

    hits2 = await service.search(db, "kelly position sizing")
    assert hits2 and hits2[0].title == "Sizing book"


@pytest.mark.anyio
async def test_hybrid_fusion_with_stub_embedder(db, monkeypatch):
    # Deterministic stub: vector = [len(text) mod 7, count of 'drawdown'].
    async def fake_embed(texts):
        return [[float(len(t) % 7 + 1), float(t.lower().count("drawdown"))] for t in texts]

    monkeypatch.setattr(embeddings, "available", lambda: True)
    monkeypatch.setattr(embeddings, "embed", fake_embed)

    from app.core.config import get_settings
    monkeypatch.setattr(get_settings(), "embeddings_model", "stub-model", raising=False)

    await service.ingest_document(db, title="Sizing book", text=BOOK, source_type="book")
    from sqlalchemy import select
    from app.knowledge.models import Chunk
    embedded = db.scalars(select(Chunk).where(Chunk.embedding.is_not(None))).all()
    assert embedded and all(c.embedding_model == "stub-model" for c in embedded)

    hits = await service.search(db, "drawdown scaling with position size")
    assert hits  # fusion of keyword + vector rankings returns results
    assert hits[0].document_id == embedded[0].document_id


@pytest.mark.anyio
async def test_delete_document_removes_from_search(db):
    doc = await service.ingest_document(db, title="Mean reversion paper", text=PAPER)
    assert (await service.search(db, "liquidity shocks"))
    assert service.delete_document(db, doc.id) is True
    assert (await service.search(db, "liquidity shocks")) == []


def test_endpoints_auth_and_status(client):
    unauth = TestClient(app)
    assert unauth.get("/knowledge/search?q=test").status_code == 401
    assert unauth.get("/knowledge/status").status_code == 401

    status = client.get("/knowledge/status").json()
    assert status == {
        "documents": 0, "chunks": 0, "embedded_chunks": 0, "vector_search": False,
    }
    assert client.get("/knowledge/search?q=liquidity").json() == []
