"""Auth + projects integration tests against an in-memory app instance."""

from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("BELFORT_DATABASE_URL", "sqlite:///./test_belfort.db")
os.environ.setdefault("BELFORT_BCRYPT_ROUNDS", "4")  # fast hashing in tests

import pytest
from fastapi.testclient import TestClient

from app.core.db import Base, engine
from app.main import app

EMAIL = "trader@example.com"
PASSWORD = "correct-horse-battery"


@pytest.fixture()
def client():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    with TestClient(app) as c:
        yield c


def register_and_login(client) -> dict:
    client.post(
        "/auth/register",
        json={"email": EMAIL, "password": PASSWORD, "display_name": "Trader"},
    )
    resp = client.post("/auth/login", json={"email": EMAIL, "password": PASSWORD})
    assert resp.status_code == 200
    return resp.json()


def auth_headers(tokens: dict) -> dict:
    return {"Authorization": f"Bearer {tokens['access_token']}"}


def test_register_login_me(client):
    resp = client.post(
        "/auth/register",
        json={"email": EMAIL, "password": PASSWORD, "display_name": "Trader"},
    )
    assert resp.status_code == 201
    body = resp.json()
    assert body["email"] == EMAIL
    assert "password" not in body and "password_hash" not in body

    tokens = client.post("/auth/login", json={"email": EMAIL, "password": PASSWORD}).json()
    me = client.get("/users/me", headers={"Authorization": f"Bearer {tokens['access_token']}"})
    assert me.status_code == 200
    assert me.json()["email"] == EMAIL


def test_wrong_password_and_unknown_email_both_401(client):
    register_and_login(client)
    r1 = client.post("/auth/login", json={"email": EMAIL, "password": "wrong-password-x"})
    r2 = client.post("/auth/login", json={"email": "nobody@example.com", "password": PASSWORD})
    assert r1.status_code == 401 and r2.status_code == 401
    assert r1.json() == r2.json()  # identical body: no user enumeration


def test_short_password_rejected(client):
    resp = client.post("/auth/register", json={"email": EMAIL, "password": "short"})
    assert resp.status_code == 422


def test_duplicate_email_conflict(client):
    client.post("/auth/register", json={"email": EMAIL, "password": PASSWORD})
    resp = client.post("/auth/register", json={"email": EMAIL.upper(), "password": PASSWORD})
    assert resp.status_code == 409


def test_refresh_rotation_and_revocation(client):
    tokens = register_and_login(client)
    old_refresh = tokens["refresh_token"]

    rotated = client.post("/auth/refresh", json={"refresh_token": old_refresh})
    assert rotated.status_code == 200
    new_tokens = rotated.json()
    assert new_tokens["refresh_token"] != old_refresh

    # The old token is dead after rotation.
    reuse = client.post("/auth/refresh", json={"refresh_token": old_refresh})
    assert reuse.status_code == 401

    # Logout kills the new one too.
    out = client.post("/auth/logout", json={"refresh_token": new_tokens["refresh_token"]})
    assert out.status_code == 204
    dead = client.post("/auth/refresh", json={"refresh_token": new_tokens["refresh_token"]})
    assert dead.status_code == 401


def test_me_requires_token(client):
    assert client.get("/users/me").status_code == 401
    bad = client.get("/users/me", headers={"Authorization": "Bearer not-a-token"})
    assert bad.status_code == 401


def test_projects_crud_and_isolation(client):
    tokens = register_and_login(client)
    h = auth_headers(tokens)

    created = client.post(
        "/projects",
        json={"name": "NQ mean reversion", "kind": "strategy", "content": {"v": 1}},
        headers=h,
    )
    assert created.status_code == 201
    pid = created.json()["id"]

    listed = client.get("/projects", headers=h).json()
    assert len(listed) == 1 and listed[0]["content"] == {"v": 1}

    updated = client.put(
        f"/projects/{pid}",
        json={"name": "NQ mean reversion v2", "kind": "strategy", "content": {"v": 2}},
        headers=h,
    )
    assert updated.status_code == 200 and updated.json()["content"] == {"v": 2}

    # A second user cannot see or touch it.
    client.post("/auth/register", json={"email": "other@example.com", "password": PASSWORD})
    other = client.post(
        "/auth/login", json={"email": "other@example.com", "password": PASSWORD}
    ).json()
    oh = auth_headers(other)
    assert client.get(f"/projects/{pid}", headers=oh).status_code == 404
    assert client.delete(f"/projects/{pid}", headers=oh).status_code == 404
    assert client.get("/projects", headers=oh).json() == []

    # Owner deletes.
    assert client.delete(f"/projects/{pid}", headers=h).status_code == 204
    assert client.get(f"/projects/{pid}", headers=h).status_code == 404


def test_ai_providers_honest_status(client):
    tokens = register_and_login(client)
    resp = client.get("/ai/providers", headers=auth_headers(tokens))
    assert resp.status_code == 200
    body = resp.json()
    assert body == [{"name": "groq", "available": False}]  # no key set in tests
