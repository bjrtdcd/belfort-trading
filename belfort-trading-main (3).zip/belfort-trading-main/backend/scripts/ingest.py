"""Ingest .txt / .md files into the Belfort knowledge base.

Usage (from backend/):

    python scripts/ingest.py path/to/folder --source-type paper --license "owned copy"
    python scripts/ingest.py notes.md --title "Execution notes" --author "Bastian"

- Duplicate content (same SHA-256) is skipped, so re-running is safe.
- With no embedding provider configured, documents are ingested for keyword
  search now; run this again after configuring embeddings to backfill
  vectors (delete + re-ingest, or a future backfill command).

PDFs and heavier formats go through a proper extraction worker later; this
CLI covers plain text so the library can start filling today.
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.core.db import SessionLocal, create_all  # noqa: E402
from app.knowledge import service  # noqa: E402
from app.knowledge.fts import ensure_fts  # noqa: E402

TEXT_SUFFIXES = {".txt", ".md", ".markdown"}


def collect_files(path: Path) -> list[Path]:
    if path.is_file():
        return [path]
    return sorted(p for p in path.rglob("*") if p.suffix.lower() in TEXT_SUFFIXES)


async def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", type=Path, help="File or folder of .txt/.md files")
    parser.add_argument("--title", default="", help="Title (single file only; defaults to filename)")
    parser.add_argument("--source-type", default="doc",
                        choices=["paper", "book", "transcript", "note", "doc"])
    parser.add_argument("--author", default="")
    parser.add_argument("--license", dest="license_note", default="",
                        help="How we're allowed to use this material")
    args = parser.parse_args()

    files = collect_files(args.path)
    if not files:
        print(f"No .txt/.md files found under {args.path}")
        return 1
    if args.title and len(files) > 1:
        print("--title only applies to a single file")
        return 1

    create_all()
    ensure_fts()
    db = SessionLocal()
    ingested = skipped = 0
    try:
        for f in files:
            text = f.read_text(encoding="utf-8", errors="replace")
            if not text.strip():
                print(f"  empty, skipping: {f.name}")
                continue
            doc = await service.ingest_document(
                db,
                title=args.title or f.stem.replace("_", " ").replace("-", " ").strip(),
                text=text,
                source_type=args.source_type,
                author=args.author,
                license_note=args.license_note,
                origin=str(f),
            )
            if doc is None:
                skipped += 1
                print(f"  already ingested: {f.name}")
            else:
                ingested += 1
                print(f"  ingested: {doc.title} ({len(doc.chunks)} chunks)")
    finally:
        db.close()

    print(f"Done. {ingested} ingested, {skipped} duplicates skipped.")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
