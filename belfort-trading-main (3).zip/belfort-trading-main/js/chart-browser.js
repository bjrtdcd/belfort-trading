// Chart browser for the backtester report.
//
// Each tab used to dump every chart it had into one column — 22 on Performance,
// 50 across the report — so reading it meant scrolling past everything you did
// not want. This adds, per tab: a jump bar for its sections, a picker for which
// charts are shown, and an "essentials" default so the page opens short.
(function () {
  'use strict';

  var STORE = 'belfort-charts2-';
  var ESSENTIALS = {
    'panel-performance': ['Equity curve', 'Underwater drawdown', 'Per-trade P&L', 'Rolling Sharpe', 'Monthly returns', 'Long vs short performance'],
    'panel-montecarlo': ['Equity percentile bands', 'Terminal outcome distribution', 'Max drawdown distribution', 'Risk of ruin over time'],
    'panel-propfirm': ['Expected value breakdown (per attempt)', 'Pass / fail outcome', 'Pass probability (≥1 pass in N accounts)', 'Risk of ruin over N accounts'],
    'panel-views3d': ['Equity path fan', 'Monte Carlo equity surface', 'Drawdown surface'],
  };

  function title(card) {
    var h = card.querySelector('h3');
    return h ? h.textContent.trim() : '';
  }

  // A panel is a flat list of section headings each followed by a grid of cards.
  function readSections(panel) {
    var sections = [];
    var current = null;
    Array.prototype.forEach.call(panel.children, function (el) {
      if (el.classList.contains('section-title')) {
        current = { heading: el, name: el.textContent.trim(), grids: [], cards: [] };
        sections.push(current);
        return;
      }
      var cards = el.classList && el.classList.contains('chart-card') ? [el] : Array.prototype.slice.call(el.querySelectorAll('.chart-card'));
      if (!cards.length) return;
      if (!current) {
        current = { heading: null, name: 'Charts', grids: [], cards: [] };
        sections.push(current);
      }
      current.grids.push(el);
      current.cards = current.cards.concat(cards);
    });
    return sections.filter(function (s) { return s.cards.length; });
  }

  function loadChoice(panelId, allTitles) {
    var raw = localStorage.getItem(STORE + panelId);
    if (raw) {
      try {
        var saved = JSON.parse(raw).filter(function (t) { return allTitles.indexOf(t) !== -1; });
        if (saved.length) return saved;
      } catch (e) { /* fall through to defaults */ }
    }
    // No saved choice: show every chart by default. The Essentials preset
    // below is still available for users who want the short version.
    return allTitles.slice();
  }

  function resize(card) {
    var plot = card.querySelector('.js-plotly-plot');
    if (plot && window.Plotly && window.Plotly.Plots) {
      try { window.Plotly.Plots.resize(plot); } catch (e) { /* chart not drawn yet */ }
    }
  }

  function build(panel) {
    if (panel.dataset.browser === '1') return;
    var sections = readSections(panel);
    if (!sections.length) return;

    var allTitles = [];
    sections.forEach(function (s) { s.cards.forEach(function (c) { allTitles.push(title(c)); }); });
    if (allTitles.length < 5) return;   // short tabs do not need a browser

    var shown = loadChoice(panel.id, allTitles);

    var bar = document.createElement('div');
    bar.className = 'chart-browser';
    bar.innerHTML =
      '<div class="cb-jump"></div>'
      + '<div class="cb-right">'
      + '  <span class="cb-count"></span>'
      + '  <button type="button" class="cb-btn" data-preset="essentials">Essentials</button>'
      + '  <button type="button" class="cb-btn" data-preset="all">All</button>'
      + '  <div class="cb-picker-wrap">'
      + '    <button type="button" class="cb-btn cb-toggle">Choose charts ▾</button>'
      + '    <div class="cb-picker"></div>'
      + '  </div>'
      + '</div>';
    panel.insertBefore(bar, panel.firstChild);

    var jump = bar.querySelector('.cb-jump');
    var picker = bar.querySelector('.cb-picker');

    sections.forEach(function (s, i) {
      var chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'cb-chip';
      chip.textContent = s.name;
      chip.addEventListener('click', function () {
        (s.heading || s.grids[0]).scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
      jump.appendChild(chip);

      var group = document.createElement('div');
      group.className = 'cb-group';
      group.innerHTML = '<div class="cb-group-name">' + s.name + '</div>';
      s.cards.forEach(function (card) {
        var t = title(card);
        var row = document.createElement('label');
        row.className = 'cb-row';
        row.innerHTML = '<input type="checkbox" value="' + t.replace(/"/g, '&quot;') + '"><span>' + t + '</span>';
        group.appendChild(row);
      });
      picker.appendChild(group);
      s.index = i;
    });

    function apply() {
      sections.forEach(function (s) {
        var visible = 0;
        s.cards.forEach(function (card) {
          var on = shown.indexOf(title(card)) !== -1;
          card.style.display = on ? '' : 'none';
          if (on) { visible++; resize(card); }
        });
        if (s.heading) s.heading.style.display = visible ? '' : 'none';
        s.grids.forEach(function (g) { g.style.display = visible ? '' : 'none'; });
        var chip = jump.children[s.index];
        if (chip) chip.classList.toggle('cb-chip-off', !visible);
      });
      Array.prototype.forEach.call(picker.querySelectorAll('input'), function (input) {
        input.checked = shown.indexOf(input.value) !== -1;
      });
      bar.querySelector('.cb-count').textContent = shown.length + ' of ' + allTitles.length + ' charts';
      localStorage.setItem(STORE + panel.id, JSON.stringify(shown));
    }

    picker.addEventListener('change', function (e) {
      var v = e.target.value;
      if (e.target.checked) { if (shown.indexOf(v) === -1) shown.push(v); }
      else shown = shown.filter(function (t) { return t !== v; });
      apply();
    });
    bar.querySelector('[data-preset="all"]').addEventListener('click', function () { shown = allTitles.slice(); apply(); });
    bar.querySelector('[data-preset="essentials"]').addEventListener('click', function () {
      shown = (ESSENTIALS[panel.id] || []).filter(function (t) { return allTitles.indexOf(t) !== -1; });
      if (!shown.length) shown = allTitles.slice(0, 6);
      apply();
    });
    bar.querySelector('.cb-toggle').addEventListener('click', function (e) {
      e.stopPropagation();
      picker.classList.toggle('open');
    });
    document.addEventListener('click', function (e) {
      if (!picker.contains(e.target)) picker.classList.remove('open');
    });

    apply();
    panel.dataset.browser = '1';
  }

  function buildAll() {
    Array.prototype.forEach.call(document.querySelectorAll('.bt-tab-panel'), build);
  }

  // Keep the open tab in the URL so a view can be linked and survives reload.
  // The report renders tabs as <button role="tab" id="tab-performance">.
  function wireTabs() {
    var buttons = document.querySelectorAll('button[role="tab"][id^="tab-"]');
    if (!buttons.length) return;
    Array.prototype.forEach.call(buttons, function (b) {
      var name = b.id.replace(/^tab-/, '');
      b.addEventListener('click', function () { history.replaceState({}, '', '#' + name); });
    });
    var want = location.hash.replace('#', '');
    if (want) {
      var target = document.getElementById('tab-' + want);
      if (target) target.click();
    }
  }

  function boot() {
    buildAll();
    wireTabs();
    var report = document.getElementById('report') || document.body;
    // A new backtest run rebuilds the cards; re-apply once they settle.
    var pending;
    new MutationObserver(function () {
      clearTimeout(pending);
      pending = setTimeout(function () {
        Array.prototype.forEach.call(document.querySelectorAll('.bt-tab-panel'), function (p) {
          if (!p.querySelector('.chart-browser')) p.dataset.browser = '';
        });
        buildAll();
      }, 400);
    }).observe(report, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { setTimeout(boot, 800); });
  else setTimeout(boot, 800);
})();
