// Copilot Code-Server client — launches a real VS Code (code-server) container
// via the backend (server/codeserver/api.js) and embeds it. Self-contained:
// reads window.QUANTPAD_CODESERVER, calls the API, renders the panel + iframe.
// No Monaco, no clone — the actual VS Code on Linux, hosted by your backend.
(function () {
  'use strict';
  var cfg = window.QUANTPAD_CODESERVER || {};
  var SESSION_KEY = 'quantpad-cs-session';

  function esc(s) { var d = document.createElement('div'); d.textContent = String(s == null ? '' : s); return d.innerHTML; }

  function session() {
    var s = localStorage.getItem(SESSION_KEY);
    if (s) return s;
    s = 'sess-' + Math.random().toString(36).slice(2, 10);
    localStorage.setItem(SESSION_KEY, s);
    return s;
  }

  function api(path, opts) {
    if (!cfg.apiBase) return Promise.reject(new Error('not configured'));
    return fetch(cfg.apiBase + path, Object.assign({
      headers: { 'content-type': 'application/json', 'x-belfort-key': cfg.apiKey || '' },
    }, opts)).then(function (r) {
      if (!r.ok) return r.json().catch(function () { return {}; }).then(function (b) { throw new Error(b.error || ('HTTP ' + r.status)); });
      return r.json();
    });
  }

  var host, statusEl, iframeWrap, iframe, startBtn, stopBtn, refreshBtn;

  function renderState(state) {
    if (!host) return;
    if (!cfg.apiBase) {
      host.innerHTML = '<div class="gh-panel" style="margin:0;color:var(--color-text-tertiary)">Real VS Code on Linux is not configured. Set <code>apiBase</code> + <code>apiKey</code> in <code>config/codeserver.js</code> and deploy <code>server/codeserver</code>. See <code>server/codeserver/README.md</code>.<br><br>This is the actual VS Code (code-server), not a clone — but it needs a backend host you run.</div>';
      return;
    }
    if (state === 'starting') statusEl.textContent = 'Starting your real VS Code container… (first run pulls the image, ~1–2 min)';
    else if (state === 'stopping') statusEl.textContent = 'Stopping…';
    else if (state === 'error') statusEl.textContent = 'Error — see below.';
  }

  function showVscode(url) {
    if (!iframe) return;
    iframe.src = url;
    iframeWrap.style.display = 'block';
    startBtn.style.display = 'none';
    stopBtn.style.display = '';
    refreshBtn.style.display = '';
    statusEl.textContent = 'Real VS Code ready — embedded below.';
  }

  function start() {
    renderState('starting');
    api('/start', { method: 'POST', body: JSON.stringify({ session: session() }) }).then(function (r) {
      // code-server needs a moment to boot inside the container; poll status.
      var tries = 0;
      (function poll() {
        api('/status?session=' + encodeURIComponent(session())).then(function (s) {
          if (s.running) { showVscode(r.url); }
          else if (tries++ < 30) { setTimeout(poll, 2000); }
          else { renderState('error'); statusEl.textContent = 'Container started but VS Code did not come up. Open ' + r.url + ' directly.'; }
        }).catch(function (e) { statusEl.textContent = e.message; });
      })();
    }).catch(function (e) { renderState('error'); statusEl.textContent = e.message; });
  }

  function stop() {
    renderState('stopping');
    api('/stop', { method: 'POST', body: JSON.stringify({ session: session() }) }).then(function () {
      if (iframe) iframe.src = 'about:blank';
      iframeWrap.style.display = 'none';
      startBtn.style.display = '';
      stopBtn.style.display = 'none';
      refreshBtn.style.display = 'none';
      statusEl.textContent = 'Stopped. Your files are kept on the server volume.';
    }).catch(function (e) { statusEl.textContent = e.message; });
  }

  function refresh() { if (iframe && iframe.src && iframe.src !== 'about:blank') iframe.src = iframe.src; }

  function mount(panel) {
    panel.innerHTML =
      '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:12px">'
      + '<div style="font-size:.92rem;font-weight:600">Real VS Code on Linux</div>'
      + '<div style="margin-left:auto;display:flex;gap:8px">'
      + '<button class="ws-btn ws-btn-primary" id="cs-start">Launch real VS Code</button>'
      + '<button class="ws-btn ws-btn-ghost" id="cs-refresh" style="display:none">Reload</button>'
      + '<button class="ws-btn ws-btn-danger" id="cs-stop" style="display:none">Stop</button>'
      + '</div></div>'
      + '<div class="gh-sub" id="cs-status" style="margin-bottom:10px"></div>'
      + '<div id="cs-iframe-wrap" style="display:none;border:1px solid var(--color-border-primary);border-radius:10px;overflow:hidden;height:70vh;background:#1f1f1f">'
      + '<iframe id="cs-iframe" style="width:100%;height:100%;border:0" allow="clipboard-read;clipboard-write" title="VS Code"></iframe>'
      + '</div>';
    host = panel;
    statusEl = panel.querySelector('#cs-status');
    iframeWrap = panel.querySelector('#cs-iframe-wrap');
    iframe = panel.querySelector('#cs-iframe');
    startBtn = panel.querySelector('#cs-start');
    stopBtn = panel.querySelector('#cs-stop');
    refreshBtn = panel.querySelector('#cs-refresh');
    startBtn.addEventListener('click', start);
    stopBtn.addEventListener('click', stop);
    refreshBtn.addEventListener('click', refresh);
    renderState(cfg.apiBase ? 'idle' : 'unconfigured');
    if (cfg.apiBase) statusEl.textContent = 'Click "Launch real VS Code" — it starts a real code-server container and embeds it here.';
  }

  window.CodeServerClient = { mount: mount, start: start, stop: stop };
})();
