(() => {
  // backtester-src/csv.ts
  var normalize = (value) => String(value || "").trim().toLowerCase().replace(/[%$£€]/g, "").replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");
  var RESULT_ALIASES = [
    "pnl",
    "profit",
    "profit_loss",
    "profitloss",
    "net_pnl",
    "net_profit",
    "net_return",
    "return",
    "returns",
    "ret",
    "r",
    "r_multiple",
    "r_multiple_points",
    "profit_pct",
    "return_pct",
    "pnl_pct",
    "net",
    "realized_pnl",
    "pl",
    "gain",
    "gains"
  ];
  var DATE_ALIASES = [
    "date",
    "datetime",
    "date_time",
    "date_time_1",
    "timestamp",
    "time",
    "trade_date",
    "entry_date",
    "entry_time",
    "exit_date",
    "exit_time",
    "open_time",
    "close_time",
    "opened_at",
    "closed_at",
    "open_date",
    "close_date"
  ];
  var ENTRY_ALIASES = ["entry", "entry_price", "avg_entry_price", "open", "open_price", "entry_price_1", "price_1", "buy_price", "entry_fill_price"];
  var EXIT_ALIASES = ["exit", "exit_price", "avg_exit_price", "close", "close_price", "exit_price_1", "price_2", "sell_price", "exit_fill_price"];
  var SIZE_ALIASES = ["size", "quantity", "qty", "shares", "contracts", "units", "lots", "volume", "position"];
  var DIRECTION_ALIASES = ["direction", "side", "position", "type", "action", "signal", "b_s", "long_short"];
  var FEE_ALIASES = ["fee", "fees", "commission", "commissions", "comm", "cost", "slippage", "swap"];
  var QUANTITY_RE = /^([0-9.]+)(m|k|klote|lot)?$/i;
  var SHORT_RE = /^(short|sell|s|bajista|put)$/i;
  var LONG_RE = /^(long|buy|l|call)$/i;
  function parseNumber(raw) {
    const value = String(raw ?? "").trim();
    if (!value) return NaN;
    const negative = /^\(.*\)$/.test(value);
    let cleaned = value.replace(/[()$£€,%\s]/g, "");
    cleaned = cleaned.replace(/(\d)[,.](\d)/g, "$1.$2");
    const parsed = Number(cleaned);
    if (Number.isNaN(parsed)) {
      const match = value.replace(/[()$£€,\s]/g, "").match(/^[+-]?(\d+)$/);
      return match ? negative ? -Number(match[1]) : Number(match[1]) : NaN;
    }
    return negative ? -parsed : parsed;
  }
  function parseSize(raw) {
    const value = String(raw ?? "").trim();
    if (!value) return null;
    const match = value.match(QUANTITY_RE);
    if (!match) return null;
    let number = parseFloat(match[1]);
    if (Number.isNaN(number)) return null;
    const suffix = (match[2] || "").toLowerCase();
    if (suffix === "k") number *= 1e3;
    else if (suffix === "m") number *= 1e6;
    return number;
  }
  function parseDate(raw) {
    const s = String(raw ?? "").trim();
    if (!s) return null;
    const base = new Date(s);
    if (!Number.isNaN(base.getTime())) return base.toISOString();
    let m = s.match(/^(\d{4})[.\/-](\d{1,2})[.\/-](\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?)?$/i);
    if (m) {
      let h = m[4] ? +m[4] : 0;
      if (m[7]) h = h % 12 + (/PM/i.test(m[7]) ? 12 : 0);
      const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], h, m[5] ? +m[5] : 0, m[6] ? +m[6] : 0));
      if (!Number.isNaN(d.getTime())) return d.toISOString();
    }
    m = s.match(/^(\d{1,2})[\/.](\d{1,2})[\/.](\d{2,4})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?)?$/i);
    if (m) {
      let yr = +m[3];
      if (yr < 100) yr += 2e3;
      let mo = +m[1], da = +m[2];
      if (mo > 12) {
        const t = mo;
        mo = da;
        da = t;
      }
      let h = m[4] ? +m[4] : 0;
      if (m[7]) h = h % 12 + (/PM/i.test(m[7]) ? 12 : 0);
      const d = new Date(Date.UTC(yr, mo - 1, da, h, m[5] ? +m[5] : 0, m[6] ? +m[6] : 0));
      if (!Number.isNaN(d.getTime())) return d.toISOString();
    }
    return null;
  }
  function detectPlatform(headers) {
    if (headers.includes("instrument")) return "ninjatrader";
    if (headers.includes("swap") || headers.includes("volume") && headers.includes("commission")) return "metatrader";
    if (headers.includes("contracts") && (headers.includes("signal") || headers.includes("profit_loss") || headers.includes("profitloss"))) return "multicharts";
    if (headers.includes("type") && headers.includes("price") && headers.includes("date_time")) return "tradingview";
    if (headers.includes("order_id") || headers.includes("ticket")) return "metatrader";
    return null;
  }
  function parseCsv(text) {
    const rows = [];
    let row = [];
    let cell = "";
    let quoted = false;
    for (let i = 0; i < text.length; i += 1) {
      const char = text[i];
      const next = text[i + 1];
      if (char === '"' && quoted && next === '"') {
        cell += '"';
        i += 1;
        continue;
      }
      if (char === '"') {
        quoted = !quoted;
        continue;
      }
      if (char === "," && !quoted) {
        row.push(cell);
        cell = "";
        continue;
      }
      if ((char === "\n" || char === "\r") && !quoted) {
        if (char === "\r" && next === "\n") i += 1;
        row.push(cell);
        if (row.some((v) => v.trim())) rows.push(row);
        row = [];
        cell = "";
        continue;
      }
      cell += char;
    }
    if (cell.length || row.length) {
      row.push(cell);
      if (row.some((v) => v.trim())) rows.push(row);
    }
    return rows;
  }
  function findIndex(headers, aliases) {
    for (const alias of aliases) {
      const index = headers.indexOf(alias);
      if (index >= 0) return index;
    }
    return -1;
  }
  function isTradingViewFormat(headers) {
    return headers.includes("type") && headers.includes("price") && headers.includes("date_time");
  }
  function parseTradingViewTradeList(rows) {
    const headers = rows[0].map(normalize);
    const typeIdx = headers.indexOf("type");
    const dateIdx = headers.indexOf("date_time");
    const priceIdx = headers.indexOf("price");
    const qtyIdx = headers.indexOf("qty") >= 0 ? headers.indexOf("qty") : headers.indexOf("quantity");
    const pnlIdx = headers.indexOf("p_l");
    const tradeNumIdx = headers.indexOf("trade");
    if (typeIdx < 0 || priceIdx < 0 || dateIdx < 0) return null;
    const groups = /* @__PURE__ */ new Map();
    for (let r = 1; r < rows.length; r += 1) {
      const row = rows[r];
      if (!row.some((v) => v.trim())) continue;
      const key = tradeNumIdx >= 0 && row[tradeNumIdx] ? row[tradeNumIdx].trim() : String(r);
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(row);
    }
    const trades = [];
    groups.forEach((group) => {
      let entry = group.find((row) => /entry/i.test(row[typeIdx] || ""));
      let exit = group.find((row) => /exit/i.test(row[typeIdx] || ""));
      if (!entry && !exit) {
        entry = group[0];
        exit = group[group.length - 1];
      }
      if (!entry || !exit) return;
      const typeStr = (entry[typeIdx] || "").toLowerCase();
      const direction = /short/.test(typeStr) ? "short" : /long/.test(typeStr) ? "long" : "unknown";
      const entryPrice = parseNumber(entry[priceIdx]);
      const exitPrice = parseNumber(exit[priceIdx]);
      const qty = qtyIdx >= 0 ? parseSize((entry[qtyIdx] || exit[qtyIdx] || "").trim()) : null;
      const size = qty ?? 1;
      let pnl = pnlIdx >= 0 ? parseNumber(exit[pnlIdx] || "") : NaN;
      if (!Number.isFinite(pnl) && Number.isFinite(entryPrice) && Number.isFinite(exitPrice)) {
        const sign = direction === "short" ? -1 : 1;
        pnl = (exitPrice - entryPrice) * sign * size;
      }
      if (!Number.isFinite(pnl)) return;
      const rawDate = (exit[dateIdx] || "").trim();
      const date = parseDate(rawDate);
      trades.push({
        row: 0,
        date,
        direction,
        entry: Number.isFinite(entryPrice) ? entryPrice : null,
        exit: Number.isFinite(exitPrice) ? exitPrice : null,
        size: qtyIdx >= 0 ? qty : null,
        fee: 0,
        pnl
      });
    });
    trades.sort((a, b) => {
      if (a.date && b.date) return new Date(a.date).getTime() - new Date(b.date).getTime();
      return 0;
    });
    trades.forEach((trade, index) => {
      trade.row = index + 2;
    });
    return trades;
  }
  function buildTradeLog(text) {
    const rows = parseCsv(text);
    if (rows.length < 2) {
      throw new Error("Add a header row and at least two trade rows to run a backtest.");
    }
    const headers = rows[0].map(normalize);
    if (isTradingViewFormat(headers)) {
      const tvTrades = parseTradingViewTradeList(rows);
      if (tvTrades && tvTrades.length >= 2) {
        const platform2 = detectPlatform(headers) || "tradingview";
        return {
          trades: tvTrades,
          ignored: 0,
          detected: [platform2, "date", "entry", "exit", "size", "direction"],
          derivedPnl: false,
          hasDates: tvTrades.some((trade) => trade.date !== null)
        };
      }
      throw new Error(
        "TradingView trade list detected but fewer than two complete trades were found. Each trade needs both an Entry and an Exit fill."
      );
    }
    const resultIndex = findIndex(headers, RESULT_ALIASES);
    const dateIndex = findIndex(headers, DATE_ALIASES);
    const entryIndex = findIndex(headers, ENTRY_ALIASES);
    const exitIndex = findIndex(headers, EXIT_ALIASES);
    const sizeIndex = findIndex(headers, SIZE_ALIASES);
    const directionIndex = findIndex(headers, DIRECTION_ALIASES);
    const feeIndex = findIndex(headers, FEE_ALIASES);
    if (resultIndex < 0 && (entryIndex < 0 || exitIndex < 0)) {
      throw new Error(
        "No usable result column. Include pnl/profit/return, or entry and exit price columns."
      );
    }
    const trades = [];
    let ignored = 0;
    let derived = false;
    const detected = [];
    const platform = detectPlatform(headers);
    if (platform) detected.push(platform);
    if (resultIndex >= 0) detected.push(headers[resultIndex]);
    if (dateIndex >= 0) detected.push("date");
    if (entryIndex >= 0) detected.push("entry");
    if (exitIndex >= 0) detected.push("exit");
    if (sizeIndex >= 0) detected.push("size");
    if (directionIndex >= 0) detected.push("direction");
    if (feeIndex >= 0) detected.push("fee");
    for (let r = 1; r < rows.length; r += 1) {
      const values = rows[r];
      const read = (index) => index >= 0 && index < values.length ? values[index] : "";
      let pnl = NaN;
      if (resultIndex >= 0) {
        pnl = parseNumber(read(resultIndex));
      }
      if (!Number.isFinite(pnl) && entryIndex >= 0 && exitIndex >= 0) {
        const entry2 = parseNumber(read(entryIndex));
        const exit2 = parseNumber(read(exitIndex));
        const size2 = sizeIndex >= 0 ? parseSize(read(sizeIndex)) : 1;
        if (Number.isFinite(entry2) && Number.isFinite(exit2)) {
          const directionRaw2 = read(directionIndex);
          const direction2 = SHORT_RE.test(directionRaw2) ? -1 : 1;
          pnl = (exit2 - entry2) * direction2 * (size2 ?? 1);
          derived = true;
        }
      }
      if (!Number.isFinite(pnl)) {
        ignored += 1;
        continue;
      }
      const rawDate = read(dateIndex).trim();
      const date = parseDate(rawDate);
      const fee = feeIndex >= 0 ? parseNumber(read(feeIndex)) : 0;
      const directionRaw = read(directionIndex);
      let direction = "unknown";
      if (directionRaw) {
        if (LONG_RE.test(directionRaw)) direction = "long";
        else if (SHORT_RE.test(directionRaw)) direction = "short";
      }
      const entry = entryIndex >= 0 ? parseNumber(read(entryIndex)) : null;
      const exit = exitIndex >= 0 ? parseNumber(read(exitIndex)) : null;
      const size = sizeIndex >= 0 ? parseSize(read(sizeIndex)) : null;
      trades.push({
        row: r + 1,
        date,
        direction,
        entry: Number.isFinite(entry) ? entry : null,
        exit: Number.isFinite(exit) ? exit : null,
        size,
        fee: Number.isFinite(fee) ? fee : 0,
        pnl: pnl - (Number.isFinite(fee) ? fee : 0)
      });
    }
    if (trades.length < 2) {
      throw new Error("At least two valid trade rows are required after parsing.");
    }
    return {
      trades,
      ignored,
      detected,
      derivedPnl: derived,
      hasDates: trades.some((trade) => trade.date !== null)
    };
  }

  // backtester-src/metrics.ts
  function percentileSorted(sorted, fraction) {
    if (sorted.length === 0) return 0;
    const idx = Math.min(sorted.length - 1, Math.floor(sorted.length * fraction));
    return sorted[idx];
  }
  function mean(arr) {
    if (arr.length === 0) return 0;
    let s = 0;
    for (let i = 0; i < arr.length; i += 1) s += arr[i];
    return s / arr.length;
  }
  function variance(arr, m) {
    if (arr.length < 2) return 0;
    const mu = m == null ? mean(arr) : m;
    let s = 0;
    for (let i = 0; i < arr.length; i += 1) {
      const d = arr[i] - mu;
      s += d * d;
    }
    return s / arr.length;
  }
  function stddev(arr, m) {
    return Math.sqrt(variance(arr, m));
  }
  function sampleSkew(arr, m) {
    if (arr.length < 3) return 0;
    const sd = stddev(arr, m);
    if (sd === 0) return 0;
    let s = 0;
    for (let i = 0; i < arr.length; i += 1) {
      const d = (arr[i] - m) / sd;
      s += d * d * d;
    }
    const n = arr.length;
    const g1 = Math.sqrt(n * (n - 1)) / (n - 2) * (s / n);
    return Number.isFinite(g1) ? g1 : 0;
  }
  function sampleKurtosis(arr, m) {
    if (arr.length < 4) return 0;
    const sd = stddev(arr, m);
    if (sd === 0) return 0;
    let s = 0;
    for (let i = 0; i < arr.length; i += 1) {
      const d = (arr[i] - m) / sd;
      s += d * d * d * d;
    }
    const n = arr.length;
    const m4 = s / n;
    const g2 = (n - 1) / ((n - 2) * (n - 3)) * ((n + 1) * m4 - 3 * (n - 1));
    return Number.isFinite(g2) ? g2 : 0;
  }
  function computeMetrics(log, opts = {}) {
    const trades = log.trades;
    const returns = trades.map((trade) => trade.pnl);
    const wins = returns.filter((value) => value > 0);
    const losses = returns.filter((value) => value < 0);
    const count = returns.length;
    const winCount = wins.length;
    const lossCount = losses.length;
    const winRate = count > 0 ? winCount / count : 0;
    const grossWins = wins.reduce((total, value) => total + value, 0);
    const grossLosses = Math.abs(losses.reduce((total, value) => total + value, 0));
    const netPnl = returns.reduce((total, value) => total + value, 0);
    const expectancy = count > 0 ? netPnl / count : 0;
    let equity = 0;
    const equitySeries = [];
    const drawdownSeries = [];
    const drawdownPctSeries = [];
    const tradeDates = [];
    const monthlyMap = /* @__PURE__ */ new Map();
    let peak = 0;
    let maxDrawdown = 0;
    let currentDdDuration = 0;
    let maxDrawdownDuration = 0;
    let longestDdStartIdx = -1;
    let longestDdEndIdx = -1;
    let ulcerSqSum = 0;
    for (let i = 0; i < returns.length; i += 1) {
      const value = returns[i];
      equity += value;
      equitySeries.push(equity);
      const prevPeak = peak;
      peak = Math.max(peak, equity);
      const drawdown = equity - peak;
      drawdownSeries.push(drawdown);
      const ddPct = peak > 0 ? drawdown / peak * 100 : 0;
      drawdownPctSeries.push(ddPct);
      ulcerSqSum += ddPct * ddPct;
      maxDrawdown = Math.min(maxDrawdown, drawdown);
      if (drawdown < 0) {
        if (prevPeak === peak) {
          currentDdDuration += 1;
        } else {
          currentDdDuration = 1;
        }
        if (currentDdDuration > maxDrawdownDuration) {
          maxDrawdownDuration = currentDdDuration;
          longestDdEndIdx = i;
          longestDdStartIdx = i - currentDdDuration + 1;
        }
      } else {
        currentDdDuration = 0;
      }
      const trade = trades[i];
      const iso = trade.date ?? null;
      tradeDates.push(iso);
      if (iso) {
        const parsed = new Date(iso);
        if (!Number.isNaN(parsed.getTime())) {
          const key = `${parsed.getFullYear()}-${parsed.getMonth()}`;
          monthlyMap.set(key, (monthlyMap.get(key) || 0) + value);
        }
      }
    }
    const monthlyReturns = Array.from(monthlyMap.entries()).map(([key, pnl]) => {
      const [year, month] = key.split("-").map(Number);
      return { year, month, pnl };
    }).sort((a, b) => a.year !== b.year ? a.year - b.year : a.month - b.month);
    const tradeDetails = trades.map((trade, i) => ({
      index: i + 1,
      date: trade.date,
      direction: trade.direction,
      entry: trade.entry,
      exit: trade.exit,
      size: trade.size,
      pnl: returns[i],
      equity: equitySeries[i],
      drawdown: drawdownSeries[i]
    }));
    let maxConsecutiveWins = 0;
    let maxConsecutiveLosses = 0;
    let currentWins = 0;
    let currentLosses = 0;
    for (const value of returns) {
      if (value > 0) {
        currentWins += 1;
        currentLosses = 0;
        maxConsecutiveWins = Math.max(maxConsecutiveWins, currentWins);
      } else if (value < 0) {
        currentLosses += 1;
        currentWins = 0;
        maxConsecutiveLosses = Math.max(maxConsecutiveLosses, currentLosses);
      }
    }
    const mean2 = expectancy;
    const variance2 = count > 0 ? returns.reduce((total, value) => total + (value - mean2) ** 2, 0) / count : 0;
    const standardDeviation = Math.sqrt(variance2);
    const dated = trades.filter((trade) => trade.date !== null).sort(
      (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
    );
    let avgHoldMs = null;
    if (dated.length > 1) {
      let totalHold = 0;
      let pairs = 0;
      for (let i = 1; i < dated.length; i += 1) {
        const current = new Date(dated[i].date).getTime();
        const previous = new Date(dated[i - 1].date).getTime();
        if (Number.isFinite(current) && Number.isFinite(previous)) {
          totalHold += current - previous;
          pairs += 1;
        }
      }
      if (pairs > 0) avgHoldMs = totalHold / pairs;
    }
    const bestTrade = returns.length > 0 ? Math.max(...returns) : 0;
    const worstTrade = returns.length > 0 ? Math.min(...returns) : 0;
    const positivePathsPct = winRate;
    const sharpeLike = standardDeviation > 0 ? mean2 / standardDeviation * Math.sqrt(Math.max(count, 1)) : 0;
    const rExpectancy = standardDeviation > 0 ? expectancy / standardDeviation : 0;
    const score = gradeScore({
      expectancy,
      profitFactor: grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? 3 : 0,
      winRate,
      maxDrawdownAbs: Math.abs(maxDrawdown),
      grossWins,
      count,
      positivePathsPct,
      sharpeLike,
      rExpectancy,
      maxConsecutiveLosses
    });
    const MS_PER_YEAR = 365.25 * 24 * 3600 * 1e3;
    let tradesPerYear = 252;
    if (avgHoldMs && avgHoldMs > 0) {
      tradesPerYear = Math.min(Math.max(MS_PER_YEAR / avgHoldMs, 1), 25e4);
    }
    const annualizedReturn = expectancy * tradesPerYear;
    const annualizedVolatility = standardDeviation * Math.sqrt(tradesPerYear);
    const sharpe = standardDeviation > 0 ? expectancy / standardDeviation * Math.sqrt(tradesPerYear) : 0;
    const downsideReturns = returns.filter((r) => r < 0);
    const downsideDeviation = downsideReturns.length > 0 ? Math.sqrt(downsideReturns.reduce((s, r) => s + r * r, 0) / Math.max(count, 1)) : 0;
    const sortino = downsideDeviation > 0 ? expectancy / downsideDeviation * Math.sqrt(tradesPerYear) : 0;
    const maxDrawdownAbs = Math.abs(maxDrawdown);
    const calmar = maxDrawdownAbs > 0 ? annualizedReturn / maxDrawdownAbs : 0;
    const omega = grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? Infinity : 0;
    const recoveryFactor = maxDrawdownAbs > 0 ? netPnl / maxDrawdownAbs : 0;
    const gainPain = grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? Infinity : 0;
    const ulcerIndex = count > 0 ? Math.sqrt(ulcerSqSum / count) : 0;
    const sortedReturns = returns.slice().sort((a, b) => a - b);
    const p5 = percentileSorted(sortedReturns, 0.05);
    const p95 = percentileSorted(sortedReturns, 0.95);
    const tailRatio = p5 < 0 ? Math.abs(p95) / Math.abs(p5) : 0;
    const valueAtRisk95 = Math.abs(p5);
    const tailCount = Math.max(1, Math.floor(count * 0.05));
    let cvarSum = 0;
    for (let i = 0; i < tailCount; i += 1) cvarSum += sortedReturns[i] || 0;
    const cvar95 = Math.abs(cvarSum / tailCount);
    let maxDrawdownDurationDays = null;
    if (longestDdStartIdx >= 0 && longestDdEndIdx >= longestDdStartIdx) {
      const startIso = tradeDates[longestDdStartIdx];
      const endIso = tradeDates[longestDdEndIdx];
      if (startIso && endIso) {
        const t0 = new Date(startIso).getTime();
        const t1 = new Date(endIso).getTime();
        if (Number.isFinite(t0) && Number.isFinite(t1) && t1 >= t0) {
          maxDrawdownDurationDays = (t1 - t0) / (24 * 3600 * 1e3);
        }
      }
    }
    const avgWin = winCount > 0 ? grossWins / winCount : 0;
    const avgLoss = lossCount > 0 ? -(grossLosses / lossCount) : 0;
    const winLossRatio = avgLoss < 0 ? avgWin / Math.abs(avgLoss) : 0;
    const skewness = sampleSkew(returns, mean2);
    const kurtosis = sampleKurtosis(returns, mean2) + 3;
    let benchmark = null;
    let beta = null;
    let alpha = null;
    let informationRatio = null;
    if (opts.benchmark && opts.benchmark.returns && opts.benchmark.returns.length > 1) {
      benchmark = opts.benchmark.name;
      const br = opts.benchmark.returns;
      const n = Math.min(returns.length, br.length);
      if (n > 2) {
        let bmSum = 0;
        for (let i = 0; i < n; i += 1) bmSum += br[i];
        const bmMean = bmSum / n;
        let bmVarSum = 0;
        for (let i = 0; i < n; i += 1) bmVarSum += (br[i] - bmMean) ** 2;
        const bmVar = bmVarSum / n;
        if (bmVar > 0) {
          let cov = 0;
          for (let i = 0; i < n; i += 1) cov += (returns[i] - expectancy) * (br[i] - bmMean);
          cov /= n;
          beta = cov / bmVar;
          alpha = expectancy - beta * bmMean;
          const active = [];
          for (let i = 0; i < n; i += 1) active.push(returns[i] - br[i]);
          let activeSum = 0;
          for (let i = 0; i < active.length; i += 1) activeSum += active[i];
          const activeMean = activeSum / active.length;
          let activeVarSum = 0;
          for (let i = 0; i < active.length; i += 1) activeVarSum += (active[i] - activeMean) ** 2;
          const activeStd = Math.sqrt(activeVarSum / Math.max(active.length, 1));
          informationRatio = activeStd > 0 ? activeMean / activeStd * Math.sqrt(tradesPerYear) : 0;
        }
      }
    }
    let turnover = null;
    const sizedTrades = trades.filter((t) => t.entry != null && t.size != null);
    if (sizedTrades.length > 0 && peak > 0) {
      let notional = 0;
      for (const t of sizedTrades) {
        const sz = Math.abs(t.size);
        const px = Math.abs(t.entry);
        notional += sz * px;
      }
      turnover = notional / peak;
    }
    return {
      count,
      winCount,
      lossCount,
      winRate,
      grossWins,
      grossLosses,
      profitFactor: grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? Infinity : 0,
      netPnl,
      expectancy,
      rExpectancy: standardDeviation > 0 ? expectancy / standardDeviation : 0,
      standardDeviation,
      sharpeLike: standardDeviation > 0 ? mean2 / standardDeviation * Math.sqrt(Math.max(count, 1)) : 0,
      maxDrawdown: Math.abs(maxDrawdown),
      maxDrawdownPct: peak > 0 ? Math.abs(maxDrawdown) / peak : 0,
      maxConsecutiveWins,
      maxConsecutiveLosses,
      avgHoldMs,
      bestTrade,
      worstTrade,
      equity: equitySeries,
      drawdownSeries,
      returns,
      tradeDates,
      monthlyReturns,
      tradeDetails,
      grade: score.grade,
      gradeLabel: score.label,
      gradeScore: score.score,
      gradeBreakdown: score.breakdown,
      gradeAdvice: score.advice,
      tradesPerYear,
      annualizedReturn,
      annualizedVolatility,
      sharpe,
      sortino,
      calmar,
      omega,
      tailRatio,
      valueAtRisk95,
      cvar95,
      maxDrawdownDuration,
      maxDrawdownDurationDays,
      recoveryFactor,
      ulcerIndex,
      gainPain,
      avgWin,
      avgLoss,
      winLossRatio,
      skewness,
      kurtosis,
      benchmark,
      beta,
      alpha,
      informationRatio,
      turnover
    };
  }
  function gradeScore(metrics) {
    const subs = [];
    let prof = 0;
    if (metrics.expectancy > 0) prof += 10;
    if (metrics.profitFactor >= 2) prof += 15;
    else if (metrics.profitFactor >= 1.5) prof += 10;
    else if (metrics.profitFactor >= 1.15) prof += 4;
    subs.push({ category: "Profitability", score: prof, max: 25 });
    let cons = 0;
    if (metrics.winRate >= 0.55) cons += 10;
    else if (metrics.winRate >= 0.45) cons += 6;
    else if (metrics.winRate >= 0.35) cons += 3;
    if (metrics.positivePathsPct >= 0.7) cons += 10;
    else if (metrics.positivePathsPct >= 0.55) cons += 6;
    else if (metrics.positivePathsPct >= 0.4) cons += 3;
    subs.push({ category: "Consistency", score: cons, max: 20 });
    let risk = 0;
    if (metrics.grossWins > 0) {
      if (metrics.maxDrawdownAbs <= metrics.grossWins * 0.25) risk += 15;
      else if (metrics.maxDrawdownAbs <= metrics.grossWins * 0.5) risk += 10;
      else if (metrics.maxDrawdownAbs <= metrics.grossWins) risk += 4;
    }
    if (metrics.maxConsecutiveLosses <= 3) risk += 10;
    else if (metrics.maxConsecutiveLosses <= 5) risk += 6;
    else if (metrics.maxConsecutiveLosses <= 8) risk += 2;
    subs.push({ category: "Risk control", score: risk, max: 25 });
    let rob = 0;
    if (metrics.sharpeLike >= 2) rob += 10;
    else if (metrics.sharpeLike >= 1.2) rob += 7;
    else if (metrics.sharpeLike >= 0.6) rob += 3;
    if (metrics.rExpectancy >= 0.3) rob += 10;
    else if (metrics.rExpectancy >= 0.15) rob += 6;
    else if (metrics.rExpectancy >= 0.05) rob += 2;
    subs.push({ category: "Robustness", score: rob, max: 20 });
    let samp = 0;
    if (metrics.count >= 200) samp += 10;
    else if (metrics.count >= 100) samp += 8;
    else if (metrics.count >= 50) samp += 5;
    else if (metrics.count >= 20) samp += 3;
    else if (metrics.count >= 5) samp += 1;
    subs.push({ category: "Sample size", score: samp, max: 10 });
    const score = subs.reduce((a, s) => a + s.score, 0);
    const grade = score >= 88 ? "A" : score >= 74 ? "B" : score >= 58 ? "C" : score >= 40 ? "D" : "F";
    const labels = {
      A: "Strong evidence",
      B: "Promising evidence",
      C: "Mixed evidence",
      D: "Weak evidence",
      F: "Needs work"
    };
    const advice = [];
    if (prof < 15) advice.push("Improve profitability: filter trades with weak edge or tighten stops to lift profit factor above 1.5.");
    if (cons < 12) advice.push("Raise consistency: review losing streaks and entry timing (see autocorrelation) to push the win rate above 50%.");
    if (risk < 15) advice.push("Tighten risk control: reduce position size or add a hard stop to cap drawdown and consecutive losses.");
    if (rob < 12) advice.push("Strengthen robustness: the risk-adjusted return is thin \u2014 favor higher-expectancy setups to improve the Sharpe-like ratio.");
    if (samp < 5) advice.push("Gather more trades: the sample is small, so every metric here carries low confidence.");
    return { score, grade, label: labels[grade], breakdown: subs, advice };
  }

  // backtester-src/rng.ts
  function mulberry32(seed) {
    let state = seed >>> 0;
    return () => {
      state = state + 1831565813 >>> 0;
      let value = state;
      value = Math.imul(value ^ value >>> 15, value | 1);
      value ^= value + Math.imul(value ^ value >>> 7, value | 61);
      return ((value ^ value >>> 14) >>> 0) / 4294967296;
    };
  }
  function shuffle(array, random) {
    const copy = array.slice();
    for (let i = copy.length - 1; i > 0; i -= 1) {
      const j = Math.floor(random() * (i + 1));
      const swap = copy[i];
      copy[i] = copy[j];
      copy[j] = swap;
    }
    return copy;
  }

  // backtester-src/montecarlo.ts
  function runMonteCarlo(returns, config, startingBalance = 0) {
    if (returns.length < 2) {
      throw new Error("At least two trades are required for Monte Carlo.");
    }
    const paths = Math.min(Math.max(config.paths, 10), 5e3);
    const blockSize = Math.min(Math.max(config.blockSize, 1), Math.max(returns.length, 1));
    const random = mulberry32(config.seed);
    const numberOfBlocks = Math.ceil(returns.length / blockSize);
    const pathEquity = [];
    const terminals = [];
    const drawdowns = [];
    for (let path = 0; path < paths; path += 1) {
      const blocks = [];
      for (let block = 0; block < numberOfBlocks; block += 1) {
        const start = Math.floor(random() * returns.length);
        for (let offset = 0; offset < blockSize; offset += 1) {
          blocks.push(returns[(start + offset) % returns.length]);
        }
      }
      const sampled = blocks.slice(0, returns.length);
      let equity = startingBalance;
      const series = [];
      let peak = startingBalance;
      let maxDrawdown = 0;
      for (const value of sampled) {
        equity += value;
        series.push(equity);
        peak = Math.max(peak, equity);
        maxDrawdown = Math.max(maxDrawdown, peak - equity);
      }
      pathEquity.push(series);
      terminals.push(equity);
      drawdowns.push(maxDrawdown);
    }
    const sorted = terminals.slice().sort((a, b) => a - b);
    const sortedDrawdowns = drawdowns.slice().sort((a, b) => a - b);
    const positivePaths = terminals.filter((value) => value > startingBalance).length;
    return {
      config,
      terminals,
      paths: pathEquity,
      p5: percentile(sorted, 0.05),
      p50: percentile(sorted, 0.5),
      p95: percentile(sorted, 0.95),
      positivePaths,
      positivePathsPct: positivePaths / paths,
      riskOfRuinPct: percentile(sorted, 0.05) < startingBalance ? lowTailRisk(terminals, startingBalance) : 0,
      drawdownPercentiles: {
        p50: percentile(sortedDrawdowns, 0.5),
        p95: percentile(sortedDrawdowns, 0.95)
      }
    };
  }
  function percentile(sorted, fraction) {
    if (sorted.length === 0) return 0;
    const index = Math.min(sorted.length - 1, Math.floor(sorted.length * fraction));
    return sorted[index];
  }
  function lowTailRisk(terminals, startingBalance) {
    const loss = terminals.filter((value) => value < startingBalance).length;
    return loss / terminals.length * 100;
  }

  // backtester-src/propfirm.ts
  var PROP_FIRM_PRESETS = [
    {
      name: "FTMO 100k",
      accountSize: 1e5,
      profitTarget: 1e4,
      maxDailyLoss: 5e3,
      maxTotalDrawdown: 1e4,
      evaluationDays: 30,
      payoutPct: 80,
      challengeFee: 549,
      minPayout: 1e3,
      payoutDays: 14,
      trailingDrawdown: false,
      resetFee: 549,
      scaling: 1,
      phases: 1,
      consistencyPct: 50
    },
    {
      name: "FTMO 50k",
      accountSize: 5e4,
      profitTarget: 5e3,
      maxDailyLoss: 2500,
      maxTotalDrawdown: 5e3,
      evaluationDays: 30,
      payoutPct: 80,
      challengeFee: 299,
      minPayout: 500,
      payoutDays: 14,
      trailingDrawdown: false,
      resetFee: 299,
      scaling: 1,
      phases: 1,
      consistencyPct: 50
    },
    {
      name: "Apex 100k",
      accountSize: 1e5,
      profitTarget: 6e3,
      maxDailyLoss: 4500,
      maxTotalDrawdown: 5e3,
      evaluationDays: 30,
      payoutPct: 90,
      challengeFee: 150,
      minPayout: 500,
      payoutDays: 1,
      trailingDrawdown: false,
      resetFee: 150,
      scaling: 1,
      phases: 1,
      consistencyPct: 0
    },
    {
      name: "Topstep 50k",
      accountSize: 5e4,
      profitTarget: 3e3,
      maxDailyLoss: 2e3,
      maxTotalDrawdown: 2e3,
      evaluationDays: 15,
      payoutPct: 100,
      challengeFee: 165,
      minPayout: 500,
      payoutDays: 5,
      trailingDrawdown: true,
      resetFee: 165,
      scaling: 1,
      phases: 1,
      consistencyPct: 50
    },
    {
      name: "E8 100k",
      accountSize: 1e5,
      profitTarget: 8e3,
      maxDailyLoss: 3e3,
      maxTotalDrawdown: 6e3,
      evaluationDays: 30,
      payoutPct: 100,
      challengeFee: 599,
      minPayout: 500,
      payoutDays: 7,
      trailingDrawdown: false,
      resetFee: 599,
      scaling: 2,
      phases: 1,
      consistencyPct: 50
    }
  ];
  function tradesPerDay(trades) {
    const days = /* @__PURE__ */ new Set();
    for (const trade of trades) {
      if (trade.date) days.add(trade.date.slice(0, 10));
    }
    return Math.max(days.size, 1);
  }
  function runPropFirmSimulation(trades, config, options) {
    const runs = Math.min(Math.max(options.runs, 10), 1e4);
    const random = mulberry32(options.seed);
    const baseline = options.strategyBaseline && options.strategyBaseline > 0 ? options.strategyBaseline : config.accountSize;
    const scale = config.accountSize / baseline;
    const pnl = trades.map((trade) => trade.pnl * scale);
    const actualDays = tradesPerDay(trades);
    const tradesPerDayCount = pnl.length / actualDays;
    const dailyLossLimit = config.maxDailyLoss;
    const totalDrawdownLimit = config.maxTotalDrawdown;
    const target = config.profitTarget;
    let passCount = 0;
    let daysToTargetTotal = 0;
    let daysToTargetCount = 0;
    let profitAtPassTotal = 0;
    let daysPerAttemptTotal = 0;
    const passDaysList = [];
    const failures = {
      "Daily loss breach": 0,
      "Max total drawdown breach": 0,
      "Consistency rule breach": 0,
      "Evaluation period expired": 0
    };
    const consistencyLimit = config.consistencyPct > 0 && config.consistencyPct < 100 ? config.consistencyPct / 100 * config.profitTarget : Infinity;
    const sampleRuns = [];
    let passSamples = 0;
    const failByReason = {};
    const MAX_PASS_SAMPLES = 12;
    const MAX_FAIL_PER_REASON = 4;
    const SAFETY_CAP = config.evaluationDays * Math.max(1, Math.ceil(tradesPerDayCount)) * 50;
    for (let run = 0; run < runs; run += 1) {
      let order = shuffle(pnl, random);
      let cursor = 0;
      let balance = config.accountSize;
      let peak = config.accountSize;
      let trough = config.accountSize;
      let dailyNet = 0;
      let maxDailyProfit = 0;
      let tradesToday = 0;
      let day = 1;
      let result = "fail";
      let failureReason = "Evaluation period expired";
      const runEquity = [config.accountSize];
      for (let iter = 0; iter < SAFETY_CAP; iter += 1) {
        if (cursor >= order.length) {
          order = shuffle(pnl, random);
          cursor = 0;
        }
        if (tradesToday >= tradesPerDayCount && day < config.evaluationDays) {
          day += 1;
          dailyNet = 0;
          tradesToday = 0;
        }
        const pnlThisTrade = order[cursor];
        cursor += 1;
        tradesToday += 1;
        balance += pnlThisTrade;
        dailyNet += pnlThisTrade;
        if (dailyNet > maxDailyProfit) maxDailyProfit = dailyNet;
        runEquity.push(balance);
        peak = Math.max(peak, balance);
        trough = Math.min(trough, balance);
        if (dailyNet <= -dailyLossLimit) {
          result = "fail";
          failureReason = "Daily loss breach";
          break;
        }
        const totalBreach = config.trailingDrawdown ? peak - balance >= totalDrawdownLimit : balance <= config.accountSize - totalDrawdownLimit;
        if (totalBreach) {
          result = "fail";
          failureReason = "Max total drawdown breach";
          break;
        }
        if (balance - config.accountSize >= target) {
          if (maxDailyProfit > consistencyLimit) {
            result = "fail";
            failureReason = "Consistency rule breach";
          } else {
            result = "pass";
          }
          break;
        }
        if (day >= config.evaluationDays && tradesToday >= tradesPerDayCount) {
          result = "fail";
          failureReason = "Evaluation period expired";
          break;
        }
      }
      daysPerAttemptTotal += day;
      if (result === "pass") {
        passCount += 1;
        daysToTargetTotal += day;
        daysToTargetCount += 1;
        passDaysList.push(day);
        profitAtPassTotal += balance - config.accountSize;
      } else {
        failures[failureReason] = (failures[failureReason] || 0) + 1;
      }
      const wantSample = result === "pass" && passSamples < MAX_PASS_SAMPLES || result === "fail" && (failByReason[failureReason] || 0) < MAX_FAIL_PER_REASON;
      if (wantSample) {
        sampleRuns.push({
          equity: runEquity,
          outcome: result,
          reason: result === "pass" ? "Target reached" : failureReason,
          days: day,
          peak,
          trough,
          terminal: balance,
          accountSize: config.accountSize,
          profitTarget: target,
          maxDrawdown: config.maxTotalDrawdown
        });
        if (result === "pass") passSamples += 1;
        else failByReason[failureReason] = (failByReason[failureReason] || 0) + 1;
      }
    }
    const passRate = passCount / runs;
    const avgProfitAtPass = passCount > 0 ? profitAtPassTotal / passCount : null;
    const profitAtPass = avgProfitAtPass !== null ? avgProfitAtPass : config.profitTarget;
    const payoutPerPass = profitAtPass * config.payoutPct / 100;
    const effectivePayout = payoutPerPass >= config.minPayout ? payoutPerPass : 0;
    const expectedValue = passRate * effectivePayout - (1 - passRate) * config.challengeFee;
    const TRADING_DAYS_PER_YEAR = 252;
    const averageDaysToTarget = daysToTargetCount > 0 ? daysToTargetTotal / daysToTargetCount : null;
    const medianDaysToTarget = passDaysList.length ? passDaysList.slice().sort((a, b) => a - b)[Math.floor(passDaysList.length / 2)] : null;
    const avgDaysPerAttempt = daysPerAttemptTotal / runs;
    const attemptsPerYear = avgDaysPerAttempt > 0 ? TRADING_DAYS_PER_YEAR / avgDaysPerAttempt : 0;
    const evalsPassedPerYear = attemptsPerYear * passRate;
    const expectedAttemptsToPass = passRate > 0 ? 1 / passRate : Infinity;
    const expectedCostToPass = Number.isFinite(expectedAttemptsToPass) ? config.challengeFee + (expectedAttemptsToPass - 1) * config.resetFee : Infinity;
    const annualExpectedValue = attemptsPerYear * expectedValue;
    const annualExpectedPayout = evalsPassedPerYear * effectivePayout;
    const roiPerAttempt = config.challengeFee > 0 ? expectedValue / config.challengeFee : 0;
    const failureList = Object.entries(failures).map(([reason, count]) => ({ reason, count, pct: count / runs })).filter((failure) => failure.count > 0).sort((a, b) => b.count - a.count);
    return {
      config,
      passRatePct: passRate * 100,
      failRatePct: (1 - passRate) * 100,
      averageDaysToTarget,
      medianDaysToTarget,
      avgDaysPerAttempt,
      avgProfitAtPass,
      effectivePayout,
      expectedValue,
      payoutProbabilityPct: passRate * 100,
      attemptsPerYear,
      evalsPassedPerYear,
      expectedAttemptsToPass,
      expectedCostToPass,
      annualExpectedValue,
      annualExpectedPayout,
      roiPerAttempt,
      failures: failureList,
      runs,
      passCount,
      sampleRuns
    };
  }

  // backtester-src/sample.ts
  var SAMPLE_TRADE_LOG = (() => {
    const header = "Trade #,Type,Signal,Date/Time,Price,Qty,P&L,Cumulative P&L,Drawdown,Run-up,Cumulative P&L %,Buy & Hold %,Trade #";
    const rows = [header];
    const data = [
      [1, "long", "2025-01-03 09:30", "2025-01-05 16:00", 4200.5, 15, 2400],
      [2, "short", "2025-01-07 10:00", "2025-01-08 11:00", 4300, 15, -285],
      [3, "long", "2025-01-10 09:30", "2025-01-12 15:00", 4250, 15, 690],
      [4, "long", "2025-01-14 10:00", "2025-01-15 14:00", 4280, 8, 488],
      [5, "short", "2025-01-17 10:00", "2025-01-17 15:00", 4310, 15, -3500],
      [6, "long", "2025-01-22 09:30", "2025-01-24 16:00", 4260, 15, 885],
      [7, "short", "2025-01-27 10:00", "2025-01-28 11:00", 4340, 15, -195],
      [8, "long", "2025-01-31 09:30", "2025-02-03 15:00", 4270, 8, 672],
      [9, "long", "2025-02-04 09:30", "2025-02-06 16:00", 4290, 15, 2300],
      [10, "short", "2025-02-07 10:00", "2025-02-10 11:00", 4380, 15, -435],
      [11, "long", "2025-02-12 09:30", "2025-02-14 15:00", 4300, 8, 608],
      [12, "long", "2025-02-18 09:30", "2025-02-20 16:00", 4310, 15, 773],
      [13, "short", "2025-02-21 10:00", "2025-02-24 11:00", 4400, 15, -308],
      [14, "long", "2025-02-26 09:30", "2025-02-28 15:00", 4320, 8, 536],
      [15, "long", "2025-03-03 09:30", "2025-03-05 16:00", 4300, 15, 2200],
      [16, "short", "2025-03-06 10:00", "2025-03-07 11:00", 4450, 15, -3500],
      [17, "long", "2025-03-11 09:30", "2025-03-13 15:00", 4340, 8, 704],
      [18, "long", "2025-03-17 09:30", "2025-03-19 16:00", 4360, 15, 2200],
      [19, "short", "2025-03-20 10:00", "2025-03-21 11:00", 4420, 15, -263],
      [20, "long", "2025-03-26 09:30", "2025-03-28 15:00", 4350, 8, 392],
      [21, "long", "2025-04-02 09:30", "2025-04-04 16:00", 4380, 15, 2200],
      [22, "short", "2025-04-08 10:00", "2025-04-09 11:00", 4480, 15, -3500],
      [23, "long", "2025-04-15 09:30", "2025-04-17 15:00", 4400, 8, 760],
      [24, "long", "2025-04-22 09:30", "2025-04-24 16:00", 4410, 8, 584]
    ];
    let cum = 0;
    for (const [num, dir, entryDate, exitDate, entry, qty, pnl] of data) {
      const exit = dir === "long" ? entry + pnl / qty : entry - pnl / qty;
      const entryType = dir === "long" ? "Entry long" : "Entry short";
      const exitType = dir === "long" ? "Exit long" : "Exit short";
      rows.push(`${num},${entryType},,${entryDate},${entry},${qty},,,,,,, ,${num}`);
      cum += pnl;
      rows.push(`${num},${exitType},,${exitDate},${exit.toFixed(2)},${qty},${pnl.toFixed(2)},${cum.toFixed(2)},,,,, ,${num}`);
    }
    return rows.join("\n");
  })();

  // backtester-src/home.ts
  function fmt(v, dec = 0, prefix = "") {
    const s = Math.abs(v).toFixed(dec).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return (v < 0 ? "\u2212" : prefix) + s;
  }
  function pct(v, dec = 1) {
    return (v * 100).toFixed(dec == null ? 1 : dec) + "%";
  }
  function setText(sel, value) {
    document.querySelectorAll(sel).forEach((el) => {
      el.textContent = value;
    });
  }
  function gradeColor(g) {
    return g === "A" ? "#34d399" : g === "B" ? "#a3e635" : g === "C" ? "#fbbf24" : g === "D" ? "#fb923c" : "#fb7185";
  }
  function theme() {
    const cs = getComputedStyle(document.documentElement);
    const raw = (n, fb) => cs.getPropertyValue(n).trim() || fb;
    const triplet = (n, fb) => `rgb(${raw(n, fb)})`;
    return {
      text: triplet("--color-text-primary", "242 242 242"),
      textSec: triplet("--color-text-secondary", "163 163 163"),
      grid: triplet("--color-border-primary", "34 34 34"),
      gridSoft: `rgba(${raw("--color-border-primary", "34 34 34").replace(/\s+/g, ",")},0.55)`,
      blue: "#7c83ff",
      green: "#34d399",
      red: "#fb7185",
      amber: "#fbbf24",
      accent: "#7c83ff"
    };
  }
  function baseLayout(t) {
    return {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, Archivo, system-ui, sans-serif", size: 12 },
      margin: { l: 48, r: 14, t: 10, b: 34 },
      showlegend: false,
      hovermode: "closest",
      hoverlabel: { bgcolor: "#0b1014", bordercolor: t.grid, font: { color: t.text, size: 12 } },
      xaxis: { gridcolor: t.gridSoft, zerolinecolor: t.grid, linecolor: t.gridSoft, tickfont: { color: t.textSec, size: 10 }, automargin: true },
      yaxis: { gridcolor: t.gridSoft, zerolinecolor: t.grid, linecolor: "rgba(0,0,0,0)", tickfont: { color: t.textSec, size: 10 }, automargin: true }
    };
  }
  function sceneAxis(t, title) {
    return { title: { text: title, font: { color: t.textSec, size: 10 } }, gridcolor: t.gridSoft, zerolinecolor: t.grid, showspikes: false, showbackground: true, backgroundcolor: "rgba(0,0,0,0)", tickfont: { color: t.textSec, size: 10 } };
  }
  function plotInto(div, data, layout) {
    if (typeof Plotly === "undefined" || !Plotly || typeof Plotly.react !== "function") {
      div.innerHTML = '<div class="plot-empty">Plotly failed to load. Check your connection and reload.</div>';
      return;
    }
    Plotly.react(div, data, layout, { displayModeBar: false, responsive: true });
  }
  function propRunsData(t, pf) {
    const runs = pf.sampleRuns || [];
    const data = [];
    const layout = baseLayout(t);
    if (!runs.length) return { data, layout };
    runs.forEach((run, i) => {
      data.push({
        x: run.equity.map((_, j) => j),
        y: run.equity,
        mode: "lines",
        line: { color: run.outcome === "pass" ? t.green : t.red, width: 1.6 },
        opacity: 0.6,
        showlegend: false,
        hovertemplate: `Run ${i + 1} (${run.outcome.toUpperCase()}: ${run.reason})<br>Trade %{x}<br>Balance %{y:,.0f}<extra></extra>`
      });
    });
    const maxX = Math.max(...runs.map((r) => r.equity.length));
    data.push({
      x: runs.map((r) => r.equity.length - 1),
      y: runs.map((r) => r.terminal),
      mode: "markers",
      marker: { size: 8, color: runs.map((r) => r.outcome === "pass" ? t.green : t.red), line: { color: "#0b1014", width: 1.5 } },
      hovertemplate: runs.map((r, i) => `Run ${i + 1} \u2014 ${r.outcome.toUpperCase()}<br>${r.reason}<br>Day ${r.days} \xB7 $${r.terminal.toFixed(0)}`),
      showlegend: false
    });
    const targetLine = pf.config.accountSize + pf.config.profitTarget;
    const ddLimitLine = pf.config.accountSize - pf.config.maxTotalDrawdown;
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: { text: "Trade #", font: { color: t.textSec, size: 10 } } },
      yaxis: { ...layout.yaxis, title: { text: "Balance", font: { color: t.textSec, size: 10 } } },
      shapes: [
        { type: "line", x0: 0, x1: maxX - 1, y0: pf.config.accountSize, y1: pf.config.accountSize, line: { color: t.textSec, width: 1, dash: "dot" } },
        { type: "line", x0: 0, x1: maxX - 1, y0: targetLine, y1: targetLine, line: { color: t.green, width: 1.5, dash: "dash" } },
        { type: "line", x0: 0, x1: maxX - 1, y0: ddLimitLine, y1: ddLimitLine, line: { color: t.red, width: 1.5, dash: "dash" } }
      ],
      annotations: [
        { x: 0, y: pf.config.accountSize, text: "Start", showarrow: false, yshift: 8, font: { color: t.textSec, size: 10 }, xanchor: "left" },
        { x: 0, y: targetLine, text: "Target", showarrow: false, yshift: 8, font: { color: t.green, size: 10 }, xanchor: "left" },
        { x: 0, y: ddLimitLine, text: "Max DD", showarrow: false, yshift: -10, font: { color: t.red, size: 10 }, xanchor: "left" }
      ]
    });
    return { data, layout };
  }
  function surfaceData(t, paths0, n) {
    const sorted = paths0.slice().sort((a, b) => a[a.length - 1] - b[b.length - 1]);
    const limit = Math.min(sorted.length, 40);
    const z = sorted.slice(0, limit);
    const x = Array.from({ length: n + 1 }, (_, i) => i);
    const y = Array.from({ length: limit }, (_, i) => i);
    const data = [{
      type: "surface",
      x,
      y,
      z,
      colorscale: [[0, t.red], [0.5, t.amber], [1, t.green]],
      showscale: false,
      opacity: 0.92,
      hovertemplate: "Path %{y}<br>Trade %{x}<br>Equity %{z:,.0f}<extra></extra>"
    }];
    const layout = {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, Archivo, system-ui, sans-serif", size: 11 },
      margin: { l: 0, r: 0, t: 0, b: 0 },
      showlegend: false,
      scene: {
        xaxis: sceneAxis(t, "Trade"),
        yaxis: sceneAxis(t, "Path"),
        zaxis: sceneAxis(t, "Equity"),
        camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
        bgcolor: "rgba(0,0,0,0)"
      }
    };
    return { data, layout };
  }
  function donutData(t, passCount, expired, breach, passPct) {
    const data = [{
      type: "pie",
      hole: 0.62,
      labels: ["Passed", "Period expired", "Drawdown breach"],
      values: [passCount, expired, breach],
      marker: { colors: [t.green, t.amber, t.red] },
      textfont: { color: t.text, size: 11 },
      hovertemplate: "%{label}<br>%{value} (%{percent})<extra></extra>",
      sort: false,
      direction: "clockwise",
      rotation: 90
    }];
    const layout = {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, Archivo, system-ui, sans-serif", size: 11 },
      margin: { l: 0, r: 0, t: 0, b: 0 },
      showlegend: false,
      annotations: [{ text: `<b style="font-size:18px">${pct(passPct / 100, 0)}</b><br><span style="font-size:9px;color:${t.textSec}">PASS</span>`, showarrow: false, font: { color: t.text, family: "IBM Plex Mono, monospace" } }]
    };
    return { data, layout };
  }
  function bgShape() {
    const cvEl = document.getElementById("bg-shape");
    if (!cvEl) return;
    const cv = cvEl;
    const ctx0 = cv.getContext("2d");
    if (!ctx0) return;
    const ctx = ctx0;
    const reduce = !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
    const phi = (1 + Math.sqrt(5)) / 2;
    const V = [
      [0, 1, phi],
      [0, 1, -phi],
      [0, -1, phi],
      [0, -1, -phi],
      [1, phi, 0],
      [1, -phi, 0],
      [-1, phi, 0],
      [-1, -phi, 0],
      [phi, 0, 1],
      [phi, 0, -1],
      [-phi, 0, 1],
      [-phi, 0, -1]
    ];
    const E = [];
    for (let i = 0; i < V.length; i += 1) {
      for (let j = i + 1; j < V.length; j += 1) {
        const d = Math.hypot(V[i][0] - V[j][0], V[i][1] - V[j][1], V[i][2] - V[j][2]);
        if (Math.abs(d - 2) < 1e-6) E.push([i, j]);
      }
    }
    let w = 0, h = 0;
    function resize() {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = cv.clientWidth;
      h = cv.clientHeight;
      cv.width = Math.round(w * dpr);
      cv.height = Math.round(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    resize();
    window.addEventListener("resize", resize);
    let ay = 0;
    let scrollY = 0;
    window.addEventListener("scroll", () => {
      scrollY = window.scrollY || 0;
    }, { passive: true });
    function rot(p, ayAng, axAng, cx, cyC, scale) {
      const cy = Math.cos(ayAng), sy = Math.sin(ayAng);
      const x1 = p[0] * cy - p[2] * sy;
      const z1 = p[0] * sy + p[2] * cy;
      const cxr = Math.cos(axAng), sx = Math.sin(axAng);
      const y2 = p[1] * cxr - z1 * sx;
      const z2 = p[1] * sx + z1 * cxr;
      const persp = 6 / (6 - z2);
      return { x: cx + x1 * scale * persp, y: cyC + y2 * scale * persp, z: z2 };
    }
    function ico(cx, cyC, scale, ayAng, axAng, base, range) {
      const P = V.map((v) => rot(v, ayAng, axAng, cx, cyC, scale));
      ctx.lineWidth = 1;
      for (const e of E) {
        const a = P[e[0]], b = P[e[1]];
        const dz = ((a.z + b.z) / 2 + 2) / 4;
        const al = Math.max(0.04, Math.min(base + range, base + range * dz));
        ctx.strokeStyle = `rgba(124,131,255,${al})`;
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
      }
      for (const p of P) {
        const dz = (p.z + 2) / 4;
        const al = Math.max(0.06, Math.min(base + range + 0.05, base + range * dz + 0.05));
        ctx.fillStyle = `rgba(124,131,255,${al})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, 1.6, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    let t0 = performance.now();
    let raf = 0;
    function frame(now) {
      const dt = Math.min(50, now - t0);
      t0 = now;
      if (!reduce) ay += dt * 15e-5;
      ctx.clearRect(0, 0, w, h);
      const cyC = h / 2 - scrollY * 0.04;
      ico(w / 2, cyC, Math.max(w, h) * 0.45, ay, 0.35, 0.05, 0.1);
      ico(w / 2, cyC, Math.min(w, h) * 0.26, -ay * 1.4 + 0.6, 0.5, 0.08, 0.14);
      raf = reduce ? 0 : requestAnimationFrame(frame);
    }
    raf = requestAnimationFrame(frame);
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) {
        if (raf) {
          cancelAnimationFrame(raf);
          raf = 0;
        }
      } else if (!raf) {
        t0 = performance.now();
        raf = requestAnimationFrame(frame);
      }
    });
  }
  function ready(fn) {
    if (document.readyState !== "loading") fn();
    else document.addEventListener("DOMContentLoaded", fn);
  }
  ready(() => {
    bgShape();
    const log = buildTradeLog(SAMPLE_TRADE_LOG);
    const m = computeMetrics(log);
    const mc = runMonteCarlo(m.returns, { paths: 1e3, blockSize: 1, seed: 4060720449 }, 0);
    const pf = runPropFirmSimulation(log.trades, PROP_FIRM_PRESETS[0], { runs: 2e3, seed: 20260820, strategyBaseline: 1e5 });
    const n = m.count;
    const paths0 = mc.paths.map((p) => [0].concat(p));
    let expiredCount = 0, breachCount = 0;
    (pf.failures || []).forEach((f) => {
      if (f.reason === "Evaluation period expired") expiredCount += f.count;
      else breachCount += f.count;
    });
    const payout = pf.avgProfitAtPass ? pf.avgProfitAtPass * (pf.config.payoutPct / 100) : 0;
    const be = payout > 0 ? pf.config.challengeFee / payout : 0;
    setText('[data-m="count"]', String(n));
    setText('[data-m="net"]', fmt(m.netPnl, 0, "+"));
    setText('[data-m="pf"]', m.profitFactor.toFixed(2));
    setText('[data-m="maxdd"]', fmt(m.maxDrawdown));
    setText('[data-pf="avgt"]', pf.averageDaysToTarget != null ? pf.averageDaysToTarget.toFixed(1) : "\u2014");
    setText('[data-pf="maxdd"]', fmt(pf.config.maxTotalDrawdown));
    setText('[data-pf="fee"]', "fee " + pf.config.challengeFee);
    setText('[data-pf="rate"]', pct(pf.passRatePct / 100, 0));
    setText('[data-pf="ev"]', (pf.expectedValue >= 0 ? "+" : "") + fmt(pf.expectedValue, 0));
    setText('[data-pf="be"]', pct(be));
    setText('[data-pf="pass"]', fmt(pf.passCount));
    setText('[data-pf="expired"]', fmt(expiredCount));
    setText('[data-pf="breach"]', fmt(breachCount));
    document.querySelectorAll('[data-pf="ev"]').forEach((el) => el.classList.add(pf.expectedValue >= 0 ? "pos" : "neg"));
    setText("[data-grade] .g", m.grade);
    setText("[data-grade] .s", m.gradeScore + " / 100");
    const gc = gradeColor(m.grade);
    document.querySelectorAll("[data-grade]").forEach((el) => {
      el.style.setProperty("--bar", gc);
      el.setAttribute("aria-label", "Grade " + m.grade + ", " + m.gradeScore + " of 100 \u2014 " + m.gradeLabel);
    });
    const BLURB = {
      "Profitability": "Expectancy, profit factor, payoff.",
      "Consistency": "Monthly returns, win rate, streaks.",
      "Risk control": "Drawdown depth, recovery, consecutive losses.",
      "Robustness": "Survives resampling \u2014 Sharpe-like, R-expectancy.",
      "Sample size": "More trades, more confidence."
    };
    const PCOLOR = ["#34d399", "#7c83ff", "#fbbf24", "#fb923c", "#fb7185"];
    const ph = document.querySelector("[data-pillars]");
    if (ph) {
      ph.innerHTML = (m.gradeBreakdown || []).map((b, i) => {
        const w = b.score / b.max * 100;
        return `<div class="pillar rv" style="--i:${i};--bar:${PCOLOR[i % PCOLOR.length]}"><div class="label">${b.category}</div><div class="score">${b.score}<small> / ${b.max}</small></div><div class="bar"><i style="--w:${w}%"></i></div><p>${BLURB[b.category] || ""}</p></div>`;
      }).join("");
    }
    const hero3d = document.getElementById("hero-plot-3d");
    const heroMc = document.getElementById("hero-plot-mc");
    const heroPass = document.getElementById("hero-plot-pass");
    const stressMc = document.getElementById("stress-plot-mc");
    const stressPass = document.getElementById("stress-plot-pass");
    const renders = [];
    function renderAll() {
      const tt = theme();
      if (hero3d) {
        const d = surfaceData(tt, paths0, n);
        plotInto(hero3d, d.data, d.layout);
      }
      if (heroMc) {
        const d = propRunsData(tt, pf);
        plotInto(heroMc, d.data, d.layout);
      }
      if (heroPass) {
        const d = donutData(tt, pf.passCount, expiredCount, breachCount, pf.passRatePct);
        plotInto(heroPass, d.data, d.layout);
      }
      if (stressMc) {
        const d = propRunsData(tt, pf);
        plotInto(stressMc, d.data, d.layout);
      }
      if (stressPass) {
        const d = donutData(tt, pf.passCount, expiredCount, breachCount, pf.passRatePct);
        plotInto(stressPass, d.data, d.layout);
      }
    }
    renders.push(renderAll);
    renderAll();
    const tabs = Array.from(document.querySelectorAll(".hero-tab"));
    const panels = { "3d": hero3d, "mc": heroMc, "pass": heroPass };
    function showTab(name) {
      tabs.forEach((b) => b.classList.toggle("on", b.dataset.htab === name));
      Object.keys(panels).forEach((k) => {
        if (panels[k]) panels[k].hidden = k !== name;
      });
      const shown = panels[name];
      if (shown && typeof Plotly !== "undefined") setTimeout(() => {
        try {
          Plotly.Plots.resize(shown);
        } catch {
        }
      }, 30);
    }
    tabs.forEach((b) => b.addEventListener("click", () => showTab(b.dataset.htab || "3d")));
    showTab("3d");
    const COUNT = {
      net: { v: m.netPnl, dec: 0, prefix: "+" },
      pf: { v: m.profitFactor, dec: 2, prefix: "" },
      maxdd: { v: m.maxDrawdown, dec: 0, prefix: "\u2212" }
    };
    const counters = Array.from(document.querySelectorAll("[data-count]"));
    counters.forEach((el) => {
      const c = COUNT[el.dataset.count || ""];
      if (c) el.textContent = fmt(0, c.dec, c.prefix);
    });
    if (typeof gsap !== "undefined") {
      const state = { net: 0, pf: 0, maxdd: 0 };
      gsap.to(state, {
        net: COUNT.net.v,
        pf: COUNT.pf.v,
        maxdd: COUNT.maxdd.v,
        duration: 1.6,
        ease: "power2.out",
        delay: 0.25,
        onUpdate: () => {
          counters.forEach((el) => {
            const c = COUNT[el.dataset.count || ""];
            if (c) el.textContent = fmt(state[el.dataset.count] * 1, c.dec, c.prefix);
          });
        }
      });
    } else {
      counters.forEach((el) => {
        const c = COUNT[el.dataset.count || ""];
        if (c) el.textContent = fmt(c.v, c.dec, c.prefix);
      });
    }
    const reveal = (el) => el.classList.add("in");
    if ("IntersectionObserver" in window) {
      const io = new IntersectionObserver((es) => {
        es.forEach((e) => {
          if (e.isIntersecting) {
            reveal(e.target);
            io.unobserve(e.target);
          }
        });
      }, { threshold: 0.15, rootMargin: "0px 0px -6% 0px" });
      document.querySelectorAll(".rv").forEach((el) => io.observe(el));
    } else {
      document.querySelectorAll(".rv").forEach(reveal);
    }
    const entryCta = document.getElementById("entry-cta");
    if (entryCta) {
      let authed = false;
      try {
        authed = !!localStorage.getItem("quantpad-authenticated");
      } catch {
      }
      entryCta.setAttribute("href", authed ? "/workspace/" : "/sign-up/");
    }
    if ("ResizeObserver" in window && hero3d) {
      new ResizeObserver(() => {
        [hero3d, heroMc, heroPass, stressMc, stressPass].forEach((d) => {
          if (d && !d.hidden && typeof Plotly !== "undefined") {
            try {
              Plotly.Plots.resize(d);
            } catch {
            }
          }
        });
      }).observe(hero3d);
    }
  });
})();
