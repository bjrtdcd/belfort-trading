// ── Codespaces engine — shared by /projects/ and /quant-copilot/ ──────
// Self-contained, DOM-free data + operations layer over the GitHub API
// and the localStorage workspace store. workspace/index.html has its
// own inline copy of the same logic (left untouched to avoid breaking a
// working page); this is the canonical version new pages build on.
//
// Everything talks to the real GitHub API from the browser. Nothing is
// simulated: if GitHub refuses, the error surfaces on the card. The only
// server-side piece anywhere is the optional OAuth token worker
// (server/github-token-worker.js); personal-access-token linking needs
// no backend at all.
//
// localStorage keys (shared with the workspace page):
//   quantpad-github          linked account { login, token, ... }
//   quantpad-github-repos    cached repo list
//   quantpad-github-config   admin overrides (Admin tab)
//   quantpad-workspaces      workspace + codespace records
(function () {
  'use strict';

  // ── Config (config/github.js merged with admin overrides) ──
  var GH_FILE = window.QUANTPAD_GITHUB || {};
  var GH_ADMIN = {};
  try { GH_ADMIN = JSON.parse(localStorage.getItem('quantpad-github-config') || '{}'); } catch (e) {}
  var GH = Object.assign({}, GH_FILE, GH_ADMIN);
  var GH_IMAGES = GH.images || [{ id: 'default', name: 'Default - GitHub Codespaces (VS Code)', ref: 'mcr.microsoft.com/devcontainers/universal:2-linux', desc: 'The stock Codespaces universal image.', badge: 'Default', available: true }];
  var GH_MACHINES = GH.machines || [{ id: 'basicLinux32gb', name: '2-core', cpus: 2, memory: '8 GB', storage: '32 GB', creditsPerHour: 2 }];
  var GH_REGIONS = GH.regions || [{ id: '', name: 'Automatic' }];
  var GH_IDLE = GH.idleTimeoutOptions || [30, 60, 120];
  var GH_SCOPES = GH.scopes || ['read:user', 'repo', 'codespace', 'read:org'];
  var oauthMode = !!(GH.clientId && GH.tokenProxy);
  var patMode = GH.allowPat !== false;

  var imageById = function (id) { return GH_IMAGES.find(function (i) { return i.id === id; }) || GH_IMAGES[0]; };
  var machineById = function (id) { return GH_MACHINES.find(function (m) { return m.id === id; }) || GH_MACHINES[0]; };
  var regionName = function (id) { return (GH_REGIONS.find(function (r) { return r.id === id; }) || GH_REGIONS[0]).name; };

  // ── Account ──
  var account = null;
  try { account = JSON.parse(localStorage.getItem('quantpad-github') || 'null'); } catch (e) {}
  function saveAccount() {
    if (account) localStorage.setItem('quantpad-github', JSON.stringify(account));
    else localStorage.removeItem('quantpad-github');
  }
  var connected = function () { return !!(account && account.login); };
  var live = function () { return !!(account && account.token); };
  var getAccount = function () { return account; };

  function ghApi(path, opts) {
    var url = (GH.apiBase || 'https://api.github.com') + path;
    var headers = { Accept: 'application/vnd.github+json', Authorization: 'Bearer ' + account.token, 'Content-Type': 'application/json' };
    if (opts && opts.headers) Object.assign(headers, opts.headers);
    return fetch(url, Object.assign({}, opts, { headers: headers })).then(function (res) {
      if (!res.ok) {
        var status = res.status;
        return res.json().catch(function () { return {}; }).then(function (body) {
          var detail = body.message || '';
          if (body.errors && body.errors.length) detail += ' (' + body.errors.map(function (e) { return e.message || (e.field + ' ' + e.code); }).join('; ') + ')';
          throw new Error('GitHub ' + status + (detail ? ': ' + detail : ' on ' + path));
        });
      }
      return res.status === 204 ? null : res.json();
    });
  }

  // Verifies a token against /user, enforces the codespace scope and the
  // org rule, then stores it. Surfaces GitHub's own message on failure.
  function linkWithToken(token, mode) {
    var headers = { Accept: 'application/vnd.github+json', Authorization: 'Bearer ' + token };
    return fetch((GH.apiBase || 'https://api.github.com') + '/user', { headers: headers }).then(function (meRes) {
      if (meRes.status === 401) throw new Error('GitHub rejected that token (401). Check it was copied whole and has not expired.');
      if (!meRes.ok) throw new Error('GitHub API ' + meRes.status + ' while reading the account');
      return meRes.json().then(function (me) {
        var scopeHeader = meRes.headers.get('x-oauth-scopes') || '';
        var granted = scopeHeader.split(',').map(function (s) { return s.trim(); }).filter(Boolean);
        if (granted.length && !granted.includes('codespace')) {
          throw new Error('That token has no "codespace" scope, so workspaces cannot be created. Scopes seen: ' + (granted.join(', ') || 'none'));
        }
        if (GH.org) {
          return fetch((GH.apiBase || 'https://api.github.com') + '/orgs/' + encodeURIComponent(GH.org) + '/members/' + encodeURIComponent(me.login), { headers: headers }).then(function (memRes) {
            if (memRes.status !== 204) {
              throw new Error(me.login + ' is not a visible member of ' + GH.org + '. Join the organization (and grant the token read:org) before linking.');
            }
            return me;
          });
        }
        return me;
      }).then(function (me) {
        account = { login: me.login, name: me.name || me.login, token: token, mode: mode || 'pat', avatarUrl: me.avatar_url, org: GH.org || null, connectedAt: Date.now() };
        saveAccount();
        return account;
      });
    }).then(function (acc) { return loadRepos().then(function () { return acc; }); });
  }

  function startOAuth() {
    var state = Math.random().toString(36).slice(2);
    sessionStorage.setItem('quantpad-gh-state', state);
    var redirect = GH.redirectUri || (window.location.origin + window.location.pathname);
    window.location.href = 'https://github.com/login/oauth/authorize?client_id=' + encodeURIComponent(GH.clientId)
      + '&redirect_uri=' + encodeURIComponent(redirect)
      + '&scope=' + encodeURIComponent(GH_SCOPES.join(' '))
      + '&state=' + state;
  }

  function finishOAuth(code, state) {
    if (state !== sessionStorage.getItem('quantpad-gh-state')) return Promise.reject(new Error('OAuth state mismatch - aborted'));
    sessionStorage.removeItem('quantpad-gh-state');
    return fetch(GH.tokenProxy, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: code, redirect_uri: GH.redirectUri || (window.location.origin + window.location.pathname) })
    }).then(function (res) { return res.json(); }).then(function (data) {
      if (!data.access_token) throw new Error(data.error_description || data.error || 'no token returned by the exchange endpoint');
      return linkWithToken(data.access_token, 'oauth');
    });
  }

  function disconnect() { account = null; repos = []; saveAccount(); localStorage.removeItem('quantpad-github-repos'); }

  // ── Repos ──
  var repos = [];
  try { repos = JSON.parse(localStorage.getItem('quantpad-github-repos') || 'null') || []; } catch (e) {}
  function getRepos() { return repos; }
  function loadRepos() {
    if (!connected()) { repos = []; return Promise.resolve(repos); }
    if (!live()) { repos = []; return Promise.reject(new Error('No GitHub token stored - reconnect the account')); }
    var map = function (r) { return { id: r.id, name: r.name, full_name: r.full_name, private: r.private, language: r.language, description: r.description, default_branch: r.default_branch, pushed_at: new Date(r.pushed_at).getTime() }; };
    var calls = [ghApi('/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator').catch(function () { return []; })];
    if (GH.org) calls.unshift(ghApi('/orgs/' + encodeURIComponent(GH.org) + '/repos?per_page=100&sort=updated').catch(function () { return []; }));
    return Promise.all(calls).then(function (lists) {
      var seen = new Set();
      repos = [];
      lists.forEach(function (list) { (list || []).forEach(function (r) { if (!seen.has(r.id)) { seen.add(r.id); repos.push(map(r)); } }); });
      if (GH.org) repos = repos.filter(function (r) { return r.full_name.split('/')[0].toLowerCase() === String(GH.org).toLowerCase() || !GH.orgOnly; });
      localStorage.setItem('quantpad-github-repos', JSON.stringify(repos));
      return repos;
    });
  }

  // ── Workspaces (shared store with the workspace page) ──
  var WS_KEY = 'quantpad-workspaces';
  function listWorkspaces() {
    var ws = [];
    try { ws = JSON.parse(localStorage.getItem(WS_KEY) || '[]'); } catch (e) {}
    // Drop placeholder cards an earlier build seeded (no repo, no codespace).
    ws = ws.filter(function (w) { return w.repo || (w.codespace && w.codespace.name); });
    // Migrate older saves.
    ws.forEach(function (w) {
      if (!w.id) w.id = 'ws' + Math.random().toString(36).slice(2, 10);
      if (!w.imageId) w.imageId = 'default';
      if (!w.machineId) w.machineId = GH_MACHINES[0].id;
      if (!w.region && w.region !== '') w.region = (GH_REGIONS[0] || {}).id || '';
      if (!w.branch) w.branch = 'main';
      if (w.idleTimeout == null) w.idleTimeout = GH_IDLE[1] || GH_IDLE[0];
      if (!w.codespace) w.codespace = { name: '', state: 'Shutdown', createdAt: Date.now(), lastUsedAt: null };
    });
    return ws;
  }
  function saveWorkspaces(ws) { localStorage.setItem(WS_KEY, JSON.stringify(ws || [])); }
  function getWorkspace(id) { return listWorkspaces().find(function (w) { return w.id === id; }) || null; }

  function b64(s) { return btoa(unescape(encodeURIComponent(s))); }

  function writeDevcontainer(ws) {
    return buildDevBody(ws).then(function (body) {
      var content = b64(JSON.stringify(body, null, 2) + '\n');
      return ghApi('/repos/' + ws.repo + '/contents/.devcontainer/devcontainer.json', {
        method: 'PUT',
        body: JSON.stringify({ message: 'Add dev container for Belfort Trading workspace', content: content, branch: ws.branch })
      });
    });
  }

  function buildDevBody(ws) {
    if (ws.template !== 'ml') {
      var img = imageById(ws.imageId);
      return Promise.resolve({
        name: ws.name,
        image: img.ref,
        features: { 'ghcr.io/devcontainers/features/github-cli:1': {} },
        customizations: { vscode: { extensions: ['ms-python.python', 'ms-toolsai.jupyter'] } }
      });
    }
    var py = (GH_IMAGES.find(function (i) { return i.id === 'python'; }) || {}).ref || 'mcr.microsoft.com/devcontainers/python:3.12';
    var pipInstall = 'pip install --no-cache-dir numpy pandas scipy matplotlib plotly jupyterlab';
    var runMjs = "import { buildTradeLog, computeMetrics, runMonteCarlo, PROP_FIRM_PRESETS, runPropFirmSimulation, SAMPLE_TRADE_LOG } from './engine.mjs';\n"
      + "const log = buildTradeLog(SAMPLE_TRADE_LOG);\n"
      + "const m = computeMetrics(log);\n"
      + "const mc = runMonteCarlo(m.returns, { paths: 1000, blockSize: 1, seed: 42 });\n"
      + "const pf = runPropFirmSimulation(log.trades, PROP_FIRM_PRESETS[0], { runs: 500, seed: 42, strategyBaseline: 100000 });\n"
      + "console.log('Belfort backtest  - ', m.count, 'trades, net', m.netPnl.toFixed(0), 'grade', m.grade, '(' + m.gradeLabel + ')');\n"
      + "console.log('Monte Carlo p5/p50/p95:', mc.p5.toFixed(0), mc.p50.toFixed(0), mc.p95.toFixed(0));\n"
      + "console.log('FTMO pass rate:', pf.passRatePct.toFixed(0) + '%  EV $' + pf.expectedValue.toFixed(0));\n"
      + "console.log('Edit .belfort/run.mjs to backtest your own log.');";
    // Fetch the self-contained backtester engine (ESM, ~30 KB) and embed it
    // (base64) into the codespace so it has the real Belfort backtester even
    // when it isn't built from the Belfort repo. Falls back to a Python-only
    // starter if the bundle can't be fetched.
    return fetch('/backtester/engine.mjs').then(function (r) { return r.ok ? r.text() : ''; }, function () { return ''; }).then(function (engineSrc) {
      var postCreate;
      if (engineSrc) {
        postCreate = pipInstall + ' && mkdir -p .belfort'
          + " && printf '%s' '" + b64(engineSrc) + "' | base64 -d > .belfort/engine.mjs"
          + " && cat > .belfort/run.mjs <<'EOF'\n" + runMjs + '\nEOF\n'
          + 'node .belfort/run.mjs || true';
      } else {
        postCreate = pipInstall + " && cat > belfort_copilot.py <<'EOF'\nimport pandas as pd\nimport matplotlib.pyplot as plt\n\n# Load a TradingView 'List of Trades' export and analyse it.\n# df = pd.read_csv('trades.csv')\n# pnl = df['P&L'].astype(float)\n# print('Net P&L', pnl.sum(), 'Win rate', (pnl > 0).mean())\n# pnl.cumsum().plot(title='Equity curve'); plt.show()\nprint('Belfort Quant Copilot - edit me and run.')\nEOF";
      }
      return {
        name: 'Belfort Trading Quant Copilot',
        image: py,
        features: {
          'ghcr.io/devcontainers/features/github-cli:1': {},
          'ghcr.io/devcontainers/features/node:1': { version: 'lts' }
        },
        postCreateCommand: postCreate,
        customizations: { vscode: { extensions: ['ms-python.python', 'ms-toolsai.jupyter', 'ms-toolsai.jupyter-renderers'] } },
        forwardPorts: [8888],
        portsAttributes: { '8888': { label: 'JupyterLab', onAutoForward: 'openBrowserOnce' } }
      };
    });
  }

  function pollCodespace(ws, tries) {
    if (!live() || !ws.codespace || !ws.codespace.name) return Promise.resolve();
    return new Promise(function (resolve) {
      var i = 0;
      (function step() {
        if (i >= (tries || 30)) return resolve();
        i++;
        setTimeout(function () {
          ghApi('/user/codespaces/' + encodeURIComponent(ws.codespace.name)).then(function (cs) {
            ws.codespace.state = cs.state;
            ws.codespace.webUrl = cs.web_url;
            upsert(ws); emit();
            if (cs.state === 'Available') { resolve(); return; }
            if (/Failed|Deleted|Shutdown|Unavailable/.test(cs.state)) { resolve(); return; }
            step();
          }).catch(function (err) { ws.codespace.error = err.message; upsert(ws); emit(); resolve(); });
        }, 5000);
      })();
    });
  }

  // Create a codespace on the linked account for the workspace's repo.
  // Returns the updated workspace; throws on GitHub refusal.
  function createCodespace(ws) {
    if (!live()) {
      ws.codespace = { name: '', state: 'Failed', createdAt: Date.now(), error: 'No GitHub account is linked, so no codespace can be created.' };
      upsert(ws); emit();
      return Promise.resolve(ws);
    }
    if (!ws.repo) {
      ws.codespace = { name: '', state: 'Failed', createdAt: Date.now(), error: 'No repository selected - a codespace always comes from a repository.' };
      upsert(ws); emit();
      return Promise.resolve(ws);
    }
    var repo = repos.find(function (r) { return r.full_name === ws.repo; });
    if (!repo) {
      ws.codespace = { name: '', state: 'Failed', createdAt: Date.now(), error: 'Repository ' + ws.repo + ' is no longer in the list - refresh the GitHub connection.' };
      upsert(ws); emit();
      return Promise.resolve(ws);
    }
    ws.codespace = { name: '', state: 'Provisioning', createdAt: Date.now(), lastUsedAt: null };
    upsert(ws); emit();
    var chain = Promise.resolve();
    if (ws.writeDevcontainer) {
      chain = chain.then(function () { return writeDevcontainer(ws).then(function () { ws.devcontainerCommitted = true; upsert(ws); emit(); }).catch(function (err) {
        ws.codespace.state = 'Failed';
        ws.codespace.error = 'Could not commit the dev container: ' + err.message;
        upsert(ws); emit();
        throw err;
      }); });
    }
    return chain.then(function () {
      var payload = { repository_id: repo.id, ref: ws.branch, machine: ws.machineId, idle_timeout_minutes: ws.idleTimeout };
      if (ws.region) payload.location = ws.region;
      if (ws.writeDevcontainer || ws.repoHasDevcontainer) payload.devcontainer_path = '.devcontainer/devcontainer.json';
      return ghApi('/user/codespaces', { method: 'POST', body: JSON.stringify(payload) }).then(function (cs) {
        ws.codespace = { name: cs.name, state: cs.state || 'Provisioning', createdAt: Date.now(), lastUsedAt: null, webUrl: cs.web_url, machine: cs.machine && cs.machine.name };
        upsert(ws); emit();
        pollCodespace(ws);
        return ws;
      });
    }).catch(function (err) {
      // The writeDevcontainer failure already set the card; a POST failure lands here.
      if (!ws.codespace || ws.codespace.state !== 'Failed') {
        ws.codespace = { name: '', state: 'Failed', createdAt: Date.now(), error: err.message };
        upsert(ws); emit();
      }
      return ws;
    });
  }

  // opts: { name, desc, template, repo, branch, imageId, machineId, region, idleTimeout, prebuild, writeDevcontainer }
  function createWorkspace(opts) {
    var ws = Object.assign({
      id: 'ws' + Math.random().toString(36).slice(2, 10),
      name: opts.name || 'Workspace',
      desc: opts.desc || '',
      status: 'active',
      template: opts.template || 'blank',
      created: new Date().toISOString().slice(0, 10),
      repo: opts.repo || null,
      branch: opts.branch || 'main',
      imageId: opts.imageId || 'default',
      machineId: opts.machineId || GH_MACHINES[0].id,
      region: opts.region != null ? opts.region : (GH_REGIONS[0] || {}).id || '',
      idleTimeout: opts.idleTimeout != null ? opts.idleTimeout : (GH_IDLE[1] || GH_IDLE[0]),
      prebuild: opts.prebuild !== false,
      writeDevcontainer: !!opts.writeDevcontainer,
      repoHasDevcontainer: !!opts.repoHasDevcontainer,
      codespace: { name: '', state: 'Provisioning', createdAt: Date.now(), lastUsedAt: null }
    }, {});
    var all = listWorkspaces();
    all.unshift(ws);
    saveWorkspaces(all);
    return createCodespace(ws).then(function () { return ws; });
  }

  function power(id, target) {
    var ws = getWorkspace(id);
    if (!ws || !ws.codespace || !ws.codespace.name) return Promise.resolve();
    if (live()) {
      return ghApi('/user/codespaces/' + encodeURIComponent(ws.codespace.name) + (target === 'Available' ? '/start' : '/stop'), { method: 'POST' }).then(function () {
        ws.codespace.state = target; upsert(ws); emit();
      });
    }
    // Demo transition (no token): model Starting -> Available.
    return new Promise(function (resolve) {
      if (target === 'Available') {
        ws.codespace.state = 'Starting'; upsert(ws); emit();
        setTimeout(function () { ws.codespace.state = 'Available'; ws.codespace.lastUsedAt = Date.now(); upsert(ws); emit(); resolve(); }, 1600);
      } else {
        ws.codespace.state = 'Shutdown'; upsert(ws); emit(); resolve();
      }
    });
  }

  function sync() {
    if (!live()) return Promise.resolve(listWorkspaces());
    return ghApi('/user/codespaces?per_page=100').then(function (data) {
      var list = (data && data.codespaces) || [];
      var byName = {}; list.forEach(function (cs) { byName[cs.name] = cs; });
      var all = listWorkspaces();
      all.forEach(function (ws) {
        var cs = ws.codespace || {};
        if (!cs.name) return;
        var real = byName[cs.name];
        if (real) {
          cs.state = real.state; cs.webUrl = real.web_url; cs.machine = real.machine && real.machine.name;
          cs.lastUsedAt = real.last_used_at ? new Date(real.last_used_at).getTime() : cs.lastUsedAt; cs.missing = false;
        } else { cs.missing = true; }
      });
      // Codespaces created outside Belfort Trading show up as workspaces too.
      list.forEach(function (cs) {
        if (all.some(function (w) { return w.codespace && w.codespace.name === cs.name; })) return;
        all.push({
          id: 'ws' + Math.random().toString(36).slice(2, 10),
          name: cs.display_name || cs.name, desc: 'Imported from GitHub', status: 'active', template: 'blank',
          created: (cs.created_at || new Date().toISOString()).slice(0, 10),
          repo: cs.repository && cs.repository.full_name, branch: (cs.git_status && cs.git_status.ref) || 'main',
          imageId: 'default', machineId: (cs.machine && cs.machine.name) || GH_MACHINES[0].id,
          region: cs.location || '', idleTimeout: cs.idle_timeout_minutes || 30,
          codespace: { name: cs.name, state: cs.state, webUrl: cs.web_url, createdAt: Date.now(), lastUsedAt: null }
        });
      });
      saveWorkspaces(all);
      emit();
      return all;
    });
  }

  function remove(id) {
    var all = listWorkspaces().filter(function (w) { return w.id !== id; });
    saveWorkspaces(all); emit();
  }
  function setArchived(id, archived) {
    var all = listWorkspaces();
    var ws = all.find(function (w) { return w.id === id; });
    if (!ws) return;
    ws.status = archived ? 'archived' : 'draft';
    saveWorkspaces(all); emit();
  }

  function upsert(ws) {
    var all = listWorkspaces();
    var i = all.findIndex(function (w) { return w.id === ws.id; });
    if (i >= 0) all[i] = ws; else all.unshift(ws);
    saveWorkspaces(all);
  }

  // ── Tiny pub/sub so pages can re-render on change ──
  var listeners = [];
  function on(fn) { listeners.push(fn); }
  function off(fn) { listeners = listeners.filter(function (f) { return f !== fn; }); }
  function emit() { listeners.forEach(function (fn) { try { fn(); } catch (e) {} }); }

  window.Codespaces = {
    GH: GH, GH_IMAGES: GH_IMAGES, GH_MACHINES: GH_MACHINES, GH_REGIONS: GH_REGIONS, GH_IDLE: GH_IDLE, GH_SCOPES: GH_SCOPES,
    oauthMode: oauthMode, patMode: patMode,
    connected: connected, live: live, getAccount: getAccount,
    linkWithToken: linkWithToken, startOAuth: startOAuth, finishOAuth: finishOAuth, disconnect: disconnect,
    loadRepos: loadRepos, getRepos: getRepos,
    listWorkspaces: listWorkspaces, getWorkspace: getWorkspace, createWorkspace: createWorkspace, createCodespace: createCodespace,
    power: power, sync: sync, remove: remove, setArchived: setArchived, upsert: upsert,
    imageById: imageById, machineById: machineById, regionName: regionName,
    on: on, off: off
  };
})();
