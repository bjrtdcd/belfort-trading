/* =====================================================================
   Backtest report v2 - proposal
   =====================================================================
   Runs on the same pure engine as the shipped report (window.BelfortEngine),
   so every figure here is computed from the trade log in the textarea.
   Nothing is staged.

   The difference is order and density: verdict, headline figures, equity,
   weekly heatmap and the metrics table all land in the first screen and a
   half; the remaining analysis lives in collapsed groups that only draw
   their charts when opened.
   ===================================================================== */
(function () {
  'use strict';

  var E = window.BelfortEngine;
  var log = null, metrics = null;
  var drawn = {};

  var $ = function (id) { return document.getElementById(id); };
  var fmt0 = function (v) { return (v < 0 ? '-' : '') + '$' + Math.abs(Math.round(v)).toLocaleString(); };
  var pct = function (v, d) { return (v * 100).toFixed(d == null ? 1 : d) + '%'; };
  var esc = function (s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;'); };
  var num = function (v, d) { return (v == null || isNaN(v)) ? 'n/a' : Number(v).toFixed(d == null ? 2 : d); };

  function theme() {
    var cs = getComputedStyle(document.documentElement);
    var raw = function (n, fb) { return cs.getPropertyValue(n).trim() || fb; };
    return {
      fg: 'rgb(' + raw('--color-text-primary', '242 242 242') + ')',
      dim: 'rgb(' + raw('--color-text-secondary', '163 163 163') + ')',
      grid: 'rgb(' + raw('--color-border-primary', '34 34 34') + ')',
      accent: raw('--accent', '#7c83ff'),
      gain: raw('--gain', '#34d399'),
      loss: raw('--loss', '#fb7185'),
      font: 'IBM Plex Mono, ui-monospace, monospace',
    };
  }

  function layout(t, extra) {
    var base = {
      paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: 'rgba(0,0,0,0)',
      font: { color: t.dim, family: t.font, size: 10 },
      margin: { l: 46, r: 12, t: 8, b: 30 },
      xaxis: { gridcolor: t.grid, zerolinecolor: t.grid },
      yaxis: { gridcolor: t.grid, zerolinecolor: t.grid },
      showlegend: false, hovermode: 'closest',
    };
    Object.keys(extra || {}).forEach(function (k) { base[k] = extra[k]; });
    return base;
  }

  var CONFIG = { displayModeBar: false, responsive: true };

  // ── the grade, using the same shape of judgement as the shipped report ──
  function grade(m) {
    var score = 0;
    score += Math.min(m.profitFactor, 3) / 3 * 30;
    score += Math.min(Math.max(m.sharpeLike, 0), 2) / 2 * 25;
    score += m.winRate * 20;
    score += m.netPnl > 0 ? 15 : 0;
    score += m.maxDrawdownPct < .25 ? 10 : m.maxDrawdownPct < .5 ? 5 : 0;
    var letter = score > 80 ? 'A' : score > 66 ? 'B' : score > 50 ? 'C' : score > 35 ? 'D' : 'F';
    var line = m.netPnl <= 0
      ? 'This log loses money over the period. Nothing below changes that.'
      : m.profitFactor < 1.2
        ? 'Marginally profitable. The edge is thin enough that costs or a bad month erase it.'
        : m.maxDrawdownPct > .4
          ? 'Profitable, but the drawdown is deep relative to the gain. Size accordingly.'
          : 'Profitable with a workable drawdown. Check the sample size before trusting it.';
    return { letter: letter, score: Math.round(score), line: line };
  }

  // ── weekly / monthly buckets from real trade dates ──────────────────
  function buckets(trades) {
    var weeks = {}, months = {}, dows = [0, 0, 0, 0, 0, 0, 0];
    trades.forEach(function (tr) {
      var d = tr.date || tr.exitTime || tr.entryTime || tr.time;
      var when = d ? new Date(d) : null;
      if (!when || isNaN(when)) return;
      var y = when.getFullYear();
      var week = Math.floor((when - new Date(y, 0, 1)) / 604800000);
      var wk = y + '-W' + String(week).padStart(2, '0');
      var mo = y + '-' + String(when.getMonth() + 1).padStart(2, '0');
      weeks[wk] = (weeks[wk] || 0) + tr.pnl;
      months[mo] = (months[mo] || 0) + tr.pnl;
      dows[when.getDay()] += tr.pnl;
    });
    return { weeks: weeks, months: months, dows: dows };
  }

  // ── first-screen charts ─────────────────────────────────────────────
  function drawEquity() {
    var t = theme();
    var eq = metrics.equity;
    Plotly.newPlot('rv-equity', [
      { y: eq, type: 'scatter', mode: 'lines', line: { color: t.accent, width: 2 },
        hovertemplate: 'Trade %{x}<br>Equity %{y:$,.0f}<extra></extra>' },
    ], layout(t, { yaxis: { gridcolor: t.grid, tickformat: '$,.0f' }, xaxis: { gridcolor: t.grid, title: '' } }), CONFIG);

    Plotly.newPlot('rv-dd', [
      { y: metrics.drawdownSeries, type: 'scatter', mode: 'lines', fill: 'tozeroy',
        line: { color: t.loss, width: 1 }, fillcolor: 'rgba(251,113,133,.18)',
        hovertemplate: 'Trade %{x}<br>Drawdown %{y:$,.0f}<extra></extra>' },
    ], layout(t, { yaxis: { gridcolor: t.grid, tickformat: '$,.0f' } }), CONFIG);
  }

  function drawHeatmap() {
    var t = theme();
    var b = buckets(log.trades);
    var keys = Object.keys(b.weeks).sort();
    if (!keys.length) {
      $('rv-heat').innerHTML = '<p style="font-size:.78rem;color:var(--fg-3);padding:20px 0;">'
        + 'This log has no dates, so weekly P&L cannot be bucketed. Export with a date column to see it.</p>';
      $('rv-monthly').innerHTML = $('rv-heat').innerHTML;
      return;
    }
    // one row per year, one column per ISO week
    var years = [], cols = [];
    keys.forEach(function (k) {
      var y = k.slice(0, 4), w = +k.slice(6);
      if (years.indexOf(y) === -1) years.push(y);
      if (cols.indexOf(w) === -1) cols.push(w);
    });
    cols.sort(function (a, b2) { return a - b2; });
    var z = years.map(function (y) {
      return cols.map(function (w) {
        var k = y + '-W' + String(w).padStart(2, '0');
        return b.weeks[k] == null ? null : b.weeks[k];
      });
    });
    // size the container before plotting: one row of weeks does not need 260px
    if (years.length === 1) $('rv-heat').style.height = '170px';
    Plotly.newPlot('rv-heat', [{
      z: z, x: cols.map(function (c) { return 'W' + c; }), y: years, type: 'heatmap',
      colorscale: [[0, t.loss], [.5, 'rgba(120,120,120,.25)'], [1, t.gain]], zmid: 0,
      showscale: false, xgap: 2, ygap: 2,
      hovertemplate: '%{y} %{x}<br>%{z:$,.0f}<extra></extra>',
    }], layout(t, {
      margin: { l: 46, r: 12, t: 8, b: 34 },
      // years are labels, not a numeric scale: without this a single-year log
      // renders as a continuous axis reading 2024.6, 2024.8, 2025.0
      yaxis: { type: 'category', gridcolor: t.grid },
      xaxis: { type: 'category', gridcolor: t.grid },
    }), CONFIG);

    var mk = Object.keys(b.months).sort();
    Plotly.newPlot('rv-monthly', [{
      x: mk, y: mk.map(function (k) { return b.months[k]; }), type: 'bar',
      marker: { color: mk.map(function (k) { return b.months[k] >= 0 ? t.gain : t.loss; }) },
      hovertemplate: '%{x}<br>%{y:$,.0f}<extra></extra>',
    }], layout(t, { yaxis: { gridcolor: t.grid, tickformat: '$,.0f' } }), CONFIG);
  }

  // ── Monte Carlo: on the first screen, because it is the question most
  //    people open the report to answer. 1,000 paths costs ~12ms. ───────
  function drawMonteCarlo() {
    var t = theme();
    var res;
    try {
      res = E.runMonteCarlo(log.trades.map(function (tr) { return tr.pnl; }),
        { paths: 1000, blockSize: 5, seed: 42 });
    } catch (err) {
      $('rv-mc-stats').innerHTML = '';
      $('rv-mc-band').innerHTML = '<p style="font-size:.78rem;color:var(--fg-3);padding:20px 0;">' + esc(err.message) + '</p>';
      return;
    }

    // percentile envelope across the resampled paths, step by step
    var steps = res.paths[0].length, lo = [], mid = [], hi = [];
    for (var i = 0; i < steps; i++) {
      var col = res.paths.map(function (path) { return path[i]; }).sort(function (a, b) { return a - b; });
      lo.push(col[Math.floor(.05 * (col.length - 1))]);
      mid.push(col[Math.floor(.5 * (col.length - 1))]);
      hi.push(col[Math.floor(.95 * (col.length - 1))]);
    }
    var x = lo.map(function (_, i) { return i + 1; });

    Plotly.newPlot('rv-mc-band', [
      { x: x, y: hi, type: 'scatter', mode: 'lines', line: { width: 0 }, hoverinfo: 'skip' },
      { x: x, y: lo, type: 'scatter', mode: 'lines', line: { width: 0 }, fill: 'tonexty',
        fillcolor: 'rgba(124,131,255,.16)', hoverinfo: 'skip' },
      { x: x, y: mid, type: 'scatter', mode: 'lines', line: { color: t.accent, width: 2 },
        hovertemplate: 'Trade %{x}<br>Median %{y:$,.0f}<extra></extra>' },
      { x: x, y: metrics.equity, type: 'scatter', mode: 'lines',
        line: { color: t.fg, width: 1.5, dash: 'dot' },
        hovertemplate: 'Trade %{x}<br>Actual %{y:$,.0f}<extra></extra>' },
    ], layout(t, { yaxis: { gridcolor: t.grid, tickformat: '$,.0f' } }), CONFIG);

    var stats = [
      ['Median outcome', fmt0(res.p50), res.p50 >= 0 ? 'pos' : 'neg'],
      ['5th percentile', fmt0(res.p5), res.p5 >= 0 ? 'pos' : 'neg'],
      ['95th percentile', fmt0(res.p95), 'pos'],
      ['Paths in profit', (res.positivePathsPct * 100).toFixed(1) + '%', ''],
      ['Risk of ruin', res.riskOfRuinPct.toFixed(1) + '%', res.riskOfRuinPct > 10 ? 'neg' : ''],
      ['Actual run', fmt0(metrics.netPnl),
        metrics.netPnl >= res.p50 ? 'pos' : '',
        metrics.netPnl >= res.p50 ? 'above the median path' : 'below the median path'],
    ];
    $('rv-mc-stats').innerHTML = stats.map(function (st) {
      return '<div class="rv-kpi"><div class="rv-kpi-v ' + st[2] + '">' + st[1] + '</div>'
        + '<div class="rv-kpi-l">' + st[0] + '</div>'
        + (st[3] ? '<div class="rv-kpi-s">' + st[3] + '</div>' : '') + '</div>';
    }).join('');
  }

  // ── Prop firms ──────────────────────────────────────────────────────
  //    Most people arrive asking "would this pass a challenge?", so the
  //    answer gets its own section with the firm's own rules applied.
  var propPreset = 0;
  // Custom rule set, seeded from the first preset, editable in the UI.
  var customCfg = (function () {
    var base = {};
    var p = E.PROP_FIRM_PRESETS[0];
    Object.keys(p).forEach(function (k) { base[k] = p[k]; });
    base.name = 'Custom rules';
    return base;
  })();

  function currentPropConfig() {
    return propPreset === 'custom' ? customCfg : E.PROP_FIRM_PRESETS[propPreset];
  }

  function drawPropFirm() {
    var t = theme();
    var cfg = currentPropConfig();
    var res;
    try {
      res = E.runPropFirmSimulation(log.trades, cfg, { runs: 2000, seed: 42, tradesPerRun: 60 });
    } catch (err) {
      $('rv-prop-stats').innerHTML = '';
      $('rv-prop-paths').innerHTML = '<p style="font-size:.78rem;color:var(--fg-3);padding:20px 0;">' + esc(err.message) + '</p>';
      return;
    }

    $('rv-prop-headline').innerHTML =
      '<div class="rv-prop-rate ' + (res.passRatePct >= 50 ? 'pos' : res.passRatePct >= 25 ? '' : 'neg') + '">'
      + res.passRatePct.toFixed(1) + '%</div>'
      + '<div class="rv-prop-rate-l">of 2,000 simulated attempts pass ' + esc(cfg.name) + '</div>'
      + '<div class="rv-prop-rate-s">' + fmt0(cfg.profitTarget) + ' target · '
      + fmt0(cfg.maxTotalDrawdown) + ' max drawdown · ' + cfg.evaluationDays + ' days · '
      + fmt0(cfg.challengeFee) + ' fee</div>';

    var daysToTarget = res.averageDaysToTarget == null ? 'n/a'
      : res.averageDaysToTarget.toFixed(0) + ' / ' + (res.medianDaysToTarget == null ? '-' : res.medianDaysToTarget.toFixed(0));
    var costToPass = isFinite(res.expectedCostToPass) ? fmt0(res.expectedCostToPass) : 'never';
    var stats = [
      ['EV per attempt', fmt0(res.expectedValue), res.expectedValue >= 0 ? 'pos' : 'neg', 'after fees, one attempt'],
      ['ROI per attempt', (res.roiPerAttempt * 100).toFixed(0) + '%', res.roiPerAttempt >= 0 ? 'pos' : 'neg', 'EV as a share of the fee'],
      ['Evals passed / year', res.evalsPassedPerYear.toFixed(1), res.evalsPassedPerYear >= 1 ? 'pos' : '', res.attemptsPerYear.toFixed(0) + ' attempts/yr'],
      ['Annual EV', fmt0(res.annualExpectedValue), res.annualExpectedValue >= 0 ? 'pos' : 'neg', 'running it all year'],
      ['Annual payout', fmt0(res.annualExpectedPayout), 'pos', 'expected, gross of fees'],
      ['Attempts to pass', isFinite(res.expectedAttemptsToPass) ? res.expectedAttemptsToPass.toFixed(1) : '∞', '', 'expected, first pass'],
      ['Cost to pass', costToPass, 'neg', 'fees to a first funded account'],
      ['Payout / days to target', fmt0(res.effectivePayout) + ' · ' + daysToTarget + 'd', '', 'per pass · mean/median days'],
    ];
    $('rv-prop-stats').innerHTML = stats.map(function (st) {
      return '<div class="rv-kpi"><div class="rv-kpi-v ' + st[2] + '">' + st[1] + '</div>'
        + '<div class="rv-kpi-l">' + st[0] + '</div><div class="rv-kpi-s">' + st[3] + '</div></div>';
    }).join('');

    // sample attempts against the target and the drawdown floor
    var traces = res.sampleRuns.slice(0, 20).map(function (rn) {
      return {
        y: rn.equity, type: 'scatter', mode: 'lines',
        line: { color: rn.outcome === 'pass' ? t.gain : t.loss, width: 1 },
        opacity: .55, hoverinfo: 'skip',
      };
    });
    traces.push({
      y: res.sampleRuns[0].equity.map(function () { return cfg.accountSize + cfg.profitTarget; }),
      type: 'scatter', mode: 'lines', line: { color: t.fg, width: 1, dash: 'dash' },
      hovertemplate: 'Target ' + fmt0(cfg.accountSize + cfg.profitTarget) + '<extra></extra>',
    });
    traces.push({
      y: res.sampleRuns[0].equity.map(function () { return cfg.accountSize - cfg.maxTotalDrawdown; }),
      type: 'scatter', mode: 'lines', line: { color: t.loss, width: 1, dash: 'dot' },
      hovertemplate: 'Bust ' + fmt0(cfg.accountSize - cfg.maxTotalDrawdown) + '<extra></extra>',
    });
    Plotly.newPlot('rv-prop-paths', traces,
      layout(t, { yaxis: { gridcolor: t.grid, tickformat: '$,.0f' } }), CONFIG);

    $('rv-prop-fails').innerHTML = res.failures.length
      ? res.failures.map(function (f) {
          return '<div class="rv-fail"><span>' + esc(f.reason) + '</span>'
            + '<span class="mono">' + (f.pct * 100).toFixed(1) + '%</span></div>';
        }).join('')
      : '<div class="rv-fail"><span>No failures in this sample.</span></div>';
  }

  function buildPropTabs() {
    var html = E.PROP_FIRM_PRESETS.map(function (p, i) {
      return '<button type="button" class="rv-tab' + (i === propPreset ? ' on' : '') + '" data-preset="' + i + '">'
        + esc(p.name) + '</button>';
    }).join('');
    html += '<button type="button" class="rv-tab' + (propPreset === 'custom' ? ' on' : '') + '" data-preset="custom">+ Custom</button>';
    $('rv-prop-tabs').innerHTML = html;
    $('rv-prop-tabs').querySelectorAll('button').forEach(function (b) {
      b.addEventListener('click', function () {
        propPreset = b.dataset.preset === 'custom' ? 'custom' : +b.dataset.preset;
        buildPropTabs();
        renderCustomForm();
        if (log) drawPropFirm();
      });
    });
    renderCustomForm();
  }

  // ── Custom prop-firm rules: an editable rule set the sim runs directly ─
  var PROP_FIELDS = [
    ['accountSize', 'Account size', '$'],
    ['profitTarget', 'Profit target', '$'],
    ['maxDailyLoss', 'Max daily loss', '$'],
    ['maxTotalDrawdown', 'Max total drawdown', '$'],
    ['evaluationDays', 'Evaluation days', 'd'],
    ['challengeFee', 'Challenge fee', '$'],
    ['resetFee', 'Reset fee', '$'],
    ['payoutPct', 'Profit split', '%'],
    ['minPayout', 'Min payout', '$'],
    ['consistencyPct', 'Consistency cap', '%'],
  ];

  function renderCustomForm() {
    var host = $('rv-prop-custom');
    if (!host) return;
    if (propPreset !== 'custom') { host.hidden = true; host.innerHTML = ''; return; }
    host.hidden = false;
    var fields = PROP_FIELDS.map(function (f) {
      var key = f[0], label = f[1], unit = f[2];
      return '<label class="rv-cf"><span>' + label + (unit === '%' ? ' (%)' : unit === 'd' ? ' (days)' : '') + '</span>'
        + '<input type="number" data-key="' + key + '" value="' + customCfg[key] + '" step="any" min="0"></label>';
    }).join('');
    var trailing = '<label class="rv-cf rv-cf-check"><input type="checkbox" data-key="trailingDrawdown"'
      + (customCfg.trailingDrawdown ? ' checked' : '') + '><span>Trailing drawdown</span></label>';
    host.innerHTML = '<div class="rv-cf-grid">' + fields + trailing + '</div>';
    host.querySelectorAll('input').forEach(function (inp) {
      inp.addEventListener('input', function () {
        var key = inp.dataset.key;
        if (inp.type === 'checkbox') customCfg[key] = inp.checked;
        else { var v = parseFloat(inp.value); customCfg[key] = isNaN(v) ? 0 : v; }
        if (log) drawPropFirm();
      });
    });
  }

  // ── 3D: one surface, not seventeen ──────────────────────────────────
  function draw3D() {
    var t = theme();
    var res;
    try {
      res = E.runMonteCarlo(log.trades.map(function (tr) { return tr.pnl; }),
        { paths: 400, blockSize: 5, seed: 7 });
    } catch (err) {
      $('rv-3d').innerHTML = '<p style="font-size:.78rem;color:var(--fg-3);padding:20px 0;">' + esc(err.message) + '</p>';
      return;
    }
    // sort the paths by outcome so the surface reads as a distribution
    var sorted = res.paths.slice().sort(function (a, b) { return a[a.length - 1] - b[b.length - 1]; });
    var step = Math.max(1, Math.floor(sorted.length / 40));
    var z = [];
    for (var i = 0; i < sorted.length; i += step) z.push(sorted[i]);
    Plotly.newPlot('rv-3d', [{
      z: z, type: 'surface', showscale: false,
      colorscale: [[0, t.loss], [.5, 'rgba(124,131,255,.75)'], [1, t.gain]], cmid: 0,
      contours: { z: { show: true, usecolormap: true, project: { z: true } } },
      hovertemplate: 'Trade %{x}<br>Path %{y}<br>Equity %{z:$,.0f}<extra></extra>',
    }], {
      paper_bgcolor: 'rgba(0,0,0,0)',
      font: { color: t.dim, family: t.font, size: 10 },
      margin: { l: 0, r: 0, t: 0, b: 0 },
      scene: {
        xaxis: { title: 'trade', gridcolor: t.grid, color: t.dim, backgroundcolor: 'rgba(0,0,0,0)', showbackground: true },
        yaxis: { title: 'path, worst to best', gridcolor: t.grid, color: t.dim, backgroundcolor: 'rgba(0,0,0,0)', showbackground: true },
        zaxis: { title: 'equity', gridcolor: t.grid, color: t.dim, backgroundcolor: 'rgba(0,0,0,0)', showbackground: true },
        camera: { eye: { x: 1.6, y: -1.5, z: .8 } },
      },
    }, CONFIG);
  }

  // ── Market regimes ──────────────────────────────────────────────────
  //    Bull/Bear × Low/High Vol detected from the equity path itself.
  //    The attribution tabs decide which window classifies each trade:
  //    entry (short window at entry), dominant (long window), exit.
  var regimeMode = 'entry';

  function drawRegimes() {
    var t = theme();
    var host = $('rv-regime-stats');
    var plots = ['rv-regime-equity', 'rv-regime-pnl', 'rv-regime-mc', 'rv-regime-trans'];
    var regimes = E.detectRegimes(metrics);
    if (regimes.length < 4) {
      host.innerHTML = '';
      plots.forEach(function (id) {
        $(id).innerHTML = '<p style="font-size:.78rem;color:var(--fg-3);padding:20px 0;">'
          + 'Need at least 4 trades to detect regimes.</p>';
      });
      return;
    }
    var attributed = E.attributeRegimes(regimes, regimeMode);
    var returns = metrics.returns;
    var stats = E.computeRegimeStats(returns, attributed);
    var bands = E.regimeEquityBands(attributed);

    host.innerHTML = stats.map(function (s) {
      return '<div class="rv-kpi"><div class="rv-kpi-v" style="color:' + s.color + ';">' + fmt0(s.netPnl) + '</div>'
        + '<div class="rv-kpi-l">' + esc(s.regime) + '</div>'
        + '<div class="rv-kpi-s">' + s.trades + ' trades · ' + pct(s.winRate) + ' win · ' + s.exposurePct.toFixed(0) + '% of time</div></div>';
    }).join('');

    // equity with regime bands behind it
    var shapes = bands.map(function (b) {
      return { type: 'rect', xref: 'x', yref: 'paper', x0: b.start, x1: b.end, y0: 0, y1: 1,
        fillcolor: b.color, opacity: .13, line: { width: 0 } };
    });
    Plotly.newPlot('rv-regime-equity', [
      { y: metrics.equity, type: 'scatter', mode: 'lines', line: { color: t.fg, width: 1.6 },
        hovertemplate: 'Trade %{x}<br>Equity %{y:$,.0f}<extra></extra>' },
    ], layout(t, { shapes: shapes, yaxis: { gridcolor: t.grid, tickformat: '$,.0f' } }), CONFIG);

    // net P&L per regime
    Plotly.newPlot('rv-regime-pnl', [{
      x: stats.map(function (s) { return s.regime; }),
      y: stats.map(function (s) { return s.netPnl; }),
      type: 'bar', marker: { color: stats.map(function (s) { return s.color; }) },
      hovertemplate: '%{x}<br>%{y:$,.0f}<extra></extra>',
    }], layout(t, { yaxis: { gridcolor: t.grid, tickformat: '$,.0f' }, xaxis: { type: 'category', gridcolor: t.grid } }), CONFIG);

    // regime-aware MC envelope vs IID baseline
    function envelope(res) {
      var steps = res.paths.length ? res.paths[0].length : 0, lo = [], mid = [], hi = [];
      for (var i = 0; i < steps; i++) {
        var col = res.paths.map(function (path) { return path[i]; }).sort(function (a, b) { return a - b; });
        lo.push(col[Math.floor(.05 * (col.length - 1))]);
        mid.push(col[Math.floor(.5 * (col.length - 1))]);
        hi.push(col[Math.floor(.95 * (col.length - 1))]);
      }
      return { lo: lo, mid: mid, hi: hi };
    }
    var aware = envelope(E.runRegimeAwareMC(returns, attributed, { paths: 500, blockSize: 5, seed: 42, regimeAware: true }));
    var iid = envelope(E.runRegimeAwareMC(returns, attributed, { paths: 500, blockSize: 5, seed: 42, regimeAware: false }));
    var x = aware.mid.map(function (_, i) { return i; });
    Plotly.newPlot('rv-regime-mc', [
      { x: x, y: aware.hi, type: 'scatter', mode: 'lines', line: { width: 0 }, hoverinfo: 'skip' },
      { x: x, y: aware.lo, type: 'scatter', mode: 'lines', line: { width: 0 }, fill: 'tonexty',
        fillcolor: 'rgba(45,212,191,.14)', hoverinfo: 'skip' },
      { x: x, y: aware.mid, type: 'scatter', mode: 'lines', line: { color: '#2dd4bf', width: 2 },
        hovertemplate: 'Trade %{x}<br>Regime-aware median %{y:$,.0f}<extra></extra>' },
      { x: x, y: iid.mid, type: 'scatter', mode: 'lines', line: { color: t.dim, width: 1.5, dash: 'dot' },
        hovertemplate: 'Trade %{x}<br>IID median %{y:$,.0f}<extra></extra>' },
    ], layout(t, { yaxis: { gridcolor: t.grid, tickformat: '$,.0f' } }), CONFIG);

    // transition matrix
    var order = E.REGIME_ORDER;
    var counts = order.map(function () { return order.map(function () { return 0; }); });
    for (var i = 1; i < attributed.length; i++) {
      counts[order.indexOf(attributed[i - 1])][order.indexOf(attributed[i])] += 1;
    }
    var zn = counts.map(function (row) {
      var total = row.reduce(function (a, b) { return a + b; }, 0);
      return row.map(function (v) { return total ? v / total : 0; });
    });
    Plotly.newPlot('rv-regime-trans', [{
      z: zn, x: order, y: order, type: 'heatmap',
      colorscale: [[0, 'rgba(120,120,120,.08)'], [1, t.accent]], zmin: 0, zmax: 1,
      showscale: false, xgap: 2, ygap: 2,
      hovertemplate: 'From %{y}<br>To %{x}<br>%{z:.0%}<extra></extra>',
    }], layout(t, {
      margin: { l: 92, r: 12, t: 8, b: 60 },
      xaxis: { type: 'category', gridcolor: t.grid },
      yaxis: { type: 'category', gridcolor: t.grid, autorange: 'reversed' },
    }), CONFIG);
  }

  function buildRegimeTabs() {
    var modes = [['entry', 'Entry'], ['dominant', 'Dominant'], ['exit', 'Exit']];
    $('rv-regime-tabs').innerHTML = modes.map(function (m) {
      return '<button type="button" class="rv-tab' + (m[0] === regimeMode ? ' on' : '') + '" data-mode="' + m[0] + '">'
        + m[1] + '</button>';
    }).join('');
    $('rv-regime-tabs').querySelectorAll('button').forEach(function (b) {
      b.addEventListener('click', function () {
        regimeMode = b.dataset.mode;
        buildRegimeTabs();
        if (log) drawRegimes();
      });
    });
  }

  // ── Risk & return distribution ──────────────────────────────────────
  //    The institutional risk metrics the engine already computes, plus a
  //    per-trade return distribution with VaR / CVaR marked on it.
  function drawRisk() {
    var t = theme(), m = metrics;
    var cards = [
      ['Sortino', num(m.sortino, 2), '', 'downside-only Sharpe'],
      ['Calmar', num(m.calmar, 2), '', 'return over max drawdown'],
      ['Omega', num(m.omega, 2), '', 'gains over losses, prob-weighted'],
      ['Tail ratio', num(m.tailRatio, 2), '', '95th vs 5th percentile'],
      ['VaR 95%', fmt0(-Math.abs(m.valueAtRisk95)), 'neg', 'worst 1-in-20 trade'],
      ['CVaR 95%', fmt0(-Math.abs(m.cvar95)), 'neg', 'mean of the worst 5%'],
      ['Ulcer index', num(m.ulcerIndex, 2), '', 'depth × duration of drawdown'],
      ['Skew / Kurtosis', num(m.skewness, 2) + ' / ' + num(m.kurtosis, 2), '', 'shape of the return distribution'],
    ];
    $('rv-risk-stats').innerHTML = cards.map(function (c) {
      return '<div class="rv-kpi"><div class="rv-kpi-v ' + c[2] + '">' + c[1] + '</div>'
        + '<div class="rv-kpi-l">' + c[0] + '</div><div class="rv-kpi-s">' + c[3] + '</div></div>';
    }).join('');

    // return distribution with VaR / CVaR lines
    var pnls = log.trades.map(function (tr) { return tr.pnl; });
    var v = -Math.abs(m.valueAtRisk95), cv = -Math.abs(m.cvar95);
    Plotly.newPlot('rv-risk-dist', [{
      x: pnls, type: 'histogram', marker: { color: t.accent }, nbinsx: 30, opacity: .85,
      hovertemplate: 'P&L %{x:$,.0f}<br>%{y} trades<extra></extra>',
    }], layout(t, {
      xaxis: { gridcolor: t.grid, tickformat: '$,.0f' },
      shapes: [
        { type: 'line', x0: v, x1: v, yref: 'paper', y0: 0, y1: 1, line: { color: t.loss, width: 1.5, dash: 'dash' } },
        { type: 'line', x0: cv, x1: cv, yref: 'paper', y0: 0, y1: 1, line: { color: t.loss, width: 1.5, dash: 'dot' } },
      ],
      annotations: [
        { x: v, yref: 'paper', y: 1, text: 'VaR', showarrow: false, font: { color: t.loss, size: 9 }, yshift: 6 },
        { x: cv, yref: 'paper', y: .9, text: 'CVaR', showarrow: false, font: { color: t.loss, size: 9 }, yshift: 6 },
      ],
    }), CONFIG);
  }

  // ── Robustness: is the edge real or overfit? ────────────────────────
  //    Walk-forward IS→OOS, purged K-fold, deflated Sharpe and a
  //    stationary-bootstrap envelope, all from buildOverfitReport.
  function drawRobustness() {
    var t = theme();
    var pnls = log.trades.map(function (tr) { return tr.pnl; });
    var host = $('rv-robust-stats'), verdictEl = $('rv-robust-verdict');
    var rep;
    try {
      rep = E.buildOverfitReport(pnls, {
        sharpe: metrics.sharpeLike,
        skewness: metrics.skewness,
        kurtosis: metrics.kurtosis,
        count: metrics.count,
        tradesPerYear: 252,
      }, { folds: 5, trials: 1, paths: 1000, seed: 42 });
    } catch (err) {
      host.innerHTML = '';
      verdictEl.textContent = err.message;
      ['rv-robust-wf', 'rv-robust-sb'].forEach(function (id) { $(id).innerHTML = ''; });
      return;
    }

    verdictEl.textContent = rep.verdict;
    var wf = rep.walkForward, dsr = rep.deflatedSharpe, pkf = rep.purgedKFold;
    var cards = [
      ['Walk-forward OOS', pct(wf.oosPositivePct, 0), wf.oosPositivePct >= .5 ? 'pos' : 'neg', 'folds positive out of sample'],
      ['IS → OOS Sharpe', num(wf.meanIsSharpe, 2) + ' → ' + num(wf.meanOosSharpe, 2), '', 'degradation ' + num(wf.meanDegradation, 2)],
      ['Purged K-fold OOS', pct(pkf.oosPositivePct, 0), pkf.oosPositivePct >= .5 ? 'pos' : 'neg', 'leakage-controlled cross-validation'],
      ['Deflated Sharpe', pct(dsr.dsr, 0), dsr.dsr >= .8 ? 'pos' : dsr.dsr >= .5 ? '' : 'neg', 'prob the Sharpe is real'],
    ];
    host.innerHTML = cards.map(function (c) {
      return '<div class="rv-kpi"><div class="rv-kpi-v ' + c[2] + '">' + c[1] + '</div>'
        + '<div class="rv-kpi-l">' + c[0] + '</div><div class="rv-kpi-s">' + c[3] + '</div></div>';
    }).join('');

    // walk-forward: IS vs OOS Sharpe per fold
    if (wf.folds && wf.folds.length) {
      var idx = wf.folds.map(function (_, i) { return 'F' + (i + 1); });
      Plotly.newPlot('rv-robust-wf', [
        { x: idx, y: wf.folds.map(function (f) { return f.isSharpe; }), type: 'bar', name: 'In-sample',
          marker: { color: t.dim }, hovertemplate: '%{x} IS Sharpe %{y:.2f}<extra></extra>' },
        { x: idx, y: wf.folds.map(function (f) { return f.oosSharpe; }), type: 'bar', name: 'Out-of-sample',
          marker: { color: t.accent }, hovertemplate: '%{x} OOS Sharpe %{y:.2f}<extra></extra>' },
      ], layout(t, { barmode: 'group', showlegend: true,
        legend: { orientation: 'h', y: 1.15, font: { size: 9 } },
        yaxis: { gridcolor: t.grid } }), CONFIG);
    } else {
      $('rv-robust-wf').innerHTML = '<p style="font-size:.78rem;color:var(--fg-3);padding:20px 0;">Need more trades to split into walk-forward folds.</p>';
    }

    // stationary bootstrap envelope
    var sb = rep.stationaryBootstrap;
    if (sb.paths && sb.paths.length) {
      var steps = sb.paths[0].length, lo = [], mid = [], hi = [];
      for (var i = 0; i < steps; i++) {
        var col = sb.paths.map(function (p) { return p[i]; }).sort(function (a, b) { return a - b; });
        lo.push(col[Math.floor(.05 * (col.length - 1))]);
        mid.push(col[Math.floor(.5 * (col.length - 1))]);
        hi.push(col[Math.floor(.95 * (col.length - 1))]);
      }
      var x = mid.map(function (_, i) { return i; });
      Plotly.newPlot('rv-robust-sb', [
        { x: x, y: hi, type: 'scatter', mode: 'lines', line: { width: 0 }, hoverinfo: 'skip' },
        { x: x, y: lo, type: 'scatter', mode: 'lines', line: { width: 0 }, fill: 'tonexty',
          fillcolor: 'rgba(124,131,255,.14)', hoverinfo: 'skip' },
        { x: x, y: mid, type: 'scatter', mode: 'lines', line: { color: t.accent, width: 2 },
          hovertemplate: 'Trade %{x}<br>Median %{y:$,.0f}<extra></extra>' },
        { x: x, y: metrics.equity, type: 'scatter', mode: 'lines',
          line: { color: t.fg, width: 1.5, dash: 'dot' },
          hovertemplate: 'Trade %{x}<br>Actual %{y:$,.0f}<extra></extra>' },
      ], layout(t, { yaxis: { gridcolor: t.grid, tickformat: '$,.0f' } }), CONFIG);
    } else {
      $('rv-robust-sb').innerHTML = '';
    }
  }

  // ── deferred groups: only drawn when the details element opens ───────
  var DEFERRED = {
    'rv-dist': function () {
      var t = theme();
      Plotly.newPlot('rv-dist', [{
        x: log.trades.map(function (tr) { return tr.pnl; }), type: 'histogram',
        marker: { color: t.accent }, nbinsx: 24,
        hovertemplate: 'P&L %{x:$,.0f}<br>%{y} trades<extra></extra>',
      }], layout(t, { xaxis: { gridcolor: t.grid, tickformat: '$,.0f' } }), CONFIG);
    },
    'rv-dow': function () {
      var t = theme();
      var b = buckets(log.trades);
      var names = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      Plotly.newPlot('rv-dow', [{
        x: names, y: b.dows, type: 'bar',
        marker: { color: b.dows.map(function (v) { return v >= 0 ? t.gain : t.loss; }) },
        hovertemplate: '%{x}<br>%{y:$,.0f}<extra></extra>',
      }], layout(t, { yaxis: { gridcolor: t.grid, tickformat: '$,.0f' } }), CONFIG);
    },
    'rv-streaks': function () {
      var t = theme();
      var run = 0, runs = [];
      log.trades.forEach(function (tr) {
        if (tr.pnl > 0) { if (run < 0) { runs.push(run); run = 0; } run++; }
        else { if (run > 0) { runs.push(run); run = 0; } run--; }
      });
      runs.push(run);
      Plotly.newPlot('rv-streaks', [{
        x: runs, type: 'histogram', marker: { color: t.accent },
        hovertemplate: 'Run of %{x}<br>%{y}×<extra></extra>',
      }], layout(t), CONFIG);
    },
  };

  // -- the rest of the library -----------------------------------------
  //    The classic report put fifty charts in one column. These are the
  //    ones worth keeping, each drawn on demand inside its fold so
  //    nothing renders until it is opened.
  function addLibrary() {
    var lib = {
      'rv-pertrade': function () {
        var t = theme();
        var p = log.trades.map(function (tr) { return tr.pnl; });
        Plotly.newPlot('rv-pertrade', [{
          y: p, type: 'bar',
          marker: { color: p.map(function (v) { return v >= 0 ? t.gain : t.loss; }) },
          hovertemplate: 'Trade %{x}<br>%{y:$,.0f}<extra></extra>',
        }], layout(t, { yaxis: { gridcolor: t.grid, tickformat: '$,.0f' } }), CONFIG);
      },
      'rv-rolling': function () {
        var t = theme(), w = Math.max(5, Math.floor(log.trades.length / 4));
        var p = log.trades.map(function (tr) { return tr.pnl; }), out = [];
        for (var i = w; i <= p.length; i++) {
          var win = p.slice(i - w, i);
          var m = win.reduce(function (a, b) { return a + b; }, 0) / w;
          var sd = Math.sqrt(win.reduce(function (a, b) { return a + (b - m) * (b - m); }, 0) / Math.max(1, w - 1));
          out.push(sd ? (m / sd) * Math.sqrt(w) : 0);
        }
        Plotly.newPlot('rv-rolling', [{
          y: out, type: 'scatter', mode: 'lines', line: { color: t.accent, width: 2 },
          hovertemplate: 'Trade %{x}<br>Sharpe %{y:.2f}<extra></extra>',
        }], layout(t, { yaxis: { gridcolor: t.grid } }), CONFIG);
      },
      'rv-winrate': function () {
        var t = theme(), wins = 0, out = [];
        log.trades.forEach(function (tr, i) { if (tr.pnl > 0) wins++; out.push(wins / (i + 1)); });
        Plotly.newPlot('rv-winrate', [{
          y: out, type: 'scatter', mode: 'lines', line: { color: t.accent, width: 2 },
          hovertemplate: 'Trade %{x}<br>Win rate %{y:.1%}<extra></extra>',
        }], layout(t, { yaxis: { gridcolor: t.grid, tickformat: '.0%' } }), CONFIG);
      },
      'rv-box': function () {
        var t = theme();
        var wins = log.trades.filter(function (x) { return x.pnl > 0; }).map(function (x) { return x.pnl; });
        var losses = log.trades.filter(function (x) { return x.pnl <= 0; }).map(function (x) { return x.pnl; });
        Plotly.newPlot('rv-box', [
          { y: wins, type: 'box', name: 'Wins', marker: { color: t.gain } },
          { y: losses, type: 'box', name: 'Losses', marker: { color: t.loss } },
        ], layout(t, { yaxis: { gridcolor: t.grid, tickformat: '$,.0f' } }), CONFIG);
      },
      'rv-longshort': function () {
        var t = theme(), by = { long: 0, short: 0 }, cnt = { long: 0, short: 0 };
        log.trades.forEach(function (tr) {
          var d = String(tr.direction || '').toLowerCase().indexOf('short') === 0 ? 'short' : 'long';
          by[d] += tr.pnl; cnt[d]++;
        });
        Plotly.newPlot('rv-longshort', [{
          x: ['Long (' + cnt.long + ')', 'Short (' + cnt.short + ')'],
          y: [by.long, by.short], type: 'bar',
          marker: { color: [by.long >= 0 ? t.gain : t.loss, by.short >= 0 ? t.gain : t.loss] },
          hovertemplate: '%{x}<br>%{y:$,.0f}<extra></extra>',
        }], layout(t, { yaxis: { gridcolor: t.grid, tickformat: '$,.0f' } }), CONFIG);
      },
      'rv-underwater': function () {
        var t = theme(), eq = 0, peak = 0, under = 0, runs = [];
        log.trades.forEach(function (tr) {
          eq += tr.pnl;
          if (eq >= peak) { peak = eq; if (under) { runs.push(under); under = 0; } }
          else under++;
        });
        if (under) runs.push(under);
        Plotly.newPlot('rv-underwater', [{
          x: runs.length ? runs : [0], type: 'histogram', marker: { color: t.loss },
          hovertemplate: '%{x} trades underwater<br>%{y} times<extra></extra>',
        }], layout(t, { xaxis: { gridcolor: t.grid } }), CONFIG);
      },
      'rv-recovery': function () {
        var t = theme(), eq = 0, peak = 0, since = null, gaps = [];
        log.trades.forEach(function (tr, i) {
          eq += tr.pnl;
          if (eq >= peak) {
            peak = eq;
            if (since !== null) { gaps.push(i - since); since = null; }
          } else if (since === null) since = i;
        });
        Plotly.newPlot('rv-recovery', [{
          x: gaps.length ? gaps : [0], type: 'histogram', marker: { color: t.accent },
          hovertemplate: 'Recovered in %{x} trades<br>%{y} times<extra></extra>',
        }], layout(t, { xaxis: { gridcolor: t.grid } }), CONFIG);
      },
      'rv-mcdd': function () {
        var t = theme();
        var res = E.runMonteCarlo(log.trades.map(function (tr) { return tr.pnl; }),
          { paths: 1000, blockSize: 5, seed: 42 });
        var dds = res.paths.map(function (path) {
          var peak = 0, dd = 0;
          path.forEach(function (v) { peak = Math.max(peak, v); dd = Math.min(dd, v - peak); });
          return dd;
        });
        Plotly.newPlot('rv-mcdd', [{
          x: dds, type: 'histogram', marker: { color: t.loss }, nbinsx: 36,
          hovertemplate: 'Max drawdown %{x:$,.0f}<br>%{y} paths<extra></extra>',
        }], layout(t, { xaxis: { gridcolor: t.grid, tickformat: '$,.0f' } }), CONFIG);
      },
      'rv-cdf': function () {
        var t = theme();
        var res = E.runMonteCarlo(log.trades.map(function (tr) { return tr.pnl; }),
          { paths: 1000, blockSize: 5, seed: 42 });
        var f = (res.terminals || []).slice().sort(function (a, b) { return a - b; });
        Plotly.newPlot('rv-cdf', [{
          x: f, y: f.map(function (_, i) { return 1 - i / f.length; }),
          type: 'scatter', mode: 'lines', line: { color: t.accent, width: 2 },
          hovertemplate: 'Terminal at least %{x:$,.0f}<br>P %{y:.1%}<extra></extra>',
        }], layout(t, { xaxis: { gridcolor: t.grid, tickformat: '$,.0f' },
                        yaxis: { gridcolor: t.grid, tickformat: '.0%' } }), CONFIG);
      },
      'rv-ruin': function () {
        var t = theme();
        var res = E.runMonteCarlo(log.trades.map(function (tr) { return tr.pnl; }),
          { paths: 1000, blockSize: 5, seed: 42 });
        var floor = -Math.abs(metrics.maxDrawdown);
        var steps = res.paths[0].length, curve = [];
        for (var i = 0; i < steps; i++) {
          var hit = 0;
          for (var p = 0; p < res.paths.length; p++) {
            for (var k = 0; k <= i; k++) {
              if (res.paths[p][k] <= floor) { hit++; break; }
            }
          }
          curve.push(hit / res.paths.length);
        }
        Plotly.newPlot('rv-ruin', [{
          y: curve, type: 'scatter', mode: 'lines', line: { color: t.loss, width: 2 },
          hovertemplate: 'By trade %{x}<br>%{y:.1%} of paths breached<extra></extra>',
        }], layout(t, { yaxis: { gridcolor: t.grid, tickformat: '.0%' } }), CONFIG);
      },
    };
    Object.keys(lib).forEach(function (k) { DEFERRED[k] = lib[k]; });
  }

  addLibrary();

  function drawDeferred(id) {
    if (drawn[id] || !DEFERRED[id] || !log) return;
    drawn[id] = true;
    try { DEFERRED[id](); }
    catch (err) { var el = $(id); if (el) el.innerHTML = '<p style="font-size:.78rem;color:var(--loss);padding:16px 0;">' + esc(err.message) + '</p>'; }
  }

  // ── tables ──────────────────────────────────────────────────────────
  function fillMetrics() {
    var m = metrics;
    var rows = [
      ['Net P&L', fmt0(m.netPnl), m.netPnl >= 0 ? 'pos' : 'neg'],
      ['Gross wins', fmt0(m.grossWins), ''],
      ['Gross losses', fmt0(-m.grossLosses), ''],
      ['Profit factor', m.profitFactor.toFixed(2), ''],
      ['Expectancy per trade', fmt0(m.expectancy), m.expectancy >= 0 ? 'pos' : 'neg'],
      ['R-expectancy', m.rExpectancy.toFixed(3), ''],
      ['Win rate', pct(m.winRate), ''],
      ['Trades', m.count + ' (' + m.winCount + 'W / ' + m.lossCount + 'L)', ''],
      ['Sharpe-like', m.sharpeLike.toFixed(2), ''],
      ['Standard deviation', fmt0(m.standardDeviation), ''],
      ['Max drawdown', fmt0(-m.maxDrawdown) + ' (' + pct(m.maxDrawdownPct) + ')', 'neg'],
      ['Best trade', fmt0(m.bestTrade), 'pos'],
      ['Worst trade', fmt0(m.worstTrade), 'neg'],
      ['Longest win streak', m.maxConsecutiveWins, ''],
      ['Longest loss streak', m.maxConsecutiveLosses, ''],
      ['Average hold', m.avgHoldMs ? (m.avgHoldMs / 3600000).toFixed(1) + ' h' : 'n/a', ''],
    ];
    $('rv-metrics').innerHTML = rows.map(function (r) {
      return '<tr><td>' + r[0] + '</td><td class="num ' + r[2] + '">' + r[1] + '</td></tr>';
    }).join('');
  }

  function fillTrades() {
    var rows = log.trades.map(function (tr, i) {
      var when = tr.date || tr.exitTime || tr.entryTime || tr.time;
      var d = when ? new Date(when) : null;
      return '<tr>'
        + '<td class="num">' + (i + 1) + '</td>'
        + '<td>' + (d && !isNaN(d) ? d.toLocaleDateString() : '-') + '</td>'
        + '<td>' + esc(tr.direction || tr.side || '-') + '</td>'
        + '<td class="num ' + (tr.pnl >= 0 ? 'pos' : 'neg') + '">' + fmt0(tr.pnl) + '</td>'
        + '</tr>';
    });
    $('rv-trades').innerHTML = rows.join('');
    $('rv-trades-count').textContent = log.trades.length + ' trades';
  }

  // ── run ─────────────────────────────────────────────────────────────
  function run(text, isSample) {
    var status = $('rv-status');
    try {
      log = E.buildTradeLog(text);
      metrics = E.computeMetrics(log);
    } catch (err) {
      status.className = 'rv-status err';
      status.textContent = err.message;
      return;
    }
    drawn = {};
    var g = grade(metrics);
    $('rv-grade-letter').textContent = g.letter;
    $('rv-grade-score').textContent = g.score + ' / 100';
    $('rv-verdict-line').textContent = g.line;
    $('rv-verdict-title').textContent = metrics.netPnl >= 0
      ? fmt0(metrics.netPnl) + ' over ' + metrics.count + ' trades'
      : fmt0(metrics.netPnl) + ' over ' + metrics.count + ' trades';

    var k = [
      ['Net P&L', fmt0(metrics.netPnl), metrics.netPnl >= 0 ? 'pos' : 'neg', metrics.count + ' trades'],
      ['Win rate', pct(metrics.winRate), '', metrics.winCount + 'W / ' + metrics.lossCount + 'L'],
      ['Profit factor', metrics.profitFactor.toFixed(2), '', 'gross ' + fmt0(metrics.grossWins) + ' / ' + fmt0(metrics.grossLosses)],
      ['Expectancy', fmt0(metrics.expectancy), metrics.expectancy >= 0 ? 'pos' : 'neg', 'per trade'],
      ['Sharpe-like', metrics.sharpeLike.toFixed(2), '', 'σ ' + fmt0(metrics.standardDeviation)],
      ['Max drawdown', fmt0(-metrics.maxDrawdown), 'neg', pct(metrics.maxDrawdownPct) + ' of peak'],
      ['Best / worst', fmt0(metrics.bestTrade) + ' / ' + fmt0(metrics.worstTrade), '', 'single trades'],
      ['Avg hold', metrics.avgHoldMs ? (metrics.avgHoldMs / 3600000).toFixed(1) + ' h' : 'n/a', '',
        'streak ' + metrics.maxConsecutiveWins + 'W / ' + metrics.maxConsecutiveLosses + 'L'],
    ];
    $('rv-kpis').innerHTML = k.map(function (x) {
      return '<div class="rv-kpi"><div class="rv-kpi-v ' + x[2] + '">' + x[1] + '</div>'
        + '<div class="rv-kpi-l">' + x[0] + '</div><div class="rv-kpi-s">' + x[3] + '</div></div>';
    }).join('');

    drawEquity();
    drawMonteCarlo();
    drawPropFirm();
    draw3D();
    drawRegimes();
    drawRisk();
    drawRobustness();
    drawHeatmap();
    fillMetrics();
    fillTrades();

    // re-draw any group the reader had already opened
    Object.keys(DEFERRED).forEach(function (id) {
      var host = $(id);
      if (host && host.closest('details') && host.closest('details').open) drawDeferred(id);
    });

    $('rv-sample-flag').hidden = !isSample;
    status.className = 'rv-status';
    status.textContent = 'Backtest complete: ' + metrics.count + ' trades'
      + (log.detected ? ' · detected ' + log.detected : '')
      + (log.ignored ? ' · ' + log.ignored + ' rows ignored' : '');

    // Fold the input away once there is a report to read; the summary line
    // keeps the source visible without the textarea owning the first screen.
    var data = $('rv-data');
    if (data) {
      data.open = false;
      $('rv-data-summary').textContent = (isSample ? 'Sample log' : 'Your log')
        + ' · ' + metrics.count + ' trades'
        + (log.detected ? ' · ' + String(log.detected).split(',')[0] : '');
    }
  }

  // ── wiring ──────────────────────────────────────────────────────────
  document.addEventListener('DOMContentLoaded', function () {
    var input = $('rv-csv');
    input.value = E.SAMPLE_TRADE_LOG;
    run(input.value, true);

    buildPropTabs();
    buildRegimeTabs();
    $('rv-run').addEventListener('click', function () { run(input.value, input.value === E.SAMPLE_TRADE_LOG); });
    $('rv-sample').addEventListener('click', function () { input.value = E.SAMPLE_TRADE_LOG; run(input.value, true); });
    $('rv-clear').addEventListener('click', function () { input.value = ''; $('rv-status').textContent = 'Paste a trade log and run it.'; });
    $('rv-file').addEventListener('change', function (e) {
      var file = e.target.files[0];
      if (!file) return;
      var reader = new FileReader();
      reader.onload = function () { input.value = String(reader.result); run(input.value, false); };
      reader.readAsText(file);
    });
    $('rv-use-own').addEventListener('click', function () {
      input.scrollIntoView({ behavior: 'smooth', block: 'center' });
      input.focus(); input.select();
    });

    document.querySelectorAll('details.rv-more').forEach(function (det) {
      det.addEventListener('toggle', function () {
        if (!det.open) return;
        det.querySelectorAll('[data-plot]').forEach(function (el) { drawDeferred(el.id); });
      });
    });

    // rail scrollspy
    var sections = [].slice.call(document.querySelectorAll('.rv-section'));
    var railLinks = {};
    document.querySelectorAll('.rv-rail a').forEach(function (a) { railLinks[a.getAttribute('href').slice(1)] = a; });
    var spy = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        Object.keys(railLinks).forEach(function (id) { railLinks[id].classList.toggle('on', id === en.target.id); });
      });
    }, { rootMargin: '-64px 0px -70% 0px' });
    sections.forEach(function (s) { spy.observe(s); });

    window.addEventListener('resize', function () {
      document.querySelectorAll('.rv-plot').forEach(function (el) {
        if (el.data && window.Plotly) Plotly.Plots.resize(el);
      });
    });
  });
})();
