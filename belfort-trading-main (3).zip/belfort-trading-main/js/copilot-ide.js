// In-browser Copilot IDE — Monaco (the real VS Code editor) over a virtual
// file system in localStorage, with a Run button that executes the Belfort
// backtester engine in the browser (JS) and Python via Pyodide. No GitHub,
// no codespace. This is the "VS Code actually" that works for every user.
(function () {
  'use strict';
  var E = window.BelfortEngine;
  var FS_KEY = 'quantpad-copilot-fs';
  var LANG = { js: 'javascript', mjs: 'javascript', cjs: 'javascript', ts: 'typescript', py: 'python', csv: 'plaintext', md: 'markdown', json: 'json', txt: 'plaintext', pine: 'typescript', html: 'html', htm: 'html', css: 'css', yml: 'yaml', yaml: 'yaml', sh: 'shell', sql: 'sql', rs: 'rust', go: 'go', java: 'java', c: 'c', cpp: 'cpp', cs: 'csharp', r: 'r', rb: 'ruby', php: 'php', swift: 'swift', kt: 'kotlin', scala: 'scala', lua: 'lua', dart: 'dart', ipynb: 'json' };
  function ext(name) { var i = name.lastIndexOf('.'); return i < 0 ? '' : name.slice(i + 1).toLowerCase(); }
  function lang(name) { return LANG[ext(name)] || 'plaintext'; }

  function starterFiles() {
    return {
      'backtest.js': [
        "// The Belfort backtester engine is injected as `BelfortEngine`.",
        "// Press ▶ Run - it runs the real engine in your browser.",
        "const E = BelfortEngine;",
        "const log = E.buildTradeLog(E.SAMPLE_TRADE_LOG);",
        "const m = E.computeMetrics(log);",
        "const mc = E.runMonteCarlo(m.returns, { paths: 500, blockSize: 1, seed: 42 });",
        "const pf = E.runPropFirmSimulation(log.trades, E.PROP_FIRM_PRESETS[0],",
        "  { runs: 300, seed: 42, strategyBaseline: 100000 });",
        "console.log('Trades:', m.count, '| Net P&L:', m.netPnl.toFixed(0),",
        "  '| Win rate:', (m.winRate * 100).toFixed(0) + '%',",
        "  '| Profit factor:', m.profitFactor.toFixed(2));",
        "console.log('Grade:', m.grade, '(' + m.gradeLabel + ')');",
        "console.log('Monte Carlo  p5/p50/p95:', mc.p5.toFixed(0), mc.p50.toFixed(0), mc.p95.toFixed(0));",
        "console.log('FTMO  pass rate:', pf.passRatePct.toFixed(0) + '%  EV $' + pf.expectedValue.toFixed(0));",
        "console.log('Edit the sample log in trades.csv, or load your own. See the Backtester for the full report.')"
      ].join('\n'),
      'analyze.py': [
        "# Python runs in your browser via Pyodide (numpy/pandas load on first Run).",
        "import numpy as np",
        "",
        "# Pull the per-trade P&L out of the bundled sample trade log:",
        "trades = [2400, -285, 690, 488, -3500, 885, -195, 672, 2300, -435, 608, 773,",
        "          -308, 536, 2200, -3500, 704, 2200, -263, 392, 2200, -3500, 760, 584]",
        "eq = np.array(trades).cumsum()",
        "peak = np.maximum.accumulate(eq)",
        "dd = peak - eq",
        "print(f'Trades: {len(trades)} | Net: {eq[-1]:.0f} | Win rate: {np.mean(np.array(trades) > 0) * 100:.0f}%')",
        "print(f'Max drawdown: {dd.max():.0f} | Sharpe-like: {np.mean(trades) / np.std(trades):.2f}')",
        "print('Edit me and Run - real Python, no server.')"
      ].join('\n'),
      'trades.csv': E ? E.SAMPLE_TRADE_LOG : 'Trade #,Type,Signal,Date/Time,Price,Qty,P&L,Cumulative P&L,Drawdown,Run-up,Cumulative P&L %,Buy & Hold %,Trade #',
      'README.md': [
        "# Belfort Copilot IDE",
        "",
        "A real VS Code editor (Monaco) running in your browser, with the Belfort",
        "backtester engine + a real Linux terminal (v86). Nothing leaves your machine.",
        "",
        "- **backtest.js** - runs the real engine on the sample log. Press **▶ Run**.",
        "- **analyze.py** - real Python (Pyodide, numpy). Press **▶ Run**.",
        "- **trades.csv** - the sample trade log. Replace it with your export.",
        "",
        "The backtester auto-detects the platform: TradingView, NinjaTrader,",
        "MultiCharts, MetaTrader, TradeStation - or any CSV with a P&L column",
        "(or entry/exit prices). Drop it into the Backtester, or paste it here.",
        "",
        "New files are saved in this browser (localStorage). No GitHub, no codespace."
      ].join('\n')
    };
  }

  function loadFS() {
    try {
      var f = JSON.parse(localStorage.getItem(FS_KEY) || 'null');
      if (f && Object.keys(f).length) return f;
    } catch (e) {}
    var s = starterFiles();
    localStorage.setItem(FS_KEY, JSON.stringify(s));
    return s;
  }
  function saveFS(fs) { localStorage.setItem(FS_KEY, JSON.stringify(fs)); }

  // ── Output ──
  var outEl = document.getElementById('ide-output');
  function out(text, cls) {
    var span = document.createElement('span');
    if (cls) span.className = cls;
    span.textContent = text + '\n';
    outEl.appendChild(span);
    outEl.scrollTop = outEl.scrollHeight;
  }
  document.getElementById('ide-clear').addEventListener('click', function () { outEl.innerHTML = ''; });

  // ── Run ──
  function fmt(v) {
    if (typeof v === 'string') return v;
    try { return JSON.stringify(v); } catch (e) { return String(v); }
  }
  function runJS(code) {
    var logs = [];
    var cap = function () { logs.push(Array.prototype.map.call(arguments, fmt).join(' ')); };
    var fakeConsole = { log: cap, info: cap, warn: cap, debug: cap, error: function () { logs.push('⚠ ' + Array.prototype.map.call(arguments, fmt).join(' ')); } };
    try {
      var fn = new Function('BelfortEngine', 'console', '"use strict";\n' + code);
      fn(window.BelfortEngine, fakeConsole);
      out(logs.join('\n') || '(no output)', logs.length ? 'ok' : 'info');
    } catch (e) {
      out(String(e.message || e), 'err');
    }
  }
  function loadScript(src) {
    return new Promise(function (resolve, reject) {
      var s = document.createElement('script'); s.src = src; s.onload = resolve; s.onerror = function () { reject(new Error('failed to load ' + src)); };
      document.head.appendChild(s);
    });
  }
  var pyLoading = null;
  function getPyodide() {
    if (window.pyodide) return Promise.resolve(window.pyodide);
    if (pyLoading) return pyLoading;
    pyLoading = loadScript('https://cdn.jsdelivr.net/pyodide/v0.27.2/full/pyodide.js').then(function () {
      return window.loadPyodide();
    }).then(function (py) {
      py.setStdout({ batched: function (s) { out(s); } });
      py.setStderr({ batched: function (s) { out(s, 'err'); } });
      return py;
    });
    return pyLoading;
  }
  function runPy(code) {
    out('Loading Pyodide (one-time, ~10 MB)…', 'info');
    getPyodide().then(function (py) {
      return py.loadPackagesFromImports(code).then(function () { return py.runPythonAsync(code); });
    }).then(function (r) {
      if (r !== undefined && r !== null) out(String(r), 'ok');
    }).catch(function (e) { out('Python error: ' + String(e.message || e), 'err'); });
  }
  document.getElementById('ide-run').addEventListener('click', function () {
    if (!active) return;
    out('$ run ' + active, 'info');
    var code = models[active].getValue();
    var e = ext(active);
    if (e === 'js' || e === 'mjs' || e === 'ts') runJS(code);
    else if (e === 'py') runPy(code);
    else out('Nothing to run for .' + e + ' files.', 'info');
  });

  // ── Explorer / tabs / editor ──
  var fs = loadFS();
  var models = {};      // name -> monaco.editor.ITextModel
  var active = null;
  var editor;

  function ensureModel(name) {
    if (models[name]) return models[name];
    var model = monaco.editor.createModel(fs[name] || '', lang(name), monaco.Uri.parse('inmemory://belfort/' + name));
    model.onDidChangeContent(function () { fs[name] = model.getValue(); saveFS(fs); });
    models[name] = model;
    return model;
  }
  function openFile(name) {
    ensureModel(name);
    active = name;
    editor.setModel(models[name]);
    renderExplorer(); renderTabs();
    updateStatus();
  }
  function closeTab(name) {
    if (models[name]) { models[name].dispose(); delete models[name]; }
    if (active === name) {
      var names = Object.keys(models);
      active = names.length ? names[names.length - 1] : null;
      if (active) editor.setModel(models[active]); else editor.setModel(monaco.editor.createModel('', 'plaintext'));
    }
    renderExplorer(); renderTabs();
  }
  function renderExplorer() {
    var host = document.getElementById('ide-explorer');
    host.innerHTML = '';
    Object.keys(fs).sort().forEach(function (name) {
      var d = document.createElement('div');
      d.className = 'ide-file ' + (ext(name) || 'txt') + (name === active ? ' active' : '');
      d.innerHTML = '<span class="dot"></span><span class="name"></span>';
      d.querySelector('.name').textContent = name;
      d.addEventListener('click', function () { openFile(name); });
      host.appendChild(d);
    });
  }
  function renderTabs() {
    var host = document.getElementById('ide-tabs');
    host.innerHTML = '';
    Object.keys(models).forEach(function (name) {
      var t = document.createElement('div');
      t.className = 'ide-tab' + (name === active ? ' active' : '');
      t.innerHTML = '<span></span><span class="x">×</span>';
      t.querySelector('span').textContent = name;
      t.addEventListener('click', function (e) { if (e.target.classList.contains('x')) { closeTab(name); } else { openFile(name); } });
      host.appendChild(t);
    });
  }
  document.getElementById('ide-new').addEventListener('click', function () {
    var name = prompt('File name (e.g. strategy.py):', 'strategy.py');
    if (!name) return;
    if (fs[name]) { openFile(name); return; }
    fs[name] = ''; saveFS(fs);
    openFile(name);
  });
  document.getElementById('ide-reset').addEventListener('click', function () {
    if (!confirm('Reset files to the Belfort starter set? Your changes will be lost.')) return;
    fs = starterFiles(); saveFS(fs);
    Object.keys(models).forEach(function (n) { models[n].dispose(); }); models = {};
    openFile(Object.keys(fs)[0]);
  });

  // ── Bottom panel: Output / Linux tabs ──
  var outBody = document.getElementById('ide-output');
  var linuxPanel = document.getElementById('ide-linux');
  function showTab(which) {
    if (which === 'linux') {
      outBody.classList.remove('show'); linuxPanel.classList.add('show');
      document.getElementById('otab-out').classList.remove('active');
      document.getElementById('otab-linux').classList.add('active');
      document.getElementById('linux-term').focus();
    } else {
      linuxPanel.classList.remove('show'); outBody.classList.add('show');
      document.getElementById('otab-linux').classList.remove('active');
      document.getElementById('otab-out').classList.add('active');
    }
  }
  outBody.classList.add('show');
  document.getElementById('otab-out').addEventListener('click', function () { showTab('out'); });
  document.getElementById('otab-linux').addEventListener('click', function () { showTab('linux'); });

  // ── Real Linux in the browser via v86 (vendored, BSD-2-Clause — no CheerpX) ──
  // Boots a Buildroot Linux kernel with a busybox shell on the serial console.
  var emu = null;
  var termEl = document.getElementById('linux-term');
  var statusEl = document.getElementById('linux-status');
  var termBuf = '';
  var booted = false;
  function termRender() {
    // Strip ANSI escape sequences for a clean text terminal.
    var clean = termBuf.replace(/\x1b\[[0-9;?]*[ -\/]*[@-~]|\x1b[=>]|\x1b\][^\x07]*\x07|\x08/g, '');
    if (clean.length > 65536) clean = clean.slice(-65536);
    termEl.textContent = clean;
    termEl.scrollTop = termEl.scrollHeight;
  }
  function termSend(s) { if (emu && emu.serial0_send) emu.serial0_send(s); }
  termEl.addEventListener('keydown', function (e) {
    if (!emu) { e.preventDefault(); return; }
    if (e.key === 'Enter') { termSend('\n'); e.preventDefault(); }
    else if (e.key === 'Backspace') { termSend('\x7f'); e.preventDefault(); }
    else if (e.key === 'Tab') { termSend('\t'); e.preventDefault(); }
    else if (e.key === 'Escape') { termSend('\x1b'); e.preventDefault(); }
    else if (e.ctrlKey && e.key.length === 1) { termSend(String.fromCharCode(e.key.charCodeAt(0) - 64)); e.preventDefault(); }
    else if (e.key.length === 1 && !e.ctrlKey && !e.altKey && !e.metaKey) { termSend(e.key); e.preventDefault(); }
  });
  document.getElementById('linux-start').addEventListener('click', function () {
    if (emu) { termEl.focus(); return; }
    statusEl.textContent = 'Loading the emulator (~2 MB)…';
    document.getElementById('sb-linux').textContent = 'Linux: loading';
    loadScript('/js/vendor/v86/libv86.js').then(function () {
      statusEl.textContent = 'Booting Linux (first boot takes ~20s)…';
      try {
        emu = new window.V86({
          wasm_path: '/js/vendor/v86/v86.wasm',
          bios: { url: '/js/vendor/v86/seabios.bin' },
          vga_bios: { url: '/js/vendor/v86/vgabios.bin' },
          bzimage: { url: '/js/vendor/v86/buildroot-bzimage68.bin', async: false },
          filesystem: {},
          cmdline: 'tsc=reliable mitigations=off random.trust_cpu=on',
          autostart: true,
          disable_keyboard: true
        });
      } catch (e) {
        statusEl.textContent = 'Failed to start v86: ' + (e.message || e);
        return;
      }
      emu.add_listener('serial0-output-byte', function (b) {
        var ch = String.fromCharCode(b);
        if (ch !== '\r') { termBuf += ch; termRender(); }
        if (!booted && /[#%\$] $|~% |\$ $/.test(termBuf.slice(-16))) {
          booted = true;
          statusEl.textContent = 'Linux ready - a real Buildroot shell. Type `uname -a` or `ls /`. Click the terminal and type.';
          document.getElementById('sb-linux').textContent = 'Linux: ready';
        }
      });
      termEl.focus();
    }).catch(function (e) { statusEl.textContent = 'Could not load v86: ' + (e.message || e); });
  });

  // ── Activity bar / sidebar views ──
  function showView(view) {
    ['explorer', 'search', 'run'].forEach(function (v) {
      document.getElementById('view-' + v).classList.toggle('show', v === view);
    });
    document.querySelectorAll('.ide-act[data-view]').forEach(function (b) {
      b.classList.toggle('active', b.getAttribute('data-view') === view);
    });
    document.getElementById('ide-view-head').textContent = view.charAt(0).toUpperCase() + view.slice(1);
    if (view === 'search') document.getElementById('ide-search-input').focus();
  }
  document.getElementById('ide-activitybar').addEventListener('click', function (e) {
    var b = e.target.closest('.ide-act'); if (!b) return;
    var v = b.getAttribute('data-view'), a = b.getAttribute('data-act');
    if (v) showView(v);
    else if (a === 'terminal') { showTab('linux'); document.getElementById('linux-term').focus(); }
    else if (a === 'settings') openPalette('commands');
  });

  // ── Status bar ──
  function updateStatus() {
    if (!active || !editor) return;
    var m = models[active];
    document.getElementById('sb-lang').textContent = (m && m.getLanguageId) ? m.getLanguageId() : lang(active);
    var p = editor.getPosition();
    if (p) document.getElementById('sb-cursor').textContent = 'Ln ' + p.lineNumber + ', Col ' + p.column;
  }

  // ── Command palette / quick open ──
  var palette = document.getElementById('ide-palette');
  var palInput = document.getElementById('ide-palette-input');
  var palList = document.getElementById('ide-palette-list');
  var palItems = [], palSel = 0;
  var commands = [
    { label: 'Run active file', run: function () { document.getElementById('ide-run').click(); } },
    { label: 'New file', run: function () { document.getElementById('ide-new').click(); } },
    { label: 'Reset to starter files', run: function () { document.getElementById('ide-reset').click(); } },
    { label: 'Start Linux (v86)', run: function () { showTab('linux'); document.getElementById('linux-start').click(); } },
    { label: 'Focus: Explorer', run: function () { showView('explorer'); } },
    { label: 'Focus: Search', run: function () { showView('search'); } },
    { label: 'Focus: Run', run: function () { showView('run'); } },
    { label: 'Open Copilot page', run: function () { window.location.href = '../quant-copilot/'; } }
  ];
  function openPalette(mode) {
    palInput.value = (mode === 'commands') ? '>' : '';
    palSel = 0; renderPalette();
    palInput.placeholder = (mode === 'commands') ? '> type a command' : 'Search files by name (Ctrl+P)';
    palette.classList.add('open');
    setTimeout(function () { palInput.focus(); palInput.select(); }, 0);
  }
  function closePalette() { palette.classList.remove('open'); }
  function renderPalette() {
    var q = palInput.value, isCmd = q[0] === '>', term = (isCmd ? q.slice(1) : q).trim().toLowerCase();
    palItems = isCmd
      ? commands.filter(function (c) { return !term || c.label.toLowerCase().indexOf(term) >= 0; }).map(function (c) { return { kind: 'cmd', label: c.label, run: c.run }; })
      : Object.keys(fs).filter(function (n) { return !term || n.toLowerCase().indexOf(term) >= 0; }).sort().map(function (n) { return { kind: 'file', label: n, run: function () { openFile(n); } }; });
    if (palSel >= palItems.length) palSel = palItems.length - 1;
    if (palSel < 0) palSel = 0;
    if (!palItems.length) { palList.innerHTML = '<div class="ide-palette-empty">No results.</div>'; return; }
    palList.innerHTML = palItems.slice(0, 30).map(function (it, i) {
      return '<div class="ide-palette-item' + (i === palSel ? ' active' : '') + '" data-i="' + i + '"><span class="kind">' + (it.kind === 'file' ? 'file' : it.kind) + '</span><span class="label"></span></div>';
    }).join('');
    Array.prototype.forEach.call(palList.querySelectorAll('.ide-palette-item'), function (el, i) { el.querySelector('.label').textContent = palItems[i].label; });
  }
  palInput.addEventListener('input', function () { palSel = 0; renderPalette(); });
  palInput.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { closePalette(); e.preventDefault(); }
    else if (e.key === 'ArrowDown') { palSel++; renderPalette(); e.preventDefault(); }
    else if (e.key === 'ArrowUp') { palSel--; renderPalette(); e.preventDefault(); }
    else if (e.key === 'Enter') { if (palItems[palSel]) palItems[palSel].run(); closePalette(); e.preventDefault(); }
  });
  palList.addEventListener('click', function (e) {
    var it = e.target.closest('.ide-palette-item'); if (!it) return;
    var i = parseInt(it.dataset.i, 10); if (palItems[i]) palItems[i].run(); closePalette();
  });
  palList.addEventListener('mousemove', function (e) {
    var it = e.target.closest('.ide-palette-item'); if (!it) return;
    var i = parseInt(it.dataset.i, 10); if (i !== palSel) { palSel = i; renderPalette(); }
  });
  palette.addEventListener('click', function (e) { if (e.target === palette) closePalette(); });
  // Global keybindings (capture phase so they beat Monaco's own Ctrl+P).
  document.addEventListener('keydown', function (e) {
    if (e.ctrlKey && e.shiftKey && (e.key === 'P' || e.key === 'p')) { e.preventDefault(); openPalette('commands'); }
    else if (e.ctrlKey && !e.shiftKey && !e.altKey && !e.metaKey && (e.key === 'p' || e.key === 'P')) { e.preventDefault(); openPalette('files'); }
    else if (e.ctrlKey && e.key === 'Enter') { e.preventDefault(); document.getElementById('ide-run').click(); }
  }, true);

  // ── Search across files ──
  function esc(s) { return String(s).replace(/[&<>]/g, function (c) { return c === '&' ? '&amp;' : c === '<' ? '&lt;' : '&gt;'; }); }
  var searchInput = document.getElementById('ide-search-input');
  var searchResults = document.getElementById('ide-search-results');
  function runSearch() {
    var q = searchInput.value.trim();
    if (!q) { searchResults.innerHTML = '<div class="ide-search-empty">Type to search all files.</div>'; return; }
    var hits = [];
    Object.keys(fs).forEach(function (name) {
      (fs[name] || '').split('\n').forEach(function (ln, i) {
        if (ln.toLowerCase().indexOf(q.toLowerCase()) >= 0) hits.push({ name: name, line: i + 1, text: ln });
      });
    });
    if (!hits.length) { searchResults.innerHTML = '<div class="ide-search-empty">No results.</div>'; return; }
    searchResults.innerHTML = hits.slice(0, 200).map(function (h) {
      var i = h.text.toLowerCase().indexOf(q.toLowerCase());
      return '<div class="ide-search-res" data-name="' + esc(h.name) + '" data-line="' + h.line + '"><div class="file">' + esc(h.name) + ':' + h.line + '</div><div class="line">' + esc(h.text.slice(0, i)) + '<mark>' + esc(h.text.slice(i, i + q.length)) + '</mark>' + esc(h.text.slice(i + q.length)) + '</div></div>';
    }).join('');
  }
  searchInput.addEventListener('input', runSearch);
  searchResults.addEventListener('click', function (e) {
    var r = e.target.closest('.ide-search-res'); if (!r) return;
    openFile(r.getAttribute('data-name'));
    var line = parseInt(r.getAttribute('data-line'), 10);
    if (editor && line) { editor.revealLineNearTop(line); editor.setPosition({ lineNumber: line, column: 1 }); editor.focus(); }
  });
  document.getElementById('sb-linux').addEventListener('click', function () { showTab('linux'); document.getElementById('linux-term').focus(); });

  // ── Boot Monaco ──
  // Configure language web workers for diagnostics
  window.MonacoEnvironment = window.MonacoEnvironment || {};
  window.MonacoEnvironment.getWorkerUrl = function (_, label) {
    var base = 'https://cdn.jsdelivr.net/npm/monaco-editor@0.52.2/min/vs';
    if (label === 'typescript' || label === 'javascript') return base + '/language/typescript/ts.worker.js';
    if (label === 'css' || label === 'scss' || label === 'less') return base + '/language/css/css.worker.js';
    if (label === 'html' || label === 'handlebars' || label === 'razor') return base + '/language/html/html.worker.js';
    if (label === 'json') return base + '/language/json/json.worker.js';
    return base + '/editor/editor.worker.js';
  };
  window.require.config({ paths: { vs: 'https://cdn.jsdelivr.net/npm/monaco-editor@0.52.2/min/vs' } });
  window.require(['vs/editor/editor.main'], function () {
    monaco.editor.defineTheme('belfort-dark', {
      base: 'vs-dark', inherit: true,
      colors: {
        'editor.background': '#0A0A0A',
        'editor.foreground': '#D4D4D4',
        'editorLineNumber.foreground': '#707070',
        'editorLineNumber.activeForeground': '#F2F2F2',
        'editorCursor.foreground': '#7c83ff',
        'editor.selectionBackground': '#264F78',
        'editor.lineHighlightBackground': '#111111',
        'editorWidget.background': '#111111',
        'editorWidget.border': '#222222',
        'editorGutter.background': '#0A0A0A',
        'editorError.foreground': '#F48771',
        'editorWarning.foreground': '#CCA700',
        'editorInfo.foreground': '#75BEFF',
      },
      rules: [
        { token: '', foreground: 'D4D4D4' },
        { token: 'comment', foreground: '6A9955', fontStyle: 'italic' },
        { token: 'keyword', foreground: '569CD6' },
        { token: 'string', foreground: 'CE9178' },
        { token: 'number', foreground: 'B5CEA8' },
        { token: 'type', foreground: '4EC9B0' },
        { token: 'function', foreground: 'DCDCAA' },
        { token: 'variable', foreground: '9CDCFE' },
      ]
    });
    // Enable TS/JS diagnostics
    var ts = monaco.languages.typescript;
    ts.typescriptDefaults.setCompilerOptions({
      target: ts.ScriptTarget.ES2020, module: ts.ModuleKind.ESNext,
      allowNonTsExtensions: true, noEmit: true, strict: true,
      noSemanticValidation: false, noSyntaxValidation: false,
    });
    ts.javascriptDefaults.setCompilerOptions({
      target: ts.ScriptTarget.ES2020, allowNonTsExtensions: true, noEmit: true,
      noSemanticValidation: false, noSyntaxValidation: false,
    });
    monaco.languages.json.jsonDefaults.setDiagnosticsOptions({ validate: true, allowComments: true });
    monaco.languages.css.cssDefaults.setDiagnosticsOptions({ validate: true });
    // Python syntax checker
    function checkPy(code) {
      var ms = [], lines = code.split('\n'), stack = [];
      for (var i = 0; i < lines.length; i++) {
        var l = lines[i], ln = i + 1, s = l.replace(/(#.*$)|('(?:[^'\\]|\\.)*')|("(?:[^"\\]|\\.)*")/g, '');
        for (var j = 0; j < s.length; j++) {
          var c = s[j];
          if (c === '(' || c === '[' || c === '{') stack.push({ c: c, ln: ln, col: j + 1 });
          if (c === ')' || c === ']' || c === '}') {
            if (!stack.length) ms.push({ startLineNumber: ln, startColumn: j + 1, endLineNumber: ln, endColumn: j + 2, message: 'Unexpected "' + c + '"', severity: monaco.MarkerSeverity.Error });
            else { var t = stack.pop(); if (!(c === ')' && t.c === '(' || c === ']' && t.c === '[' || c === '}' && t.c === '{')) ms.push({ startLineNumber: ln, startColumn: j + 1, endLineNumber: ln, endColumn: j + 2, message: 'Mismatched "' + c + '"', severity: monaco.MarkerSeverity.Error }); }
          }
        }
        var tr = l.trim();
        if (/^(def |class |if |elif |for |while |except |with )/.test(tr) && !tr.endsWith(':') && !tr.endsWith('\\')) ms.push({ startLineNumber: ln, startColumn: l.length, endLineNumber: ln, endColumn: l.length + 1, message: 'Expected ":"', severity: monaco.MarkerSeverity.Error });
        if (/^(else|try|finally)$/.test(tr) && !tr.endsWith(':')) ms.push({ startLineNumber: ln, startColumn: l.length, endLineNumber: ln, endColumn: l.length + 1, message: 'Expected ":"', severity: monaco.MarkerSeverity.Error });
      }
      while (stack.length) { var u = stack.pop(); ms.push({ startLineNumber: u.ln, startColumn: u.col, endLineNumber: u.ln, endColumn: u.col + 1, message: 'Unclosed "' + u.c + '"', severity: monaco.MarkerSeverity.Error }); }
      return ms;
    }
    editor = monaco.editor.create(document.getElementById('ide-editor'), {
      theme: 'belfort-dark', automaticLayout: true, fontSize: 13, fontFamily: 'IBM Plex Mono, Menlo, Monaco, Consolas, monospace',
      fontLigatures: true, minimap: { enabled: false }, scrollBeyondLastLine: false, tabSize: 2,
      bracketPairColorization: { enabled: true }, renderWhitespace: 'selection',
    });
    editor.onDidChangeModelContent(function () {
      var model = editor.getModel();
      if (model && model.getLanguageId() === 'python') monaco.editor.setModelMarkers(model, 'py-syntax', checkPy(model.getValue()));
    });
    editor.onDidChangeCursorPosition(updateStatus);
    openFile('backtest.js');
    updateStatus();
    out('Ready. Press ▶ Run (or Ctrl+Enter). ⌘P/Ctrl+P opens files, Ctrl+Shift+P commands.', 'info');
  });
})();
