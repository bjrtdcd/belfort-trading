// The homepage pricing block asks a backend for its tiers (`/api/pricing-tiers`),
// which does not exist on a static deploy — visitors saw "Unable to load pricing
// information" where the price should be. Until billing is wired up, render the
// plan statically so the section sells instead of erroring.
(function () {
  'use strict';

  var PLAN = {
    name: 'Belfort Trading',
    price: '$49',
    cadence: '/month',
    note: 'Launch price - fixed for as long as your subscription stays active.',
    features: [
      'Backtester: performance, Monte Carlo, prop-firm simulation, 3D risk surfaces',
      'Unlimited backtests - always free, no trade-log limits',
      'GitHub Codespaces workspaces on your own account',
      'Quant Copilot for strategy research and Pine/Python generation',
      'Community strategy library',
    ],
    cta: 'Get started',
    ctaHref: '/sign-up/',
    footnote: 'Backtesting stays free. The subscription covers market data and Copilot usage.',
  };

  function card() {
    var authed = !!localStorage.getItem('quantpad-authenticated');
    var el = document.createElement('div');
    el.className = 'static-pricing';
    var cta = authed ? 'Go to workspace' : PLAN.cta;
    var ctaHref = authed ? '/workspace/' : PLAN.ctaHref;
    el.innerHTML =
      '<div class="sp-card">'
      + '<div class="sp-head">'
      + '<div><div class="sp-name">' + PLAN.name + '</div>'
      + '<div class="sp-price">' + PLAN.price + '<span>' + PLAN.cadence + '</span></div></div>'
      + '<span class="sp-tag">Launch price</span>'
      + '</div>'
      + '<p class="sp-note">' + PLAN.note + '</p>'
      + '<ul class="sp-features">' + PLAN.features.map(function (f) { return '<li>' + f + '</li>'; }).join('') + '</ul>'
      + '<a class="sp-cta" href="' + ctaHref + '">' + cta + '</a>'
      + '<p class="sp-foot">' + PLAN.footnote + '</p>'
      + '</div>';
    return el;
  }

  function patch() {
    var nodes = document.querySelectorAll('body *');
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i];
      if (n.children.length || n.dataset.pricingPatched) continue;
      if (!/Unable to load pricing/i.test(n.textContent)) continue;
      var host = n.parentElement || n;
      host.dataset.pricingPatched = '1';
      host.innerHTML = '';
      host.appendChild(card());
      return;
    }
  }

  patch();
  window.addEventListener('load', patch);
  if (document.body) new MutationObserver(patch).observe(document.body, { childList: true, subtree: true });
})();
