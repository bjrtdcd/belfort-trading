// Global command palette (⌘K / Ctrl+K) — the cohesion layer across every
// route. Self-contained: injects its own stylesheet + overlay + a small
// floating trigger, so each page only adds this one <script> tag. Reads
// localStorage directly (no dependency on Codespaces) to build contextual
// actions: navigate, start a backtest, create a codespace, open the last
// codespace, subscribe, buy credits, connect GitHub, sign out.
(function () {
  'use strict';
  if (window.__cpInjected) return;
  window.__cpInjected = true;

  var CSS =
'.cpk-overlay{position:fixed;inset:0;z-index:300;background:rgba(0,0,0,.55);display:none;align-items:flex-start;justify-content:center;padding-top:12vh;backdrop-filter:blur(2px)}'
+ '.cpk-overlay.open{display:flex}'
+ '.cpk-box{width:100%;max-width:560px;background:rgb(20 20 22);border:1px solid #2b2b30;border-radius:14px;box-shadow:0 24px 60px rgba(0,0,0,.5);overflow:hidden}'
+ '.cpk-input{width:100%;box-sizing:border-box;padding:14px 16px;background:transparent;border:none;border-bottom:1px solid #2b2b30;color:#edeef0;font:600 15px/1 system-ui,sans-serif;outline:none}'
+ '.cpk-input::placeholder{color:#6b6d77;font-weight:400}'
+ '.cpk-list{max-height:52vh;overflow-y:auto;padding:6px}'
+ '.cpk-list::-webkit-scrollbar{width:8px}.cpk-list::-webkit-scrollbar-thumb{background:#2b2b30;border-radius:4px}'
+ '.cpk-item{display:flex;align-items:center;gap:12px;padding:9px 12px;border-radius:9px;cursor:pointer;color:#c8cad2;font-size:13px}'
+ '.cpk-item.active{background:rgba(124,131,255,.16);color:#fff}'
+ '.cpk-item .cpk-label{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}'
+ '.cpk-item .cpk-mark{color:var(--accent, #7c83ff);font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em}'
+ '.cpk-item .cpk-hint{color:#5a5c66;font-size:11px;font-family:monospace}'
+ '.cpk-empty{padding:22px;text-align:center;color:#6b6d77;font-size:13px}'
+ '.cpk-foot{display:flex;justify-content:space-between;padding:8px 14px;border-top:1px solid #2b2b30;color:#5a5c66;font-size:11px}'
+ '.cpk-kbd{font-family:monospace;background:#2b2b30;border-radius:4px;padding:1px 5px;color:#c8cad2}'
+ '.cpk-fab{position:fixed;right:18px;bottom:18px;z-index:290;display:inline-flex;align-items:center;gap:7px;padding:7px 11px;border:1px solid #2b2b30;border-radius:99px;background:rgba(20,20,22,.85);color:#c8cad2;font-size:12px;cursor:pointer;backdrop-filter:blur(4px);box-shadow:0 6px 18px rgba(0,0,0,.4)}'
+ '.cpk-fab:hover{color:#edeef0;border-color:var(--accent, #7c83ff)}'
+ '.cpk-fab .cpk-kbd{font-size:10px;padding:0 4px}'
+ '.cpk-hl{color:var(--accent, #7c83ff);font-weight:700}';

  function inject() {
    var style = document.createElement('style');
    style.id = 'cpk-style';
    style.textContent = CSS;
    document.head.appendChild(style);

    var overlay = document.createElement('div');
    overlay.className = 'cpk-overlay';
    overlay.id = 'cpk-overlay';
    overlay.innerHTML =
      '<div class="cpk-box"><input class="cpk-input" id="cpk-input" type="text" placeholder="Search Belfort Trading - pages, actions…" autocomplete="off" spellcheck="false">'
      + '<div class="cpk-list" id="cpk-list" role="listbox"></div>'
      + '<div class="cpk-foot"><span><span class="cpk-kbd">↑</span> <span class="cpk-kbd">↓</span> navigate · <span class="cpk-kbd">↵</span> select</span>'
      + '<span><span class="cpk-kbd">esc</span> close</span></div></div>';
    document.body.appendChild(overlay);

    var fab = document.createElement('button');
    fab.className = 'cpk-fab';
    fab.type = 'button';
    fab.id = 'cpk-fab';
    fab.innerHTML = 'Command <span class="cpk-kbd">⌘K</span>';
    document.body.appendChild(fab);

    wire();
  }

  function esc(s) { var d = document.createElement('div'); d.textContent = String(s == null ? '' : s); return d.innerHTML; }
  function highlight(text, idxs) {
    if (!idxs || !idxs.length) return esc(text);
    var out = '', i = 0;
    for (var t = 0; t < text.length; t++) {
      if (idxs.indexOf(t) >= 0) out += '<span class="cpk-hl">' + esc(text[t]) + '</span>';
      else out += esc(text[t]);
    }
    return out;
  }
  function fuzzy(query, text) {
    query = query.toLowerCase(); text = text.toLowerCase();
    if (!query) return { matched: true, score: 1, idxs: [] };
    var qi = 0, ti = 0, score = 0, prev = -2, idxs = [];
    while (qi < query.length && ti < text.length) {
      if (query[qi] === text[ti]) {
        idxs.push(ti);
        score += 1 + (ti === prev + 1 ? 5 : 0) + (ti === 0 ? 8 : 0);
        prev = ti; qi++;
      }
      ti++;
    }
    return qi === query.length ? { matched: true, score: score, idxs: idxs } : { matched: false };
  }

  function buildActions() {
    var authed = !!localStorage.getItem('quantpad-authenticated');
    var A = [];
    function nav(label, url, group, kw, opts) { A.push(Object.assign({ label: label, group: group, url: url, keywords: kw || '' }, opts || {})); }
    nav('Home', '/', 'Go to');
    nav('Backtester', '/strategy-validator/', 'Go to', 'strategy validator backtest import csv');
    nav('Projects', '/projects/', 'Go to', 'codespaces workspaces github');
    nav('Quant Copilot', '/quant-copilot/', 'Go to', 'copilot agent research chat');
    nav('Copilot IDE (in-browser VS Code)', '/copilot-ide/', 'Go to', 'vscode monaco editor run code backtest python');
    nav('Workspace', '/workspace/', 'Go to', 'account subscription balance github admin');
    nav('Social', '/social/', 'Go to', 'community library strategies');
    nav('New backtest', '/strategy-validator/', 'Do', 'run backtest import trade log');
    nav('See pricing / subscribe', '/subscribe/', 'Account', 'price plan pro team launch');
    if (authed) {
      nav('New project (codespace)', '/projects/#new', 'Do', 'create codespace github repository');
      nav('Quant Copilot: validate', '/quant-copilot/', 'Do', 'agent backtest sample verdict');
      nav('Subscribe / upgrade', '/workspace/#plan', 'Account', 'pricing pro team upgrade stripe');
      nav('Buy data credits', '/workspace/#balance', 'Account', 'top up credits purchase');
      nav('Connect GitHub', '/workspace/#github', 'Account', 'link token oauth codespace');
      var lastCs = null;
      try {
        var ws = JSON.parse(localStorage.getItem('quantpad-workspaces') || '[]');
        ws.forEach(function (w) { if (w.codespace && w.codespace.webUrl && (!lastCs || (w.codespace.createdAt || 0) > (lastCs.codespace.createdAt || 0))) lastCs = w; });
      } catch (e) {}
      if (lastCs) nav('Open last codespace', lastCs.codespace.webUrl, 'Do', 'github codespace open web', { external: true });
      A.push({ label: 'Sign out', group: 'Account', keywords: 'logout', run: function () { localStorage.removeItem('quantpad-authenticated'); localStorage.removeItem('quantpad-github'); location.href = '/'; } });
    } else {
      nav('Sign in', '/sign-in/', 'Account', 'login');
      nav('Create account', '/sign-up/?redirect_url=' + encodeURIComponent('/workspace/'), 'Account', 'register sign up');
    }
    return A;
  }

  var list = [], selected = 0, query = '';
  var overlay, input, listBox;

  function open() {
    list = buildActions();
    query = ''; selected = 0;
    input.value = ''; render();
    overlay.classList.add('open');
    setTimeout(function () { input.focus(); }, 0);
  }
  function close() { overlay.classList.remove('open'); }

  function render() {
    var scored = list.map(function (a) {
      var m = fuzzy(query, a.label + ' ' + a.group + ' ' + (a.keywords || ''));
      return { a: a, score: m.matched ? m.score : -1 };
    }).filter(function (x) { return x.score >= 0; }).sort(function (a, b) { return b.score - a.score; });
    if (selected >= scored.length) selected = scored.length - 1;
    if (selected < 0) selected = 0;
    if (!scored.length) { listBox.innerHTML = '<div class="cpk-empty">No matches.</div>'; return; }
    listBox.innerHTML = scored.slice(0, 30).map(function (x, i) {
      var a = x.a, active = i === selected;
      var m = fuzzy(query, a.label);
      var labelHtml = (m.matched && m.idxs.length) ? highlight(a.label, m.idxs) : esc(a.label);
      var mark = a.group === 'Do' ? '<span class="cpk-mark">Do</span>' : a.group === 'Account' ? '<span class="cpk-mark" style="color:#fbbf24">Account</span>' : '';
      var hint = a.external ? '↗' : (a.url && a.url.indexOf('#') >= 0 ? a.url.replace('#', ' · ') : '');
      return '<div class="cpk-item' + (active ? ' active' : '') + '" data-i="' + i + '" role="option">'
        + mark + '<span class="cpk-label">' + labelHtml + '</span>'
        + (hint ? '<span class="cpk-hint">' + esc(hint) + '</span>' : '')
        + '</div>';
    }).join('');
  }

  function activate(i) {
    var scored = list.map(function (a) { return { a: a, score: fuzzy(query, a.label + ' ' + a.group + ' ' + (a.keywords || '')).score }; }).filter(function (x) { return x.score >= 0; }).sort(function (a, b) { return b.score - a.score; });
    var a = scored[i] && scored[i].a;
    if (!a) return;
    close();
    if (a.run) a.run();
    else if (a.url) window.location.href = a.url;
  }

  function wire() {
    overlay = document.getElementById('cpk-overlay');
    input = document.getElementById('cpk-input');
    listBox = document.getElementById('cpk-list');
    document.getElementById('cpk-fab').addEventListener('click', open);
    overlay.addEventListener('click', function (e) { if (e.target === overlay) close(); });
    input.addEventListener('input', function () { query = input.value; selected = 0; render(); });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { close(); e.preventDefault(); }
      else if (e.key === 'ArrowDown') { selected++; clamp(); render(); e.preventDefault(); }
      else if (e.key === 'ArrowUp') { selected--; clamp(); render(); e.preventDefault(); }
      else if (e.key === 'Enter') { activate(selected); e.preventDefault(); }
    });
    listBox.addEventListener('click', function (e) {
      var it = e.target.closest('.cpk-item'); if (!it) return;
      activate(parseInt(it.dataset.i, 10));
    });
    listBox.addEventListener('mousemove', function (e) {
      var it = e.target.closest('.cpk-item'); if (!it) return;
      var i = parseInt(it.dataset.i, 10);
      if (i !== selected) { selected = i; render(); }
    });
    document.addEventListener('keydown', function (e) {
      if ((e.metaKey || e.ctrlKey) && (e.key === 'k' || e.key === 'K')) { e.preventDefault(); if (overlay.classList.contains('open')) close(); else open(); }
    });
  }
  function clamp() { selected = Math.max(0, Math.min(selected, 29)); }

  if (document.body) inject();
  else document.addEventListener('DOMContentLoaded', inject);
})();
