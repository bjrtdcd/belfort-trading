// ── Codespace creator + GitHub connect modal — shared UI ─────────────
// Mounts the "New workspace" creator modal and the "Connect GitHub"
// modal into any page that includes codespaces.js + config/github.js.
// Pages call CodespaceCreator.open(prefill) and .openConnect(); the
// creator calls window.Codespaces.createWorkspace directly and toasts
// the result. No markup duplication per page.
//
// Loaded synchronously in <head>, so window.CodespaceCreator is defined
// before inline page scripts run. DOM injection is deferred until the
// body exists (DOMContentLoaded or first open()), so appending to
// document.body from <head> is safe.
(function () {
  'use strict';
  if (!window.Codespaces) return;

  var C = window.Codespaces;
  var GH = C.GH;

  function esc(s) { var d = document.createElement('div'); d.textContent = String(s == null ? '' : s); return d.innerHTML; }

  var toastTimer;
  function toast(msg) {
    var el = document.getElementById('cc-toast');
    if (!el) {
      if (!document.body) return;
      el = document.createElement('div');
      el.className = 'ws-toast'; el.id = 'cc-toast';
      document.body.appendChild(el);
    }
    el.textContent = msg; el.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { el.classList.remove('show'); }, 2000);
  }

  var MODALS_HTML =
'<div class="ws-modal-bg" id="cc-ws-modal-bg"><div class="ws-modal" style="max-width:620px; max-height:88vh; overflow-y:auto;">'
+ '<div style="font-size:.92rem; font-weight:600; margin-bottom:4px;">New workspace</div>'
+ '<div style="font-size:.78rem; color:var(--color-text-tertiary); margin-bottom:18px;">Runs as a GitHub Codespace on your own account.</div>'
+ '<div class="ws-warn" id="cc-gh-warn" style="display:none;"><span>GitHub is not linked. Link it to run this workspace on your own Codespaces.</span><button class="ws-btn ws-btn-primary" id="cc-modal-connect-btn" style="flex-shrink:0;">Connect</button></div>'
+ '<div class="ws-grid2"><div class="ws-field"><label class="ws-field-label" for="cc-name-input">Name</label><input class="ws-input" type="text" id="cc-name-input" placeholder="Strategy name" maxlength="80"></div><div class="ws-field"><label class="ws-field-label" for="cc-desc-input">Description</label><input class="ws-input" type="text" id="cc-desc-input" placeholder="Optional" maxlength="140"></div></div>'
+ '<div class="ws-grid2"><div class="ws-field"><label class="ws-field-label" for="cc-repo-select">Repository</label><select class="ws-input" id="cc-repo-select"></select></div><div class="ws-field"><label class="ws-field-label" for="cc-branch-input">Branch</label><input class="ws-input" type="text" id="cc-branch-input" value="main" maxlength="80"></div></div>'
+ '<div class="gh-note" id="cc-repo-status" style="margin:-6px 0 12px;"></div>'
+ '<label id="cc-dc-row" style="display:none; align-items:center; gap:8px; font-size:.76rem; color:var(--color-text-secondary); margin-bottom:14px; cursor:pointer;"><input type="checkbox" id="cc-write-dc" style="accent-color:var(--ws-accent);">Commit <span style="font-family:monospace;">.devcontainer/devcontainer.json</span> with the image selected below</label>'
+ '<div class="ws-sub-label">Container image</div><div id="cc-image-list"></div>'
+ '<div class="ws-sub-label">Machine</div>'
+ '<div class="ws-grid3"><div class="ws-field"><label class="ws-field-label" for="cc-machine-select">Type</label><select class="ws-input" id="cc-machine-select"></select></div><div class="ws-field"><label class="ws-field-label" for="cc-region-select">Region</label><select class="ws-input" id="cc-region-select"></select></div><div class="ws-field"><label class="ws-field-label" for="cc-idle-select">Idle timeout</label><select class="ws-input" id="cc-idle-select"></select></div></div>'
+ '<label style="display:flex; align-items:center; gap:8px; font-size:.76rem; color:var(--color-text-secondary); margin-bottom:14px; cursor:pointer;"><input type="checkbox" id="cc-prebuild-check" checked style="accent-color:var(--ws-accent);">Use prebuild when available — skips the container build on first open</label>'
+ '<div class="ws-est" id="cc-cost"></div>'
+ '<div style="display:flex; justify-content:flex-end; gap:10px; margin-top:20px;"><button class="ws-btn ws-btn-ghost" id="cc-cancel-btn">Cancel</button><button class="ws-btn ws-btn-primary" id="cc-create-btn">Create workspace</button></div>'
+ '</div></div>'

+ '<div class="ws-modal-bg" id="cc-gh-modal-bg"><div class="ws-modal" style="max-width:500px;">'
+ '<div style="display:flex; align-items:center; gap:10px; margin-bottom:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 .5C5.7.5.5 5.7.5 12c0 5.1 3.3 9.4 7.8 10.9.6.1.8-.2.8-.6v-2c-3.2.7-3.9-1.5-3.9-1.5-.5-1.3-1.3-1.7-1.3-1.7-1-.7.1-.7.1-.7 1.1.1 1.7 1.2 1.7 1.2 1 1.8 2.7 1.3 3.4 1 .1-.8.4-1.3.7-1.6-2.6-.3-5.3-1.3-5.3-5.8 0-1.3.5-2.3 1.2-3.2-.1-.3-.5-1.5.1-3.1 0 0 1-.3 3.3 1.2a11.4 11.4 0 0 1 6 0c2.3-1.5 3.3-1.2 3.3-1.2.6 1.6.2 2.8.1 3.1.8.9 1.2 1.9 1.2 3.2 0 4.5-2.7 5.5-5.3 5.8.4.4.8 1.1.8 2.2v3.3c0 .4.2.7.8.6 4.5-1.5 7.8-5.8 7.8-10.9C23.5 5.7 18.3.5 12 .5z"/></svg><span style="font-size:.92rem; font-weight:600;">Connect GitHub</span></div>'
+ '<p style="font-size:.76rem; color:var(--color-text-tertiary); margin-bottom:16px; line-height:1.45;" id="cc-connect-org-line"></p>'
+ '<div id="cc-connect-oauth" style="display:none;"><p class="gh-note" style="margin-bottom:16px;">You will be sent to <span style="font-family:monospace;">github.com</span> to authorize Belfort Trading. Nothing happens until you approve it there.</p><button class="ws-btn ws-btn-primary" id="cc-oauth-go" style="width:100%;">Continue to GitHub</button></div>'
+ '<div id="cc-connect-pat" style="display:none;"><div class="ws-sub-label" style="margin-top:0;">1 · Create a token on GitHub</div><p class="gh-note" style="margin-bottom:10px;">Opens GitHub with the required scopes preselected: <span class="gh-scope">repo</span><span class="gh-scope">codespace</span><span class="gh-scope">read:org</span>.</p><a class="ws-btn ws-btn-ghost" id="cc-pat-open" href="#" target="_blank" rel="noopener" style="width:100%; margin-bottom:16px;">Open GitHub token page ↗</a><div class="ws-sub-label" style="margin-top:0;">2 · Paste it here</div><input class="ws-input" type="password" id="cc-token-input" placeholder="ghp_… or github_pat_…" autocomplete="off" spellcheck="false"><p class="gh-note" style="margin-top:8px;">Stored in this browser only; sent straight to <span style="font-family:monospace;">api.github.com</span>.</p><button class="ws-btn ws-btn-primary" id="cc-pat-go" style="width:100%; margin-top:14px;">Link account</button></div>'
+ '<div id="cc-connect-none" style="display:none;"><div class="ws-warn" style="margin-bottom:0;"><span>GitHub is not configured yet. An admin has to set it in the <a href="../workspace/" style="color:var(--ws-accent);">workspace Admin tab</a> (or <span style="font-family:monospace;">config/github.js</span>).</span></div></div>'
+ '<div style="display:flex; justify-content:flex-end; gap:10px; margin-top:20px;"><button class="ws-btn ws-btn-ghost" id="cc-gh-cancel-btn">Close</button></div>'
+ '</div></div>';

  // ── State ──
  var mounted = false;
  var mbg, ghModalBg;
  var selectedImage = (C.GH_IMAGES.find(function (i) { return i.available !== false; }) || C.GH_IMAGES[0]).id;
  var repoMachines = null, repoHasDevcontainer = null;
  var prefillTemplate = 'blank';

  function mount() {
    if (mounted) return;
    if (!document.body) return;          // not ready yet
    var host = document.createElement('div');
    host.innerHTML = MODALS_HTML;
    while (host.firstChild) document.body.appendChild(host.firstChild);
    mounted = true;
    mbg = document.getElementById('cc-ws-modal-bg');
    ghModalBg = document.getElementById('cc-gh-modal-bg');
    wireControls();
    handleOAuthReturn();
  }

  function renderImageOptions() {
    document.getElementById('cc-image-list').innerHTML = C.GH_IMAGES.map(function (img) {
      var off = img.available === false;
      var tag = img.badge ? '<span class="ws-tag ' + (off ? 'soon' : '') + '">' + esc(img.badge) + '</span>' : '';
      return '<div class="ws-opt ' + (selectedImage === img.id ? 'selected' : '') + ' ' + (off ? 'disabled' : '') + '" data-image="' + esc(img.id) + '">'
        + '<div class="ws-opt-radio"></div>'
        + '<div><div class="ws-opt-name">' + esc(img.name) + tag + '</div>'
        + '<div class="ws-opt-desc">' + esc(img.desc || '') + '</div>'
        + '<div class="ws-opt-ref">' + esc(img.ref) + '</div></div></div>';
    }).join('');
    document.querySelectorAll('#cc-image-list .ws-opt').forEach(function (el) {
      el.addEventListener('click', function () {
        if (el.classList.contains('disabled')) { toast('That image is not published yet'); return; }
        selectedImage = el.dataset.image; renderImageOptions(); updateCost();
      });
    });
  }

  function renderRepoSelect() {
    var sel = document.getElementById('cc-repo-select');
    var opts = ['<option value="">Select a repository…</option>'];
    C.getRepos().forEach(function (r) { opts.push('<option value="' + esc(r.full_name) + '" data-branch="' + esc(r.default_branch) + '">' + esc(r.full_name) + (r.private ? ' (private)' : '') + '</option>'); });
    sel.innerHTML = opts.join('');
    sel.disabled = !C.connected();
    document.getElementById('cc-gh-warn').style.display = C.connected() ? 'none' : 'flex';
  }

  function machineOptions() {
    var list = (repoMachines && repoMachines.length) ? repoMachines : C.GH_MACHINES;
    var sel = document.getElementById('cc-machine-select');
    var keep = sel.value;
    sel.innerHTML = list.map(function (m) { return '<option value="' + esc(m.id) + '">' + esc(m.name) + ' · ' + esc(m.memory) + ' RAM · ' + esc(m.storage) + '</option>'; }).join('');
    if (keep && list.some(function (m) { return m.id === keep; })) sel.value = keep;
    updateCost();
  }
  function machineLookup(id) { var list = (repoMachines && repoMachines.length) ? repoMachines : C.GH_MACHINES; return list.find(function (m) { return m.id === id; }) || list[0] || C.GH_MACHINES[0]; }

  function loadRepoDetails(fullName) {
    repoMachines = null; repoHasDevcontainer = null;
    var status = document.getElementById('cc-repo-status');
    var dcRow = document.getElementById('cc-dc-row');
    if (!fullName) { machineOptions(); dcRow.style.display = 'none'; status.textContent = C.live() ? 'Without a repository no codespace is created.' : ''; return; }
    if (!C.live()) { machineOptions(); dcRow.style.display = 'none'; status.textContent = ''; return; }
    status.textContent = 'Checking ' + fullName + ' on GitHub…';
    var branch = document.getElementById('cc-branch-input').value.trim() || 'main';
    var headers = { Accept: 'application/vnd.github+json', Authorization: 'Bearer ' + C.getAccount().token };
    fetch((GH.apiBase || 'https://api.github.com') + '/repos/' + fullName + '/codespaces/machines', { headers: headers }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    }).then(function (data) {
      repoMachines = (data.machines || []).map(function (m) { return { id: m.name, name: m.display_name || m.name, cpus: m.cpus, memory: Math.round(m.memory_in_bytes / 1073741824) + ' GB', storage: Math.round(m.storage_in_bytes / 1073741824) + ' GB', creditsPerHour: m.cpus }; });
    }).catch(function () { repoMachines = null; status.textContent = 'Could not read machine types from GitHub.'; }).then(function () {
      machineOptions();
      return fetch((GH.apiBase || 'https://api.github.com') + '/repos/' + fullName + '/contents/.devcontainer/devcontainer.json?ref=' + encodeURIComponent(branch), { headers: headers });
    }).then(function (rr) { repoHasDevcontainer = rr.ok ? true : (/404/.test(rr.status) ? false : null); })
      .catch(function () { repoHasDevcontainer = null; })
      .then(function () {
        dcRow.style.display = repoHasDevcontainer === false ? '' : 'none';
        document.getElementById('cc-write-dc').checked = repoHasDevcontainer === false;
        status.innerHTML = repoHasDevcontainer === true
          ? 'This repository already has <span style="font-family:monospace;">.devcontainer/devcontainer.json</span> — the codespace builds from it.'
          : repoHasDevcontainer === false
            ? 'No dev container in this repository. GitHub uses its default image unless Belfort Trading commits one.'
            : 'Repository reachable. Could not determine the dev container.';
      });
  }

  function updateCost() {
    var mach = machineLookup(document.getElementById('cc-machine-select').value);
    var img = C.imageById(selectedImage);
    document.getElementById('cc-cost').innerHTML =
      '<strong style="color:var(--color-text-primary);">' + esc(mach.name) + '</strong> · ' + mach.cpus + ' vCPU · ' + esc(mach.memory) + ' RAM · ' + esc(mach.storage) + ' storage'
      + (repoMachines ? ' <span style="color:#34d399;">· offered by GitHub for this repo</span>' : '')
      + '<br>Billed by GitHub against your Codespaces quota. The free tier covers 120 core-hours a month.<br>Image <span style="font-family:monospace;">' + esc(img.ref) + '</span> is used only if Belfort Trading writes <span style="font-family:monospace;">.devcontainer/devcontainer.json</span>.';
  }

  function open(prefill) {
    mount();
    prefill = prefill || {};
    prefillTemplate = prefill.template || 'blank';
    renderRepoSelect(); renderImageOptions();
    repoMachines = null; repoHasDevcontainer = null; machineOptions();
    document.getElementById('cc-name-input').value = prefill.name || '';
    document.getElementById('cc-desc-input').value = prefill.desc || '';
    document.getElementById('cc-branch-input').value = prefill.branch || 'main';
    if (prefill.repo) {
      var sel = document.getElementById('cc-repo-select');
      if ([].some.call(sel.options, function (o) { return o.value === prefill.repo; })) sel.value = prefill.repo;
      loadRepoDetails(prefill.repo);
    } else {
      loadRepoDetails('');
    }
    mbg.classList.add('open');
    document.getElementById('cc-name-input').focus();
  }

  function openConnect() {
    mount();
    var org = GH.org ? String(GH.org) : '';
    document.getElementById('cc-connect-org-line').textContent = org
      ? 'Linking gives Belfort Trading access to your repositories and codespaces in ' + org + '.'
      : 'Linking gives Belfort Trading access to your repositories and codespaces.';
    document.getElementById('cc-connect-oauth').style.display = C.oauthMode ? '' : 'none';
    document.getElementById('cc-connect-pat').style.display = (!C.oauthMode && C.patMode) ? '' : 'none';
    document.getElementById('cc-connect-none').style.display = (!C.oauthMode && !C.patMode) ? '' : 'none';
    var patLink = document.getElementById('cc-pat-open');
    if (patLink) patLink.href = 'https://github.com/settings/tokens/new?scopes=' + encodeURIComponent(C.GH_SCOPES.join(','))
      + '&description=' + encodeURIComponent('Belfort Trading Workspace' + (org ? ' - ' + org : ''));
    ghModalBg.classList.add('open');
    var ti = document.getElementById('cc-token-input');
    if (!C.oauthMode && C.patMode && ti) ti.focus();
  }

  function wireControls() {
    document.getElementById('cc-cancel-btn').addEventListener('click', function () { mbg.classList.remove('open'); });
    mbg.addEventListener('click', function (e) { if (e.target === mbg) mbg.classList.remove('open'); });
    document.getElementById('cc-modal-connect-btn').addEventListener('click', function () { mbg.classList.remove('open'); openConnect(); });
    document.getElementById('cc-region-select').innerHTML = C.GH_REGIONS.map(function (r) { return '<option value="' + esc(r.id) + '">' + esc(r.name) + '</option>'; }).join('');
    document.getElementById('cc-idle-select').innerHTML = C.GH_IDLE.map(function (t) { return '<option value="' + t + '">' + t + ' min</option>'; }).join('');
    document.getElementById('cc-idle-select').value = String(C.GH_IDLE[1] || C.GH_IDLE[0]);
    document.getElementById('cc-machine-select').addEventListener('change', updateCost);
    document.getElementById('cc-repo-select').addEventListener('change', function (e) {
      var opt = e.target.selectedOptions[0];
      if (opt && opt.dataset.branch) document.getElementById('cc-branch-input').value = opt.dataset.branch;
      var nameInput = document.getElementById('cc-name-input');
      if (!nameInput.value.trim() && e.target.value) nameInput.value = e.target.value.split('/')[1];
      loadRepoDetails(e.target.value);
    });
    document.getElementById('cc-branch-input').addEventListener('change', function () { loadRepoDetails(document.getElementById('cc-repo-select').value); });
    document.getElementById('cc-create-btn').addEventListener('click', function () {
      var n = document.getElementById('cc-name-input').value.trim();
      if (!n) { toast('Name required'); return; }
      if (!C.live()) { toast('Link your GitHub account first'); return; }
      if (!document.getElementById('cc-repo-select').value) { toast('Pick a repository - the codespace is built from it'); return; }
      mbg.classList.remove('open');
      toast('Creating codespace on GitHub…');
      C.createWorkspace({
        name: n,
        desc: document.getElementById('cc-desc-input').value.trim(),
        template: prefillTemplate,
        repo: document.getElementById('cc-repo-select').value,
        branch: document.getElementById('cc-branch-input').value.trim() || 'main',
        imageId: selectedImage,
        machineId: document.getElementById('cc-machine-select').value,
        region: document.getElementById('cc-region-select').value,
        idleTimeout: parseInt(document.getElementById('cc-idle-select').value, 10),
        prebuild: document.getElementById('cc-prebuild-check').checked,
        writeDevcontainer: repoHasDevcontainer === false && document.getElementById('cc-write-dc').checked,
        repoHasDevcontainer: repoHasDevcontainer === true,
      }).then(function () { document.getElementById('cc-name-input').value = ''; document.getElementById('cc-desc-input').value = ''; if (window.CodespaceCreator.onCreate) window.CodespaceCreator.onCreate(); })
        .catch(function (e) { toast(e.message); });
    });

    document.getElementById('cc-gh-cancel-btn').addEventListener('click', function () { ghModalBg.classList.remove('open'); });
    ghModalBg.addEventListener('click', function (e) { if (e.target === ghModalBg) ghModalBg.classList.remove('open'); });
    document.getElementById('cc-oauth-go').addEventListener('click', function () { C.startOAuth(); });
    document.getElementById('cc-pat-go').addEventListener('click', function () {
      var token = document.getElementById('cc-token-input').value.trim();
      if (!token) { toast('Paste a token first'); return; }
      toast('Verifying with GitHub…');
      C.linkWithToken(token, 'pat').then(function () {
        ghModalBg.classList.remove('open'); toast('GitHub connected as ' + C.getAccount().login);
        if (window.CodespaceCreator.onConnect) window.CodespaceCreator.onConnect();
      }).catch(function (e) { toast(e.message); });
    });
  }

  function handleOAuthReturn() {
    var p = new URLSearchParams(location.search);
    var code = p.get('code'), state = p.get('state');
    if (code && state && sessionStorage.getItem('quantpad-gh-state')) {
      history.replaceState(null, '', location.pathname);
      toast('Finishing GitHub sign-in…');
      C.finishOAuth(code, state).then(function () {
        toast('GitHub connected as ' + C.getAccount().login);
        if (window.CodespaceCreator.onConnect) window.CodespaceCreator.onConnect();
      }).catch(function (e) { toast(e.message); });
    }
  }

  window.CodespaceCreator = { open: open, openConnect: openConnect, toast: toast, mount: mount };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount);
  else mount();
})();
