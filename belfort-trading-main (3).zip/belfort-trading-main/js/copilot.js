// Quant Copilot — a deterministic, in-browser tool-use agent over the real
// backtester engine (backtester/engine.js → window.BelfortEngine). There is
// no LLM: it parses the user's intent with simple rules and calls the real
// engine tools (backtest / Monte Carlo / prop-firm / validate) on the working
// trade log. The working log + transcript persist in localStorage.
//
// Honesty: the page says plainly that this is not a chatbot — it runs real
// tool calls on your trade log. Nothing is invented; every number comes from
// the same engine the Strategy Validator uses.
(function () {
  'use strict';

  var E = window.BelfortEngine;
  var STORE_LOG = 'quantpad-copilot-log';
  var STORE_CHAT = 'quantpad-copilot-chat';

  function esc(s) { var d = document.createElement('div'); d.textContent = String(s == null ? '' : s); return d.innerHTML; }
  function num(n, d) { d = d == null ? 2 : d; if (!isFinite(n)) return ' - '; return Number(n).toLocaleString(undefined, { minimumFractionDigits: d, maximumFractionDigits: d }); }
  function money(n) { if (!isFinite(n)) return ' - '; return (n < 0 ? '-$' : '$') + Math.abs(n).toLocaleString(undefined, { maximumFractionDigits: 0 }); }
  function pct(n) { return num(n, 1) + '%'; }

  function Copilot(panel) {
    this.panel = panel;
    this.thread = panel.querySelector('#cp-thread');
    this.input = panel.querySelector('#cp-input');
    this.send = panel.querySelector('#cp-send');
    this.chips = panel.querySelector('#cp-chips');
    this.reset = panel.querySelector('#cp-reset');
    this.log = localStorage.getItem(STORE_LOG) || '';
    this.chat = [];
    try { this.chat = JSON.parse(localStorage.getItem(STORE_CHAT) || '[]'); } catch (e) { this.chat = []; }
    this.init();
  }

  Copilot.prototype.saveChat = function () { localStorage.setItem(STORE_CHAT, JSON.stringify(this.chat.slice(-40))); };
  Copilot.prototype.saveLog = function () { localStorage.setItem(STORE_LOG, this.log); };

  Copilot.prototype.init = function () {
    var self = this;
    if (!E) {
      this.render({ role: 'agent', html: '<div class="cp-card" style="color:#fb7185">The backtester engine failed to load. Reload the page — <code>backtester/engine.js</code> is required.</div>' });
      return;
    }
    // replay transcript
    this.chat.forEach(function (m) { self.render(m); });
    if (!this.chat.length) this.help(true);
    this.send.addEventListener('click', function () { self.submit(); });
    this.input.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); self.submit(); } });
    this.reset.addEventListener('click', function () {
      self.chat = []; self.saveChat(); self.thread.innerHTML = ''; self.help(true);
    });
    this.chips.addEventListener('click', function (e) {
      var c = e.target.closest('[data-cmd]'); if (!c) return;
      self.input.value = c.getAttribute('data-cmd'); self.submit();
    });
  };

  Copilot.prototype.render = function (m) {
    var row = document.createElement('div');
    row.className = 'cp-msg ' + (m.role === 'user' ? 'user' : 'agent');
    row.innerHTML = '<div class="cp-msg-role">' + (m.role === 'user' ? 'You' : 'Copilot') + '</div><div class="cp-bubble">' + m.html + '</div>';
    this.thread.appendChild(row);
    this.thread.scrollTop = this.thread.scrollHeight;
    return row;
  };

  Copilot.prototype.addUser = function (text) {
    var m = { role: 'user', html: esc(text) };
    this.chat.push(m); this.saveChat(); this.render(m);
  };
  Copilot.prototype.addAgent = function (html) {
    var m = { role: 'agent', html: html };
    this.chat.push(m); this.saveChat(); this.render(m);
    return this.thread.lastChild.querySelector('.cp-bubble');
  };
  Copilot.prototype.replaceLast = function (bubble, html) {
    var last = this.chat[this.chat.length - 1];
    if (last) { last.html = html; this.saveChat(); }
    bubble.innerHTML = html;
    this.thread.scrollTop = this.thread.scrollHeight;
  };

  Copilot.prototype.submit = function () {
    var text = (this.input.value || '').trim();
    if (!text) return;
    this.input.value = '';
    this.addUser(text);
    var plan = this.parse(text);
    this.run(plan);
  };

  // ── Intent parsing (deterministic; no LLM) ──
  Copilot.prototype.parse = function (text) {
    var lower = text.toLowerCase();
    var firstLine = text.split('\n')[0] || '';
    var looksCsv = /^Trade #,/im.test(text) || (/^[A-Za-z #].*,/.test(firstLine) && text.split('\n').length >= 4 && /type|price|p&l/i.test(firstLine));

    var then = null;
    if (looksCsv) {
      var after = text.slice(firstLine.length);
      then = this.detectTool(after || 'backtest') || { tool: 'backtest' };
      return { tool: 'import', log: text, then: then };
    }
    return this.detectTool(text) || { tool: 'help' };
  };

  Copilot.prototype.detectTool = function (text) {
    var t = text.toLowerCase();
    if (/sample|example|demo log|load log/.test(t)) return { tool: 'sample' };
    if (/validate|verdict|full report|grade my/.test(t)) return { tool: 'validate', paths: parsePaths(t, 1000), runs: parseRuns(t, 1000) };
    if (/monte carlo|monte-carlo|bootstrap|resample|paths/.test(t)) return { tool: 'mc', paths: parsePaths(t, 1000) };
    if (/prop firm|propfirm|ftmo|apex|topstep|e8|pass rate|evaluation/.test(t)) return { tool: 'prop', preset: detectPreset(t) };
    if (/backtest|analyze|analyse|metrics|performance|how.*did|grade/.test(t)) return { tool: 'backtest' };
    if (/help|what can you|tools|commands/.test(t)) return { tool: 'help' };
    return null;
  };

  function parsePaths(t, dflt) { var m = t.match(/(\d+)\s*(paths|path)/); if (m) return clamp(+m[1], 10, 5000); return dflt; }
  function parseRuns(t, dflt) { var m = t.match(/(\d+)\s*(runs|run|evals)/); if (m) return clamp(+m[1], 10, 10000); return dflt; }
  function clamp(n, lo, hi) { n = Math.floor(n); return Math.min(Math.max(n, lo), hi); }
  function detectPreset(t) {
    if (/ftmo\s*50/.test(t)) return 'FTMO 50k';
    if (/ftmo/.test(t)) return 'FTMO 100k';
    if (/apex/.test(t)) return 'Apex 100k';
    if (/topstep/.test(t)) return 'Topstep 50k';
    if (/e8/.test(t)) return 'E8 100k';
    return 'FTMO 100k';
  }

  // ── Execution ──
  Copilot.prototype.run = function (plan) {
    var self = this, bubble;
    if (plan.tool === 'import') {
      this.log = plan.log; this.saveLog();
      var trades = countTrades(plan.log);
      this.addAgent('<div class="cp-step">✓ Imported trade log — ' + trades + ' trades. Working log updated.</div>');
      plan = plan.then || { tool: 'backtest' };
    }
    bubble = this.addAgent('<div class="cp-step"><span class="cp-spin"></span> Calling tool <code>' + esc(plan.tool) + '</code>…</div>');
    setTimeout(function () { self.execute(plan, bubble); }, 40);
  };

  Copilot.prototype.execute = function (plan, bubble) {
    var html;
    try {
      if (plan.tool === 'sample') html = this.toolSample();
      else if (plan.tool === 'backtest') html = this.toolBacktest();
      else if (plan.tool === 'mc') html = this.toolMc(plan.paths);
      else if (plan.tool === 'prop') html = this.toolProp(plan.preset, 1000);
      else if (plan.tool === 'validate') html = this.toolValidate(plan.paths, plan.runs);
      else if (plan.tool === 'help') html = this.helpHtml();
      else html = this.helpHtml();
    } catch (e) {
      html = '<div class="cp-card" style="color:#fb7185">' + esc(e.message || String(e)) + '</div>';
    }
    this.replaceLast(bubble, html);
  };

  Copilot.prototype.needLog = function () {
    return '<div class="cp-card">No trade log loaded. Paste a TradingView "List of Trades" export, or say <code>load sample</code>.</div>';
  };

  Copilot.prototype.toolSample = function () {
    this.log = E.SAMPLE_TRADE_LOG; this.saveLog();
    var m = E.computeMetrics(E.buildTradeLog(this.log));
    return '<div class="cp-step">✓ Loaded the bundled sample trade log — ' + m.count + ' trades, net ' + money(m.netPnl) + '.</div>'
      + '<div class="cp-card"><div class="cp-card-title">Working log ready</div>'
      + '<div class="cp-row"><span>Trades</span><span>' + m.count + '</span></div>'
      + '<div class="cp-row"><span>Net P&L</span><span>' + money(m.netPnl) + '</span></div>'
      + '<div class="cp-row"><span>Grade</span><span>' + esc(m.grade) + ' - ' + esc(m.gradeLabel) + '</span></div>'
      + '<a class="cp-link" href="#" data-cmd="validate">Now run the full verdict →</a></div>';
  };

  Copilot.prototype.toolBacktest = function () {
    if (!this.log) return this.needLog();
    var m = E.computeMetrics(E.buildTradeLog(this.log));
    var advice = m.gradeAdvice.slice(0, 3).map(function (a) { return '<li>' + esc(a) + '</li>'; }).join('');
    return '<div class="cp-step">✓ <code>backtest</code> — ' + m.count + ' trades</div>' + backtestCard(m) + adviceBlock(advice)
      + '<a class="cp-link" href="../strategy-validator/">Open the full report in the Backtester →</a>';
  };

  Copilot.prototype.toolMc = function (paths) {
    if (!this.log) return this.needLog();
    var m = E.computeMetrics(E.buildTradeLog(this.log));
    var mc = E.runMonteCarlo(m.returns, { paths: paths, blockSize: 1, seed: E.hashSeed(m.returns) });
    return '<div class="cp-step">✓ <code>monte_carlo</code> — ' + mc.config.paths + ' paths</div>' + mcCard(mc);
  };

  Copilot.prototype.toolProp = function (preset, runs) {
    if (!this.log) return this.needLog();
    var log = E.buildTradeLog(this.log);
    var p = E.PROP_FIRM_PRESETS.find(function (x) { return x.name === preset; }) || E.PROP_FIRM_PRESETS[0];
    var pf = E.runPropFirmSimulation(log.trades, p, { runs: runs, seed: E.hashSeed(log.trades.map(function (t) { return t.pnl; })), strategyBaseline: p.accountSize });
    return '<div class="cp-step">✓ <code>prop_firm_sim</code> — ' + p.name + ', ' + pf.runs + ' runs</div>' + propCard(pf);
  };

  Copilot.prototype.toolValidate = function (paths, runs) {
    if (!this.log) return this.needLog();
    var log = E.buildTradeLog(this.log);
    var m = E.computeMetrics(log);
    var mc = E.runMonteCarlo(m.returns, { paths: paths, blockSize: 1, seed: E.hashSeed(m.returns) });
    var p = E.PROP_FIRM_PRESETS[0];
    var pf = E.runPropFirmSimulation(log.trades, p, { runs: runs, seed: mc.config.seed, strategyBaseline: p.accountSize });
    var advice = m.gradeAdvice.slice(0, 4).map(function (a) { return '<li>' + esc(a) + '</li>'; }).join('');
    return '<div class="cp-step">✓ <code>validate</code> — full verdict</div>'
      + '<div class="cp-card"><div class="cp-card-head"><div class="cp-card-title">Verdict</div>'
      + '<span class="ws-ws-badge grade-' + esc(m.grade) + '" style="font-size:.7rem;padding:3px 9px;">' + esc(m.grade) + ' · ' + esc(m.gradeLabel) + '</span></div>'
      + '<div class="cp-grid">' + stat(m.netPnl, 'Net P&L', money) + stat(m.winRate * 100, 'Win rate', pct) + stat(m.profitFactor, 'Profit factor', num, 2) + stat(m.sharpeLike, 'Sharpe-like', num, 2) + '</div></div>'
      + backtestCard(m) + mcCard(mc) + propCard(pf) + adviceBlock(advice)
      + '<a class="cp-link" href="../strategy-validator/">Open the full interactive report →</a>';
  };

  Copilot.prototype.help = function (silent) {
    var html = this.helpHtml();
    if (silent) { this.chat.push({ role: 'agent', html: html }); this.saveChat(); this.render({ role: 'agent', html: html }); }
    else this.addAgent(html);
  };
  Copilot.prototype.helpHtml = function () {
    return '<div class="cp-card"><div class="cp-card-title">Quant Copilot — real tools, no chatbot</div>'
      + '<div style="font-size:.8rem;color:var(--color-text-secondary);line-height:1.55;margin-bottom:10px;">'
      + 'I run the same backtester engine the Strategy Validator uses, on your trade log. There is no language model — every number is computed from your rows. Paste a TradingView "List of Trades" export, or start from the sample.</div>'
      + '<div class="cp-row"><span><code>load sample</code></span><span>use the bundled 24-trade log</span></div>'
      + '<div class="cp-row"><span><code>backtest</code></span><span>metrics + Verdict grade</span></div>'
      + '<div class="cp-row"><span><code>monte carlo 1000 paths</code></span><span>bootstrap percentiles</span></div>'
      + '<div class="cp-row"><span><code>simulate FTMO</code></span><span>prop-firm pass rate + EV</span></div>'
      + '<div class="cp-row"><span><code>validate</code></span><span>full verdict in one call</span></div>'
      + '<div class="cp-row"><span><i>paste a CSV</i></span><span>imports it, then backtests</span></div></div>';
  };

  function countTrades(csv) { try { return E.buildTradeLog(csv).trades.length; } catch (e) { return 0; } }

  // ── Result cards ──
  function stat(v, label, fmt, d) { return '<div class="cp-stat"><div class="cp-stat-v">' + (fmt ? fmt(v, d) : esc(v)) + '</div><div class="cp-stat-l">' + esc(label) + '</div></div>'; }
  function backtestCard(m) {
    return '<div class="cp-card" style="margin-top:8px;"><div class="cp-card-head"><div class="cp-card-title">Performance</div>'
      + '<span class="ws-ws-badge grade-' + esc(m.grade) + '" style="font-size:.7rem;padding:3px 9px;">' + esc(m.grade) + ' · ' + esc(m.gradeLabel) + '</span></div>'
      + '<div class="cp-grid">'
      + stat(m.netPnl, 'Net P&L', money) + stat(m.winRate * 100, 'Win rate', pct) + stat(m.profitFactor, 'Profit factor', num, 2)
      + stat(m.sharpeLike, 'Sharpe-like', num, 2) + stat(m.maxDrawdownPct, 'Max drawdown', pct) + stat(m.expectancy, 'Expectancy', money)
      + '</div></div>';
  }
  function mcCard(mc) {
    return '<div class="cp-card" style="margin-top:8px;"><div class="cp-card-title">Monte Carlo</div><div class="cp-grid">'
      + stat(mc.p5, '5th pct', money) + stat(mc.p50, 'Median', money) + stat(mc.p95, '95th pct', money)
      + stat(mc.positivePathsPct * 100, 'Positive paths', pct) + stat(mc.riskOfRuinPct, 'Risk of ruin', pct)
      + '</div></div>';
  }
  function propCard(pf) {
    var fails = pf.failures.map(function (f) {
      return '<div class="cp-fail"><span style="width:150px;">' + esc(f.reason) + '</span>'
        + '<div class="cp-fail-bar"><div class="cp-fill" style="width:' + Math.min(100, f.pct) + '%;"></div></div>'
        + '<span style="width:46px;text-align:right;">' + pct(f.pct) + '</span></div>';
    }).join('');
    return '<div class="cp-card" style="margin-top:8px;"><div class="cp-card-head"><div class="cp-card-title">Prop firm · ' + esc(pf.config.name) + '</div></div><div class="cp-grid">'
      + stat(pf.passRatePct, 'Pass rate', pct) + stat(pf.expectedValue, 'Expected value', money)
      + stat(pf.averageDaysToTarget == null ? 0 : pf.averageDaysToTarget, 'Avg days', num, 0) + stat(pf.payoutProbabilityPct, 'Payout prob.', pct)
      + '</div>' + (fails ? '<div style="margin-top:8px;">' + fails + '</div>' : '') + '</div>';
  }
  function adviceBlock(html) { return html ? '<div class="cp-advice"><b>What to fix</b><ul>' + html + '</ul></div>' : ''; }

  window.Copilot = Copilot;
})();
