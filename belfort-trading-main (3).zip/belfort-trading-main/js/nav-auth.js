// Every page except the workspace rendered a static "Sign In" link, even for a
// signed-in visitor. This swaps that link for the account menu once a session
// exists, and keeps working after the homepage's React bundle re-renders.
(function () {
  'use strict';

  var KEY = 'quantpad-authenticated';

  function prettyName(email) {
    return email.split('@')[0].replace(/[._-]/g, ' ').replace(/\b\w/g, function (c) { return c.toUpperCase(); });
  }

  function build(email, base, cls) {
    var name = localStorage.getItem('quantpad-display-name') || prettyName(email);
    var initials = name.split(' ').map(function (w) { return w[0] || ''; }).slice(0, 2).join('').toUpperCase();

    var wrap = document.createElement('div');
    wrap.className = 'nav-account relative';
    wrap.style.position = 'relative';

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = cls;
    btn.style.cssText = 'display:flex;align-items:center;gap:8px;background:none;border:0;cursor:pointer;';
    btn.innerHTML = '<span style="display:flex;height:28px;width:28px;align-items:center;justify-content:center;'
      + 'border-radius:9999px;background:var(--accent-soft, rgba(124,131,255,.14));font-size:11px;font-weight:700;color:var(--accent, #7c83ff);">'
      + initials + '</span><span class="hidden sm:inline">' + name + '</span>';

    var menu = document.createElement('div');
    menu.style.cssText = 'position:absolute;right:0;top:100%;margin-top:8px;display:none;min-width:190px;'
      + 'border:1px solid var(--color-border-primary,#2b2b2b);border-radius:10px;background:rgb(var(--color-bg-secondary,17 17 19));'
      + 'box-shadow:0 12px 30px rgba(0,0,0,.45);z-index:60;overflow:hidden;';
    menu.innerHTML =
      '<div style="padding:10px 14px;border-bottom:1px solid var(--color-border-primary,#2b2b2b);">'
      + '<div style="font-size:11px;color:var(--color-text-tertiary,#9d9d9d);">Signed in as</div>'
      + '<div style="font-size:12.5px;font-weight:500;overflow:hidden;text-overflow:ellipsis;">' + email + '</div></div>'
      + '<a href="' + base + 'workspace/" style="display:block;padding:9px 14px;font-size:13px;text-decoration:none;color:inherit;">Workspace</a>'
      + '<a href="' + base + 'strategy-validator/" style="display:block;padding:9px 14px;font-size:13px;text-decoration:none;color:inherit;">Backtester</a>'
      + '<button type="button" data-signout style="display:block;width:100%;padding:9px 14px;text-align:left;font-size:13px;background:none;border:0;color:var(--color-text-secondary, #A3A3A3);cursor:pointer;">Sign out</button>';

    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
    });
    document.addEventListener('click', function () { menu.style.display = 'none'; });
    menu.querySelector('[data-signout]').addEventListener('click', function () {
      localStorage.removeItem(KEY);
      location.reload();
    });

    wrap.appendChild(btn);
    wrap.appendChild(menu);
    return wrap;
  }

  function patch() {
    var email = localStorage.getItem(KEY);
    if (!email) return;
    var links = document.querySelectorAll('a[href$="/sign-in"], a[href$="/sign-in/"], a[href$="sign-in/"]');
    for (var i = 0; i < links.length; i++) {
      var a = links[i];
      if (!/sign\s*in/i.test(a.textContent)) continue;
      if (a.closest('.nav-account')) continue;
      // "../" for nested routes, "/" for the homepage.
      var base = a.getAttribute('href').indexOf('../') === 0 ? '../' : '/';
      a.parentNode.replaceChild(build(email, base, a.className), a);
    }
  }

  // Signed out, every route should offer the same pair the homepage does:
  // a quiet "Sign in" next to the primary call to action.
  function addCta() {
    if (localStorage.getItem(KEY)) return;
    var links = document.querySelectorAll('a[href$="/sign-in"], a[href$="/sign-in/"], a[href$="sign-in/"]');
    for (var i = 0; i < links.length; i++) {
      var a = links[i];
      if (!/sign\s*in/i.test(a.textContent)) continue;
      if (a.dataset.ctaPaired) continue;
      // The homepage ships its own call to action; only pages without one
      // need the pair injected, or the row ends up with two of them.
      var scope = a.closest('nav, header') || document;
      if (scope.querySelector('a[href$="sign-up/"], a[href$="/sign-up"]')) { a.dataset.ctaPaired = '1'; continue; }
      var base = a.getAttribute('href').indexOf('../') === 0 ? '../' : '/';
      a.dataset.ctaPaired = '1';
      a.className = 'nav-signin-link';
      a.textContent = 'Sign in';
      var cta = document.createElement('a');
      cta.className = 'nav-cta';
      cta.href = base + 'sign-up/';
      cta.textContent = 'Entry platform';
      a.insertAdjacentElement('afterend', cta);
    }
  }

  function run() { patch(); addCta(); }

  run();
  window.addEventListener('load', run);
  if (document.body) new MutationObserver(run).observe(document.body, { childList: true, subtree: true });
})();
