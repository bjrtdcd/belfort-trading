// The homepage nav is rendered by the scraped Next.js bundle, so edits to the
// static markup are wiped on hydration. Re-apply them after every render:
// unify the label to "Backtester" and add the Workspace route.
(function () {
  'use strict';

  function patchScope(scope) {
    var links = scope.querySelectorAll('a[href^="/strategy-validator"]');
    for (var i = 0; i < links.length; i++) {
      var sv = links[i];
      if (sv.textContent.trim() === 'Strategy Validator') sv.textContent = 'Backtester';
      var row = sv.parentElement;
      if (!row || row.querySelector('a[href="/workspace/"]')) continue;
      var link = document.createElement('a');
      link.className = sv.className;
      link.href = '/workspace/';
      link.textContent = 'Workspace';
      sv.insertAdjacentElement('afterend', link);
    }
  }

  // The footer product column has no Backtester link; anchor on Social instead.
  function patchFooter(scope) {
    if (scope.querySelector('a[href="/workspace/"]')) return;
    var social = scope.querySelector('a[href^="/social"]');
    if (!social) return;
    var link = document.createElement('a');
    link.className = social.className;
    link.href = '/workspace/';
    link.textContent = 'Workspace';
    social.insertAdjacentElement('afterend', link);
  }

  function patch() {
    var scopes = document.querySelectorAll('nav, footer');
    for (var i = 0; i < scopes.length; i++) {
      patchScope(scopes[i]);
      if (scopes[i].tagName === 'FOOTER') patchFooter(scopes[i]);
    }
  }

  patch();
  window.addEventListener('load', patch);
  if (document.body) new MutationObserver(patch).observe(document.body, { childList: true, subtree: true });
})();
