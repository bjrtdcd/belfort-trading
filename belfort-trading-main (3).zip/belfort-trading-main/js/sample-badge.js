// The report auto-runs on a bundled sample log when the page opens, with
// nothing on screen saying so — a first-time visitor can read those metrics as
// their own results. This marks the report as sample data until a real log is
// loaded, and clears itself the moment the input changes.
(function () {
  'use strict';

  var sampleCsv = null;

  function makeBadge() {
    var el = document.createElement('div');
    el.id = 'sample-banner';
    el.innerHTML =
      '<span class="sample-dot"></span>'
      + '<div><strong>Sample data</strong> - this report is generated from a bundled example trade log, '
      + 'not from your trading. Paste or upload your own log and run it to replace every number below.</div>'
      + '<button type="button" class="sample-cta">Use my own log</button>';
    el.querySelector('.sample-cta').addEventListener('click', function () {
      var input = document.getElementById('csv-input') || document.querySelector('textarea');
      if (!input) return;
      input.scrollIntoView({ behavior: 'smooth', block: 'center' });
      input.focus();
      input.select();
    });
    return el;
  }

  function sync() {
    var report = document.getElementById('report');
    var input = document.getElementById('csv-input') || document.querySelector('textarea');
    if (!report || !input) return;
    if (sampleCsv === null) sampleCsv = input.value;      // whatever the page auto-ran with
    var isSample = input.value.trim() === (sampleCsv || '').trim();
    var badge = document.getElementById('sample-banner');
    if (isSample && report.classList.contains('visible')) {
      if (!badge) report.insertBefore(makeBadge(), report.firstChild);
    } else if (badge) {
      badge.remove();
    }
  }

  function boot() {
    sync();
    var input = document.getElementById('csv-input') || document.querySelector('textarea');
    if (input) input.addEventListener('input', sync);
    var file = document.querySelector('input[type="file"]');
    if (file) file.addEventListener('change', function () { setTimeout(sync, 600); });
    ['run-button', 'sample-button', 'clear-button'].forEach(function (id) {
      var b = document.getElementById(id);
      if (b) b.addEventListener('click', function () { setTimeout(sync, 400); });
    });
    var report = document.getElementById('report');
    if (report) new MutationObserver(function () { setTimeout(sync, 100); }).observe(report, { attributes: true, attributeFilter: ['class'] });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { setTimeout(boot, 700); });
  else setTimeout(boot, 700);
})();
