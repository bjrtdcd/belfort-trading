# Strategy Validator Implementation Plan

> **For agentic workers:** Implement this plan task-by-task with verification after each focused change.

**Goal:** Add a dedicated client-side Strategy Validator page for trade-log CSV files and link it from the Belfort Trading homepage/navigation.

**Architecture:** Create one self-contained static route at `strategy-validator/index.html`. The route reuses the existing Belfort Trading CSS, parses CSV in the browser, computes performance/risk/Monte Carlo metrics, and renders accessible charts with inline SVG/CSS. Modify the homepage and key navigation pages only to expose the route.

**Tech Stack:** Static HTML, CSS already packaged in `css/`, browser JavaScript, FileReader, Blob/object URLs, inline SVG.

---

### Task 1: Create the validator route

**Files:**
- Create: `strategy-validator/index.html`

- [ ] Add the Belfort Trading navigation shell and page heading.
- [ ] Add CSV file upload, paste textarea, clear/run controls, and input guidance.
- [ ] Add report sections for Verdict, core metrics, equity/drawdown charts, risk summary, regime breakdown, Monte Carlo percentiles, and errors.
- [ ] Add inline browser logic that parses quoted CSV values, detects P&L/return/date aliases, calculates metrics, assigns a grade, creates charts, and handles invalid input.
- [ ] Keep all calculations client-side and do not call external APIs.

### Task 2: Expose the validator from existing pages

**Files:**
- Modify: `index.html`
- Modify: `projects/index.html`
- Modify: `quant-copilot/index.html`

- [ ] Add `Strategy Validator` links to the existing navigation/primary actions without changing authentication behavior.

### Task 3: Verify the static route

**Files:**
- Test: served pages and validator script

- [ ] Run a JavaScript syntax check on the inline script extracted from the route.
- [ ] Start/restart the correct Python static server on port 4173.
- [ ] Fetch the route and assert the validator fields, report sections, and navigation links exist.
- [ ] Execute the calculator logic with valid and invalid CSV fixtures through Node where possible.
- [ ] Confirm the old verification screen and unwanted user-facing demo wording remain absent.
