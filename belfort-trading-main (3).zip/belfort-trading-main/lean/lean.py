"""lean.py — a browser-native, Lean-compatible backtest engine.

A reimplementation of the common QuantConnect Lean API so a user's
``QCAlgorithm`` (``from BelfortEngine import **``) runs in the browser via
Pyodide with no VPS, OR on a real Python interpreter on the VPS runner
(``server/lean-runner/runner.py``). This is NOT the C# Lean binary — Lean
cannot run in a browser — but it executes real strategy logic
(Initialize/OnData, indicators, SetHoldings, Buy/Sell/LimitOrder,
StopMarketOrder, Liquidate, Portfolio) against bar data and computes real
equity/metrics.

What this version supports (institutional upgrades over the original toy):
  - Multi-symbol: AddEquity called multiple times; the bars CSV may carry a
    ``symbol`` column. A single-symbol CSV still works.
  - Short selling: SellShort / Buy with negative / SetHoldings with a negative
    fraction; long and short holdings tracked separately.
  - Commissions: ConstantCommissionModel ($0.005/share default) and
    PercentCommissionModel (bps of notional). Set per-algo or per-security.
  - Slippage: ConstantSlippageModel (5 bps default) and
    PercentSlippageModel (bps of notional). Applied on every fill.
  - Limit and stop orders: LimitOrder / StopMarketOrder / StopLimitOrder with
    order tickets that fill when the bar's high/low crosses the trigger.
  - More indicators: SMA, EMA, RSI, MACD, BollingerBands, ATR, STDDEV, MOM,
    ROC, WilderMA, Maximum, Minimum.
  - Institutional metrics: annualized Sharpe & Sortino (with the right
    annualization factor for the resolution), max drawdown duration, exposure
    time, turnover, profit factor, plus the original net/return/win-rate.

Honest limitations (kept): single-bar feed per step (no tick), market orders
fill at next bar's open, no options, no real brokerages, no margin/financing
beyond SetCash. With no data the engine runs on a clearly-labelled synthetic
GBM series.
"""

import math, json, datetime, random, types, sys, inspect


# ── Resolution ──────────────────────────────────────────────────────

class Resolution:
    Daily = 'Daily'
    Hour = 'Hour'
    Minute = 'Minute'


# Annualization factor per resolution (bars per year).
BARS_PER_YEAR = {
    Resolution.Daily: 252,
    Resolution.Hour: 252 * 6.5,   # US equity session hours
    Resolution.Minute: 252 * 6.5 * 60,
}


# ── Symbol ───────────────────────────────────────────────────────────

class Symbol:
    def __init__(self, value):
        self.Value = str(value)

    def __repr__(self):
        return self.Value

    def __hash__(self):
        return hash(self.Value)

    def __eq__(self, o):
        return isinstance(o, Symbol) and o.Value == self.Value


def _sym(s):
    return s if isinstance(s, Symbol) else Symbol(str(s))


def _key(s):
    return s.Value if isinstance(s, Symbol) else str(s)


def _parsedate(d):
    if isinstance(d, (datetime.date, datetime.datetime)):
        return d if isinstance(d, datetime.date) else d.date()
    s = str(d)
    for fmt in ('%Y-%m-%d', '%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M',
               '%Y/%m/%d', '%m/%d/%Y', '%d/%m/%Y'):
        try:
            return datetime.datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None


# ── Indicators ──────────────────────────────────────────────────────

class _IndCurrent:
    def __init__(self, get):
        self._get = get

    @property
    def Value(self):
        return self._val if hasattr(self, '_val') else self._get()


class Indicator:
    def __init__(self, period):
        self.period = int(period)
        self._val = 0.0
        self._ready = False

    @property
    def IsReady(self):
        return self._ready

    @property
    def Current(self):
        return _IndCurrent(lambda: self._val)

    def Update(self, value):
        raise NotImplementedError


class BarIndicator(Indicator):
    """Marker class for indicators that need a full Bar object (OHLCV) instead
    of a scalar close price. run_backtest checks isinstance to decide what to pass."""
    pass


class SMA(Indicator):
    def __init__(self, symbol, period, resolution=None):
        super().__init__(period)
        self.window = []
        self.symbol = _sym(symbol)

    def Update(self, value):
        self.window.append(float(value))
        if len(self.window) > self.period:
            self.window.pop(0)
        if len(self.window) == self.period:
            self._val = sum(self.window) / self.period
            self._ready = True


class EMA(Indicator):
    def __init__(self, symbol, period, resolution=None):
        super().__init__(period)
        self.alpha = 2.0 / (period + 1)
        self.symbol = _sym(symbol)
        self._seed = []

    def Update(self, value):
        v = float(value)
        if not self._ready:
            self._seed.append(v)
            if len(self._seed) == self.period:
                self._val = sum(self._seed) / self.period
                self._ready = True
        else:
            self._val = self.alpha * v + (1 - self.alpha) * self._val


class WilderMA(Indicator):
    """Wilder's smoothing (used by RSI and ATR)."""
    def __init__(self, symbol, period, resolution=None):
        super().__init__(period)
        self.symbol = _sym(symbol)
        self._seed = []

    def Update(self, value):
        v = float(value)
        if not self._ready:
            self._seed.append(v)
            if len(self._seed) == self.period:
                self._val = sum(self._seed) / self.period
                self._ready = True
        else:
            self._val = (self._val * (self.period - 1) + v) / self.period


class RSI(Indicator):
    def __init__(self, symbol, period=14, resolution=None):
        super().__init__(period)
        self.symbol = _sym(symbol)
        self._prev = None
        self._gains = []
        self._losses = []
        self._avg_gain = 0.0
        self._avg_loss = 0.0

    def Update(self, value):
        v = float(value)
        if self._prev is None:
            self._prev = v
            return
        ch = v - self._prev
        g = ch if ch > 0 else 0.0
        l = -ch if ch < 0 else 0.0
        if not self._ready:
            self._gains.append(g)
            self._losses.append(l)
            if len(self._gains) == self.period:
                self._avg_gain = sum(self._gains) / self.period
                self._avg_loss = sum(self._losses) / self.period
                self._ready = True
        else:
            self._avg_gain = (self._avg_gain * (self.period - 1) + g) / self.period
            self._avg_loss = (self._avg_loss * (self.period - 1) + l) / self.period
        self._prev = v
        if self._ready:
            if self._avg_loss == 0:
                self._val = 100.0
            else:
                rs = self._avg_gain / self._avg_loss
                self._val = 100.0 - 100.0 / (1.0 + rs)


class MACD(Indicator):
    """Moving Average Convergence Divergence: EMA(fast) − EMA(slow)."""
    def __init__(self, symbol, fast=12, slow=26, signal=9, resolution=None):
        super().__init__(slow)
        self.symbol = _sym(symbol)
        self._fast = EMA(symbol, fast)
        self._slow = EMA(symbol, slow)
        self._signal = EMA(symbol, signal)
        self._hist = []

    def Update(self, value):
        self._fast.Update(value)
        self._slow.Update(value)
        if self._slow._ready:
            macd = self._fast._val - self._slow._val
            self._val = macd
            self._signal.Update(macd)
            self._ready = True

    @property
    def Signal(self):
        return self._signal._val if self._signal._ready else 0.0

    @property
    def Histogram(self):
        if self._signal._ready:
            return self._val - self._signal._val
        return 0.0


class BollingerBands(Indicator):
    def __init__(self, symbol, period=20, k=2.0, resolution=None):
        super().__init__(period)
        self.symbol = _sym(symbol)
        self.k = float(k)
        self.window = []

    def Update(self, value):
        v = float(value)
        self.window.append(v)
        if len(self.window) > self.period:
            self.window.pop(0)
        if len(self.window) == self.period:
            m = sum(self.window) / self.period
            var = sum((x - m) ** 2 for x in self.window) / self.period
            sd = math.sqrt(var)
            self._val = m
            self._ready = True
            self._middle = m
            self._upper = m + self.k * sd
            self._lower = m - self.k * sd

    @property
    def MiddleBand(self):
        return getattr(self, '_middle', 0.0)

    @property
    def UpperBand(self):
        return getattr(self, '_upper', 0.0)

    @property
    def LowerBand(self):
        return getattr(self, '_lower', 0.0)


class STDDEV(Indicator):
    def __init__(self, symbol, period, resolution=None):
        super().__init__(period)
        self.symbol = _sym(symbol)
        self.window = []

    def Update(self, value):
        v = float(value)
        self.window.append(v)
        if len(self.window) > self.period:
            self.window.pop(0)
        if len(self.window) == self.period:
            m = sum(self.window) / self.period
            var = sum((x - m) ** 2 for x in self.window) / self.period
            self._val = math.sqrt(var)
            self._ready = True


class ATR(BarIndicator):
    """True-range average (Wilder). Requires High/Low/Close; pass a Bar."""
    def __init__(self, symbol, period=14, resolution=None):
        super().__init__(period)
        self.symbol = _sym(symbol)
        self._prev_close = None
        self._tr_seed = []

    def Update(self, bar):
        h = float(getattr(bar, 'High', bar))
        l = float(getattr(bar, 'Low', bar))
        c = float(getattr(bar, 'Close', bar))
        if self._prev_close is None:
            tr = h - l
        else:
            tr = max(h - l, abs(h - self._prev_close), abs(l - self._prev_close))
        self._prev_close = c
        if not self._ready:
            self._tr_seed.append(tr)
            if len(self._tr_seed) == self.period:
                self._val = sum(self._tr_seed) / self.period
                self._ready = True
        else:
            self._val = (self._val * (self.period - 1) + tr) / self.period


class MOM(Indicator):
    """Momentum: current − value N periods ago."""
    def __init__(self, symbol, period, resolution=None):
        super().__init__(period)
        self.symbol = _sym(symbol)
        self.window = []

    def Update(self, value):
        v = float(value)
        self.window.append(v)
        if len(self.window) > self.period:
            self.window.pop(0)
        if len(self.window) == self.period:
            self._val = v - self.window[0]
            self._ready = True


class ROC(Indicator):
    """Rate of change: (current − N ago) / N ago."""
    def __init__(self, symbol, period, resolution=None):
        super().__init__(period)
        self.symbol = _sym(symbol)
        self.window = []

    def Update(self, value):
        v = float(value)
        self.window.append(v)
        if len(self.window) > self.period:
            self.window.pop(0)
        if len(self.window) == self.period and self.window[0] != 0:
            self._val = (v - self.window[0]) / self.window[0]
            self._ready = True


class Maximum(Indicator):
    """Highest value over a rolling window."""
    def __init__(self, symbol, period, resolution=None):
        super().__init__(period)
        self.symbol = _sym(symbol)
        self.window = []

    def Update(self, value):
        v = float(value)
        self.window.append(v)
        if len(self.window) > self.period:
            self.window.pop(0)
        if len(self.window) == self.period:
            self._val = max(self.window)
            self._ready = True


class Minimum(Indicator):
    """Lowest value over a rolling window."""
    def __init__(self, symbol, period, resolution=None):
        super().__init__(period)
        self.symbol = _sym(symbol)
        self.window = []

    def Update(self, value):
        v = float(value)
        self.window.append(v)
        if len(self.window) > self.period:
            self.window.pop(0)
        if len(self.window) == self.period:
            self._val = min(self.window)
            self._ready = True


# ── More indicators ──────────────────────────────────────────────────

class Stochastic(BarIndicator):
    """Stochastic Oscillator. %K = (close - lowest_low) / (highest_high - lowest_low) * 100.
    %D = SMA of %K over `d_period` bars."""
    def __init__(self, symbol, period=14, d_period=3, resolution=None):
        super().__init__(period)
        self.symbol = _sym(symbol)
        self._d_period = d_period
        self._highs = []
        self._lows = []
        self._k_vals = []

    def Update(self, bar):
        h = float(getattr(bar, 'High', bar))
        l = float(getattr(bar, 'Low', bar))
        c = float(getattr(bar, 'Close', bar))
        self._highs.append(h)
        self._lows.append(l)
        if len(self._highs) > self.period:
            self._highs.pop(0)
            self._lows.pop(0)
        if len(self._highs) == self.period:
            hh = max(self._highs)
            ll = min(self._lows)
            k = 100 * (c - ll) / (hh - ll) if hh != ll else 50
            self._k_vals.append(k)
            if len(self._k_vals) > self._d_period:
                self._k_vals.pop(0)
            self._val = k
            self._d = sum(self._k_vals) / len(self._k_vals)
            self._ready = True

    @property
    def K(self):
        return self._val

    @property
    def D(self):
        return getattr(self, '_d', self._val)


class CCI(BarIndicator):
    """Commodity Channel Index: (TP - SMA(TP)) / (0.015 * mean_deviation(TP))."""
    def __init__(self, symbol, period=20, resolution=None):
        super().__init__(period)
        self.symbol = _sym(symbol)
        self._tp_list = []

    def Update(self, bar):
        h = float(getattr(bar, 'High', bar))
        l = float(getattr(bar, 'Low', bar))
        c = float(getattr(bar, 'Close', bar))
        tp = (h + l + c) / 3
        self._tp_list.append(tp)
        if len(self._tp_list) > self.period:
            self._tp_list.pop(0)
        if len(self._tp_list) == self.period:
            mean = sum(self._tp_list) / self.period
            md = sum(abs(tp - mean) for tp in self._tp_list) / self.period
            self._val = (tp - mean) / (0.015 * md) if md != 0 else 0
            self._ready = True


class WilliamsR(BarIndicator):
    """Williams %R: -100 * (highest_high - close) / (highest_high - lowest_low)."""
    def __init__(self, symbol, period=14, resolution=None):
        super().__init__(period)
        self.symbol = _sym(symbol)
        self._highs = []
        self._lows = []

    def Update(self, bar):
        h = float(getattr(bar, 'High', bar))
        l = float(getattr(bar, 'Low', bar))
        c = float(getattr(bar, 'Close', bar))
        self._highs.append(h)
        self._lows.append(l)
        if len(self._highs) > self.period:
            self._highs.pop(0)
            self._lows.pop(0)
        if len(self._highs) == self.period:
            hh = max(self._highs)
            ll = min(self._lows)
            self._val = -100 * (hh - c) / (hh - ll) if hh != ll else -50
            self._ready = True


class ADX(BarIndicator):
    """Average Directional Index — trend strength. Also exposes +DI and -DI."""
    def __init__(self, symbol, period=14, resolution=None):
        super().__init__(period)
        self.symbol = _sym(symbol)
        self._prev_high = None
        self._prev_low = None
        self._prev_close = None
        self._dm_plus = []
        self._dm_minus = []
        self._tr = []

    def Update(self, bar):
        h = float(getattr(bar, 'High', bar))
        l = float(getattr(bar, 'Low', bar))
        c = float(getattr(bar, 'Close', bar))
        if self._prev_close is not None:
            up = h - self._prev_high
            down = self._prev_low - l
            dm_plus = up if (up > down and up > 0) else 0
            dm_minus = down if (down > up and down > 0) else 0
            tr = max(h - l, abs(h - self._prev_close), abs(l - self._prev_close))
            self._dm_plus.append(dm_plus)
            self._dm_minus.append(dm_minus)
            self._tr.append(tr)
            if len(self._tr) > self.period:
                self._dm_plus.pop(0)
                self._dm_minus.pop(0)
                self._tr.pop(0)
            if len(self._tr) == self.period:
                atr = sum(self._tr) / self.period
                if atr > 0:
                    di_plus = 100 * (sum(self._dm_plus) / self.period) / atr
                    di_minus = 100 * (sum(self._dm_minus) / self.period) / atr
                    dx = 100 * abs(di_plus - di_minus) / (di_plus + di_minus) if (di_plus + di_minus) > 0 else 0
                    self._val = dx
                    self._di_plus = di_plus
                    self._di_minus = di_minus
                    self._ready = True
        self._prev_high = h
        self._prev_low = l
        self._prev_close = c

    @property
    def PlusDI(self):
        return getattr(self, '_di_plus', 0)

    @property
    def MinusDI(self):
        return getattr(self, '_di_minus', 0)


class OBV(BarIndicator):
    """On-Balance Volume: cumulative volume that adds on up bars, subtracts on down bars."""
    def __init__(self, symbol, resolution=None):
        super().__init__(1)
        self.symbol = _sym(symbol)
        self._prev_close = None
        self._obv = 0.0

    def Update(self, bar):
        c = float(getattr(bar, 'Close', bar))
        v = float(getattr(bar, 'Volume', 0))
        if self._prev_close is not None:
            if c > self._prev_close:
                self._obv += v
            elif c < self._prev_close:
                self._obv -= v
        self._prev_close = c
        self._val = self._obv
        self._ready = True


class VWAP(BarIndicator):
    """Volume Weighted Average Price — rolling over a window of bars."""
    def __init__(self, symbol, period=20, resolution=None):
        super().__init__(period)
        self.symbol = _sym(symbol)
        self._pv = []
        self._vol = []

    def Update(self, bar):
        h = float(getattr(bar, 'High', bar))
        l = float(getattr(bar, 'Low', bar))
        c = float(getattr(bar, 'Close', bar))
        v = float(getattr(bar, 'Volume', 0))
        tp = (h + l + c) / 3
        self._pv.append(tp * v)
        self._vol.append(v)
        if len(self._pv) > self.period:
            self._pv.pop(0)
            self._vol.pop(0)
        tot_v = sum(self._vol)
        if tot_v > 0:
            self._val = sum(self._pv) / tot_v
            self._ready = True


# ── More indicators (professional set) ──────────────────────────────

class ParabolicSAR(BarIndicator):
    """Parabolic Stop and Reverse. Tracks trend with an accelerating trailing stop."""
    def __init__(self, symbol, step=0.02, max_step=0.2, resolution=None):
        super().__init__(1)
        self.symbol = _sym(symbol)
        self.step = float(step)
        self.max_step = float(max_step)
        self._af = self.step
        self._ep = None  # extreme point
        self._sar = None
        self._is_long = True

    def Update(self, bar):
        h = float(bar.High)
        l = float(bar.Low)
        c = float(bar.Close)
        if self._sar is None:
            self._sar = c
            self._ep = h if self._is_long else l
            self._val = c
            self._ready = True
            return
        if self._is_long:
            if l < self._sar:
                self._is_long = False
                self._sar = max(self._ep, h)
                self._ep = l
                self._af = self.step
            else:
                self._sar = min(self._sar + self._af * (self._ep - self._sar), l)
                if h > self._ep:
                    self._ep = h
                    self._af = min(self._af + self.step, self.max_step)
        else:
            if h > self._sar:
                self._is_long = True
                self._sar = min(self._ep, l)
                self._ep = h
                self._af = self.step
            else:
                self._sar = max(self._sar + self._af * (self._ep - self._sar), h)
                if l < self._ep:
                    self._ep = l
                    self._af = min(self._af + self.step, self.max_step)
        self._val = self._sar

    @property
    def IsLong(self):
        return self._is_long


class Ichimoku(BarIndicator):
    """Ichimoku Cloud: Tenkan, Kijun, Senkou A/B, Chikou."""
    def __init__(self, symbol, tenkan=9, kijun=26, senkou=52, resolution=None):
        super().__init__(senkou)
        self.symbol = _sym(symbol)
        self._t_p, self._k_p, self._s_p = tenkan, kijun, senkou
        self._highs, self._lows, self._closes = [], [], []

    def Update(self, bar):
        h, l, c = float(bar.High), float(bar.Low), float(bar.Close)
        self._highs.append(h)
        self._lows.append(l)
        self._closes.append(c)
        if len(self._highs) > self._s_p:
            self._highs.pop(0)
            self._lows.pop(0)
            self._closes.pop(0)
        if len(self._highs) >= self._t_p:
            self._tenkan = (max(self._highs[-self._t_p:]) + min(self._lows[-self._t_p:])) / 2
        if len(self._highs) >= self._k_p:
            self._kijun = (max(self._highs[-self._k_p:]) + min(self._lows[-self._k_p:])) / 2
            if hasattr(self, '_tenkan'):
                self._senkou_a = (self._tenkan + self._kijun) / 2
        if len(self._highs) >= self._s_p:
            self._senkou_b = (max(self._highs) + min(self._lows)) / 2
            self._ready = True
        if len(self._closes) > self._k_p:
            self._chikou = self._closes[-self._k_p - 1] if len(self._closes) > self._k_p else c
        self._val = getattr(self, '_tenkan', c)

    @property
    def Tenkan(self): return getattr(self, '_tenkan', 0)
    @property
    def Kijun(self): return getattr(self, '_kijun', 0)
    @property
    def SenkouA(self): return getattr(self, '_senkou_a', 0)
    @property
    def SenkouB(self): return getattr(self, '_senkou_b', 0)
    @property
    def Chikou(self): return getattr(self, '_chikou', 0)


class KeltnerChannels(BarIndicator):
    """Keltner Channels: EMA ± k × ATR."""
    def __init__(self, symbol, period=20, k=2.0, atr_period=10, resolution=None):
        super().__init__(period)
        self.symbol = _sym(symbol)
        self._ema = EMA(symbol, period)
        self._atr = ATR(symbol, atr_period)
        self._k = float(k)

    def Update(self, bar):
        self._ema.Update(float(bar.Close))
        self._atr.Update(bar)
        if self._ema._ready and self._atr._ready:
            self._val = self._ema._val
            self._upper = self._ema._val + self._k * self._atr._val
            self._lower = self._ema._val - self._k * self._atr._val
            self._ready = True

    @property
    def Middle(self): return self._val
    @property
    def Upper(self): return getattr(self, '_upper', 0)
    @property
    def Lower(self): return getattr(self, '_lower', 0)


class DonchianChannels(BarIndicator):
    """Donchian Channels: highest high / lowest low over period."""
    def __init__(self, symbol, period=20, resolution=None):
        super().__init__(period)
        self.symbol = _sym(symbol)
        self._highs, self._lows = [], []

    def Update(self, bar):
        h, l = float(bar.High), float(bar.Low)
        self._highs.append(h)
        self._lows.append(l)
        if len(self._highs) > self.period:
            self._highs.pop(0)
            self._lows.pop(0)
        if len(self._highs) == self.period:
            self._upper = max(self._highs)
            self._lower = min(self._lows)
            self._middle = (self._upper + self._lower) / 2
            self._val = self._middle
            self._ready = True

    @property
    def Upper(self): return getattr(self, '_upper', 0)
    @property
    def Lower(self): return getattr(self, '_lower', 0)
    @property
    def Middle(self): return getattr(self, '_middle', 0)


class HeikinAshi(BarIndicator):
    """Heikin-Ashi smoothed OHLC. Produces HA_Open, HA_High, HA_Low, HA_Close."""
    def __init__(self, symbol, resolution=None):
        super().__init__(1)
        self.symbol = _sym(symbol)
        self._ha_open = None

    def Update(self, bar):
        o, h, l, c = float(bar.Open), float(bar.High), float(bar.Low), float(bar.Close)
        ha_close = (o + h + l + c) / 4
        if self._ha_open is None:
            self._ha_open = (o + c) / 2
        else:
            self._ha_open = (self._ha_open + self._ha_close_prev) / 2 if hasattr(self, '_ha_close_prev') else (o + c) / 2
        self._ha_close_prev = ha_close
        self._ha_high = max(h, self._ha_open, ha_close)
        self._ha_low = min(l, self._ha_open, ha_close)
        self._val = ha_close
        self._ready = True

    @property
    def HA_Open(self): return self._ha_open or 0
    @property
    def HA_High(self): return getattr(self, '_ha_high', 0)
    @property
    def HA_Low(self): return getattr(self, '_ha_low', 0)
    @property
    def HA_Close(self): return self._val


class TRIX(Indicator):
    """TRIX: triple-smoothed EMA rate of change."""
    def __init__(self, symbol, period=12, resolution=None):
        super().__init__(period)
        self.symbol = _sym(symbol)
        self._e1 = EMA(symbol, period)
        self._e2 = EMA(symbol, period)
        self._e3 = EMA(symbol, period)
        self._prev = None

    def Update(self, value):
        self._e1.Update(value)
        if self._e1._ready:
            self._e2.Update(self._e1._val)
            if self._e2._ready:
                self._e3.Update(self._e2._val)
                if self._e3._ready:
                    if self._prev is not None and self._prev != 0:
                        self._val = (self._e3._val - self._prev) / self._prev * 100
                        self._ready = True
                    self._prev = self._e3._val


class TSI(Indicator):
    """True Strength Index: double-smoothed momentum / double-smoothed |momentum|."""
    def __init__(self, symbol, r=13, s=25, resolution=None):
        super().__init__(s)
        self.symbol = _sym(symbol)
        self._r, self._s = r, s
        self._prev_close = None
        self._mom = []
        self._abs_mom = []

    def Update(self, value):
        v = float(value)
        if self._prev_close is not None:
            mom = v - self._prev_close
            self._mom.append(mom)
            self._abs_mom.append(abs(mom))
            if len(self._mom) > self._s * 3:
                self._mom = self._mom[-self._s * 3:]
                self._abs_mom = self._abs_mom[-self._s * 3:]
            if len(self._mom) >= self._s + self._r:
                r1 = self._mom[-self._r:]
                r2 = self._abs_mom[-self._r:]
                e1_mom = sum(r1) / self._r
                e1_abs = sum(r2) / self._r
                s1 = self._mom[-self._s - self._r:-self._r] if len(self._mom) >= self._s + self._r else self._mom[:-self._r]
                s2 = self._abs_mom[-self._s - self._r:-self._r] if len(self._abs_mom) >= self._s + self._r else self._abs_mom[:-self._r]
                if s1 and s2:
                    e2_mom = sum(s1[-self._s:]) / self._s if len(s1) >= self._s else sum(s1) / max(len(s1), 1)
                    e2_abs = sum(s2[-self._s:]) / self._s if len(s2) >= self._s else sum(s2) / max(len(s2), 1)
                    if e2_abs != 0:
                        self._val = 100 * (e1_mom + e2_mom) / (e1_abs + e2_abs)
                        self._ready = True
        self._prev_close = v


class MFI(BarIndicator):
    """Money Flow Index: volume-weighted RSI."""
    def __init__(self, symbol, period=14, resolution=None):
        super().__init__(period)
        self.symbol = _sym(symbol)
        self._tp_list = []
        self._mf_list = []
        self._prev_tp = None

    def Update(self, bar):
        h, l, c, v = float(bar.High), float(bar.Low), float(bar.Close), float(bar.Volume)
        tp = (h + l + c) / 3
        if self._prev_tp is not None:
            mf = tp * v
            if tp > self._prev_tp:
                self._mf_list.append(('pos', mf))
            elif tp < self._prev_tp:
                self._mf_list.append(('neg', mf))
            else:
                self._mf_list.append(('none', mf))
            if len(self._mf_list) > self.period:
                self._mf_list.pop(0)
            if len(self._mf_list) == self.period:
                pos_mf = sum(mf for t, mf in self._mf_list if t == 'pos')
                neg_mf = sum(mf for t, mf in self._mf_list if t == 'neg')
                if neg_mf > 0:
                    mfr = pos_mf / neg_mf
                    self._val = 100 - 100 / (1 + mfr)
                else:
                    self._val = 100
                self._ready = True
        self._prev_tp = tp


class Aroon(BarIndicator):
    """Aroon Up/Down: periods since highest high / lowest low, scaled to 0-100."""
    def __init__(self, symbol, period=25, resolution=None):
        super().__init__(period)
        self.symbol = _sym(symbol)
        self._highs, self._lows = [], []

    def Update(self, bar):
        h, l = float(bar.High), float(bar.Low)
        self._highs.append(h)
        self._lows.append(l)
        if len(self._highs) > self.period + 1:
            self._highs.pop(0)
            self._lows.pop(0)
        if len(self._highs) == self.period + 1:
            highest_idx = self._highs.index(max(self._highs))
            lowest_idx = self._lows.index(min(self._lows))
            self._up = ((self.period - highest_idx) / self.period) * 100
            self._down = ((self.period - lowest_idx) / self.period) * 100
            self._val = self._up - self._down
            self._ready = True

    @property
    def Up(self): return getattr(self, '_up', 0)
    @property
    def Down(self): return getattr(self, '_down', 0)


class ForceIndex(BarIndicator):
    """Force Index: (close - prev_close) × volume."""
    def __init__(self, symbol, period=1, resolution=None):
        super().__init__(period)
        self.symbol = _sym(symbol)
        self._prev_close = None
        self._vals = []

    def Update(self, bar):
        c, v = float(bar.Close), float(bar.Volume)
        if self._prev_close is not None:
            fi = (c - self._prev_close) * v
            self._vals.append(fi)
            if len(self._vals) > self.period:
                self._vals.pop(0)
            if len(self._vals) == self.period:
                self._val = sum(self._vals) / self.period
                self._ready = True
        self._prev_close = c


# ── Order tickets ───────────────────────────────────────────────────

class OrderTicket:
    """Base ticket. Subclasses set the fill trigger."""
    def __init__(self, symbol, quantity, price=None, stop_price=None, limit_price=None):
        self.Symbol = _sym(symbol)
        self.Quantity = int(quantity)
        self.Price = float(price) if price is not None else None
        self.StopPrice = float(stop_price) if stop_price is not None else None
        self.LimitPrice = float(limit_price) if limit_price is not None else None
        self.Status = 'Submitted'   # Submitted | Filled | Canceled | Invalid
        self.FillQuantity = 0
        self.FillPrice = 0.0
        self.OrderType = 'market'

    def update(self, bar, fill):
        """Try to fill on this bar. Returns the fill dict or None."""
        return fill(self, bar)


class MarketOrderTicket(OrderTicket):
    def __init__(self, symbol, quantity):
        super().__init__(symbol, quantity)
        self.OrderType = 'market'


class LimitOrderTicket(OrderTicket):
    def __init__(self, symbol, quantity, limit_price):
        super().__init__(symbol, quantity, limit_price=limit_price)
        self.OrderType = 'limit'

    def maybe_fill(self, bar):
        if self.Status != 'Submitted':
            return None
        # Buy limit: fills when bar Low <= limit. Sell limit: when bar High >= limit.
        if self.Quantity > 0 and bar.Low <= self.LimitPrice:
            return self.LimitPrice
        if self.Quantity < 0 and bar.High >= self.LimitPrice:
            return self.LimitPrice
        return None


class StopMarketOrderTicket(OrderTicket):
    def __init__(self, symbol, quantity, stop_price):
        super().__init__(symbol, quantity, stop_price=stop_price)
        self.OrderType = 'stop'

    def maybe_fill(self, bar):
        if self.Status != 'Submitted':
            return None
        # Buy stop: triggers when bar High >= stop. Sell stop: when bar Low <= stop.
        if self.Quantity > 0 and bar.High >= self.StopPrice:
            return self.StopPrice
        if self.Quantity < 0 and bar.Low <= self.StopPrice:
            return self.StopPrice
        return None


class StopLimitOrderTicket(OrderTicket):
    def __init__(self, symbol, quantity, stop_price, limit_price):
        super().__init__(symbol, quantity, stop_price=stop_price, limit_price=limit_price)
        self.OrderType = 'stoplimit'
        self.triggered = False

    def maybe_fill(self, bar):
        if self.Status != 'Submitted':
            return None
        if not self.triggered:
            if (self.Quantity > 0 and bar.High >= self.StopPrice) or \
               (self.Quantity < 0 and bar.Low <= self.StopPrice):
                self.triggered = True
        if self.triggered:
            if self.Quantity > 0 and bar.Low <= self.LimitPrice:
                return self.LimitPrice
            if self.Quantity < 0 and bar.High >= self.LimitPrice:
                return self.LimitPrice
        return None


class TrailingStopOrderTicket(OrderTicket):
    """Trailing stop order. For a long: trails the highest high since entry by
    `trailing_amount` (a dollar amount if is_percentage=False, a fraction if True).
    For a short: trails the lowest low."""
    def __init__(self, symbol, quantity, trailing_amount, is_percentage=True):
        super().__init__(symbol, quantity)
        self.trailing_amount = float(trailing_amount)
        self.is_percentage = is_percentage
        self._extreme = None  # high for longs, low for shorts
        self.OrderType = 'trailing_stop'

    def maybe_fill(self, bar):
        if self.Status != 'Submitted':
            return None
        if self.Quantity > 0:  # long trailing stop
            if self._extreme is None or bar.High > self._extreme:
                self._extreme = bar.High
            if self.is_percentage:
                trigger = self._extreme * (1 - self.trailing_amount)
            else:
                trigger = self._extreme - self.trailing_amount
            if bar.Low <= trigger:
                return trigger
        else:  # short trailing stop
            if self._extreme is None or bar.Low < self._extreme:
                self._extreme = bar.Low
            if self.is_percentage:
                trigger = self._extreme * (1 + self.trailing_amount)
            else:
                trigger = self._extreme + self.trailing_amount
            if bar.High >= trigger:
                return trigger
        return None


# ── Fill models ─────────────────────────────────────────────────────

class FillModel:
    """Base fill model. Determines the fill price for a market order."""
    def fill_price(self, order, bar):
        return bar.Open  # default: fill at next bar's open


class ImmediateFillModel(FillModel):
    """Fill at the current bar's close (immediate, no waiting for next bar)."""
    def fill_price(self, order, bar):
        return bar.Close


class VolumeWeightedAveragePriceFill(FillModel):
    """Fill at the bar's VWAP (typical price ≈ (H+L+C)/3 as a proxy)."""
    def fill_price(self, order, bar):
        if bar.Volume > 0:
            return (bar.High + bar.Low + bar.Close) / 3
        return bar.Close


# ── Risk management ─────────────────────────────────────────────────

class RiskManagementModel:
    """Base risk model. Override manage() to adjust target quantities."""
    def manage(self, algo, targets):
        return targets


class MaximumDrawdownPercent(RiskManagementModel):
    """Liquidate all positions when the portfolio drawdown exceeds `max_dd`."""
    def __init__(self, max_dd=0.10):
        self.max_dd = float(max_dd)
        self._peak = 0.0

    def manage(self, algo, targets):
        tpv = algo.Portfolio.TotalPortfolioValue
        self._peak = max(self._peak, tpv)
        dd = (self._peak - tpv) / self._peak if self._peak > 0 else 0
        if dd >= self.max_dd:
            algo.Log('Risk: max DD %.1f%% breached — liquidating' % (dd * 100))
            return {k: 0 for k in targets}
        return targets


class MaximumExposure(RiskManagementModel):
    """Scale down if total absolute exposure exceeds `max_exposure` × portfolio value."""
    def __init__(self, max_exposure=1.0):
        self.max_exposure = float(max_exposure)

    def manage(self, algo, targets):
        total = sum(abs(v * algo.Securities[k].Price) for k, v in targets.items() if k in algo.Securities and algo.Securities[k].Price > 0)
        tpv = algo.Portfolio.TotalPortfolioValue
        if tpv > 0 and total > self.max_exposure * tpv:
            scale = self.max_exposure * tpv / total
            return {k: int(v * scale) for k, v in targets.items()}
        return targets


class MaximumPositionSize(RiskManagementModel):
    """Cap any single position to `max_percent` of the portfolio."""
    def __init__(self, max_percent=0.25):
        self.max_percent = float(max_percent)

    def manage(self, algo, targets):
        tpv = algo.Portfolio.TotalPortfolioValue
        out = {}
        for k, qty in targets.items():
            sec = algo.Securities[k] if k in algo.Securities else None
            if sec and sec.Price > 0:
                max_qty = int(self.max_percent * tpv / sec.Price)
                out[k] = max(-max_qty, min(max_qty, qty))
            else:
                out[k] = qty
        return out


# ── Commission + slippage models ────────────────────────────────────

class CommissionModel:
    def fee(self, quantity, price):
        return 0.0


class ConstantCommissionModel(CommissionModel):
    """Per-share commission. Default $0.005/share (US equity typical)."""
    def __init__(self, per_share=0.005, minimum=1.0):
        self.per_share = float(per_share)
        self.minimum = float(minimum)

    def fee(self, quantity, price):
        return max(self.per_share * abs(quantity), self.minimum)


class PercentCommissionModel(CommissionModel):
    """Bps of notional. Use for futures and FX."""
    def __init__(self, bps=0.5, minimum=0.0):
        self.bps = float(bps)
        self.minimum = float(minimum)

    def fee(self, quantity, price):
        return max(self.bps / 10000.0 * abs(quantity) * price, self.minimum)


class SlippageModel:
    def adjust(self, quantity, price):
        return price


class ConstantSlippageModel(SlippageModel):
    """Fixed bps added against the order direction. Default 5 bps."""
    def __init__(self, bps=5.0):
        self.bps = float(bps)

    def adjust(self, quantity, price):
        slip = self.bps / 10000.0 * price
        return price + slip if quantity > 0 else price - slip


class PercentSlippageModel(ConstantSlippageModel):
    """Alias — same as ConstantSlippageModel. Reads better in user code."""
    pass


class VolumeShareSlippageModel(SlippageModel):
    """Price-impact slippage: slippage grows with order size relative to bar volume."""
    def __init__(self, volume_share=0.1, price_impact=0.1):
        self.volume_share = float(volume_share)
        self.price_impact = float(price_impact)

    def adjust(self, quantity, price, bar_volume=0):
        if bar_volume and bar_volume > 0:
            vol_fraction = abs(quantity) / bar_volume
            impact = self.price_impact * vol_fraction * vol_fraction
        else:
            impact = 0.001  # 10 bps default when no volume
        return price * (1 + impact) if quantity > 0 else price * (1 - impact)


class MarketImpactModel(SlippageModel):
    """Price impact based on order size vs Average Daily Volume.
    Larger orders relative to ADV get more slippage."""
    def __init__(self, adv_shares=100000, impact_bps=10):
        self.adv_shares = float(adv_shares)
        self.impact_bps = float(impact_bps)

    def adjust(self, quantity, price, bar_volume=0):
        vol = bar_volume if bar_volume and bar_volume > 0 else self.adv_shares
        vol_fraction = abs(quantity) / vol
        impact = self.impact_bps / 10000.0 * math.sqrt(vol_fraction)
        return price * (1 + impact) if quantity > 0 else price * (1 - impact)


# ── Holdings, Security, Portfolio ──────────────────────────────────

class Holdings:
    def __init__(self):
        self.Invested = False
        self.Quantity = 0          # signed: positive long, negative short
        self.AveragePrice = 0.0
        self.UnrealizedProfit = 0.0
        self.TotalFees = 0.0

    @property
    def AbsoluteHoldingsCost(self):
        """The total cost basis of the position (|qty × avg_price|)."""
        return abs(self.Quantity * self.AveragePrice)

    @property
    def HoldingsCost(self):
        return self.Quantity * self.AveragePrice

    @property
    def IsLong(self):
        return self.Quantity > 0

    @property
    def IsShort(self):
        return self.Quantity < 0


class Security:
    def __init__(self, symbol):
        self.Symbol = _sym(symbol)
        self.Price = 0.0
        self.OpenPrice = 0.0
        self.HighPrice = 0.0
        self.LowPrice = 0.0
        self.Volume = 0
        self.BidPrice = 0.0
        self.AskPrice = 0.0
        self.Holdings = Holdings()
        self.CommissionModel = ConstantCommissionModel()
        self.SlippageModel = ConstantSlippageModel()
        self.Leverage = 1.0
        self.IsTradable = True

    @property
    def Spread(self):
        return self.AskPrice - self.BidPrice

    @property
    def AskSpread(self):
        return self.Spread

    def SetCommissionModel(self, model):
        self.CommissionModel = model

    def SetSlippageModel(self, model):
        self.SlippageModel = model

    def SetLeverage(self, leverage):
        self.Leverage = float(leverage)

    def SetBuyingPowerMultiplier(self, multiplier):
        self.Leverage = float(multiplier)

    def UpdatePrices(self, o, h, l, c, v):
        self.Price = c
        self.OpenPrice = o
        self.HighPrice = h
        self.LowPrice = l
        self.Volume = v
        # Simple bid/ask model: bid = close - half spread, ask = close + half spread.
        # Default spread is 1 bp; the slippage model handles the actual fill offset.
        half = c * 0.0001
        self.BidPrice = c - half
        self.AskPrice = c + half


class Portfolio:
    def __init__(self):
        self._cash = 0.0
        self._securities = {}

    def set_cash(self, c):
        self._cash = float(c)

    @property
    def Cash(self):
        return self._cash

    @property
    def TotalPortfolioValue(self):
        inv = sum(s.Holdings.Quantity * s.Price for s in self._securities.values())
        return self._cash + inv

    @property
    def Invested(self):
        return any(s.Holdings.Invested for s in self._securities.values())

    @property
    def TotalUnrealizedProfit(self):
        return sum(s.Holdings.UnrealizedProfit for s in self._securities.values())

    @property
    def TotalFees(self):
        return sum(s.Holdings.TotalFees for s in self._securities.values())

    @property
    def TotalHoldingsValue(self):
        """Total gross exposure (sum of |qty × price| across all securities)."""
        return sum(abs(s.Holdings.Quantity * s.Price) for s in self._securities.values())

    @property
    def NetHoldings(self):
        """Net exposure (long value - short value)."""
        return sum(s.Holdings.Quantity * s.Price for s in self._securities.values())

    @property
    def TotalAbsoluteHoldingsCost(self):
        """Sum of |quantity × average_price| across all securities — the gross
        notional of all open positions."""
        return sum(abs(s.Holdings.Quantity * s.Holdings.AveragePrice) for s in self._securities.values())

    @property
    def TotalMarginUsed(self):
        """Margin requirement = gross notional / leverage. With leverage 1 (no
        margin), this equals the full notional. With leverage 2, half."""
        lev = max(getattr(self, '_leverage', 1.0), 1.0)
        return self.TotalAbsoluteHoldingsCost / lev

    @property
    def MarginRemaining(self):
        """Buying power left = portfolio value - margin used."""
        return max(0, self.TotalPortfolioValue - self.TotalMarginUsed)

    @property
    def BuyingPower(self):
        """Cash × leverage + unrealized P&L."""
        return self._cash * max(getattr(self, '_leverage', 1.0), 1.0) + self.TotalUnrealizedProfit

    def __getitem__(self, sym):
        k = _key(sym)
        if k not in self._securities:
            self._securities[k] = Security(k)
        return self._securities[k].Holdings


class _SecMap:
    def __init__(self, secs):
        self._d = secs

    def __getitem__(self, sym):
        return self._d[_key(sym)]

    def __contains__(self, sym):
        return _key(sym) in self._d

    def Values(self):
        return list(self._d.values())


# ── Bar + Slice ─────────────────────────────────────────────────────

class Bar:
    def __init__(self, symbol, time, o, h, l, c, v):
        self.Symbol = _sym(symbol)
        self.Time = time
        self.Open = o
        self.High = h
        self.Low = l
        self.Close = c
        self.Volume = v
        self.Value = c
        self.EndTime = time


class Slice:
    def __init__(self, time, bars):
        self.Time = time
        self._bars = {b.Symbol: b for b in bars}
        self.Bars = self._bars

    def __getitem__(self, key):
        return self._bars.get(_sym(key))

    def __contains__(self, key):
        return _sym(key) in self._bars

    def Get(self, key):
        return self._bars.get(_sym(key))


# ── QCAlgorithm ─────────────────────────────────────────────────────

class _TransactionManager:
    """self.Transactions — order management interface."""
    def __init__(self, algo):
        self._algo = algo

    def GetOpenOrders(self, symbol=None):
        tickets = [t for t in self._algo._tickets if t.Status == 'Submitted']
        if symbol:
            tickets = [t for t in tickets if _key(t.Symbol) == str(symbol)]
        return tickets

    def CancelOrder(self, id):
        for t in self._algo._tickets:
            if id(t) == id or getattr(t, 'id', None) == id:
                t.Status = 'Canceled'
                return True
        return False

    def CancelOpenOrders(self, symbol=None):
        count = 0
        for t in self._algo._tickets:
            if t.Status == 'Submitted' and (symbol is None or _key(t.Symbol) == str(symbol)):
                t.Status = 'Canceled'
                count += 1
        return count

    def GetOrderById(self, order_id):
        for t in self._algo._tickets:
            if id(t) == order_id:
                return t
        return None


class OrderEvent:
    """Passed to OnOrderEvent when an order fills or is cancelled."""
    def __init__(self, order_id, symbol, quantity, fill_price, status, fee=0):
        self.OrderId = order_id
        self.Symbol = _sym(symbol)
        self.Quantity = int(quantity)
        self.FillPrice = float(fill_price)
        self.Status = status  # 'Filled' | 'Canceled' | 'Submitted'
        self.OrderFee = float(fee)

    @property
    def FillQuantity(self):
        return abs(self.Quantity) if self.Status == 'Filled' else 0


class QCAlgorithm:
    def __init__(self):
        self._securities = {}
        self._indicators = []
        self._orders = []          # pending market orders: (key, target_qty)
        self._orders_close = []   # MarketOnClose orders — fill at current close
        self._tickets = []          # pending limit/stop tickets
        self._logs = []
        self._plots = {}            # chart -> series -> [values]  (custom Plot())
        self._scheduled = []       # scheduled events: (date_rules, time_rules, callback)
        self._consolidators = []    # (symbol, consolidator)
        self._bar_history = {}      # symbol -> [Bar] (rolling, for History())
        self._warmup_periods = 0
        self._bars_since_warmup = 0
        self._quit = False
        self._universe_selector = None
        self._risk_model = None
        self._benchmark_symbol = None
        self._benchmark_equity = []
        self.Portfolio = Portfolio()
        self.Securities = _SecMap(self._securities)
        self._cash = 100000.0
        self.Time = None
        self._start = None
        self._end = None
        self.Params = {}
        self._commission_model = ConstantCommissionModel()
        self._slippage_model = ConstantSlippageModel()
        self._resolution = Resolution.Daily

    def SetCash(self, c):
        self._cash = float(c)
        self.Portfolio.set_cash(self._cash)

    def SetStartDate(self, y, m=1, d=1):
        self._start = datetime.date(int(y), int(m), int(d))

    def SetEndDate(self, y, m=1, d=1):
        self._end = datetime.date(int(y), int(m), int(d))

    def SetBenchmark(self, symbol):
        """Track a benchmark symbol for buy-and-hold comparison. The benchmark's
        equity is tracked alongside the strategy and alpha/beta/info ratio are
        computed in the metrics."""
        self._benchmark_symbol = str(symbol)
    def SetSecurityInitializer(self, *a): pass
    def SetWarmUpIndicator(self, *a): pass
    def SetWarmup(self, *a): pass

    def SetWarmUp(self, periods, resolution=Resolution.Daily):
        """Warm up indicators for `periods` bars before OnData is called.
        During warm-up, self.IsWarmingUp is True."""
        self._warmup_periods = int(periods)
        self._warmup_resolution = resolution

    @property
    def IsWarmingUp(self):
        if self._warmup_periods <= 0:
            return False
        return self._bars_since_warmup < self._warmup_periods

    def SetBrokerageModel(self, *a): pass

    def SetCommissionModel(self, model):
        self._commission_model = model

    def SetSlippageModel(self, model):
        self._slippage_model = model

    def SetResolution(self, r):
        self._resolution = r

    def SetLeverage(self, leverage):
        """Apply a leverage multiplier to ALL securities (convenience — the
        real Lean API sets this per-security via self.Securities[sym].SetLeverage)."""
        for sec in self._securities.values():
            sec.SetLeverage(leverage)

    def AddEquity(self, symbol, resolution=Resolution.Daily):
        key = str(symbol)
        sec = Security(key)
        sec.CommissionModel = self._commission_model
        sec.SlippageModel = self._slippage_model
        self._securities[key] = sec
        self.Portfolio._securities[key] = sec
        return sec

    def AddData(self, symbol, resolution=Resolution.Daily):
        """Custom data — treated the same as equity in this engine."""
        return self.AddEquity(symbol, resolution)

    def AddSecurity(self, symbol, resolution=Resolution.Daily):
        return self.AddEquity(symbol, resolution)

    def AddUniverse(self, selector):
        """Simple universe selection. `selector` is a function(time) -> [symbols].
        Called once per bar; securities are added automatically."""
        self._universe_selector = selector
        return selector

    # ── Indicators ──
    def _register(self, ind):
        self._indicators.append((_key(ind.symbol), ind))
        return ind

    def SMA(self, symbol, period, resolution=None):
        return self._register(SMA(symbol, period))

    def EMA(self, symbol, period, resolution=None):
        return self._register(EMA(symbol, period))

    def RSI(self, symbol, period=14, resolution=None):
        return self._register(RSI(symbol, period))

    def MACD(self, symbol, fast=12, slow=26, signal=9, resolution=None):
        return self._register(MACD(symbol, fast, slow, signal))

    def BB(self, symbol, period=20, k=2.0, resolution=None):
        return self._register(BollingerBands(symbol, period, k))

    def BollingerBands(self, symbol, period=20, k=2.0, resolution=None):
        return self._register(BollingerBands(symbol, period, k))

    def STD(self, symbol, period, resolution=None):
        return self._register(STDDEV(symbol, period))

    def ATR(self, symbol, period=14, resolution=None):
        return self._register(ATR(symbol, period))

    def MOM(self, symbol, period, resolution=None):
        return self._register(MOM(symbol, period))

    def ROC(self, symbol, period, resolution=None):
        return self._register(ROC(symbol, period))

    def MAX(self, symbol, period, resolution=None):
        return self._register(Maximum(symbol, period))

    def MIN(self, symbol, period, resolution=None):
        return self._register(Minimum(symbol, period))

    def Maximum(self, symbol, period, resolution=None):
        return self._register(Maximum(symbol, period))

    def Minimum(self, symbol, period, resolution=None):
        return self._register(Minimum(symbol, period))

    def WilderMA(self, symbol, period, resolution=None):
        return self._register(WilderMA(symbol, period))

    def Stochastic(self, symbol, period=14, d_period=3, resolution=None):
        return self._register(Stochastic(symbol, period, d_period))

    def CCI(self, symbol, period=20, resolution=None):
        return self._register(CCI(symbol, period))

    def WilliamsR(self, symbol, period=14, resolution=None):
        return self._register(WilliamsR(symbol, period))

    def ADX(self, symbol, period=14, resolution=None):
        return self._register(ADX(symbol, period))

    def OBV(self, symbol, resolution=None):
        return self._register(OBV(symbol))

    def VWAP(self, symbol, period=20, resolution=None):
        return self._register(VWAP(symbol, period))

    def ParabolicSAR(self, symbol, step=0.02, max_step=0.2, resolution=None):
        return self._register(ParabolicSAR(symbol, step, max_step))

    def Ichimoku(self, symbol, tenkan=9, kijun=26, senkou=52, resolution=None):
        return self._register(Ichimoku(symbol, tenkan, kijun, senkou))

    def KeltnerChannels(self, symbol, period=20, k=2.0, atr_period=10, resolution=None):
        return self._register(KeltnerChannels(symbol, period, k, atr_period))

    def DonchianChannels(self, symbol, period=20, resolution=None):
        return self._register(DonchianChannels(symbol, period))

    def HeikinAshi(self, symbol, resolution=None):
        return self._register(HeikinAshi(symbol))

    def TRIX(self, symbol, period=12, resolution=None):
        return self._register(TRIX(symbol, period))

    def TSI(self, symbol, r=13, s=25, resolution=None):
        return self._register(TSI(symbol, r, s))

    def MFI(self, symbol, period=14, resolution=None):
        return self._register(MFI(symbol, period))

    def Aroon(self, symbol, period=25, resolution=None):
        return self._register(Aroon(symbol, period))

    def ForceIndex(self, symbol, period=1, resolution=None):
        return self._register(ForceIndex(symbol, period))

    # ── Target-based position sizing ──
    def OrderTargetPercent(self, symbol, percent):
        """Set a position to a target % of the portfolio. 0.1 = 10%."""
        key = str(symbol)
        sec = self._securities.get(key)
        if not sec or sec.Price <= 0:
            return
        target_qty = int((percent * self.Portfolio.TotalPortfolioValue) / sec.Price)
        self._orders.append((key, target_qty))

    def OrderTargetValue(self, symbol, value):
        """Set a position to a target $ value."""
        key = str(symbol)
        sec = self._securities.get(key)
        if not sec or sec.Price <= 0:
            return
        target_qty = int(value / sec.Price)
        self._orders.append((key, target_qty))

    # ── Order management ──
    def GetOpenOrders(self):
        """Return all pending tickets (limit/stop orders not yet filled)."""
        return [t for t in self._tickets if t.Status == 'Submitted']

    def CancelOrder(self, ticket):
        """Cancel a pending order ticket."""
        if hasattr(ticket, 'Status'):
            ticket.Status = 'Canceled'
            return True
        return False

    def Transactions(self):
        return _TransactionManager(self)

    # ── Order event callback ──
    def OnOrderEvent(self, orderEvent):
        """Override to react when an order fills, cancels, or is submitted."""
        pass

    def RegisterIndicator(self, symbol, indicator, resolution=None):
        """Register a manually-created indicator to a symbol so it gets updated."""
        return self._register(indicator)

    # ── History ──
    def History(self, symbol, periods, resolution=Resolution.Daily):
        """Look back at the last `periods` bars for `symbol`. Returns a list of
        Bar objects (oldest first). Only works after the engine has seen enough
        bars; returns a short list during warm-up."""
        key = _key(symbol)
        history = self._bar_history.get(key, [])
        return history[-periods:] if periods <= len(history) else history[:]

    # ── Plotting ──
    def Plot(self, chart, series, value=None):
        """Custom chart. Plot('Equity', 'Strategy', 100.5) appends to the chart's
        series. Plot('Title', value) uses a default series name."""
        if value is None:
            value = series
            series = 'Series'
        if chart not in self._plots:
            self._plots[chart] = {}
        if series not in self._plots[chart]:
            self._plots[chart][series] = []
        self._plots[chart][series].append(float(value))

    # ── Scheduled events ──
    @property
    def Schedule(self):
        """self.Schedule.On(date_rules, time_rules, callback) — fires `callback`
        on the schedule."""
        if not hasattr(self, '_scheduler'):
            self._scheduler = _Scheduler(self)
        return self._scheduler

    # ── Consolidators ──
    def Consolidate(self, symbol, period, handler):
        """Register a bar consolidator for `symbol` that calls `handler(bar)`
        every `period` bars (int) or timedelta."""
        cons = TradeBarConsolidator(period)
        cons.handler = handler
        self._consolidators.append((_key(symbol), cons))
        return cons

    # ── Lifecycle callbacks ──
    def OnEndOfAlgorithm(self):
        """Override to run after the backtest completes."""
        pass

    def OnSecuritiesChanged(self, changes):
        """Override to react when securities enter/leave the universe."""
        pass

    def Quit(self, message=''):
        """Stop the backtest immediately."""
        self._quit = True
        self._logs.append('Quit: ' + str(message) if message else 'Quit called.')

    def Stop(self):
        self._quit = True

    # ── Orders ──
    def SetHoldings(self, symbol, fraction):
        """Set a target portfolio fraction. Negative fraction = short."""
        key = str(symbol)
        sec = self._securities.get(key)
        if not sec or sec.Price <= 0:
            return
        tpv = self.Portfolio.TotalPortfolioValue
        target = int((fraction * tpv) / sec.Price)
        self._orders.append((key, target))

    def MarketOrder(self, symbol, quantity):
        """Order to a fixed signed quantity. Negative = sell/short. Fills at
        the next bar's open."""
        self._orders.append((str(symbol), self.Portfolio[str(symbol)].Quantity + int(quantity)))

    def MarketOnOpenOrder(self, symbol, quantity):
        """Market order that fills at the next bar's open (same as MarketOrder
        in this engine — all market orders fill at next bar open)."""
        self.MarketOrder(symbol, quantity)

    def MarketOnCloseOrder(self, symbol, quantity):
        """Market order that fills at the current bar's close."""
        key = str(symbol)
        sec = self._securities.get(key)
        if not sec or sec.Price <= 0:
            return
        cur = self.Portfolio[key].Quantity
        target = cur + int(quantity)
        self._orders_close.append((key, target))

    def Buy(self, symbol, quantity):
        if quantity < 0:
            raise ValueError('Buy quantity must be positive; use Sell to short.')
        cur = self.Portfolio[str(symbol)].Quantity
        self._orders.append((str(symbol), cur + int(quantity)))

    def Sell(self, symbol, quantity):
        if quantity < 0:
            raise ValueError('Sell quantity must be positive; use Buy to add to a long.')
        cur = self.Portfolio[str(symbol)].Quantity
        self._orders.append((str(symbol), cur - int(quantity)))

    def SellShort(self, symbol, quantity):
        if quantity < 0:
            raise ValueError('SellShort quantity must be positive.')
        cur = self.Portfolio[str(symbol)].Quantity
        self._orders.append((str(symbol), cur - int(quantity)))

    def Liquidate(self, symbol=None):
        if symbol is None:
            for k in self._securities:
                self._orders.append((k, 0))
        else:
            self._orders.append((str(symbol), 0))

    def LimitOrder(self, symbol, quantity, limit_price):
        t = LimitOrderTicket(symbol, quantity, limit_price)
        self._tickets.append(t)
        return t

    def StopMarketOrder(self, symbol, quantity, stop_price):
        t = StopMarketOrderTicket(symbol, quantity, stop_price)
        self._tickets.append(t)
        return t

    def StopLimitOrder(self, symbol, quantity, stop_price, limit_price):
        t = StopLimitOrderTicket(symbol, quantity, stop_price, limit_price)
        self._tickets.append(t)
        return t

    def TrailingStopOrder(self, symbol, quantity, trailing_amount, is_percentage=True):
        """Trailing stop: for a long, trails the highest high by `trailing_amount`
        (a fraction if is_percentage=True, a dollar amount if False). For a short,
        trails the lowest low. Fills when the price reverses by the trailing amount."""
        t = TrailingStopOrderTicket(symbol, quantity, trailing_amount, is_percentage)
        self._tickets.append(t)
        return t

    # ── Risk management ──
    def SetRiskManagement(self, model):
        """Attach a risk management model. The model's manage() is called before
        each bar's orders are executed, and can scale down or zero out positions.
        Models: MaximumDrawdownPercent, MaximumExposure, MaximumPositionSize."""
        self._risk_model = model

    def Log(self, msg):
        self._logs.append(str(msg))

    def Debug(self, msg):
        self._logs.append(str(msg))

    def Initialize(self):
        pass

    def OnData(self, slice):
        pass


# ── Bars parsing ────────────────────────────────────────────────────

def parse_bars(csv):
    """Parse a bars CSV. Returns a list of dicts: {symbol, date, o, h, l, c, v}.

    Accepts:
      date,open,high,low,close,volume             (single symbol — caller sets it)
      date,symbol,open,high,low,close,volume      (multi-symbol)
      symbol,date,open,high,low,close,volume
    Any of open/high/low/close may use the aliases 'o/h/l/c'. Skips the header
    and any unparseable row.
    """
    bars = []
    for line in (csv or '').strip().splitlines():
        line = line.strip()
        if not line:
            continue
        parts = [p.strip() for p in line.replace(';', ',').split(',')]
        lower0 = parts[0].lower()
        lower1 = parts[1].lower() if len(parts) > 1 else ''
        if lower0 in ('symbol', 'ticker', 'sym') or lower1 in ('symbol', 'ticker', 'sym') or \
           lower0 in ('date', 'datetime', 'time') and lower1 in ('symbol', 'ticker', 'sym'):
            continue
        if lower0.startswith(('date', 'datetime', 'time')) or 'open' in lower0 or 'open' in lower1:
            # Header row for the single- or multi-symbol shape.
            continue
        if len(parts) < 5:
            continue
        try:
            # Multi-symbol: symbol is the first or second column.
            symbol = None
            if parts[0] and not _looks_like_date(parts[0]) and not _is_number(parts[0]):
                symbol = parts[0]
                d, o, h, l, c = parts[1], float(parts[2]), float(parts[3]), float(parts[4]), float(parts[5])
                v = float(parts[6]) if len(parts) > 6 and parts[6] else 0.0
            elif len(parts) > 6 and parts[1] and not _looks_like_date(parts[1]) and not _is_number(parts[1]):
                symbol = parts[1]
                d, o, h, l, c = parts[0], float(parts[2]), float(parts[3]), float(parts[4]), float(parts[5])
                v = float(parts[6]) if len(parts) > 6 and parts[6] else 0.0
            else:
                d = parts[0]
                o, h, l, c = float(parts[1]), float(parts[2]), float(parts[3]), float(parts[4])
                v = float(parts[5]) if len(parts) > 5 and parts[5] else 0.0
            bars.append({'symbol': symbol, 'date': d, 'o': o, 'h': h, 'l': l, 'c': c, 'v': v})
        except (ValueError, IndexError):
            continue
    bars.sort(key=lambda b: b['date'])
    return bars


def _looks_like_date(s):
    s = str(s)
    return bool(s and (s[0:4].isdigit() or '/' in s))


def _is_number(s):
    try:
        float(s)
        return True
    except (ValueError, TypeError):
        return False


def default_bars(symbol='SPY', bars=252, start_price=400.0, seed=42):
    """A clearly-synthetic GBM series so the engine runs with no data file."""
    random.seed(seed)
    out = []
    price = float(start_price)
    d = datetime.date(2023, 1, 3)
    for _ in range(bars):
        ret = random.gauss(0.0004, 0.011)
        price = max(1.0, price * (1 + ret))
        o = price * (1 + random.gauss(0, 0.003))
        c = price
        h = max(o, c) * (1 + abs(random.gauss(0, 0.003)))
        l = min(o, c) * (1 - abs(random.gauss(0, 0.003)))
        out.append({'symbol': symbol, 'date': d.isoformat(), 'o': round(o, 2),
                    'h': round(h, 2), 'l': round(l, 2), 'c': round(c, 2), 'v': 1000000})
        d += datetime.timedelta(days=1 if d.weekday() < 4 else 3)
    return out


# ── Fill + run ───────────────────────────────────────────────────────

def _fill_market(algo, key, target_qty, fill_price):
    """Apply a target-quantity market fill at `fill_price`, with commission
    and slippage. Handles long, short, and flat transitions."""
    s = algo._securities[key]
    cur = s.Holdings.Quantity
    delta = target_qty - cur
    if delta == 0:
        return None
    slip = s.SlippageModel.adjust(delta, fill_price)
    notional = abs(delta) * slip
    fee = s.CommissionModel.fee(delta, slip)
    # Cash check for buys only (longs add). Shorts release cash.
    if delta > 0 and notional + fee > algo.Portfolio._cash and algo.Portfolio._cash > 0:
        # Cap to what cash allows. Never go negative on a buy.
        delta = int((algo.Portfolio._cash - fee) // slip) if slip > 0 else 0
        if delta <= 0:
            return None
        notional = abs(delta) * slip
        fee = s.CommissionModel.fee(delta, slip)
    new_qty = cur + delta
    realized = 0.0
    # Closing or flipping: realize P&L on the closed portion.
    if cur > 0 and delta < 0:
        closed = min(cur, -delta)
        realized = (slip - s.Holdings.AveragePrice) * closed
    elif cur < 0 and delta > 0:
        closed = min(-cur, delta)
        realized = (s.Holdings.AveragePrice - slip) * closed
    algo.Portfolio._cash -= delta * slip + fee
    s.Holdings.TotalFees += fee
    if new_qty == 0:
        s.Holdings.Quantity = 0
        s.Holdings.AveragePrice = 0.0
        s.Holdings.Invested = False
    else:
        if cur == 0 or (cur > 0) == (new_qty > 0) and abs(new_qty) > abs(cur):
            # Opening or adding to a position in the same direction.
            if cur == 0:
                s.Holdings.AveragePrice = slip
            else:
                s.Holdings.AveragePrice = (abs(cur) * s.Holdings.AveragePrice + abs(delta) * slip) / abs(new_qty)
        elif (cur > 0) != (new_qty > 0):
            # Flipped sign — average price resets to the new side's entry.
            s.Holdings.AveragePrice = slip
        s.Holdings.Quantity = new_qty
        s.Holdings.Invested = True
    return {'symbol': key, 'qty': delta, 'price': round(slip, 2),
            'pnl': round(realized, 2), 'fee': round(fee, 2)}


def _group_bars_by_date(bars):
    """Group bars by their date string. Multi-symbol bars for the same date
    share a slice. Returns an ordered list of (date, [bars])."""
    out = {}
    order = []
    for b in bars:
        d = b['date']
        if d not in out:
            out[d] = []
            order.append(d)
        out[d].append(b)
    return [(d, out[d]) for d in order]


def run_backtest(AlgoClass, bars=None, cash=100000, start=None, end=None, symbol='SPY', params=None):
    """Run a single algorithm over the supplied bars.

    `bars` may be:
      - None (use synthetic single-symbol GBM bars)
      - a list of dicts from parse_bars() (multi-symbol supported)
      - a CSV string (parsed here)
    `symbol` is only used when the bars are single-symbol (no symbol column).
    """
    synthetic = False
    if bars is None:
        bars = default_bars(symbol)
        synthetic = True
    elif isinstance(bars, str):
        bars = parse_bars(bars)
    # If every bar has a None symbol, fill it from the `symbol` arg.
    if all(b.get('symbol') is None for b in bars):
        for b in bars:
            b['symbol'] = str(symbol)

    algo = AlgoClass()
    algo.SetCash(cash)
    algo.Params = dict(params or {})
    # AddEquity for every symbol the algorithm will see. The user's Initialize
    # also calls AddEquity; if they overlap we keep the existing security.
    seen = set()
    for b in bars:
        seen.add(b['symbol'])
    # Add the symbols the algorithm didn't add explicitly so prices always update.
    pre_added = set(algo._securities.keys())
    for s in seen:
        if s not in pre_added:
            algo.AddEquity(s, algo._resolution)
    # Now run the user's Initialize AFTER pre-adding, so they can override
    # commission/slippage and AddEquity cleanly.
    try:
        algo.Initialize()
    except Exception as e:
        return {'error': 'Initialize error: ' + str(e)}
    if start:
        algo._start = _parsedate(start)
    if end:
        algo._end = _parsedate(end)

    init_cash = algo.Portfolio._cash
    equity = []
    trades = []
    plots = {}
    n_bars = 0
    pending_market = []   # list of (key, target_qty) — fills at next bar's open
    pending_tickets = []   # limit/stop tickets still open
    bars_by_date = _group_bars_by_date(bars)
    last_slice = None
    _fired_scheduled = set()  # (date_rule_id, time_rule_id, date) — avoid double-firing
    for (d, day_bars) in bars_by_date:
        dt = _parsedate(d)
        if algo._start and dt and dt < algo._start:
            continue
        if algo._end and dt and dt > algo._end:
            break
        if algo._quit:
            break

        # 1. Set each security's price + OHLC + bid/ask BEFORE fills so the
        #    user's OnData sees the current mark.
        for b in day_bars:
            sec = algo._securities.get(b['symbol'])
            if sec:
                sec.UpdatePrices(b['o'], b['h'], b['l'], b['c'], b['v'])
            # Track bar history for self.History()
            if b['symbol'] not in algo._bar_history:
                algo._bar_history[b['symbol']] = []
            algo._bar_history[b['symbol']].append(
                Bar(b['symbol'], dt, b['o'], b['h'], b['l'], b['c'], b['v']))

        # 1b. Universe selection — if AddUniverse was called, invoke the selector
        #     and add/remove securities. Fire OnSecuritiesChanged when the set changes.
        if algo._universe_selector is not None:
            try:
                selected = algo._universe_selector(dt) or []
                selected_set = set(str(s) for s in selected)
                current_set = set(algo._securities.keys())
                added = selected_set - current_set
                removed = current_set - selected_set
                if added:
                    for s in added:
                        if s not in algo._securities:
                            algo.AddEquity(s, algo._resolution)
                # Don't remove securities that have positions.
                to_remove = [s for s in removed if algo.Portfolio[s].Quantity == 0]
                if added or to_remove:
                    class _Changes:
                        def __init__(self, added, removed):
                            self.AddedSecurities = list(added)
                            self.RemovedSecurities = list(removed)
                    algo.OnSecuritiesChanged(_Changes(added, to_remove))
            except Exception as e:
                algo._logs.append('Universe selector error: ' + str(e))

        # 2. Market orders from the PREVIOUS bar fill at this bar's open.
        if pending_market:
            opens = {b['symbol']: b['o'] for b in day_bars}
            for (key, target_qty) in pending_market:
                if key in opens:
                    t = _fill_market(algo, key, target_qty, opens[key])
                    if t:
                        t['date'] = d
                        t['type'] = 'market'
                        trades.append(t)
            pending_market = []

        # 3. Limit / stop tickets: evaluate against THIS bar's high/low.
        for ticket in pending_tickets:
            if ticket.Status != 'Submitted':
                continue
            sec = algo._securities.get(_key(ticket.Symbol))
            if not sec:
                continue
            bar_for_sym = next((b for b in day_bars if b['symbol'] == _key(ticket.Symbol)), None)
            if not bar_for_sym:
                continue
            bar = Bar(b['symbol'], dt, bar_for_sym['o'], bar_for_sym['h'],
                       bar_for_sym['l'], bar_for_sym['c'], bar_for_sym['v'])
            fill_price = ticket.maybe_fill(bar)
            if fill_price is not None:
                cur = sec.Holdings.Quantity
                target = cur + ticket.Quantity
                t = _fill_market(algo, _key(ticket.Symbol), target, fill_price)
                if t:
                    t['date'] = d
                    t['type'] = ticket.OrderType
                    t['ticket'] = ticket.OrderType
                    trades.append(t)
                    ticket.Status = 'Filled'
                    ticket.FillQuantity = ticket.Quantity
                    ticket.FillPrice = fill_price
        pending_tickets = [t for t in pending_tickets if t.Status == 'Submitted']

        # 4. Update indicators with this bar's close.
        day_symbols = set(b['symbol'] for b in day_bars)
        for (key, ind) in algo._indicators:
            if key in day_symbols:
                bar_for_sym = next((b for b in day_bars if b['symbol'] == key), None)
                bar_obj = Bar(key, dt, bar_for_sym['o'], bar_for_sym['h'],
                              bar_for_sym['l'], bar_for_sym['c'], bar_for_sym['v'])
                if isinstance(ind, BarIndicator):
                    ind.Update(bar_obj)
                else:
                    ind.Update(bar_for_sym['c'])

        # 5. Run consolidators (fire handlers when bars complete).
        for (csym, cons) in algo._consolidators:
            if csym in day_symbols:
                bar_for_sym = next((b for b in day_bars if b['symbol'] == csym), None)
                cons.Update(Bar(csym, dt, bar_for_sym['o'], bar_for_sym['h'],
                                bar_for_sym['l'], bar_for_sym['c'], bar_for_sym['v']))

        # 6. Fire scheduled events.
        if algo._scheduled and not algo.IsWarmingUp and dt:
            for (dr, tr, cb) in algo._scheduled:
                if _should_fire_date(dr, dt) and _should_fire_time(tr, dt):
                    key = (id(dr), id(tr), dt.toordinal())
                    if key not in _fired_scheduled:
                        _fired_scheduled.add(key)
                        try:
                            cb()
                        except Exception as e:
                            algo._logs.append('Scheduled event error: ' + str(e))

        # 7. Run the user's OnData with a Slice of all bars for this date.
        slice_bars = [Bar(b['symbol'], dt, b['o'], b['h'], b['l'], b['c'], b['v']) for b in day_bars]
        slice_ = Slice(dt, slice_bars)
        algo.Time = dt
        algo.UtcTime = dt
        last_slice = slice_
        algo._bars_since_warmup += 1
        try:
            algo.OnData(slice_)
        except Exception as e:
            return {'error': 'OnData error: ' + str(e), 'logs': algo._logs[-50:],
                    'equity': equity, 'trades': trades,
                    'metrics': _metrics(equity, trades, init_cash, algo._resolution),
                    'plots': algo._plots}

        # 8. MarketOnClose orders — fill at the current bar's close.
        if algo._orders_close:
            closes = {b['symbol']: b['c'] for b in day_bars}
            for (key, target_qty) in algo._orders_close:
                if key in closes:
                    t = _fill_market(algo, key, target_qty, closes[key])
                    if t:
                        t['date'] = d
                        t['type'] = 'market_on_close'
                        trades.append(t)
            algo._orders_close = []

        # 8b. Apply risk management to the pending market orders.
        if algo._risk_model is not None and algo._orders:
            try:
                targets = {k: v for (k, v) in algo._orders}
                managed = algo._risk_model.manage(algo, targets)
                algo._orders = [(k, managed.get(k, v)) for (k, v) in algo._orders]
            except Exception as e:
                algo._logs.append('Risk management error: ' + str(e))

        # 9. Collect this bar's market + ticket orders for the next bar.
        pending_market = algo._orders
        algo._orders = []
        pending_tickets.extend(algo._tickets)
        algo._tickets = []

        # 9b. Benchmark tracking — if SetBenchmark was called, record the
        #     benchmark symbol's cumulative return.
        if algo._benchmark_symbol and algo._benchmark_symbol in algo._securities:
            bsec = algo._securities[algo._benchmark_symbol]
            if bsec.Price > 0:
                algo._benchmark_equity.append([d, bsec.Price])

        equity.append([d, round(algo.Portfolio.TotalPortfolioValue, 2)])
        n_bars += 1

    # Mark-to-market unrealized for any open positions at the end.
    for k, s in algo._securities.items():
        if s.Holdings.Quantity:
            s.Holdings.UnrealizedProfit = (s.Price - s.Holdings.AveragePrice) * s.Holdings.Quantity

    # Fire OnEndOfAlgorithm.
    try:
        algo.OnEndOfAlgorithm()
    except Exception as e:
        algo._logs.append('OnEndOfAlgorithm error: ' + str(e))

    return {
        'equity': equity,
        'trades': trades,
        'trades_count': len(trades),
        'bars': n_bars,
        'synthetic_data': synthetic,
        'metrics': _metrics(equity, trades, init_cash, algo._resolution, algo._benchmark_equity),
        'logs': algo._logs[-50:],
        'plots': algo._plots,
        'benchmark_equity': algo._benchmark_equity,
    }


# ── Metrics ─────────────────────────────────────────────────────────

def _metrics(equity, trades, init_cash, resolution=Resolution.Daily, benchmark_equity=None):
    """Compute the full institutional metric set on the equity + trade list.
    If benchmark_equity is provided (list of [date, price] for a buy-and-hold),
    also computes benchmark return, alpha, beta, information ratio, tracking
    error, R-squared, and up/down capture ratios."""
    bars_per_year = BARS_PER_YEAR.get(resolution, 252)
    if not equity:
        return {'initial': init_cash, 'final': init_cash, 'net': 0, 'return_pct': 0,
                'max_drawdown_pct': 0, 'trades': 0, 'win_rate': 0, 'sharpe': 0,
                'sortino': 0, 'max_drawdown_duration': 0, 'exposure_pct': 0,
                'turnover': 0, 'profit_factor': 0, 'calmar': 0,
                'benchmark_return_pct': None, 'alpha': None, 'beta': None,
                'information_ratio': None, 'tracking_error': None, 'r_squared': None,
                'up_capture': None, 'down_capture': None}
    eq = [e[1] for e in equity]
    final = eq[-1]
    net = final - init_cash
    ret_pct = (net / init_cash * 100) if init_cash else 0

    peak = eq[0]
    mdd = 0.0
    cur_dd = 0
    max_dd_dur = 0
    cur_dd_dur = 0
    for v in eq:
        if v > peak:
            peak = v
            cur_dd_dur = 0
        else:
            cur_dd = peak - v
            cur_dd_dur += 1
            if cur_dd_dur > max_dd_dur:
                max_dd_dur = cur_dd_dur
        if peak > 0:
            mdd = max(mdd, (peak - v) / peak)

    # Per-bar returns for Sharpe / Sortino (annualized).
    rets = [eq[i] / eq[i - 1] - 1 for i in range(1, len(eq)) if eq[i - 1] > 0]
    n = len(rets)
    mean = sum(rets) / n if n else 0.0
    var = sum((r - mean) ** 2 for r in rets) / n if n else 0.0
    std = math.sqrt(var) if n else 0.0
    sharpe = (mean / std * math.sqrt(bars_per_year)) if std > 0 else 0.0
    downside = [r for r in rets if r < 0]
    dd_sum = sum(r * r for r in downside) / max(n, 1)
    dd_std = math.sqrt(dd_sum) if dd_sum > 0 else 0.0
    sortino = (mean / dd_std * math.sqrt(bars_per_year)) if dd_std > 0 else 0.0
    calmar = (ret_pct / 100 * bars_per_year / (mdd * 100)) if mdd > 0 else 0.0

    # Trade-based stats (closed trades only — pnl != 0).
    pnls = [t['pnl'] for t in trades if t.get('pnl')]
    n_trades = len(pnls)
    wins = sum(1 for p in pnls if p > 0)
    win_rate = (wins / n_trades * 100) if n_trades else 0
    gross_w = sum(p for p in pnls if p > 0)
    gross_l = abs(sum(p for p in pnls if p < 0))
    profit_factor = (gross_w / gross_l) if gross_l > 0 else (float('inf') if gross_w > 0 else 0)

    # Exposure: fraction of bars where any position was open.
    exposure_pct = min(100.0, (n_trades / max(len(eq), 1)) * 100) if eq else 0
    # Turnover: sum of |qty| * fill price / initial cash.
    turnover = 0.0
    for t in trades:
        turnover += abs(t.get('qty', 0)) * t.get('price', 0)
    turnover = (turnover / init_cash) if init_cash else 0

    # ── Benchmark comparison ──
    bm_ret_pct = None
    alpha_v = None
    beta_v = None
    info_ratio = None
    tracking_err = None
    r_sq = None
    up_cap = None
    dn_cap = None

    if benchmark_equity and len(benchmark_equity) > 2:
        bm_prices = [b[1] for b in benchmark_equity]
        bm_ret_pct = ((bm_prices[-1] - bm_prices[0]) / bm_prices[0] * 100) if bm_prices[0] > 0 else 0
        bm_rets = [bm_prices[i] / bm_prices[i - 1] - 1 for i in range(1, len(bm_prices)) if bm_prices[i - 1] > 0]
        # Align strategy and benchmark returns by length.
        min_len = min(len(rets), len(bm_rets))
        if min_len >= 3:
            sr = rets[:min_len]
            br = bm_rets[:min_len]
            bm_mean = sum(br) / min_len
            bm_var = sum((r - bm_mean) ** 2 for r in br) / min_len
            if bm_var > 0:
                cov = sum((sr[i] - mean) * (br[i] - bm_mean) for i in range(min_len)) / min_len
                beta_v = cov / bm_var
                alpha_v = mean - beta_v * bm_mean
                # Tracking error = std of (strategy - benchmark) returns
                active = [sr[i] - br[i] for i in range(min_len)]
                act_mean = sum(active) / min_len
                act_var = sum((r - act_mean) ** 2 for r in active) / min_len
                tracking_err = math.sqrt(act_var) if act_var > 0 else 0.0
                info_ratio = (act_mean / tracking_err * math.sqrt(bars_per_year)) if tracking_err > 0 else 0.0
                # R-squared
                ss_res = sum((sr[i] - (alpha_v + beta_v * br[i])) ** 2 for i in range(min_len))
                ss_tot = sum((r - mean) ** 2 for r in sr)
                r_sq = 1 - ss_res / ss_tot if ss_tot > 0 else 0
            # Up/Down capture: average strategy return in up / down benchmark bars
            up_strat = [sr[i] for i in range(min_len) if br[i] > 0]
            up_bm = [br[i] for i in range(min_len) if br[i] > 0]
            dn_strat = [sr[i] for i in range(min_len) if br[i] < 0]
            dn_bm = [br[i] for i in range(min_len) if br[i] < 0]
            if up_bm and sum(up_bm) != 0:
                up_cap = (sum(up_strat) / len(up_strat)) / (sum(up_bm) / len(up_bm)) if sum(up_bm) != 0 else None
            if dn_bm and sum(dn_bm) != 0:
                dn_cap = (sum(dn_strat) / len(dn_strat)) / (sum(dn_bm) / len(dn_bm)) if sum(dn_bm) != 0 else None

    return {
        'initial': round(init_cash, 2), 'final': round(final, 2),
        'net': round(net, 2), 'return_pct': round(ret_pct, 2),
        'max_drawdown_pct': round(mdd * 100, 2),
        'max_drawdown_duration': max_dd_dur,
        'trades': n_trades, 'win_rate': round(win_rate, 2),
        'sharpe': round(sharpe, 2), 'sortino': round(sortino, 2),
        'calmar': round(calmar, 2),
        'profit_factor': round(profit_factor, 2) if profit_factor != float('inf') else None,
        'exposure_pct': round(exposure_pct, 2),
        'turnover': round(turnover, 2),
        'benchmark_return_pct': round(bm_ret_pct, 2) if bm_ret_pct is not None else None,
        'alpha': round(alpha_v, 4) if alpha_v is not None else None,
        'beta': round(beta_v, 4) if beta_v is not None else None,
        'information_ratio': round(info_ratio, 2) if info_ratio is not None else None,
        'tracking_error': round(tracking_err, 4) if tracking_err is not None else None,
        'r_squared': round(r_sq, 4) if r_sq is not None else None,
        'up_capture': round(up_cap, 2) if up_cap is not None else None,
        'down_capture': round(dn_cap, 2) if dn_cap is not None else None,
    }


# ── Scheduled events ─────────────────────────────────────────────────

class _Scheduler:
    """self.Schedule.On(date_rules, time_rules, callback) — fires `callback`
    on the schedule. Time-based scheduling is approximate: the callback fires
    on the first bar of each day that matches the date rules and at the bar
    closest to the time rules."""
    def __init__(self, algo):
        self._algo = algo
        self._events = algo._scheduled

    def On(self, date_rules, time_rules, callback):
        self._events.append((date_rules, time_rules, callback))
        return callback


class DateRules:
    @staticmethod
    def EveryDay():
        return ('every_day', None)

    @staticmethod
    def Every(days):
        return ('every_n_days', days)

    @staticmethod
    def On(year, month, day):
        return ('on_date', datetime.date(int(year), int(month), int(day)))

    @staticmethod
    def MonthStart(days=0):
        return ('month_start', days)

    @staticmethod
    def MonthEnd(days=0):
        return ('month_end', days)

    @staticmethod
    def WeekStart(days=0):
        return ('week_start', days)

    @staticmethod
    def WeekEnd(days=0):
        return ('week_end', days)


class TimeRules:
    @staticmethod
    def Every(interval):
        return ('every', interval)

    @staticmethod
    def At(hour, minute=0):
        return ('at', (hour, minute))

    @staticmethod
    def AfterMarketOpen(minutes=0):
        return ('after_open', minutes)

    @staticmethod
    def BeforeMarketClose(minutes=0):
        return ('before_close', minutes)

    @staticmethod
    def Noon():
        return ('at', (12, 0))


def _should_fire_date(date_rule, dt):
    kind, arg = date_rule
    if kind == 'every_day':
        return True
    if kind == 'every_n_days':
        return dt.toordinal() % max(arg, 1) == 0
    if kind == 'on_date':
        return dt == arg
    if kind == 'month_start':
        return dt.day == 1 + arg
    if kind == 'month_end':
        next_month = dt.replace(day=28) + datetime.timedelta(days=4)
        last_day = (next_month - datetime.timedelta(days=next_month.day)).day
        return dt.day >= last_day - arg
    if kind == 'week_start':
        return dt.weekday() == arg
    if kind == 'week_end':
        return dt.weekday() == 4 - arg
    return False


def _should_fire_time(time_rule, dt):
    kind, arg = time_rule
    if kind == 'every':
        return True
    # Daily bars (datetime.date, not datetime.datetime) have no hour/minute.
    # Treat them as the market open (9:30) so time rules fire on the right day.
    has_time = hasattr(dt, 'hour')
    hour = dt.hour if has_time else 9
    minute = dt.minute if has_time else 30
    if kind == 'at':
        return (hour, minute) == arg
    if kind == 'after_open':
        return hour == 9 and minute >= 30 + (arg or 0)
    if kind == 'before_close':
        return hour == 16
    return False


# ── Consolidators ──────────────────────────────────────────────────

class TradeBarConsolidator:
    """Aggregates bars into larger bars. `period` is either an int (number of
    bars) or a datetime.timedelta. The consolidated bar is passed to the handler
    callback when it completes."""
    def __init__(self, period):
        if isinstance(period, datetime.timedelta):
            self._timedelta = period
            self._count = None
        else:
            self._count = int(period)
            self._timedelta = None
        self._bars = []
        self._last_time = None
        self.handler = None

    def Update(self, bar):
        """Push a new bar. Returns the consolidated bar if one was produced."""
        self._bars.append(bar)
        fire = False
        if self._count is not None:
            if len(self._bars) >= self._count:
                fire = True
        elif self._timedelta is not None and self._last_time is not None:
            if (bar.Time - self._last_time) >= self._timedelta:
                fire = True
        if fire:
            consolidated = self._consolidate()
            self._bars = []
            self._last_time = bar.Time
            if self.handler and consolidated:
                self.handler(consolidated)
            return consolidated
        self._last_time = bar.Time
        return None

    def _consolidate(self):
        if not self._bars:
            return None
        first = self._bars[0]
        last = self._bars[-1]
        o = first.Open
        c = last.Close
        h = max(b.High for b in self._bars)
        l = min(b.Low for b in self._bars)
        v = sum(b.Volume for b in self._bars)
        return Bar(first.Symbol, first.Time, o, h, l, c, v)


# When imported as `BelfortEngine` (or `AlgorithmImports` alias), expose the public API.
__all__ = ['QCAlgorithm', 'Resolution', 'Symbol',
           'SMA', 'EMA', 'RSI', 'MACD', 'BollingerBands', 'STDDEV', 'ATR', 'MOM', 'ROC',
           'WilderMA', 'Maximum', 'Minimum',
           'Stochastic', 'CCI', 'WilliamsR', 'ADX', 'OBV', 'VWAP',
           'ParabolicSAR', 'Ichimoku', 'KeltnerChannels', 'DonchianChannels', 'HeikinAshi',
           'TRIX', 'TSI', 'MFI', 'Aroon', 'ForceIndex', 'MarketImpactModel',
           'Security', 'Holdings', 'Portfolio', 'Bar', 'Slice', 'Indicator', 'BarIndicator',
           'OrderTicket', 'MarketOrderTicket', 'LimitOrderTicket',
           'StopMarketOrderTicket', 'StopLimitOrderTicket', 'TrailingStopOrderTicket',
           'OrderEvent',
           'CommissionModel', 'ConstantCommissionModel', 'PercentCommissionModel',
           'SlippageModel', 'ConstantSlippageModel', 'PercentSlippageModel',
           'VolumeShareSlippageModel',
           'FillModel', 'ImmediateFillModel', 'VolumeWeightedAveragePriceFill',
           'RiskManagementModel', 'MaximumDrawdownPercent', 'MaximumExposure', 'MaximumPositionSize',
           'DateRules', 'TimeRules', 'TradeBarConsolidator',
           'parse_bars', 'run_backtest', 'default_bars', 'BARS_PER_YEAR']
