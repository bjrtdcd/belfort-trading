# Belfort Trading

The quant workflow for traders: backtest a trade log, stress-test it, and develop the
strategy in a GitHub Codespace attached to your own account.

Static site — no application server. Everything runs in the browser and talks directly to
GitHub's API. The only server-side piece in the whole product is an optional OAuth token
exchange (`server/github-token-worker.js`).

## Run it

```bash
python -m http.server 4173
```

Then open <http://localhost:4173/>. Any static file server works; there is no build step
for the site itself.

**⌘K / Ctrl-K** opens the command palette on any page — search pages and actions,
jump to a route, start a backtest, create a codespace, subscribe, sign out.

To rebuild the backtester engine (UI + shared pure engine) and the MCP server after
editing `backtester-src/*.ts` or `mcp/server.ts`:

```bash
npm install
npm run build     # backtester UI + backtester/engine.js + mcp/dist/server.mjs
npm test         # backtester suite (15) + MCP suite (8) + code-server suite (9)
```

Run the backtester as an MCP server (Claude Desktop, Cursor, opencode — see
`mcp/README.md` for wiring):

```bash
npm run build:mcp && node mcp/dist/server.mjs   # or: npm run mcp (tsx, no build)
```

## What's in here

| Path | What it is |
| --- | --- |
| `index.html` | Marketing homepage. A scraped Next.js export — compiled chunks, not source. See `routes/README.md`. |
| `strategy-validator/` | The backtester. Verdict and headline figures first, then equity, Monte Carlo, prop firms, a risk surface, the calendar, the metrics table and the trade log; the wider chart library sits behind folds. Runs on `backtester/engine.js`. |
| `strategy-validator/classic/` | The previous report, kept verbatim: 50 charts across four tabs with the chart picker. Linked from the new report, and tagged `report-v1-2026-08-21`. |
| `backtester-src/` | TypeScript source for the engine. `main.ts` is the UI entry; `engine.ts` re-exports the pure, DOM-free engine. |
| `backtester/engine.js` | Bundled pure engine as `window.BelfortEngine`, used by the Quant Copilot agent. Built by `npm run build:engine`. |
| `workspace/` | Signed-in dashboard: overview, backtests, workspaces, GitHub, profile, subscription, balance, admin. |
| `workspace/ide/` | VS Code-style editor over a linked repository — reads and commits through the GitHub API. |
| `mcp/` | Model Context Protocol server exposing the backtester engine as tools (`backtest`, `monte_carlo`, `prop_firm_sim`, `validate`, `graph_3d`, …). Run with `npm run mcp`. See `mcp/README.md`. |
| `docker/` + `.github/workflows/publish-image.yml` | The Quant Workspace Docker image (Python + backtester engine + MCP server + Jupyter, prebuilt). Publish to ghcr.io, then flip `available: true` on the `quantpad` image in `config/github.js` so every Codespace gets the full tooling. See `docker/README.md`. |
| `server/codeserver/` + `.github/workflows/publish-codeserver-image.yml` | The **real VS Code** on Linux — code-server (Coder) with the Belfort tooling prebuilt, launched per session by `api.js`, embedded in the Copilot. Needs a host with Docker you run. See `server/codeserver/README.md`. |
| `projects/`, `quant-copilot/` | Projects are real codespace-backed pages (create GitHub Codespaces via `js/codespaces.js`). **Quant Copilot** is now a VS Code-style workspace: a file-tree + Monaco editor, an **AI agent** (OpenAI-compatible, tool-calling — your key, your endpoint) on the right, and a **backtest queue** that dispatches Lean jobs to a VPS (`config/quantvps.js`). `social/` is still a shell. |
| `server/dev.js` | No-deps dev server: serves the static site **and** proxies `/v1/*` to an OpenAI-compatible upstream (Crusoe by default), injecting the key from `$AI_API_KEY`. When the key is in env it serves a managed `config/ai.js` so the AI works for **every user with no setup** — the key stays in the process env, never in the browser or the repo. |
| `server/aiproxy/proxy.js` + `server/aiproxy/README.md` | Production AI proxy (no static serving): `/v1/*` → upstream with the key from `$AI_API_KEY`, CORS, optional origin allowlist + per-IP rate limit. Deploy once, point `config/ai.js` at it. |
| `config/ai.js` | Publishable default AI config for the Quant Copilot. Empty by default (honest "not configured"); `server/dev.js` replaces it with a managed one when `$AI_API_KEY` is set. Never holds a real key. |
| `js/codespaces.js`, `js/codespace-creator.js` | Shared GitHub Codespaces engine + creator/connect modal used by projects + quant-copilot. |
| `js/copilot.js` | The Quant Copilot agent: a deterministic, in-browser tool-use agent over `BelfortEngine` (no LLM). |
| `js/command-palette.js` | Global ⌘K palette — the cohesion layer across every route. Self-contained. |
| `config/github.js` | GitHub integration settings (org, OAuth client, dev container images, machine types). |
| `config/stripe.js` | Stripe publishable key, plan + credit Payment Links, credit packages. Empty by default. |
| `server/github-token-worker.js` | Cloudflare Worker that exchanges an OAuth code for a token. Optional. |
| `js/` | Compiled homepage chunks plus hand-written enhancements (`chart-browser.js`, `nav-auth.js`, `sample-badge.js`, `pricing-static.js`, `nav-workspace.js`, `copilot.js`, `command-palette.js`). |
| `js/vendor/` | Plotly and GSAP, vendored so the validator works offline. |
| `css/workspace.css`, `css/copilot.css` | Shared `ws-*` / `gh-*` dashboard styles, and the Copilot agent UI. |
| `terms/`, `privacy/`, `disclaimer/`, `license/`, `acceptable-use/` | Legal pages. Marked draft. |
| `mockup/` | Examiner redesign mockup, design plan and original-UI reference captures. Not part of the served product; see `mockup/README.md`. |
| `NOTES.md` | Working notes, recent changes, and the backlog. Read this first. |

## GitHub Codespaces integration

Workspaces are real GitHub Codespaces created on the **signed-in user's own account** —
their machine hours, their billing, their repositories. Belfort Trading never hosts
anyone's code.

Two ways to link an account, whichever is configured first wins:

1. **Personal access token** (default, no backend). The connect dialog opens GitHub's
   token page with the right scopes preselected; the user pastes the token back. It is
   verified against `GET /user`, checked for the `codespace` scope, and stored only in
   that browser.
2. **OAuth** — set `clientId` and `tokenProxy` in `config/github.js` and deploy
   `server/github-token-worker.js`. The connect button then redirects to the real GitHub
   authorization screen. Required because GitHub's token endpoint needs the client secret
   and sends no CORS headers.

Set `org` in `config/github.js` to require membership of an organization; membership is
verified with `GET /orgs/{org}/members/{login}` before anything is stored.

Admins (currently `admin@admin.com`) can edit these settings from the workspace Admin tab
and copy out a snippet for `config/github.js`. **The client secret never goes in the
browser** — it belongs in the worker.

The GitHub tab has a **Diagnostics** panel that runs every call workspace creation
depends on (scopes, org membership, repo access, machine types, dev container) and prints
GitHub's own answer. Start there when something fails.

## Known gaps

These need a backend and are deliberately not faked:

- **Auth is `localStorage`-only.** Sign-up creates a local account in `quantpad-accounts`
  (browser-side SHA-256 of the password) and sign-in validates against it; the
  `admin@admin.com` / `admin` superuser still works. There is no server-side user
  database — nothing behind it is private.
- **Checkout is wired with Stripe Payment Links (no backend).** Each plan and each
  credit package is a fixed-price Payment Link in `config/stripe.js`; the workspace
  activates the plan / credits when Stripe bounces back. With no link configured the UI
  says "not configured" — it never fakes a purchase. A real backend is still needed for
  webhooks, custom-amount checkout, and cross-device sync. The homepage price is
  rendered statically by `js/pricing-static.js`.
- Backtests, workspaces and settings live in `localStorage` only — clearing site data
  deletes them, and nothing syncs between devices.
- `projects/` and `quant-copilot/` are real codespace-backed pages (they create GitHub
  Codespaces on your own account via the shared `js/codespaces.js` engine).
  `quant-copilot/` also hosts the in-browser Quant Copilot workspace (Monaco + an
  OpenAI-compatible AI agent + a Lean backtest queue); the AI runs against your own
  endpoint (key in localStorage) and the queue dispatches to a Lean VPS you connect
  (`config/quantvps.js`). `social/` is still a shell — the community library needs a backend.

Nothing in the product simulates a result. If GitHub refuses to create a codespace, the
card shows GitHub's error and a retry — it never invents one.

## Conventions

- No build step for the site. Edit HTML/CSS/JS directly; only `backtester-src/` compiles.
- Hand-written JS is plain ES5-ish, no framework, no bundler. Keep it that way for the
  static pages.
- The homepage nav is React-rendered from compiled chunks, so DOM tweaks there are
  re-applied after hydration (`js/nav-workspace.js`, `js/nav-auth.js`).
- Asset references carry `?v=belfort-YYYYMMDD`. Bump it when editing a compiled chunk,
  since their filenames are content-hashed but their contents are edited in place.
- Never commit `.env`, tokens, or Stripe secret keys. `config/*.js` holds publishable
  values only.

## Contributing

Branch off `main`, keep changes scoped, and update `NOTES.md` when behaviour changes.
Test by serving the site and walking the flow you touched — there is no CI yet.
