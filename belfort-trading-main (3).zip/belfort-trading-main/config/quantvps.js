// Quant backtest VPS config — the Lean engine backend.
//
// The Quant Copilot's Backtests tab dispatches Lean jobs here. Empty by default
// — jobs stay queued and the panel says so honestly (nothing is faked).
//
// To make the queue actually run, deploy the no-deps Lean runner:
//
//   cd server/lean-runner
//   LEAN_KEY=shared-secret node server.js        # default port 8788
//
// Then set apiBase + apiKey below to your runner. See server/lean-runner/README.md.
// The runner uses the SAME lean/lean.py engine the in-browser agent uses, so an
// algorithm that runs in the browser runs the same way on the VPS (with a real
// Python interpreter, real data if you POST a `data` field, and parallelism
// across jobs).
//
// Backend contract (implemented by server/lean-runner/server.js):
//   POST /backtest            { id, name, algorithm, algorithmPath, config, data? }
//                            -> { jobId }
//   GET  /jobs/:id            -> { status: "running"|"done"|"error", result?, error? }
//
// Until apiBase is set, the Quant Copilot queue keeps jobs in the browser and
// the in-browser BelfortEngine still handles trade-log backtests via the agent.

window.QUANTPAD_QUANTVPS = {
  apiBase: '',
  apiKey: '',
};
