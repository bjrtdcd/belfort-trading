// ── Stripe configuration for the workspace ───────────────────────
// Fill in your keys from https://dashboard.stripe.com/apikeys
// and your payment links from https://dashboard.stripe.com/payment-links
//
// This file is loaded by workspace/index.html, subscribe/index.html,
// projects/index.html and quant-copilot/index.html. Edit the values
// below (or regenerate from .env with a build script).
//
// Checkout is fully static: each plan and each credit package is a
// Stripe Payment Link (a fixed-price checkout hosted by Stripe). When
// a Payment Link is set, the Upgrade / Buy buttons redirect to it and
// the plan is activated when Stripe bounces back to the workspace. When
// a link is empty, the UI says "not configured" — it never fakes a
// purchase. Add a backend later for custom-amount checkout, webhooks,
// and cross-device sync.

window.QUANTPAD_STRIPE = {
  // Publishable key (safe to expose in frontend). Needed only if you
  // later switch to Stripe.js-embedded checkout; Payment Links do not
  // require it.
  publishableKey: '',

  // Payment Link URLs — create these in Stripe Dashboard → Payment
  // Links. Each must be configured to redirect back to
  // <origin>/workspace/ on success. When set, the Upgrade buttons
  // redirect here for checkout. Leave empty to show a "not configured"
  // message instead.
  paymentLinks: {
    pro:  '',   // e.g. https://buy.stripe.com/test_xxx
    team: '',   // e.g. https://buy.stripe.com/test_yyy
    // Used by the Balance tab and the Projects/Quant Copilot pages.
    // Single fallback link for a credit purchase; if you offer preset
    // packages below this is ignored in favour of the matching package.
    credits: '',
  },

  // Data-credit packages. Stripe Payment Links are fixed-price, so a
  // variable amount cannot be sent through them — offer presets
  // instead. Each package needs its own Payment Link created in
  // Stripe. The buy buttons show these; the workspace also falls back
  // to the custom-amount box (demo / pending) when none are set.
  // 1,000 credits = $3, so match each package's price in Stripe.
  creditPackages: [
    // { credits: 5000,  price: 15, link: 'https://buy.stripe.com/test_aaa' },
    // { credits: 10000, price: 30, link: 'https://buy.stripe.com/test_bbb' },
    // { credits: 25000, price: 75, link: 'https://buy.stripe.com/test_ccc' },
  ],

  // Price IDs (for server-side checkout sessions — requires a backend).
  // Not used by the static checkout; kept so the worker can pick them up
  // later.
  priceIds: {
    pro:  '',
    team: '',
  },

  // Redirect URLs after payment. These must match the after-payment
  // redirect configured on each Payment Link in Stripe. The workspace
  // reads the pending plan / purchase from sessionStorage on return.
  successUrl: window.location.origin + '/workspace/',
  cancelUrl:  window.location.origin + '/workspace/',
};
