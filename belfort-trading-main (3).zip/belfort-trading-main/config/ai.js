// Default AI config for the Quant Copilot agent. Publishable (no secrets here).
//
// By default this is empty and the page honestly says "not configured" — the
// user enters their own AI endpoint in Settings (stored in their browser only).
//
// To make the AI work for EVERY user with no setup (the key hidden on the
// server), do ONE of:
//
//   1) Run the dev server with the key in env:
//        AI_API_KEY=... node server/dev.js
//      It serves THIS file with `configured: true` + base `/v1` + model when
//      $AI_API_KEY is set, and proxies /v1/* to the upstream, injecting the key
//      from env. The browser only ever sends the placeholder "managed"; the real
//      key never reaches it. Users see base+model, never the key.
//
//   2) For production: deploy server/aiproxy/proxy.js with $AI_API_KEY set,
//      then set `configured: true` + `base` to your proxy URL below + `model`.
//      The key lives in the proxy env; this file holds only the public URL.
//
// `key` here is a non-secret placeholder the page sends; the proxy overrides it
// with the real key. Never put a real API key in this file — it's committed.

window.QUANTPAD_AI = {
  configured: false,
  base: '',
  model: '',
  key: '',
};
