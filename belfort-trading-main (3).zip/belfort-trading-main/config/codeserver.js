// Code-server backend config — the real VS Code on Linux.
// Fill these in to point the Copilot's "Real VS Code" panel at your deployed
// server/codeserver backend. Empty by default (the panel shows "not
// configured" until you set them, honestly — no fake VS Code).
//
//  apiBase  e.g. "https://cs-api.your-host.example"  (the API from api.js)
//  apiKey   the BELFORT_CS_API_KEY you set on the backend
//
// The backend launches a real code-server container per session and this page
// embeds it. See server/codeserver/README.md for deployment + security.

window.QUANTPAD_CODESERVER = {
  apiBase: '',
  apiKey: '',
};
