// ── GitHub configuration for the workspace ────────────────────────
// Workspaces run as Codespaces on the signed-in user's own GitHub account:
// their machine hours, their billing, their repos.
//
// Two ways to link an account. The connect button picks the first that is
// configured, so filling in clientId + tokenProxy takes precedence over tokens.
//
//  1. OAuth  (clientId + tokenProxy)
//     Real github.com/login/oauth/authorize redirect. Needs a small backend
//     because the code-for-token exchange requires the client secret, which
//     must never ship to the browser. A ready-made Cloudflare Worker is in
//     server/github-token-worker.js.
//
//  2. Personal access token  (allowPat: true — the default)
//     No backend at all. The connect dialog opens the real GitHub token page
//     with the right scopes preselected, the user pastes the token back, and
//     it is verified against api.github.com before anything is stored. The
//     token lives in that user's browser only.
//
// An admin can override org / clientId / tokenProxy / redirectUri / allowPat
// from the workspace Admin tab; those values are stored per browser.
// Paste the snippet it generates here to apply them for everyone.

window.QUANTPAD_GITHUB = {
  // Organization or team the user must belong to. Empty = any account.
  // Membership is verified with GET /orgs/{org}/members/{login} at link time.
  org: '',

  // GitHub OAuth App client id — https://github.com/settings/developers
  clientId: '',

  // Backend endpoint that swaps ?code= for an access token.
  // POST { code, redirect_uri } -> { access_token }
  tokenProxy: '',

  // Personal-access-token linking. Leave on unless you run the OAuth backend.
  allowPat: true,

  apiBase: 'https://api.github.com',

  // Scopes needed to create and manage Codespaces on the user's account.
  scopes: ['read:user', 'repo', 'codespace', 'read:org'],

  // Where GitHub sends the user back after authorizing. Must match the
  // callback URL registered on the OAuth App exactly.
  redirectUri: window.location.origin + '/workspace/',

  // ── Dev container images offered in the workspace creator ────────
  // `ref` is written into .devcontainer/devcontainer.json for the codespace.
  // Add the Belfort Trading image here once it is published, then flip available.
  images: [
    {
      id: 'default',
      name: 'Default — GitHub Codespaces (VS Code)',
      ref: 'mcr.microsoft.com/devcontainers/universal:2-linux',
      desc: 'The stock Codespaces universal image. Python, Node, Go, Java, gh CLI.',
      badge: 'Default',
      available: true,
    },
    {
      id: 'python',
      name: 'Python 3.12 + scientific stack',
      ref: 'mcr.microsoft.com/devcontainers/python:3.12',
      desc: 'Slimmer Python-only base. numpy, pandas, scipy preinstalled.',
      badge: null,
      available: true,
    },
    {
      id: 'quantpad',
      name: 'Belfort Trading Quant Image',
      // Built by docker/Dockerfile, published by .github/workflows/publish-image.yml.
      // After the first successful publish, flip `available: true` below — Codespaces
      // built from any repo will then use this image and get the full Belfort tooling
      // (Python scientific stack + backtester engine + MCP server + Jupyter) with no
      // postCreate install. Until then Copilot codespaces fall back to the python
      // image + the embedded engine (see js/codespaces.js writeDevcontainer).
      ref: 'ghcr.io/blndhm/quant-workspace:latest',
      desc: 'Backtester engine, MCP server, Python scientific stack + JupyterLab — preinstalled. No postCreate setup.',
      badge: 'Publish',
      available: false,
    },
  ],

  // Codespaces machine types — mirrors GitHub's own list.
  machines: [
    { id: 'basicLinux32gb',    name: '2-core',  cpus: 2,  memory: '8 GB',  storage: '32 GB', creditsPerHour: 2  },
    { id: 'standardLinux32gb', name: '4-core',  cpus: 4,  memory: '16 GB', storage: '32 GB', creditsPerHour: 4  },
    { id: 'premiumLinux',      name: '8-core',  cpus: 8,  memory: '32 GB', storage: '64 GB', creditsPerHour: 8  },
    { id: 'largePremiumLinux', name: '16-core', cpus: 16, memory: '64 GB', storage: '128 GB', creditsPerHour: 16 },
  ],

  // Codespaces "location" values accepted by the API. Empty = let GitHub pick
  // the region closest to the user, which is what github.com does by default.
  regions: [
    { id: '',              name: 'Automatic — closest to you' },
    { id: 'WestEurope',    name: 'West Europe' },
    { id: 'EastUs',        name: 'US East' },
    { id: 'WestUs2',       name: 'US West' },
    { id: 'SouthEastAsia', name: 'Southeast Asia' },
  ],

  // Minutes of inactivity before the codespace suspends itself.
  idleTimeoutOptions: [30, 60, 90, 120, 240],

  // Where "Open" sends the user. 'builtin' = the in-app VS Code-style editor
  // at /workspace/ide/. 'github' = github.dev / codespace web URL (live mode).
  openTarget: 'builtin',
};
