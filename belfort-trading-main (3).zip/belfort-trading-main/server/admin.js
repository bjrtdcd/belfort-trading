#!/usr/bin/env node
// Admin API for the Belfort debugging platform.
//
// Provides a server-side user database, audit log, shell command execution,
// and a data explorer — all behind a passphrase-gated session token. Wired
// into server/dev.js so the admin panel at /debbugingplatformpartnottoucit/
// can manage the running system instead of just localStorage.
//
// Env:
//   ADMIN_PASS   admin passphrase. If unset, defaults to "belfort-admin" for
//                local dev only. Set a real one in production.
//   ADMIN_DATA   data directory (default <repo>/data). User DB + audit log live
//                here. Never committed (see .gitignore).
//   ADMIN_CWD    working directory for shell exec (default repo root).
//   ADMIN_EXEC   "1" to enable shell exec (default "1"). Set "0" to disable.
//
// Data files:
//   data/users.json  — { email: { name, hash, createdAt, role, status, ... } }
//   data/audit.log   — append-only JSON Lines of every admin action
//
// Audit logging is fire-and-forget: it never blocks or breaks an action.

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { exec: cpExec } = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const DATA_DIR = process.env.ADMIN_DATA ? path.resolve(process.env.ADMIN_DATA) : path.join(ROOT, 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const AUDIT_FILE = path.join(DATA_DIR, 'audit.log');
const EXEC_CWD = process.env.ADMIN_CWD ? path.resolve(process.env.ADMIN_CWD) : ROOT;
const EXEC_ENABLED = String(process.env.ADMIN_EXEC || '1') === '1';
const SESSION_TTL = 8 * 60 * 60 * 1000; // 8 hours

fs.mkdirSync(DATA_DIR, { recursive: true });

// In-memory session tokens: token -> { actor, exp }
const sessions = new Map();

function sha256(str) {
  return crypto.createHash('sha256').update(String(str)).digest('hex');
}

function adminPass() {
  return process.env.ADMIN_PASS || 'belfort-admin';
}

// ── user database ──────────────────────────────────────────────────────
function readUsers() {
  try { return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8')); }
  catch (e) { return {}; }
}
function writeUsers(u) {
  fs.writeFileSync(USERS_FILE, JSON.stringify(u, null, 2));
}

// ── audit log (non-blocking, never throws) ────────────────────────────
function audit(action, actor, target, details) {
  try {
    const line = JSON.stringify({
      ts: new Date().toISOString(),
      action: action,
      actor: actor || 'system',
      target: target || null,
      details: details || null,
    }) + '\n';
    fs.appendFile(AUDIT_FILE, line, function () { /* swallow */ });
  } catch (e) { /* swallow — logging must never break the action */ }
}

function readAudit(limit) {
  try {
    const raw = fs.readFileSync(AUDIT_FILE, 'utf8').trim();
    if (!raw) return [];
    const lines = raw.split('\n');
    return lines.filter(Boolean).slice(-(limit || 200)).map(function (l) {
      try { return JSON.parse(l); } catch (e) { return null; }
    }).filter(Boolean);
  } catch (e) { return []; }
}

// ── sessions ──────────────────────────────────────────────────────────
function issueToken(actor) {
  const tok = crypto.randomBytes(24).toString('hex');
  sessions.set(tok, { actor: actor, exp: Date.now() + SESSION_TTL });
  return tok;
}
function checkAuth(req) {
  const h = req.headers['authorization'] || '';
  const m = /^Bearer\s+(.+)$/i.exec(h);
  if (!m) return null;
  const s = sessions.get(m[1]);
  if (!s) return null;
  if (Date.now() > s.exp) { sessions.delete(m[1]); return null; }
  return s;
}

// ── helpers ───────────────────────────────────────────────────────────
function send(res, code, obj) {
  res.writeHead(code, { 'content-type': 'application/json', 'cache-control': 'no-store', 'access-control-allow-origin': '*' });
  res.end(typeof obj === 'string' ? obj : JSON.stringify(obj));
}

function readBody(req) {
  return new Promise(function (resolve) {
    const chunks = [];
    req.on('data', function (c) { chunks.push(c); });
    req.on('end', function () { resolve(Buffer.concat(chunks).toString('utf8')); });
    req.on('error', function () { resolve(''); });
  });
}

function safeJoin(base, rel) {
  const resolved = path.resolve(base, rel);
  if (resolved !== base && resolved.indexOf(base + path.sep) !== 0) return null;
  return resolved;
}

function dirSize(dir) {
  let total = 0;
  try {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, e.name);
      if (e.isDirectory()) total += dirSize(full);
      else try { total += fs.statSync(full).size; } catch (x) {}
    }
  } catch (e) {}
  return total;
}

function serverStats() {
  const mem = process.memoryUsage();
  const users = readUsers();
  const uids = Object.keys(users);
  return {
    hostname: os.hostname(),
    platform: process.platform + ' ' + os.release(),
    arch: process.arch,
    nodeVersion: process.version,
    uptime: Math.round(process.uptime()),
    uptimeHuman: humanTime(process.uptime()),
    cpus: os.cpus().length,
    memTotal: os.totalmem(),
    memFree: os.freemem(),
    rss: mem.rss,
    heapUsed: mem.heapUsed,
    heapTotal: mem.heapTotal,
    dataDir: DATA_DIR,
    dataSize: dirSize(DATA_DIR),
    userCount: uids.length,
    activeSessions: sessions.size,
    execEnabled: EXEC_ENABLED,
    loadAvg: os.loadavg(),
  };
}

function humanTime(sec) {
  sec = Math.floor(sec);
  const d = Math.floor(sec / 86400), h = Math.floor((sec % 86400) / 3600), m = Math.floor((sec % 3600) / 60);
  if (d) return d + 'd ' + h + 'h ' + m + 'm';
  if (h) return h + 'h ' + m + 'm';
  return m + 'm';
}

// ── route handler ─────────────────────────────────────────────────────
// Returns true if the request was handled (it's an /admin/api/* route).
async function handle(req, res) {
  const url = req.url || '';
  const p = url.split('?')[0];
  const method = req.method || 'GET';
  if (p.indexOf('/admin/api/') !== 0) return false;

  // CORS preflight
  if (method === 'OPTIONS') {
    res.writeHead(204, { 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET,POST,PATCH,DELETE,OPTIONS', 'access-control-allow-headers': 'authorization,content-type' });
    res.end();
    return true;
  }

  // ── login (no auth required) ──
  if (p === '/admin/api/login' && method === 'POST') {
    const body = JSON.parse((await readBody(req)) || '{}');
    if (body.passphrase === adminPass()) {
      const tok = issueToken('admin');
      audit('login', 'admin', null, { ok: true });
      send(res, 200, { token: tok });
    } else {
      audit('login-failed', 'anonymous', null, { ok: false });
      send(res, 401, { error: 'invalid passphrase' });
    }
    return true;
  }

  // everything below requires auth
  const sess = checkAuth(req);
  if (!sess) { send(res, 401, { error: 'unauthorized' }); return true; }

  try {
    // ── stats ──
    if (p === '/admin/api/stats' && method === 'GET') {
      send(res, 200, serverStats()); return true;
    }

    // ── users: list ──
    if (p === '/admin/api/users' && method === 'GET') {
      const users = readUsers();
      const list = Object.keys(users).map(function (email) {
        const u = users[email];
        return {
          email: email, name: u.name, role: u.role || 'user', status: u.status || 'active',
          createdAt: u.createdAt, lastSeen: u.lastSeen || null,
        };
      });
      send(res, 200, { users: list }); return true;
    }

    // ── users: create ──
    if (p === '/admin/api/users' && method === 'POST') {
      const body = JSON.parse((await readBody(req)) || '{}');
      const email = String(body.email || '').trim().toLowerCase();
      const name = String(body.name || email.split('@')[0]).trim();
      const password = String(body.password || '');
      const role = body.role === 'admin' ? 'admin' : 'user';
      const status = body.status === 'disabled' ? 'disabled' : 'active';
      if (!email || !/.+@.+/.test(email)) { send(res, 400, { error: 'valid email required' }); return true; }
      if (!password || password.length < 8) { send(res, 400, { error: 'password must be at least 8 chars' }); return true; }
      const users = readUsers();
      if (users[email]) { send(res, 409, { error: 'user already exists' }); return true; }
      users[email] = { name: name, hash: sha256(password), createdAt: Date.now(), role: role, status: status };
      writeUsers(users);
      audit('user.create', sess.actor, email, { name: name, role: role, status: status });
      send(res, 201, { ok: true, email: email }); return true;
    }

    // ── users: update ──
    // /admin/api/users/<email>  (email may contain a dot, so match prefix)
    if (p.indexOf('/admin/api/users/') === 0 && method === 'PATCH') {
      const email = decodeURIComponent(p.slice('/admin/api/users/'.length)).toLowerCase();
      const body = JSON.parse((await readBody(req)) || '{}');
      const users = readUsers();
      if (!users[email]) { send(res, 404, { error: 'user not found' }); return true; }
      const u = users[email];
      const changes = {};
      if (body.name !== undefined) { u.name = String(body.name); changes.name = u.name; }
      if (body.role !== undefined) { u.role = body.role === 'admin' ? 'admin' : 'user'; changes.role = u.role; }
      if (body.status !== undefined) { u.status = body.status === 'disabled' ? 'disabled' : 'active'; changes.status = u.status; }
      if (body.password !== undefined && body.password) { u.hash = sha256(body.password); changes.password = true; }
      writeUsers(users);
      audit('user.update', sess.actor, email, changes);
      send(res, 200, { ok: true, email: email }); return true;
    }

    // ── users: delete ──
    if (p.indexOf('/admin/api/users/') === 0 && method === 'DELETE') {
      const email = decodeURIComponent(p.slice('/admin/api/users/'.length)).toLowerCase();
      const users = readUsers();
      if (!users[email]) { send(res, 404, { error: 'user not found' }); return true; }
      const removed = users[email];
      delete users[email];
      writeUsers(users);
      audit('user.delete', sess.actor, email, { name: removed.name, role: removed.role });
      send(res, 200, { ok: true, email: email }); return true;
    }

    // ── shell exec ──
    if (p === '/admin/api/exec' && method === 'POST') {
      if (!EXEC_ENABLED) { send(res, 403, { error: 'exec disabled (ADMIN_EXEC=0)' }); return true; }
      const body = JSON.parse((await readBody(req)) || '{}');
      const cmd = String(body.cmd || '');
      const cwd = body.cwd ? safeJoin(EXEC_CWD, body.cwd) || EXEC_CWD : EXEC_CWD;
      const timeoutMs = Math.min(parseInt(body.timeout, 10) || 15000, 60000);
      if (!cmd) { send(res, 400, { error: 'cmd required' }); return true; }
      audit('exec', sess.actor, null, { cmd: cmd, cwd: cwd });
      cpExec(cmd, { cwd: cwd, timeout: timeoutMs, maxBuffer: 2 * 1024 * 1024 }, function (err, stdout, stderr) {
        const code = err && err.code !== undefined ? err.code : (err ? 1 : 0);
        const timedOut = err && err.killed;
        send(res, 200, { code: code, stdout: stdout || '', stderr: stderr || '', timedOut: !!timedOut });
      });
      return true;
    }

    // ── data explorer: list ──
    if (p === '/admin/api/data' && method === 'GET') {
      const q = new URL('http://x' + url).searchParams;
      const rel = q.get('path') || '';
      const full = safeJoin(DATA_DIR, rel);
      if (!full) { send(res, 400, { error: 'invalid path' }); return true; }
      fs.stat(full, function (e, st) {
        if (e) { send(res, 404, { error: 'not found' }); return; }
        if (st.isDirectory()) {
          fs.readdir(full, { withFileTypes: true }, function (e2, entries) {
            if (e2) { send(res, 500, { error: 'read error' }); return; }
            const out = entries.map(function (e3) {
              try { var s = fs.statSync(path.join(full, e3.name)); return { name: e3.name, dir: e3.isDirectory(), size: s.size, mtime: s.mtime }; }
              catch (x) { return { name: e3.name, dir: e3.isDirectory(), size: 0, mtime: null }; }
            });
            send(res, 200, { path: rel || '.', entries: out });
          });
        } else {
          fs.readFile(full, function (e2, data) {
            if (e2) { send(res, 500, { error: 'read error' }); return; }
            const size = data.length;
            const truncated = size > 512 * 1024;
            const content = truncated ? data.slice(0, 512 * 1024).toString('utf8') : data.toString('utf8');
            send(res, 200, { path: rel, size: size, truncated: truncated, content: content });
          });
        }
      });
      return true;
    }

    // ── audit log ──
    if (p === '/admin/api/audit' && method === 'GET') {
      const q = new URL('http://x' + url).searchParams;
      const limit = parseInt(q.get('limit') || '200', 10);
      send(res, 200, { entries: readAudit(limit) }); return true;
    }

    // ── logout ──
    if (p === '/admin/api/logout' && method === 'POST') {
      const h = req.headers['authorization'] || '';
      const m = /^Bearer\s+(.+)$/i.exec(h);
      if (m) sessions.delete(m[1]);
      audit('logout', sess.actor, null, null);
      send(res, 200, { ok: true }); return true;
    }

    send(res, 404, { error: 'not found' });
    return true;
  } catch (e) {
    send(res, 500, { error: e.message || 'server error' });
    return true;
  }
}

module.exports = { handle: handle };
