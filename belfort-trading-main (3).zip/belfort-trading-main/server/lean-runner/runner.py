"""Lean runner — executes one algorithm via lean.py on a real Python interpreter.

Invoked by server.js. Writes a JSON result to stdout (the only stdout the parent
reads). All other output (warnings, prints from the algorithm) goes to stderr.

Usage:
    python3 runner.py <algorithm.py> [<data.csv>] [--cash 100000]
        [--start 2023-01-01] [--end 2024-01-01] [--symbols SPY,AAPL]
        [--resolution Daily] [--params '{"fast":10,"slow":30}']
        [--lean /path/to/lean.py]

The algorithm source is exec'd with `lean.py` registered as the `BelfortEngine`
module, exactly the way the in-browser Pyodide path does. The first QCAlgorithm
subclass found is run via `run_backtest`.

If `--data` is omitted, the engine runs on the synthetic GBM series (clearly
labelled `synthetic_data: true` in the result). If `--symbols` is omitted, the
symbol defaults to "SPY" (used only when the CSV has no `symbol` column).
"""
import argparse, json, os, sys, types

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('algorithm', help='Path to the .py algorithm file')
    ap.add_argument('data', nargs='?', default=None, help='Path to a bars CSV (optional)')
    ap.add_argument('--cash', type=float, default=100000.0)
    ap.add_argument('--start', default='')
    ap.add_argument('--end', default='')
    ap.add_argument('--symbols', default='SPY')
    ap.add_argument('--resolution', default='Daily')
    ap.add_argument('--params', default='{}')
    ap.add_argument('--lean', default=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'lean', 'lean.py'))
    args = ap.parse_args()

    # Load lean.py as a module and register it as `AlgorithmImports` so the
    # user's `from BelfortEngine import *` works identically to the
    # in-browser Pyodide path.
    sys.path.insert(0, os.path.dirname(os.path.abspath(args.lean)))
    import importlib.util
    spec = importlib.util.spec_from_file_location('BelfortEngine', args.lean)
    lean = importlib.util.module_from_spec(spec)
    sys.modules['BelfortEngine'] = lean; sys.modules['AlgorithmImports'] = lean  # backward-compat
    spec.loader.exec_module(lean)

    with open(args.algorithm, 'r') as f:
        src = f.read()
    ns = {'__name__': 'algorithm'}

    # Detect NautilusTrader — if the algorithm imports nautilus_trader, run it
    # as a NautilusTrader backtest instead of a lean.py backtest. NautilusTrader
    # is a professional backtesting/live-trading engine (Rust core, Python API).
    # It must be pip-installed on the VPS:  pip install nautilus_trader
    is_nautilus = 'nautilus_trader' in src or 'from nautilus' in src

    if is_nautilus:
        # NautilusTrader path: install + run the strategy directly.
        # The algorithm is expected to define a BacktestNodeFactory or a
        # run() function that configures and runs the backtest.
        try:
            import subprocess
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-q', 'nautilus_trader'])
        except Exception as e:
            print(json.dumps({'error': 'Failed to install nautilus_trader: ' + str(e)}))
            sys.exit(0)
        try:
            exec(compile(src, args.algorithm, 'exec'), ns)
            # If the algorithm defines a run() function, call it; otherwise
            # look for a BacktestNodeFactory or just exec the file.
            if 'run' in ns and callable(ns['run']):
                result = ns['run']()
                if isinstance(result, dict):
                    print(json.dumps(result, default=str))
                else:
                    print(json.dumps({'result': str(result)}))
            elif 'BacktestNodeFactory' in ns:
                # NautilusTrader convention: the factory is used by the engine.
                # We can't run a full NautilusTrader backtest here without a
                # data catalog — but we can at least validate the algorithm.
                print(json.dumps({'error': 'NautilusTrader BacktestNodeFactory detected but the runner cannot execute it without a data catalog. Configure NautilusTrader with a data catalog on the VPS and call run() or define a run() function that returns metrics.'}))
            else:
                print(json.dumps({'result': 'NautilusTrader algorithm loaded (no run() function or BacktestNodeFactory found)'}))
        except Exception as e:
            print(json.dumps({'error': 'NautilusTrader algorithm error: ' + str(e)}))
        sys.exit(0)

    # Standard Lean path (lean.py as AlgorithmImports)
    exec(compile(src, args.algorithm, 'exec'), ns)

    cls = None
    for n, o in list(ns.items()):
        if isinstance(o, type) and issubclass(o, lean.QCAlgorithm) and o is not lean.QCAlgorithm:
            cls = o
            break
    if cls is None:
        print(json.dumps({'error': 'No QCAlgorithm subclass found in the algorithm.'}))
        sys.exit(0)

    bars = None
    if args.data and os.path.exists(args.data):
        with open(args.data, 'r') as f:
            bars = lean.parse_bars(f.read())
    try:
        params = json.loads(args.params) if args.params else {}
    except Exception:
        params = {}

    symbol = (args.symbols or 'SPY').split(',')[0].strip()
    try:
        r = lean.run_backtest(cls, bars=bars, cash=args.cash, start=args.start or None,
                              end=args.end or None, symbol=symbol, params=params)
        # Set the resolution on the algo for metrics annualization. We do this
        # retroactively by re-keying the metrics if the engine didn't see it
        # (it picks up the algo's _resolution, which the user's Initialize
        # may have set via SetResolution; if not, the default Daily applies).
        print(json.dumps(r, default=str))
    except Exception as e:
        print(json.dumps({'error': 'run_backtest error: ' + str(e)}))


if __name__ == '__main__':
    main()
