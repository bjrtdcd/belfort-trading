# Lean runner — the VPS backend for the Quant Copilot backtest queue

`server.js` is a no-deps Node HTTP server that runs a user's Lean algorithm via
`lean/lean.py` on a real Python interpreter and returns the result. It implements
the contract documented in `config/quantvps.js` so the Quant Copilot's
`enqueue_backtest` queue can actually dispatch jobs instead of just queuing them.

## What it does

- **`POST /backtest`** with body `{ id, name, algorithm, algorithmPath, config, data? }`
  → `{ jobId }`. Writes the algorithm to a temp file, runs
  `python3 runner.py <algo.py> [<data.csv>] --cash --start --end --symbols --resolution
  --params --lean lean.py` in the background, and stores the result keyed by jobId.
- **`GET /jobs/:id`** → `{ status, result, error, startedAt, finishedAt }`. Poll
  until `status === 'done' | 'error'`. This is exactly what the Quant Copilot's
  `dispatch()` already polls (`js/quant-copilot.js:dispatch`).
- **`GET /health`** → `ok` (for uptime checks).

No npm dependencies. The only requirement on the host is `python3` (lean.py is
stdlib-only — no numpy/pandas needed unless the user's algorithm imports them).

## Run it

```bash
LEAN_KEY=shared-secret node server/lean-runner/server.js
# defaults: PORT=8788, PYTHON=python3, LEAN_PY=../../lean/lean.py
```

Then point the Quant Copilot at it. Edit `config/quantvps.js`:

```js
window.QUANTPAD_QUANTVPS = {
  apiBase: "https://your-vps.example:8788",
  apiKey:  "shared-secret",
};
```

Reload `/quant-copilot/`. The Backtests panel now reads "VPS: configured". New
jobs are POSTed and the result is rendered when the run completes.

## What it actually runs

`runner.py` loads `lean/lean.py` and registers it as the `AlgorithmImports`
module — exactly the same path the in-browser Pyodide engine uses, so an
algorithm that runs in the browser runs the same way here. The first
`QCAlgorithm` subclass found is run via `lean.run_backtest()`.

If the POST includes a `data` field (a bars CSV: `date,open,high,low,close,volume`
or `date,symbol,open,high,low,close,volume` for multi-symbol), the algorithm runs
on real data. Without `data`, the engine runs on the clearly-labelled synthetic
GBM series (`synthetic_data: true` in the result) — so the queue works end-to-end
even before you wire in a data feed.

## Security

- `LEAN_KEY` is the shared secret the browser sends in the `x-belfort-key`
  header. If unset, no key check is performed — fine on a private network, not
  on the public internet.
- `ALLOW_ORIGIN` (comma-separated) restricts CORS to specific browser origins.
  Default `*` (any origin) — set it to your Quant Copilot URL in production.
- Each job runs in a fresh `os.tmpdir()` subdirectory that is deleted 60s after
  completion. The algorithm runs as the same OS user as `server.js` — run the
  server under a dedicated low-privilege account, not root.
- The algorithm source is arbitrary Python. This is the whole point (it's how
  the in-browser path works too), so only run algorithms from users you trust
  or sandbox the process (container, nsjail, gVisor). For a multi-tenant
  deployment, put each job in its own container.

## Why this exists

The in-browser `lean.py` is real but toy in scope: single Python process via
Pyodide, no real market data on the page, no parallelism. The VPS runner is
the path to "actually run" the strategy on a real interpreter with real data,
with the same `lean.py` engine so behavior matches what the user iterated on in
the browser. When the Quant Copilot enqueues a job, the page POSTs the
algorithm source; the VPS runs it and reports back.
