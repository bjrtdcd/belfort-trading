#!/usr/bin/env node
// Lean runner API — the real backend for the Quant Copilot backtest queue.
//
// Implements the contract documented in config/quantvps.js:
//   POST /backtest  { id, name, algorithm, algorithmPath, config, data? }
//                  -> { jobId }
//   GET  /jobs/:id -> { status: "running"|"done"|"error", result?, error? }
//
// The algorithm source is written to a temp file and run via `python3 runner.py`
// with lean.py as the AlgorithmImports module. The result (a JSON object from
// `run_backtest`) is stored in memory keyed by jobId and returned by /jobs/:id.
//
// Run:
//   LEAN_KEY=shared-secret node server/lean-runner/server.js
//
// Then point config/quantvps.js at this host:
//   window.QUANTPAD_QUANTVPS = { apiBase: "http://your-vps:8788", apiKey: "shared-secret" };
//
// Env:
//   LEAN_KEY   shared secret required in the x-belfort-key header (optional;
//              if unset, no key check)
//   PORT       listen port (default 8788)
//   PYTHON     python interpreter to invoke (default "python3")
//   LEAN_PY    path to lean.py (default ../../lean/lean.py)
//   ALLOW_ORIGIN  comma-separated browser origins allowed (CORS)
//
// Requires: python3 on the host. No npm dependencies.

const http = require('http');
const { execFile } = require('child_process');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');

const PORT = parseInt(process.env.PORT || '8788', 10);
const KEY = process.env.LEAN_KEY || '';
const PYTHON = process.env.PYTHON || 'python3';
const LEAN_PY = process.env.LEAN_PY || path.join(__dirname, '..', '..', 'lean', 'lean.py');
const RUNNER = path.join(__dirname, 'runner.py');
const ALLOW = (process.env.ALLOW_ORIGIN || '').split(',').map(s => s.trim()).filter(Boolean);
const CORS = {
  'access-control-allow-origin': ALLOW.length ? ALLOW.join(',') : '*',
  'access-control-allow-methods': 'GET,POST,OPTIONS',
  'access-control-allow-headers': 'content-type,x-belfort-key',
};

// jobId -> { status, result?, error?, startedAt, finishedAt? }
const jobs = new Map();

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); }
      catch (e) { reject(new Error('invalid JSON body')); }
    });
    req.on('error', reject);
  });
}

function authorized(req) {
  if (!KEY) return true;
  return req.headers['x-belfort-key'] === KEY;
}

function startJob(payload) {
  const jobId = payload.id || ('job-' + crypto.randomBytes(6).toString('hex'));
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'belfort-lean-'));
  const algoPath = path.join(tmpDir, 'algorithm.py');
  fs.writeFileSync(algoPath, payload.algorithm || '');
  let dataPath = '';
  if (payload.data) {
    dataPath = path.join(tmpDir, 'data.csv');
    fs.writeFileSync(dataPath, payload.data);
  }
  const cfg = payload.config || {};
  const args = [
    RUNNER, algoPath,
  ];
  if (dataPath) args.push(dataPath);
  if (cfg.cash != null) args.push('--cash', String(cfg.cash));
  if (cfg.startDate) args.push('--start', String(cfg.startDate));
  if (cfg.endDate) args.push('--end', String(cfg.endDate));
  if (cfg.symbols) args.push('--symbols', String(cfg.symbols));
  if (cfg.resolution) args.push('--resolution', String(cfg.resolution));
  if (cfg.params) args.push('--params', JSON.stringify(cfg.params));
  args.push('--lean', LEAN_PY);

  const job = { status: 'running', startedAt: Date.now(), tmpDir };
  jobs.set(jobId, job);

  execFile(PYTHON, args, { maxBuffer: 16 * 1024 * 1024, cwd: tmpDir }, (err, stdout, stderr) => {
    job.finishedAt = Date.now();
    // The runner writes the result JSON to stdout (and only that). stderr has warnings.
    const out = (stdout || '').trim();
    let parsed = null;
    try { parsed = out ? JSON.parse(out) : null; } catch (e) {}
    if (parsed && parsed.error) {
      job.status = 'error';
      job.error = parsed.error + (stderr ? '\n--- stderr ---\n' + stderr.slice(-2000) : '');
    } else if (parsed) {
      job.status = 'done';
      job.result = parsed;
    } else {
      job.status = 'error';
      job.error = (err ? (err.message || String(err)) + ' — ' : '') + 'no JSON from runner'
        + (out ? '\nstdout: ' + out.slice(0, 1000) : '')
        + (stderr ? '\nstderr: ' + stderr.slice(0, 2000) : '');
    }
    // Clean up the temp files after a short grace period so a retry can still read them.
    setTimeout(() => {
      try { fs.rmSync(job.tmpDir, { recursive: true, force: true }); } catch (e) {}
    }, 60000);
  });
  return jobId;
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, CORS); res.end(); return;
  }
  const url = new URL(req.url, 'http://x');
  const p = url.pathname;
  if (p === '/health') {
    res.writeHead(200, { 'content-type': 'text/plain', ...CORS }); res.end('ok'); return;
  }
  if (p === '/backtest' && req.method === 'POST') {
    if (!authorized(req)) { res.writeHead(401, CORS); res.end('unauthorized'); return; }
    let body;
    try { body = await readBody(req); }
    catch (e) { res.writeHead(400, CORS); res.end('bad JSON: ' + e.message); return; }
    if (!body.algorithm && !body.algorithmPath) {
      res.writeHead(400, CORS); res.end('missing `algorithm` source'); return;
    }
    const jobId = startJob(body);
    res.writeHead(200, { 'content-type': 'application/json', ...CORS });
    res.end(JSON.stringify({ jobId }));
    return;
  }
  const jobsMatch = p.match(/^\/jobs\/(.+)$/);
  if (jobsMatch && req.method === 'GET') {
    if (!authorized(req)) { res.writeHead(401, CORS); res.end('unauthorized'); return; }
    const job = jobs.get(jobsMatch[1]);
    if (!job) { res.writeHead(404, CORS); res.end('unknown job'); return; }
    const out = { status: job.status, result: job.result, error: job.error,
                  startedAt: job.startedAt, finishedAt: job.finishedAt };
    res.writeHead(200, { 'content-type': 'application/json', ...CORS });
    res.end(JSON.stringify(out));
    return;
  }
  res.writeHead(404, { 'content-type': 'text/plain', ...CORS });
  res.end('not found (Lean runner: POST /backtest, GET /jobs/:id, GET /health)');
});

server.listen(PORT, () => {
  console.log('Lean runner API on http://localhost:' + PORT);
  console.log('  key: ' + (KEY ? 'required (x-belfort-key)' : 'OPEN — no key check'));
  console.log('  python: ' + PYTHON + '   lean.py: ' + LEAN_PY);
  console.log('  allow origins: ' + (ALLOW.length ? ALLOW.join(', ') : '*'));
});
