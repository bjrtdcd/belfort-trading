#!/usr/bin/env node
// Belfort dev server — serves the static site from the repo root AND proxies
// /v1/* to an OpenAI-compatible upstream, injecting the API key from the
// AI_API_KEY env var. Exists because some providers (Crusoe) block browser
// CORS, so the Quant Copilot page can't call them directly from a static host.
// The page calls same-origin /v1/* here and this forwards.
//
// Run:
//   AI_API_KEY=sk-...   node server/dev.js
//   # or passthrough (forward the browser's own Authorization header):
//   node server/dev.js
//
// Then open http://localhost:4173/quant-copilot/ and in Settings (⚙) set:
//   base URL:  /v1
//   model:     zai/GLM-5.2
//   key:       anything (the proxy injects the real key from $AI_API_KEY)
//
// The key lives in this process's env — never in the browser, never in the repo.
//
// Env:
//   AI_API_KEY  upstream key (injected as Authorization). If unset, the
//               browser's Authorization header is forwarded as-is (passthrough).
//   UPSTREAM    upstream origin (default https://api.inference.crusoecloud.com)
//   PORT        listen port (default 4173)

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const admin = require('./admin');

const ROOT = path.resolve(__dirname, '..');
const PORT = parseInt(process.env.PORT || '4173', 10);
const UPSTREAM = String(process.env.UPSTREAM || 'https://api.inference.crusoecloud.com').replace(/\/+$/, '');
const AI_KEY = process.env.AI_API_KEY || '';
const AI_MODEL = process.env.AI_MODEL || 'zai/GLM-5.2';
const UP_HOST = new URL(UPSTREAM).host;

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.mjs': 'text/javascript',
  '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.ico': 'image/x-icon', '.md': 'text/markdown', '.csv': 'text/csv',
  '.txt': 'text/plain', '.woff2': 'font/woff2', '.wasm': 'application/wasm', '.py': 'text/x-python',
};

function serveStatic(req, res) {
  let p = decodeURIComponent(req.url.split('?')[0]);
  if (p === '/') p = '/index.html';
  if (p.endsWith('/')) p += 'index.html';
  const fp = path.join(ROOT, p);
  if (!fp.startsWith(ROOT)) { res.writeHead(403); res.end('forbidden'); return; }
  fs.stat(fp, function (stErr, st) {
    if (stErr) { res.writeHead(404, { 'content-type': 'text/plain' }); res.end('not found: ' + req.url); return; }
    if (st.isDirectory()) { res.writeHead(302, { 'location': req.url.split('?')[0] + '/' }); res.end(); return; }
    fs.readFile(fp, function (err, data) {
      if (err) { res.writeHead(404, { 'content-type': 'text/plain' }); res.end('not found: ' + req.url); return; }
      res.writeHead(200, { 'content-type': MIME[path.extname(fp).toLowerCase()] || 'application/octet-stream', 'cache-control': 'no-cache' });
      res.end(data);
    });
  });
}

function proxy(req, res) {
  const u = new URL(UPSTREAM + req.url);
  const headers = {};
  for (const k of Object.keys(req.headers)) {
    if (/^(connection|host|origin|referer|accept-encoding|x-forwarded.*)$/i.test(k)) continue;
    headers[k] = req.headers[k];
  }
  headers['host'] = UP_HOST;
  headers['accept-encoding'] = 'identity';
  if (AI_KEY) headers['authorization'] = 'Bearer ' + AI_KEY;
  const body = [];
  req.on('data', function (c) { body.push(c); });
  req.on('end', function () {
    const payload = Buffer.concat(body);
    if (req.method !== 'GET' && req.method !== 'HEAD') headers['content-length'] = Buffer.byteLength(payload);
    const rreq = https.request({ method: req.method, hostname: u.hostname, port: u.port || 443, path: u.pathname + u.search, headers: headers }, function (rres) {
      const out = {};
      for (const k of Object.keys(rres.headers)) if (!/^(connection|keep-alive|transfer-encoding|content-encoding)$/.test(k)) out[k] = rres.headers[k];
      out['access-control-allow-origin'] = '*';
      res.writeHead(rres.statusCode || 502, out);
      rres.pipe(res);
    });
    rreq.on('error', function (e) { res.writeHead(502, { 'content-type': 'text/plain' }); res.end('proxy error: ' + (e.message || e)); });
    if (payload.length) rreq.write(payload);
    rreq.end();
  });
}

// Web proxy for the agent's live-internet tools (web_search / fetch_url). Fetches
// an arbitrary http(s) URL server-side and returns it with CORS, so the browser
// can reach DuckDuckGo / Wikipedia / docs pages despite their CORS rules.
function webProxy(req, res) {
  var target = new URL('http://x' + req.url).searchParams.get('url');
  if (!target || !/^https?:\/\//i.test(target)) { res.writeHead(400, { 'content-type': 'text/plain', 'access-control-allow-origin': '*' }); res.end('need ?url=http(s)://...'); return; }
  var host = new URL(target).hostname.toLowerCase();
  if (/^(localhost|127\.|10\.|192\.168\.|169\.254\.|0\.|::1|fe80:)/i.test(host) || /^172\.(1[6-9]|2\d|3[01])\./.test(host)) { res.writeHead(403, { 'content-type': 'text/plain', 'access-control-allow-origin': '*' }); res.end('blocked: local/private address'); return; }
  var lib = /^https:/.test(target) ? https : http;
  var ua = { 'user-agent': 'Mozilla/5.0 (compatible; BelfortQuantCopilot/1.0)', 'accept': 'text/html,application/json,*/*;q=0.8', 'accept-encoding': 'identity' };
  lib.get(target, { headers: ua }, function (rres) {
    res.writeHead(rres.statusCode || 502, { 'content-type': rres.headers['content-type'] || 'text/plain; charset=utf-8', 'access-control-allow-origin': '*' });
    rres.pipe(res);
  }).on('error', function (e) { res.writeHead(502, { 'content-type': 'text/plain', 'access-control-allow-origin': '*' }); res.end('web proxy error: ' + (e.message || e)); });
}

const server = http.createServer(function (req, res) {
  const p = req.url.split('?')[0];
  if (p === '/v1' || p.indexOf('/v1/') === 0) return proxy(req, res);
  if (p === '/web') return webProxy(req, res);
  // Admin API — user DB, audit log, shell exec, data explorer.
  if (p.indexOf('/admin/api/') === 0) {
    admin.handle(req, res).then(function (handled) {
      if (!handled) { res.writeHead(404, { 'content-type': 'application/json' }); res.end('{"error":"not found"}'); }
    });
    return;
  }
  // When the key is in env, hand the page a managed config so the AI works for
  // every user with no setup. The browser only sees base+model+the placeholder
  // "managed"; the real key stays in this process's env.
  if (p === '/config/ai.js' && AI_KEY) {
    res.writeHead(200, { 'content-type': 'text/javascript', 'cache-control': 'no-cache' });
    res.end('window.QUANTPAD_AI = { configured: true, base: "/v1", model: ' + JSON.stringify(AI_MODEL) + ', key: "managed" };');
    return;
  }
  if (req.method === 'OPTIONS') { res.writeHead(204, { 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET,POST,OPTIONS', 'access-control-allow-headers': 'authorization,content-type' }); return res.end(); }
  serveStatic(req, res);
});

server.listen(PORT, function () {
  console.log('Belfort dev server — http://localhost:' + PORT);
  console.log('  site:  http://localhost:' + PORT + '/quant-copilot/');
  console.log('  proxy: /v1/* -> ' + UPSTREAM + '/v1/*  (' + (AI_KEY ? 'key from $AI_API_KEY' : 'passthrough — no $AI_API_KEY set') + ')');
  console.log('  AI for every user: ' + (AI_KEY ? 'ON (model ' + AI_MODEL + ', key hidden on server)' : 'OFF (set $AI_API_KEY to enable)'));
});
