// Belfort Code-Server API — launches a real VS Code (code-server) Linux
// container per session and the Copilot page embeds it. No framework, no deps;
// talks to the host Docker via `docker` CLI. `createServer` takes an injected
// `docker` function so tests can stub it.
//
// Env (CLI): BELFORT_CS_API_KEY, BELFORT_CS_ORIGIN (comma-separated allowed
// origins, or *), BELFORT_CS_IMAGE, BELFORT_CS_HOST (public host for URLs),
// BELFORT_CS_PORT_BASE, BELFORT_CS_PORT_RANGE, BELFORT_CS_PORT (the API's port).

'use strict';
const http = require('node:http');
const { execFile } = require('node:child_process');

function hash(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  return Math.abs(h);
}

function safeName(session) {
  const s = String(session || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40);
  const fallback = 'sess' + (hash(String(session)) % 100000);
  return 'belfort-cs-' + (s || fallback);
}

function portFor(session, base, range) {
  return base + (hash(String(session)) % range);
}

function readBody(req) {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', (c) => { body += c; if (body.length > 1e5) req.destroy(); });
    req.on('end', () => { try { resolve(body ? JSON.parse(body) : {}); } catch { resolve({}); } });
    req.on('error', () => resolve({}));
  });
}

function send(res, code, obj, origin) {
  const headers = { 'content-type': 'application/json' };
  if (origin) headers['access-control-allow-origin'] = origin;
  res.writeHead(code, headers);
  res.end(JSON.stringify(obj));
}

// docker(args): Promise<string> stdout; rejects on non-zero exit (stderr/message).
function createServer(opts) {
  const docker = opts.docker;
  const origin = opts.origin;          // string | string[] | '*' | null
  const apiKey = opts.apiKey || '';     // if set, requests must send x-belfort-key
  const image = opts.image || 'belfort-codeserver:latest';
  const host = opts.host || 'localhost';
  const portBase = opts.portBase || 9000;
  const portRange = opts.portRange || 1000;

  function allowed(reqOrigin) {
    if (!origin || origin === '*') return reqOrigin || '*';
    const list = Array.isArray(origin) ? origin : String(origin).split(',');
    return list.includes(reqOrigin) ? reqOrigin : null;
  }
  function checkKey(req) {
    if (!apiKey) return true;
    return req.headers['x-belfort-key'] === apiKey;
  }

  async function start(session) {
    const name = safeName(session);
    const port = portFor(session, portBase, portRange);
    // Is it already running?
    try {
      const running = await docker(['inspect', '-f', '{{.State.Running}}', name]);
      if (running.trim() === 'true') return { url: `http://${host}:${port}`, status: 'running', name, port };
      // exists but stopped → start it
      await docker(['start', name]);
      return { url: `http://${host}:${port}`, status: 'started', name, port };
    } catch (_) {
      // doesn't exist → create
    }
    await docker(['run', '-d', '--name', name, '-p', `${port}:8080`,
      '-v', `belfort-cs-${name}:/home/coder/project`, '--restart', 'unless-stopped', image]);
    return { url: `http://${host}:${port}`, status: 'created', name, port };
  }
  async function stop(session) {
    const name = safeName(session);
    try { await docker(['stop', name]); } catch (_) { /* not running */ }
    try { await docker(['rm', '-f', name]); } catch (_) { /* gone */ }
    return { ok: true, name };
  }
  async function status(session) {
    const name = safeName(session);
    const port = portFor(session, portBase, portRange);
    try {
      const running = await docker(['inspect', '-f', '{{.State.Running}}', name]);
      return { running: running.trim() === 'true', url: `http://${host}:${port}`, name, port };
    } catch (_) {
      return { running: false, url: null, name, port };
    }
  }

  const server = http.createServer(async (req, res) => {
    const reqOrigin = req.headers.origin || '';
    const o = allowed(reqOrigin);
    if (req.method === 'OPTIONS') {
      res.writeHead(204, {
        'access-control-allow-origin': o || '',
        'access-control-allow-methods': 'POST, GET, OPTIONS',
        'access-control-allow-headers': 'content-type, x-belfort-key',
        'access-control-max-age': '86400', 'vary': 'origin',
      });
      return res.end();
    }
    if (!o) return send(res, 403, { error: 'origin_not_allowed' });
    if (!checkKey(req)) return send(res, 401, { error: 'bad_key' });

    const path = (req.url || '').split('?')[0];
    try {
      if (path === '/health') return send(res, 200, { ok: true, image }, o);
      if (path === '/start' && req.method === 'POST') {
        const body = await readBody(req);
        if (!body.session) return send(res, 400, { error: 'session_required' }, o);
        return send(res, 200, await start(body.session), o);
      }
      if (path === '/stop' && req.method === 'POST') {
        const body = await readBody(req);
        if (!body.session) return send(res, 400, { error: 'session_required' }, o);
        return send(res, 200, await stop(body.session), o);
      }
      if (path === '/status' && req.method === 'GET') {
        const session = new URL(req.url, 'http://x').searchParams.get('session');
        if (!session) return send(res, 400, { error: 'session_required' }, o);
        return send(res, 200, await status(session), o);
      }
      send(res, 404, { error: 'not_found' }, o);
    } catch (e) {
      send(res, 500, { error: String((e && e.message) || e).slice(0, 500) }, o);
    }
  });
  return server;
}

function realDocker(args) {
  return new Promise((resolve, reject) => {
    execFile('docker', args, { maxBuffer: 4 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) reject(new Error(String(stderr || err.message || err).trim()));
      else resolve(String(stdout).trim());
    });
  });
}

function cli() {
  const env = process.env;
  const server = createServer({
    docker: realDocker,
    apiKey: env.BELFORT_CS_API_KEY || '',
    origin: env.BELFORT_CS_ORIGIN || '*',
    image: env.BELFORT_CS_IMAGE || 'belfort-codeserver:latest',
    host: env.BELFORT_CS_HOST || 'localhost',
    portBase: parseInt(env.BELFORT_CS_PORT_BASE || '9000', 10),
    portRange: parseInt(env.BELFORT_CS_PORT_RANGE || '1000', 10),
  });
  const port = parseInt(env.BELFORT_CS_PORT || '4189', 10);
  server.listen(port, () => console.log('Belfort code-server API on :' + port));
}

module.exports = { createServer, hash, safeName, portFor, cli };
if (require.main === module) cli();
