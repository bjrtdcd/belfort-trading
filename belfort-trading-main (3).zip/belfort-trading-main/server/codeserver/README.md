# Belfort Code-Server backend — the REAL VS Code on Linux

This is the actual VS Code (code-server, by Coder — not a Monaco clone) running
on a real Linux container, with the Belfort backtester engine + MCP server +
Python stack preinstalled. The Copilot page calls this API to launch a
per-user container and embeds the running VS Code in an iframe. No user GitHub,
no CheerpX license, no Monaco — but **it needs a host with Docker that you run**;
the static site can't host it.

## What it does
- `api.js` — tiny Node API (no deps). `POST /start { session }` launches a
  container `belfort-cs-<session>` from the image on a deterministic port and
  returns `{ url }`. `POST /stop { session }` tears it down. `GET /status`.
  CORS + a shared API key (`x-belfort-key`) gate access.
- `Dockerfile` — code-server + Belfort engine + MCP + numpy/pandas/jupyterlab,
  with `CS_DISABLE_X_FRAME_OPTIONS=1` so the Copilot can embed it.

## Deploy
1. Build & publish the image (or build locally):
   ```bash
   docker build -f server/codeserver/Dockerfile -t belfort-codeserver:local .
   # or run the publish-codeserver-image workflow → ghcr.io/blndhm/belfort-codeserver:latest
   ```
2. Run the API on a host with Docker:
   ```bash
   BELFORT_CS_API_KEY=secret \
   BELFORT_CS_ORIGIN=https://your-belfort-site.example \
   BELFORT_CS_IMAGE=ghcr.io/blndhm/belfort-codeserver:latest \
   BELFORT_CS_HOST=cs.your-host.example \
   docker compose -f server/codeserver/docker-compose.yml up -d
   ```
3. Put the per-session ports behind HTTPS (Caddy/Cloudflare Tunnel — code-server
   over HTTP can't be iframed from an HTTPS page). A simple Caddy reverse proxy
   mapping `cs.host/:<port>` → the container port works; or a wildcard cert.
4. Fill `config/codeserver.js` on the static site with the API base URL + the
   same API key. The Copilot page's "Real VS Code" panel then launches + embeds.

## Security (read before going live)
- `--auth none` inside the container means anyone with the per-session URL can
  edit that session's files. The API key gates who can create a session; the
  per-session URLs are unguessable (hash-based port + name) but not a secret.
  For production put each session behind authenticated reverse-proxy routing,
  enable code-server password auth (`--auth password`), and isolate containers
  (network, resource limits, ephemeral volumes).
- Containers run as the `coder` user inside the image; the project volume is
  per-session. The Belfort tooling at `/home/coder/belfort` is read-only.
- The API needs the Docker socket — run it on a dedicated host, not a shared
  one, and scope the origin allowlist.

## Why this is the real thing
The iframe shows code-server — the actual VS Code workbench (Explorer,
Command Palette, integrated terminal, extensions), running on a real Linux
filesystem. `node /home/coder/belfort/mcp/dist/server.mjs` in its terminal is
the Belfort MCP server. This is not a clone.
