#!/usr/bin/env node
// AI proxy for production — forwards /v1/* to an OpenAI-compatible upstream
// (Crusoe by default), injecting the API key from $AI_API_KEY so the key is
// never in the browser or the repo. Use this when the Quant Copilot is served
// from a static host and you want the AI to work for every user with no setup.
//
// Run (deploy once, behind HTTPS):
//   AI_API_KEY=... node server/aiproxy/proxy.js
//
// Then set the committed config/ai.js to:
//   window.QUANTPAD_AI = { configured: true, base: "https://your-proxy/v1",
//                          model: "zai/GLM-5.2", key: "managed" };
// The browser only ever sends the placeholder "managed"; this proxy replaces it
// with the real key. Users see base+model, never the key.
//
// Env:
//   AI_API_KEY   upstream key (required — injected as Authorization).
//   UPSTREAM     upstream origin (default https://api.inference.crusoecloud.com)
//   PORT         listen port (default 8787)
//   ALLOW_ORIGIN comma-separated browser origins allowed to call this proxy
//                (e.g. "https://belfort.example,http://localhost:4173"). If
//                unset, all origins are allowed. Browsers send Origin honestly,
//                so this stops casual cross-site abuse.
//   RATE_LIMIT   max requests per minute per IP (default 60)
//   AI_GATE_KEY  optional shared secret; if set, requests must send
//                x-belfort-key: <AI_GATE_KEY>. Note: if you embed this in the
//                page it is visible — prefer ALLOW_ORIGIN for browser clients.
//
// Honest limit: a billed key behind a public client app is inherently abusable
// by someone who scripts the proxy. ALLOW_ORIGIN + RATE_LIMIT mitigate but
// don't fully prevent it — monitor usage and set provider-side quotas.

const http = require('http');
const https = require('https');

const PORT = parseInt(process.env.PORT || '8787', 10);
const UPSTREAM = String(process.env.UPSTREAM || 'https://api.inference.crusoecloud.com').replace(/\/+$/, '');
const AI_KEY = process.env.AI_API_KEY || '';
const UP_HOST = new URL(UPSTREAM).host;
const ALLOW = (process.env.ALLOW_ORIGIN || '').split(',').map(function (s) { return s.trim(); }).filter(Boolean);
const GATE = process.env.AI_GATE_KEY || '';
const RATE = parseInt(process.env.RATE_LIMIT || '60', 10);
const ORIGIN_H = { 'access-control-allow-origin': ALLOW.length ? ALLOW.join(',') : '*', 'access-control-allow-methods': 'GET,POST,OPTIONS', 'access-control-allow-headers': 'authorization,content-type,x-belfort-key' };

if (!AI_KEY) { console.error('AI_API_KEY is required.'); process.exit(1); }

const hits = new Map();
setInterval(function () { hits.clear(); }, 60000).unref();

function rateLimited(ip) {
  const n = (hits.get(ip) || 0) + 1;
  hits.set(ip, n);
  return n > RATE;
}

function allowedOrigin(req) {
  if (!ALLOW.length) return true;
  const o = req.headers['origin'] || '';
  return o && ALLOW.indexOf(o) >= 0;
}

function proxy(req, res) {
  const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
  if (rateLimited(ip)) { res.writeHead(429, ORIGIN_H); res.end('rate limit'); return; }
  if (!allowedOrigin(req)) { res.writeHead(403, ORIGIN_H); res.end('origin not allowed'); return; }
  if (GATE && req.headers['x-belfort-key'] !== GATE) { res.writeHead(401, ORIGIN_H); res.end('unauthorized'); return; }
  const u = new URL(UPSTREAM + req.url);
  const headers = {};
  for (const k of Object.keys(req.headers)) if (!/^(connection|host|origin|referer|accept-encoding|x-forwarded.*)$/i.test(k)) headers[k] = req.headers[k];
  headers['host'] = UP_HOST;
  headers['accept-encoding'] = 'identity';
  headers['authorization'] = 'Bearer ' + AI_KEY;
  const body = [];
  req.on('data', function (c) { body.push(c); });
  req.on('end', function () {
    const payload = Buffer.concat(body);
    if (req.method !== 'GET' && req.method !== 'HEAD') headers['content-length'] = Buffer.byteLength(payload);
    const rreq = https.request({ method: req.method, hostname: u.hostname, port: u.port || 443, path: u.pathname + u.search, headers: headers }, function (rres) {
      const out = {};
      for (const k of Object.keys(rres.headers)) if (!/^(connection|keep-alive|transfer-encoding|content-encoding)$/.test(k)) out[k] = rres.headers[k];
      out['access-control-allow-origin'] = ORIGIN_H['access-control-allow-origin'];
      res.writeHead(rres.statusCode || 502, out);
      rres.pipe(res);
    });
    rreq.on('error', function (e) { res.writeHead(502, Object.assign({ 'content-type': 'text/plain' }, ORIGIN_H)); res.end('proxy error: ' + (e.message || e)); });
    if (payload.length) rreq.write(payload);
    rreq.end();
  });
}

http.createServer(function (req, res) {
  if (req.method === 'OPTIONS') { res.writeHead(204, ORIGIN_H); res.end(); return; }
  const p = req.url.split('?')[0];
  if (p === '/v1' || p.indexOf('/v1/') === 0) return proxy(req, res);
  if (p === '/health') { res.writeHead(200, { 'content-type': 'text/plain' }); res.end('ok'); return; }
  res.writeHead(404, { 'content-type': 'text/plain' }); res.end('not found (proxy serves /v1/* only)');
}).listen(PORT, function () {
  console.log('AI proxy on http://localhost:' + PORT + ' -> ' + UPSTREAM + '/v1/*');
  console.log('  allow origins: ' + (ALLOW.length ? ALLOW.join(', ') : '*'));
  console.log('  rate limit: ' + RATE + '/min/ip, gate key: ' + (GATE ? 'on' : 'off'));
});
