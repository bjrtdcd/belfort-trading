# AI proxy (`server/aiproxy/proxy.js`)

A no-deps Node server that forwards `/v1/*` to an OpenAI-compatible upstream
(Crusoe by default) and **injects the API key from `$AI_API_KEY`**. Use it when
the Quant Copilot is served from a static host and you want the AI to work for
**every user with no setup**, with the key hidden on the server (never in the
browser, never in the repo).

## Why

Some providers (Crusoe) block browser CORS, so the static page can't call them
directly. This proxy is the public, always-on gateway the page calls instead.
The browser only ever sends the placeholder `managed` (or no key); the proxy
replaces it with the real key from env.

## Run (production, behind HTTPS)

```bash
AI_API_KEY=... \
ALLOW_ORIGIN=https://belfort.example \
node server/aiproxy/proxy.js
```

Then set the committed `config/ai.js` so every browser uses it:

```js
window.QUANTPAD_AI = {
  configured: true,
  base: "https://your-proxy.example/v1",
  model: "zai/GLM-5.2",
  key: "managed"
};
```

Users load the Quant Copilot and the AI just works — they never see the key.

## Env

| Var | Default | What |
| --- | --- | --- |
| `AI_API_KEY` | (required) | upstream key, injected as `Authorization: Bearer …` |
| `UPSTREAM` | `https://api.inference.crusoecloud.com` | upstream origin |
| `PORT` | `8787` | listen port |
| `ALLOW_ORIGIN` | `*` | comma-separated browser origins allowed to call |
| `RATE_LIMIT` | `60` | max requests per minute per IP |
| `AI_GATE_KEY` | (off) | if set, requests must send `x-belfort-key: <value>` |

`GET /health` → `ok` for uptime checks.

## Local dev

For local dev you don't need this proxy — `server/dev.js` serves the static site
**and** proxies `/v1/*` same-origin, and serves a managed `config/ai.js` when
`$AI_API_KEY` is set:

```bash
AI_API_KEY=... node server/dev.js   # http://localhost:4173/quant-copilot/
```

## Security (honest)

A billed key behind a public client app is inherently abusable by someone who
scripts the proxy. `ALLOW_ORIGIN` + `RATE_LIMIT` mitigate casual abuse; they
don't fully prevent it. Set provider-side quotas, monitor usage, and prefer
`ALLOW_ORIGIN` over `AI_GATE_KEY` for browser clients (a gate key embedded in
the page is visible to users).
