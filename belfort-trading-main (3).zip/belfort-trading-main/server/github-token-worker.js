/**
 * GitHub OAuth token exchange — Cloudflare Worker.
 *
 * The workspace cannot finish an OAuth login on its own: GitHub's token
 * endpoint needs the client secret and sends no CORS headers. This worker is
 * the only server-side piece required. Everything else stays static.
 *
 * Deploy:
 *   1. https://github.com/settings/developers → New OAuth App
 *        Homepage URL:               https://quantpad.ai
 *        Authorization callback URL: https://quantpad.ai/workspace/
 *      Copy the Client ID, generate a Client Secret.
 *   2. npm i -g wrangler && wrangler init quantpad-github --yes
 *      Replace src/index.js with this file.
 *   3. wrangler secret put GITHUB_CLIENT_SECRET
 *      wrangler secret put GITHUB_CLIENT_ID
 *      wrangler deploy
 *   4. In the workspace Admin tab → GitHub integration:
 *        Organization        your org slug (optional)
 *        OAuth client ID     the Client ID from step 1
 *        Token endpoint      https://quantpad-github.<you>.workers.dev/github/token
 *        Callback URL        https://quantpad.ai/workspace/
 *      Save, then paste the generated snippet into config/github.js.
 *
 * ALLOWED_ORIGINS keeps other sites from using your client secret as a free
 * token oracle. Keep it tight.
 */

const ALLOWED_ORIGINS = [
  'https://quantpad.ai',
  'http://localhost:4173',
  'http://localhost:4189',
];

function corsHeaders(origin) {
  return {
    'Access-Control-Allow-Origin': ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0],
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Max-Age': '86400',
    'Vary': 'Origin',
  };
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    const url = new URL(request.url);

    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: corsHeaders(origin) });
    }
    if (url.pathname !== '/github/token' || request.method !== 'POST') {
      return new Response('Not found', { status: 404, headers: corsHeaders(origin) });
    }
    if (!ALLOWED_ORIGINS.includes(origin)) {
      return new Response(JSON.stringify({ error: 'origin_not_allowed' }), {
        status: 403,
        headers: { 'Content-Type': 'application/json', ...corsHeaders(origin) },
      });
    }

    let body;
    try { body = await request.json(); } catch (_) { body = {}; }
    if (!body.code) {
      return new Response(JSON.stringify({ error: 'missing_code' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json', ...corsHeaders(origin) },
      });
    }

    const res = await fetch('https://github.com/login/oauth/access_token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({
        client_id: env.GITHUB_CLIENT_ID,
        client_secret: env.GITHUB_CLIENT_SECRET,
        code: body.code,
        redirect_uri: body.redirect_uri,
      }),
    });
    const data = await res.json();

    // Only the token travels back — never the secret, never the raw response.
    return new Response(JSON.stringify({
      access_token: data.access_token,
      token_type: data.token_type,
      scope: data.scope,
      error: data.error,
      error_description: data.error_description,
    }), {
      status: data.access_token ? 200 : 400,
      headers: { 'Content-Type': 'application/json', ...corsHeaders(origin) },
    });
  },
};
