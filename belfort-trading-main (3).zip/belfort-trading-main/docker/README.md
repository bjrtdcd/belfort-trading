# Belfort Trading Quant Workspace image

A Docker image with the full Belfort tooling preinstalled — Python scientific
stack + JupyterLab + the real backtester engine + the MCP server. Once
published, a GitHub Codespace built from **any** repo can use it and get a
working quant environment with no `postCreate` install.

## What's in it
- Python 3.12 + numpy, pandas, scipy, matplotlib, plotly, jupyterlab
- Node 20 (runs the MCP server + the backtester engine)
- The Belfort backtester engine, prebuilt at `/opt/belfort/backtester/engine.mjs`
- The MCP server, prebuilt at `/opt/belfort/mcp/dist/server.mjs`
- A smoke test at `/opt/belfort/.belfort/check.mjs` that runs the engine on the
  sample log

## Publish it (the full fix)

1. Push this branch to GitHub.
2. Run the workflow: **Actions → "publish-quant-image" → Run workflow**
   (or push a `v*` tag). It builds `docker/Dockerfile` and pushes to
   `ghcr.io/<owner>/quant-workspace:latest` using the default `GITHUB_TOKEN`
   (no extra secret needed). The repo owner must be lowercase for ghcr.io —
   `blndhm` is; fork owners with uppercase names must lowercase the tag.
3. After the first green run, flip `available: true` on the `quantpad` entry
   in `config/github.js`. The Copilot codespace creator will then offer the
   "Belfort Trading Quant Image"; picking it builds the codespace from this
   image, so the user's repo gets the full tooling with no commit or install.

## Build locally

```bash
docker build -f docker/Dockerfile -t belfort-quant:local .
docker run --rm belfort-quant:local node /opt/belfort/.belfort/check.mjs
# → Belfort image OK - 24 trades, grade C (Mixed evidence) ...
```

## Until it's published

The Copilot codespace flow already works without the image: `js/codespaces.js`
`writeDevcontainer` embeds the ~30 KB backtester engine (base64) into the
devcontainer's `postCreateCommand` and writes a Node starter — so any
**writable repo without an existing `.devcontainer/`** gets a working
backtester. The image just adds the MCP server and removes the install step
for every repo (including those that already have a devcontainer).
