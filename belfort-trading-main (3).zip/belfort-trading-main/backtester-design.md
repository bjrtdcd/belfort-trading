# Full Backtester Design

## Goal
Replace the `strategy-validator/` page with a complete, client-side backtester written in TypeScript, compiled to a static bundle that the exported Belfort Trading site serves. All navigation links and the route URL stay the same.

## Input
- CSV trade log import (file upload or paste).
- Column detection for date/time, direction, entry, exit, size, fees, P&L/return.
- Validation errors for missing columns, empty logs, and unusable rows.

## Engine
- Rebuild the trade series in chronological order.
- Per-trade: P&L, return %, R-multiple, fees, holding time.
- Series: cumulative equity, running drawdown, profit factor, expectancy, win rate, streak analysis.
- Verdict-style grade from the computed metrics.

## Monte Carlo
- Configurable path count and block size for block resampling.
- Equity path fan, terminal outcome distribution, drawdown distribution, risk-of-ruin estimate.

## Prop Firm Monte Carlo
- Built-in presets for common prop-firm rule sets.
- Fully customizable account size, balance target, max daily loss, max total drawdown, profit target, payout schedule.
- Report: pass rate, average time-to-target, expected value, failure modes (daily loss vs total drawdown vs timeout).

## 3D Charts
- 3D equity path fan, 3D drawdown surface, 3D terminal outcome distribution.
- Inline canvas projection; no external libraries, works offline.

## Architecture
- `backtester/` route serves `index.html` (Belfort Trading-styled shell) plus a compiled `backtester.js` bundle.
- TypeScript source under `backtester-src/` (or `ts/`), compiled with the TypeScript compiler.
- Pure calculation modules separated from DOM/rendering modules.
- Deterministic seeded RNG for reproducible Monte Carlo runs.

## Acceptance Criteria
- CSV import produces a full report with metrics, Monte Carlo, prop firm simulation, and 3D charts.
- Invalid input shows errors without crashing.
- The page loads from the static server with no network requests.
- Existing navigation links and the route remain intact.
