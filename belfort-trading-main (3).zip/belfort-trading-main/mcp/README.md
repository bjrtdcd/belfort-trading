# Belfort Trading MCP server

Exposes the Belfort Trading backtester engine as **Model Context Protocol**
tools. Any MCP client — Claude Desktop, Cursor, opencode, Continue, VS Code
copilot extensions — can run real backtests, Monte Carlo, prop-firm
simulations, and full Strategy-Validator verdicts on a TradingView "List of
Trades" export. No browser, no backend: the same TypeScript engine the site
ships, run from your editor.

## Tools

| Tool | What it does |
| --- | --- |
| `backtest` | Performance metrics + Verdict grade on a trade log. |
| `monte_carlo` | Block-bootstrap terminal-balance percentiles, positive-path %, risk of ruin, drawdown percentiles. |
| `prop_firm_sim` | Prop-firm evaluation (FTMO, Apex, Topstep, E8) — pass rate, expected value, days to target, failure breakdown. |
| `validate` | The full verdict in one call: metrics + grade, Monte Carlo, prop firm. |
| `graph_3d` | Render a real 3D surface (equity or drawdown) of the Monte Carlo paths as a PNG image. Same engine data the web app plots, rasterized in pure Node — no browser, no GPU. Returns an image plus a caption with axes, color legend, and percentiles. |
| `list_prop_presets` | The built-in presets and their limits. |
| `sample_trade_log` | The bundled 24-trade sample, so a model can try the other tools without a file. |

Every result is computed by the real engine in `backtester-src/`. Nothing is
invented. The handlers are plain functions, unit-tested in `tests/mcp.test.ts`.
The 3D graph is rasterized in pure Node by `mcp/raster.ts` (isometric projection
+ PNG via `zlib`, no external deps) — the same Monte Carlo data the web app's
3D views plot.

## Run

```bash
npm install
npm run build:mcp        # one-time: bundle to mcp/dist/server.mjs
node mcp/dist/server.mjs # start the server on stdio
```

Or run from source without a build step:

```bash
npx tsx mcp/server.ts
```

## Wire it into a client

### opencode

Add to `opencode.json` (or `~/.config/opencode/opencode.json`):

```json
{
  "mcp": {
    "belfort-trading": {
      "type": "local",
      "command": ["node", "/absolute/path/to/belfort-trading/mcp/dist/server.mjs"]
    }
  }
}
```

### Claude Desktop

`~/Library/Application Support/Claude/claude_desktop_config.json` (macOS) or the
equivalent on your OS:

```json
{
  "mcpServers": {
    "belfort-trading": {
      "command": "node",
      "args": ["/absolute/path/to/belfort-trading/mcp/dist/server.mjs"]
    }
  }
}
```

### Cursor

Settings → MCP → Add new MCP server:

```json
{
  "mcpServers": {
    "belfort-trading": {
      "command": "node",
      "args": ["/absolute/path/to/belfort-trading/mcp/dist/server.mjs"]
    }
  }
}
```

Replace `/absolute/path/to/belfort-trading` with the real checkout path. After
saving, restart the client and ask it to *"backtest this trade log"* and paste
a TradingView export, or *"use the sample trade log, then validate."*

## Develop

The handlers in `mcp/server.ts` are exported and pure — `tests/mcp.test.ts`
imports them directly (no stdio). `npm test` runs the backtester + MCP tests.
`npm run build:mcp` bundles the server + engine into a single
`mcp/dist/server.mjs` (no `tsx` needed to run it).
