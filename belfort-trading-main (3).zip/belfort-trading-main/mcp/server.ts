// Belfort Trading MCP server — exposes the backtester engine as Model
// Context Protocol tools. Any MCP client (Claude Desktop, Cursor, opencode,
// Continue, etc.) can run real backtests, Monte Carlo, prop-firm simulations,
// and full Strategy-Validator verdicts against a TradingView "List of
// Trades" export — no browser, no backend, the real engine.
//
// Run (dev):    npm run mcp        (tsx mcp/server.ts)
// Run (built):  node mcp/dist/server.mjs   (after `npm run build:mcp`)
//
// The handlers below are plain, exported, and unit-tested in tests/mcp.test.ts;
// the MCP wiring at the bottom is a thin adapter over them.

import { pathToFileURL } from 'node:url';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';

import {
  buildTradeLog,
  computeMetrics,
  runMonteCarlo,
  runPropFirmSimulation,
  PROP_FIRM_PRESETS,
  hashSeed,
  SAMPLE_TRADE_LOG,
  runStationaryBootstrap,
  walkForward,
  purgedKFold,
  deflatedSharpeRatio,
  probabilityOfBacktestOverfitting,
  buildOverfitReport,
  autoBlockSize,
} from '../backtester-src/engine';
import { renderSurface, RGBA } from './raster';

const round = (n: number, d = 2): number => Number(n.toFixed(d));

// ── Tool handlers (pure, testable) ──────────────────────────────────

export interface BacktestSummary {
  trades: number;
  ignored: number;
  winRate: number;
  profitFactor: number;
  netPnl: number;
  expectancy: number;
  maxDrawdown: number;
  maxDrawdownPct: number;
  sharpeLike: number;
  // ── Institutional extensions ──
  sharpe: number;
  sortino: number;
  calmar: number;
  omega: number | null;
  tailRatio: number;
  valueAtRisk95: number;
  cvar95: number;
  maxDrawdownDuration: number;
  maxDrawdownDurationDays: number | null;
  recoveryFactor: number;
  ulcerIndex: number;
  gainPain: number | null;
  avgWin: number;
  avgLoss: number;
  winLossRatio: number;
  skewness: number;
  kurtosis: number;
  tradesPerYear: number;
  annualizedReturn: number;
  annualizedVolatility: number;
  bestTrade: number;
  worstTrade: number;
  maxConsecutiveWins: number;
  maxConsecutiveLosses: number;
  grade: string;
  gradeLabel: string;
  gradeScore: number;
  gradeBreakdown: { category: string; score: number; max: number }[];
  gradeAdvice: string[];
  detectedFields: string[];
  hasDates: boolean;
  derivedPnl: boolean;
}

export function backtestSummary(csv: string): BacktestSummary {
  const log = buildTradeLog(csv);
  const m = computeMetrics(log);
  return {
    trades: m.count,
    ignored: log.ignored,
    winRate: round(m.winRate, 4),
    profitFactor: round(m.profitFactor, 2),
    netPnl: round(m.netPnl, 2),
    expectancy: round(m.expectancy, 2),
    maxDrawdown: round(m.maxDrawdown, 2),
    maxDrawdownPct: round(m.maxDrawdownPct, 2),
    sharpeLike: round(m.sharpeLike, 2),
    sharpe: round(m.sharpe, 2),
    sortino: round(m.sortino, 2),
    calmar: round(m.calmar, 2),
    omega: Number.isFinite(m.omega) ? round(m.omega, 2) : null,
    tailRatio: round(m.tailRatio, 2),
    valueAtRisk95: round(m.valueAtRisk95, 2),
    cvar95: round(m.cvar95, 2),
    maxDrawdownDuration: m.maxDrawdownDuration,
    maxDrawdownDurationDays: m.maxDrawdownDurationDays,
    recoveryFactor: round(m.recoveryFactor, 2),
    ulcerIndex: round(m.ulcerIndex, 2),
    gainPain: Number.isFinite(m.gainPain) ? round(m.gainPain, 2) : null,
    avgWin: round(m.avgWin, 2),
    avgLoss: round(m.avgLoss, 2),
    winLossRatio: round(m.winLossRatio, 2),
    skewness: round(m.skewness, 2),
    kurtosis: round(m.kurtosis, 2),
    tradesPerYear: round(m.tradesPerYear, 1),
    annualizedReturn: round(m.annualizedReturn, 2),
    annualizedVolatility: round(m.annualizedVolatility, 2),
    bestTrade: round(m.bestTrade, 2),
    worstTrade: round(m.worstTrade, 2),
    maxConsecutiveWins: m.maxConsecutiveWins,
    maxConsecutiveLosses: m.maxConsecutiveLosses,
    grade: m.grade,
    gradeLabel: m.gradeLabel,
    gradeScore: round(m.gradeScore, 2),
    gradeBreakdown: m.gradeBreakdown,
    gradeAdvice: m.gradeAdvice,
    detectedFields: log.detected,
    hasDates: log.hasDates,
    derivedPnl: log.derivedPnl,
  };
}

export interface MonteCarloSummary {
  paths: number;
  blockSize: number;
  seed: number;
  trades: number;
  p5: number;
  p50: number;
  p95: number;
  positivePathsPct: number;
  riskOfRuinPct: number;
  drawdownP50: number;
  drawdownP95: number;
}

export function monteCarloSummary(csv: string, paths = 1000, blockSize = 1, seed?: number): MonteCarloSummary {
  const log = buildTradeLog(csv);
  const m = computeMetrics(log);
  const s = seed != null ? seed : hashSeed(m.returns);
  const p = Math.min(Math.max(Math.floor(paths), 10), 5000);
  const b = Math.min(Math.max(Math.floor(blockSize), 1), Math.max(m.returns.length, 1));
  const mc = runMonteCarlo(m.returns, { paths: p, blockSize: b, seed: s });
  return {
    paths: p,
    blockSize: b,
    seed: s,
    trades: m.count,
    p5: round(mc.p5, 2),
    p50: round(mc.p50, 2),
    p95: round(mc.p95, 2),
    positivePathsPct: round(mc.positivePathsPct * 100, 2),
    riskOfRuinPct: round(mc.riskOfRuinPct, 2),
    drawdownP50: round(mc.drawdownPercentiles.p50, 2),
    drawdownP95: round(mc.drawdownPercentiles.p95, 2),
  };
}

export interface PropFirmSummary {
  preset: string;
  accountSize: number;
  profitTarget: number;
  runs: number;
  passCount: number;
  passRatePct: number;
  expectedValue: number;
  avgDaysToTarget: number | null;
  payoutProbabilityPct: number;
  failures: { reason: string; count: number; pct: number }[];
}

export function propFirmSummary(
  csv: string,
  presetName = 'FTMO 100k',
  runs = 2000,
  seed?: number,
  strategyBaseline?: number,
): PropFirmSummary {
  const log = buildTradeLog(csv);
  const preset = PROP_FIRM_PRESETS.find((p) => p.name === presetName) || PROP_FIRM_PRESETS[0];
  const s = seed != null ? seed : hashSeed(log.trades.map((t) => t.pnl));
  const r = Math.min(Math.max(Math.floor(runs), 10), 10000);
  const sb = strategyBaseline && strategyBaseline > 0 ? strategyBaseline : preset.accountSize;
  const pf = runPropFirmSimulation(log.trades, preset, { runs: r, seed: s, strategyBaseline: sb });
  return {
    preset: preset.name,
    accountSize: preset.accountSize,
    profitTarget: preset.profitTarget,
    runs: pf.runs,
    passCount: pf.passCount,
    passRatePct: round(pf.passRatePct, 2),
    expectedValue: round(pf.expectedValue, 2),
    avgDaysToTarget: pf.averageDaysToTarget == null ? null : round(pf.averageDaysToTarget, 1),
    payoutProbabilityPct: round(pf.payoutProbabilityPct, 2),
    failures: pf.failures.map((f) => ({ reason: f.reason, count: f.count, pct: round(f.pct * 100, 1) })),
  };
}

export interface ValidateSummary {
  backtest: BacktestSummary;
  monteCarlo: MonteCarloSummary;
  propFirm: PropFirmSummary;
  verdict: string;
  advice: string[];
}

export function validateSummary(
  csv: string,
  opts: { paths?: number; blockSize?: number; seed?: number; preset?: string; runs?: number; strategyBaseline?: number } = {},
): ValidateSummary {
  const bt = backtestSummary(csv);
  const mc = monteCarloSummary(csv, opts.paths ?? 1000, opts.blockSize ?? 1, opts.seed);
  const pf = propFirmSummary(csv, opts.preset ?? 'FTMO 100k', opts.runs ?? 2000, opts.seed, opts.strategyBaseline);
  return {
    backtest: bt,
    monteCarlo: mc,
    propFirm: pf,
    verdict: `${bt.grade} — ${bt.gradeLabel}`,
    advice: bt.gradeAdvice,
  };
}

export function listPresets() {
  return PROP_FIRM_PRESETS.map((p) => ({
    name: p.name,
    accountSize: p.accountSize,
    profitTarget: p.profitTarget,
    maxDailyLoss: p.maxDailyLoss,
    maxTotalDrawdown: p.maxTotalDrawdown,
    evaluationDays: p.evaluationDays,
    payoutPct: p.payoutPct,
    challengeFee: p.challengeFee,
    phases: p.phases,
  }));
}

export function sampleLog(): string {
  return SAMPLE_TRADE_LOG;
}

// ── Overfit / robustness summary (walk-forward, purged K-fold, DSR, PBO, stationary bootstrap)

export interface OverfitSummary {
  trades: number;
  walkForward: {
    folds: number;
    meanIsSharpe: number;
    meanOosSharpe: number;
    oosPositivePct: number;
    verdict: 'stable' | 'decaying' | 'unstable';
  };
  purgedKFold: {
    nFolds: number;
    purge: number;
    embargo: number;
    meanOosSharpe: number;
    oosPositivePct: number;
  };
  deflatedSharpe: {
    observedSharpe: number;
    threshold: number;
    dsr: number;
    trials: number;
    verdict: 'credible' | 'marginal' | 'inflated';
  };
  pbo: { pbo: number; nStrategies: number; verdict: 'not overfit' | 'suspect' | 'overfit' } | null;
  stationaryBootstrap: {
    paths: number;
    blockLength: number;
    p5: number;
    p50: number;
    p95: number;
    positivePathsPct: number;
    riskOfRuinPct: number;
    drawdownP95: number;
  };
  verdict: string;
  summary: string;
}

export function overfitSummary(
  csv: string,
  opts: { paths?: number; folds?: number; trials?: number; seed?: number; pboMatrix?: number[][] } = {},
): OverfitSummary {
  const log = buildTradeLog(csv);
  const m = computeMetrics(log);
  const r = buildOverfitReport(
    m.returns,
    { sharpe: m.sharpe, skewness: m.skewness, kurtosis: m.kurtosis, count: m.count, tradesPerYear: m.tradesPerYear },
    {
      paths: opts.paths ?? 1000,
      folds: opts.folds ?? 5,
      trials: opts.trials ?? 1,
      seed: opts.seed,
      pboMatrix: opts.pboMatrix,
    },
  );
  return {
    trades: m.count,
    walkForward: {
      folds: r.walkForward.folds.length,
      meanIsSharpe: round(r.walkForward.meanIsSharpe, 2),
      meanOosSharpe: round(r.walkForward.meanOosSharpe, 2),
      oosPositivePct: round(r.walkForward.oosPositivePct * 100, 1),
      verdict: r.walkForward.verdict,
    },
    purgedKFold: {
      nFolds: r.purgedKFold.nFolds,
      purge: r.purgedKFold.purge,
      embargo: r.purgedKFold.embargo,
      meanOosSharpe: round(r.purgedKFold.meanOosSharpe, 2),
      oosPositivePct: round(r.purgedKFold.oosPositivePct * 100, 1),
    },
    deflatedSharpe: {
      observedSharpe: round(m.sharpe, 2),
      threshold: round(r.deflatedSharpe.sr0, 2),
      dsr: round(r.deflatedSharpe.dsr, 4),
      trials: r.deflatedSharpe.trials,
      verdict: r.deflatedSharpe.verdict,
    },
    pbo: r.pbo
      ? { pbo: round(r.pbo.pbo, 4), nStrategies: r.pbo.nStrategies, verdict: r.pbo.verdict }
      : null,
    stationaryBootstrap: {
      paths: r.stationaryBootstrap.config.paths,
      blockLength: r.stationaryBootstrap.config.blockLength,
      p5: round(r.stationaryBootstrap.p5, 2),
      p50: round(r.stationaryBootstrap.p50, 2),
      p95: round(r.stationaryBootstrap.p95, 2),
      positivePathsPct: round(r.stationaryBootstrap.positivePathsPct * 100, 1),
      riskOfRuinPct: round(r.stationaryBootstrap.riskOfRuinPct, 2),
      drawdownP95: round(r.stationaryBootstrap.drawdownPercentiles.p95, 2),
    },
    verdict: r.verdict,
    summary: r.summary,
  };
}

// ── 3D graph (PNG, pure-Node rasterizer) ────────────────────────────

export interface Graph3DResult {
  image: Buffer;
  mimeType: string;
  caption: string;
}

const EQ_SCALE: RGBA[] = [ { r: 0xfb, g: 0xb1, b: 0x85, a: 1 }, { r: 0xfb, g: 0xbf, b: 0x24, a: 1 }, { r: 0x34, g: 0xd3, b: 0x99, a: 1 } ];
const DD_SCALE: RGBA[] = [ { r: 0x34, g: 0xd3, b: 0x99, a: 1 }, { r: 0xfb, g: 0xbf, b: 0x24, a: 1 }, { r: 0xfb, g: 0xb1, b: 0x85, a: 1 } ];

export function graph3D(
  csv: string,
  view: 'equity' | 'drawdown' = 'equity',
  paths = 300,
  blockSize = 1,
  seed?: number,
): Graph3DResult {
  const log = buildTradeLog(csv);
  const m = computeMetrics(log);
  const s = seed != null ? seed : hashSeed(m.returns);
  const p = Math.min(Math.max(Math.floor(paths), 10), 5000);
  const b = Math.min(Math.max(Math.floor(blockSize), 1), Math.max(m.returns.length, 1));
  const mc = runMonteCarlo(m.returns, { paths: p, blockSize: b, seed: s });

  const PATH_LIMIT = 40;
  const TRADE_LIMIT = 60;
  const pathCount = Math.min(mc.paths.length, PATH_LIMIT);
  const len = mc.paths[0]?.length || 0;
  if (!pathCount || !len) throw new Error('Monte Carlo produced no paths to render.');
  const step = len > TRADE_LIMIT ? Math.ceil(len / TRADE_LIMIT) : 1;
  const idxs: number[] = [];
  for (let i = 0; i < len; i += step) idxs.push(i);
  if (idxs[idxs.length - 1] !== len - 1) idxs.push(len - 1);

  const z: number[][] = [];
  for (let pi = 0; pi < pathCount; pi++) {
    const path = mc.paths[pi];
    const row: number[] = [];
    if (view === 'drawdown') {
      let peak = 0;
      const dd = path.map((v) => { peak = Math.max(peak, v); return peak - v; });
      for (const k of idxs) row.push(dd[k]);
    } else {
      for (const k of idxs) row.push(path[k]);
    }
    z.push(row);
  }

  const png = renderSurface(z, { colorscale: view === 'drawdown' ? DD_SCALE : EQ_SCALE });
  const zLabel = view === 'drawdown' ? 'Drawdown' : 'Equity';
  const colorMeaning = view === 'drawdown' ? 'green = small drawdown, red = deep drawdown' : 'red = low equity, green = high equity';
  const caption =
    `3D ${view} surface — ${pathCount} paths × ${idxs.length} trades (downsampled from ${mc.config.paths} paths / ${len} trades).\n`
    + `Axes: X = trade, Y = path, Z = ${zLabel}. Color: ${colorMeaning}.\n`
    + `Monte Carlo: p5 ${round(mc.p5)} · p50 ${round(mc.p50)} · p95 ${round(mc.p95)} · positive paths ${round(mc.positivePathsPct * 100)}%.`;
  return { image: png, mimeType: 'image/png', caption };
}

// ── MCP wiring ─────────────────────────────────────────────────────

function text(obj: unknown, headline?: string) {
  const body = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2);
  return { content: [{ type: 'text' as const, text: headline ? `${headline}\n\n${body}` : body }] };
}
function error(msg: string) {
  return { content: [{ type: 'text' as const, text: msg }], isError: true as const };
}
function imageResult(png: Buffer, caption: string) {
  return {
    content: [
      { type: 'image' as const, data: png.toString('base64'), mimeType: 'image/png' },
      { type: 'text' as const, text: caption },
    ],
  };
}

function startServer() {
  const server = new McpServer({
    name: 'belfort-trading',
    version: '1.0.0',
  });

  server.tool(
    'backtest',
    'Run the Belfort Trading backtester on a trade-log CSV. Auto-detects the platform: TradingView, NinjaTrader, MultiCharts, MetaTrader, TradeStation, or any CSV with a P&L column (or entry/exit prices). Returns core performance metrics and the Strategy Validator grade.',
    { csv: z.string().min(1).describe('TradingView "List of Trades" export, pasted as text') },
    async ({ csv }) => { try { return text(backtestSummary(csv), 'Backtest complete.'); } catch (e) { return error((e as Error).message); } },
  );

  server.tool(
    'monte_carlo',
    'Block-bootstrap Monte Carlo on a trade log. Returns terminal-balance percentiles, positive-path %, risk of ruin, and drawdown percentiles.',
    {
      csv: z.string().min(1),
      paths: z.number().int().min(10).max(5000).default(1000).describe('Sampled paths (10–5000).'),
      block_size: z.number().int().min(1).default(1).describe('Block size for block bootstrap.'),
      seed: z.number().int().optional().describe('RNG seed; defaults to a hash of the trade P&Ls.'),
    },
    async ({ csv, paths, block_size, seed }) => { try { return text(monteCarloSummary(csv, paths, block_size, seed), 'Monte Carlo complete.'); } catch (e) { return error((e as Error).message); } },
  );

  server.tool(
    'prop_firm_sim',
    'Simulate a prop-firm evaluation (FTMO, Apex, Topstep, E8) on a trade log. Returns pass rate, expected value, average days to target, and failure breakdown.',
    {
      csv: z.string().min(1),
      preset: z.string().default('FTMO 100k').describe('One of: ' + PROP_FIRM_PRESETS.map((p) => p.name).join(', ')),
      runs: z.number().int().min(10).max(10000).default(2000).describe('Simulated evaluations (10–10000).'),
      seed: z.number().int().optional(),
      strategy_baseline: z.number().positive().optional().describe('Account size the log is sized for; trades scale to the preset. Defaults to the preset size.'),
    },
    async ({ csv, preset, runs, seed, strategy_baseline }) => { try { return text(propFirmSummary(csv, preset, runs, seed, strategy_baseline), 'Prop-firm simulation complete.'); } catch (e) { return error((e as Error).message); } },
  );

  server.tool(
    'validate',
    'Full Strategy Validator verdict in one call: performance metrics + grade, Monte Carlo, and prop-firm simulation on the same log.',
    {
      csv: z.string().min(1),
      paths: z.number().int().min(10).max(5000).default(1000),
      block_size: z.number().int().min(1).default(1),
      preset: z.string().default('FTMO 100k'),
      runs: z.number().int().min(10).max(10000).default(2000),
      seed: z.number().int().optional(),
      strategy_baseline: z.number().positive().optional(),
    },
    async (args) => { try { return text(validateSummary(args.csv, args), 'Strategy validation complete.'); } catch (e) { return error((e as Error).message); } },
  );

  server.tool(
    'list_prop_presets',
    'List the built-in prop-firm evaluation presets and their key parameters.',
    {},
    async () => text(listPresets(), 'Prop-firm presets:'),
  );

  server.tool(
    'sample_trade_log',
    'Return the bundled sample trade log (24 trades) so a model can try the other tools without a user file.',
    {},
    async () => text(sampleLog(), 'Sample TradingView trade log (CSV):'),
  );

  server.tool(
    'graph_3d',
    'Render a real 3D surface of the Monte Carlo results as a PNG image (equity surface or drawdown surface). Same engine data the web app plots — pure-Node rasterizer, no browser. Returns an image plus a caption with the axes, color legend, and Monte Carlo percentiles.',
    {
      csv: z.string().min(1).describe('TradingView "List of Trades" export, pasted as text'),
      view: z.enum(['equity', 'drawdown']).default('equity').describe('equity = equity surface (red low → green high); drawdown = drawdown surface (green small → red deep).'),
      paths: z.number().int().min(10).max(5000).default(300).describe('Monte Carlo paths to simulate (10–5000).'),
      block_size: z.number().int().min(1).default(1),
      seed: z.number().int().optional(),
    },
    async ({ csv, view, paths, block_size, seed }) => {
      try { const r = graph3D(csv, view, paths, block_size, seed); return imageResult(r.image, r.caption); }
      catch (e) { return error((e as Error).message); }
    },
  );

  // ── Overfit / robustness tools ──
  server.tool(
    'overfit_checks',
    'Run the full overfit / robustness battery on a trade log: walk-forward (rolling IS/OOS Sharpe), purged K-fold CV with embargo, Deflated Sharpe Ratio (Bailey & López de Prado 2014), Probability of Backtest Overfitting (optional — needs a parameter matrix), and stationary bootstrap with adaptive block size. Always call after `backtest` before claiming an edge is real. Returns a verdict, per-fold stats, and the DSR probability. The honest version of "is this backtest luck?"',
    {
      csv: z.string().min(1).describe('TradingView "List of Trades" export, pasted as text'),
      paths: z.number().int().min(50).max(5000).default(1000).describe('Stationary bootstrap paths (50–5000).'),
      folds: z.number().int().min(2).max(10).default(5).describe('Walk-forward / purged K-fold folds.'),
      trials: z.number().int().min(1).default(1).describe('Number of independent backtests considered (DSR). Set to the number of parameter combinations if you ran a parameter scan.'),
      seed: z.number().int().optional(),
      pbo_matrix: z.array(z.array(z.number())).optional().describe('Per-period return matrix [N_strategies][T_periods] for PBO. Pass each parameter combination\'s per-trade returns.'),
    },
    async ({ csv, paths, folds, trials, seed, pbo_matrix }) => {
      try { return text(overfitSummary(csv, { paths, folds, trials, seed, pboMatrix: pbo_matrix }), 'Overfit checks complete.'); }
      catch (e) { return error((e as Error).message); }
    },
  );

  server.tool(
    'walk_forward',
    'Anchored walk-forward analysis: split the trade log into N contiguous folds, IS = everything before the fold, OOS = the fold. Reports per-fold Sharpe (annualized) and a stability verdict. Use to see whether the edge thins out of sample.',
    {
      csv: z.string().min(1),
      folds: z.number().int().min(2).max(20).default(5),
    },
    async ({ csv, folds }) => {
      try {
        const log = buildTradeLog(csv);
        const m = computeMetrics(log);
        const r = walkForward(m.returns, { folds, tradesPerYear: m.tradesPerYear });
        return text({ folds: r.folds, meanIsSharpe: round(r.meanIsSharpe, 2), meanOosSharpe: round(r.meanOosSharpe, 2), meanDegradation: round(r.meanDegradation, 2), oosPositivePct: round(r.oosPositivePct * 100, 1), verdict: r.verdict }, 'Walk-forward complete.');
      } catch (e) { return error((e as Error).message); }
    },
  );

  server.tool(
    'deflated_sharpe',
    'Deflated Sharpe Ratio (Bailey & López de Prado 2014). Adjusts the observed annualized Sharpe for multiple trials, sample length, skew and kurtosis; returns P(true SR > 0). Set `trials` to the number of parameter combinations tested.',
    {
      csv: z.string().min(1),
      trials: z.number().int().min(1).default(1),
    },
    async ({ csv, trials }) => {
      try {
        const log = buildTradeLog(csv);
        const m = computeMetrics(log);
        const r = deflatedSharpeRatio({ sharpe: m.sharpe, years: m.count / Math.max(m.tradesPerYear, 1), skew: m.skewness, kurtosis: m.kurtosis, trials });
        return text({ observedSharpe: round(m.sharpe, 2), threshold: round(r.sr0, 2), dsr: round(r.dsr, 4), trials: r.trials, verdict: r.verdict }, 'Deflated Sharpe complete.');
      } catch (e) { return error((e as Error).message); }
    },
  );

  server.tool(
    'pbo',
    'Probability of Backtest Overfitting (CSCV, Bailey–Borwein–López de Prado–Zhu 2017). Pass a per-period return matrix [N_strategies][T_periods] — each row is one parameter combination\'s per-trade returns. Returns the frequency with which the best in-sample strategy ranks below the median out of sample. Higher = more overfit.',
    {
      matrix: z.array(z.array(z.number())).min(2).describe('matrix[N_strategies][T_periods] per-period returns (each row is one parameter combination).'),
    },
    async ({ matrix }) => {
      try { return text(probabilityOfBacktestOverfitting(matrix), 'PBO complete.'); }
      catch (e) { return error((e as Error).message); }
    },
  );

  server.tool(
    'stationary_bootstrap',
    'Politis–Romano stationary block bootstrap on the trade log. Preserves serial structure (unlike IID blockSize=1 bootstrap) via random geometric block lengths. Block length defaults to the autocorrelation-derived optimum. Use instead of monte_carlo when the trade sequence has autocorrelation.',
    {
      csv: z.string().min(1),
      paths: z.number().int().min(10).max(5000).default(1000),
      block_length: z.number().int().min(1).optional().describe('Mean block length; default = autoBlockSize() from the autocorrelation structure.'),
      seed: z.number().int().optional(),
    },
    async ({ csv, paths, block_length, seed }) => {
      try {
        const log = buildTradeLog(csv);
        const m = computeMetrics(log);
        const bl = block_length ?? autoBlockSize(m.returns);
        const s = seed ?? hashSeed(m.returns);
        const r = runStationaryBootstrap(m.returns, { paths, blockLength: bl, seed: s });
        return text({
          paths: r.config.paths, blockLength: r.config.blockLength, seed: s,
          p5: round(r.p5, 2), p50: round(r.p50, 2), p95: round(r.p95, 2),
          positivePathsPct: round(r.positivePathsPct * 100, 2),
          riskOfRuinPct: round(r.riskOfRuinPct, 2),
          drawdownP50: round(r.drawdownPercentiles.p50, 2),
          drawdownP95: round(r.drawdownPercentiles.p95, 2),
        }, 'Stationary bootstrap complete.');
      } catch (e) { return error((e as Error).message); }
    },
  );

  const transport = new StdioServerTransport();
  server.connect(transport).catch((e) => {
    console.error('Belfort Trading MCP server failed to start:', e);
    process.exit(1);
  });
}

const isMain = (() => {
  try {
    return pathToFileURL(process.argv[1] ?? '').href === import.meta.url;
  } catch {
    return false;
  }
})();

if (isMain) startServer();
