// Pure-Node 3D surface rasterizer → PNG. No external deps, no DOM, no GPU:
// it reuses the same isometric/perspective projection the site's canvas
// renderer uses (charts3d.ts) so the look is consistent, and rasterizes the
// real engine data (Monte Carlo equity / drawdown grids) to a PNG that the
// MCP server returns as image content.
//
// Faceted (low-poly) painter's-algorithm surface + an axis box. Background
// is transparent so it reads on any client theme; axis labels travel in the
// MCP text caption alongside the image.

import { deflateSync } from 'node:zlib';

export interface RGBA { r: number; g: number; b: number; a: number; }

export interface SurfaceOptions {
  width?: number;
  height?: number;
  /** Colorscale stops at t∈[0,1]. Default: red → amber → green (low→high). */
  colorscale?: RGBA[];
  /** Super-sample factor for anti-aliasing. Default 2. */
  ssaa?: number;
}

const DEFAULT_SCALE: RGBA[] = [
  { r: 0xfb, g: 0xb1, b: 0x85, a: 1 }, // #fb7185 red
  { r: 0xfb, g: 0xbf, b: 0x24, a: 1 }, // #fbbf24 amber
  { r: 0x34, g: 0xd3, b: 0x99, a: 1 }, // #34d399 green
];

function project(p: { x: number; y: number; z: number }, rotY: number, rotX: number, cx: number, cy: number, scale: number, dist: number) {
  const cosY = Math.cos(rotY), sinY = Math.sin(rotY);
  const cosX = Math.cos(rotX), sinX = Math.sin(rotX);
  const x1 = p.x * cosY - p.z * sinY;
  const z1 = p.x * sinY + p.z * cosY;
  const y1 = p.y;
  const y2 = y1 * cosX - z1 * sinX;
  const z2 = y1 * sinX + z1 * cosX;
  const persp = dist / (dist - z2);
  return { x: cx + x1 * scale * persp, y: cy - y2 * scale * persp, depth: z2 };
}

function lerpColor(stops: RGBA[], t: number): RGBA {
  if (t <= 0) return stops[0];
  if (t >= 1) return stops[stops.length - 1];
  const seg = t * (stops.length - 1);
  const i = Math.floor(seg);
  const f = seg - i;
  const a = stops[i], b = stops[i + 1];
  return { r: a.r + (b.r - a.r) * f, g: a.g + (b.g - a.g) * f, b: a.b + (b.b - a.b) * f, a: 1 };
}

function setPx(buf: Uint8Array, W: number, H: number, x: number, y: number, c: RGBA) {
  if (x < 0 || y < 0 || x >= W || y >= H) return;
  const i = (y * W + x) * 4;
  // opaque surface over transparent bg
  buf[i] = c.r; buf[i + 1] = c.g; buf[i + 2] = c.b; buf[i + 3] = 255;
}

function fillQuad(buf: Uint8Array, W: number, H: number, pts: { x: number; y: number }[], c: RGBA) {
  // Split into two triangles and scanline-fill each.
  const tris = [[pts[0], pts[1], pts[2]], [pts[0], pts[2], pts[3]]];
  for (const tri of tris) {
    let minY = Math.floor(Math.min(tri[0].y, tri[1].y, tri[2].y));
    let maxY = Math.ceil(Math.max(tri[0].y, tri[1].y, tri[2].y));
    minY = Math.max(0, minY); maxY = Math.min(H - 1, maxY);
    for (let y = minY; y <= maxY; y++) {
      const ys = y + 0.5;
      let xs: number[] = [];
      for (let e = 0; e < 3; e++) {
        const a = tri[e], b = tri[(e + 1) % 3];
        if ((a.y <= ys && b.y > ys) || (b.y <= ys && a.y > ys)) {
          xs.push(a.x + ((ys - a.y) / (b.y - a.y)) * (b.x - a.x));
        }
      }
      if (xs.length < 2) continue;
      xs.sort((p, q) => p - q);
      const x0 = Math.max(0, Math.ceil(xs[0]));
      const x1 = Math.min(W - 1, Math.floor(xs[1]));
      for (let x = x0; x <= x1; x++) setPx(buf, W, H, x, y, c);
    }
  }
}

function line(buf: Uint8Array, W: number, H: number, x0: number, y0: number, x1: number, y1: number, c: RGBA) {
  x0 = Math.round(x0); y0 = Math.round(y0); x1 = Math.round(x1); y1 = Math.round(y1);
  const dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0);
  const sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
  let err = dx + dy;
  while (true) {
    setPx(buf, W, H, x0, y0, c);
    if (x0 === x1 && y0 === y1) break;
    const e2 = 2 * err;
    if (e2 >= dy) { err += dy; x0 += sx; }
    if (e2 <= dx) { err += dx; y0 += sy; }
  }
}

// ── PNG encoder (pure JS + node zlib) ──
const CRC_TABLE: number[] = (() => {
  const t: number[] = [];
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}
function chunk(type: string, data: Buffer): Buffer {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const crcBuf = Buffer.alloc(4); crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
  return Buffer.concat([len, typeBuf, data, crcBuf]);
}
function encodePng(W: number, H: number, rgba: Uint8Array): Buffer {
  const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(W, 0); ihdr.writeUInt32BE(H, 4);
  ihdr[8] = 8; ihdr[9] = 6; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  const stride = W * 4;
  const raw = Buffer.alloc((stride + 1) * H);
  for (let y = 0; y < H; y++) {
    raw[y * (stride + 1)] = 0;
    for (let i = 0; i < stride; i++) raw[y * (stride + 1) + 1 + i] = rgba[y * stride + i];
  }
  const idat = deflateSync(raw, { level: 9 });
  return Buffer.concat([sig, chunk('IHDR', ihdr), chunk('IDAT', idat), chunk('IEND', Buffer.alloc(0))]);
}

/**
 * Render a 3D surface (z[p][i] = value at path p, trade i) to a PNG Buffer.
 * x = trade index, y (floor) = path index, vertical = value.
 */
export function renderSurface(zGrid: number[][], opts: SurfaceOptions = {}): Buffer {
  const ssaa = opts.ssaa ?? 2;
  const outW = opts.width ?? 800, outH = opts.height ?? 520;
  const W = outW * ssaa, H = outH * ssaa;
  const buf = new Uint8Array(W * H * 4); // transparent (all 0)

  const paths = zGrid.length;
  const len = paths ? zGrid[0].length : 0;
  if (!paths || !len) return encodePng(outW, outH, buf);

  let minZ = Infinity, maxZ = -Infinity;
  for (let p = 0; p < paths; p++) for (let i = 0; i < len; i++) {
    const v = zGrid[p][i];
    if (v < minZ) minZ = v;
    if (v > maxZ) maxZ = v;
  }
  const rangeZ = maxZ - minZ || 1;
  const scale = Math.min(W, H) * 0.34;
  const cx = W / 2, cy = H / 2 + 12 * ssaa;
  const dist = 5, rotY = Math.PI / 4.2, rotX = 0.42;
  const colorscale = opts.colorscale && opts.colorscale.length ? opts.colorscale : DEFAULT_SCALE;

  const nx = (i: number) => i / (len - 1) - 0.5;
  const ny = (p: number) => paths > 1 ? p / (paths - 1) - 0.5 : 0;
  const nv = (v: number) => (v - minZ) / rangeZ - 0.5;
  const P = (i: number, p: number) => project({ x: nx(i), y: nv(zGrid[p][i]), z: ny(p) }, rotY, rotX, cx, cy, scale, dist);

  // Build quads, depth-sort (painter's), fill.
  const quads: { depth: number; pts: { x: number; y: number }[]; t: number }[] = [];
  for (let p = 0; p < paths - 1; p++) {
    for (let i = 0; i < len - 1; i++) {
      const a = P(i, p), b = P(i + 1, p), c = P(i + 1, p + 1), d = P(i, p + 1);
      const depth = (a.depth + b.depth + c.depth + d.depth) / 4;
      const meanV = (zGrid[p][i] + zGrid[p][i + 1] + zGrid[p + 1][i] + zGrid[p + 1][i + 1]) / 4;
      const t = (meanV - minZ) / rangeZ;
      quads.push({ depth, pts: [a, b, c, d], t });
    }
  }
  quads.sort((a, b) => a.depth - b.depth);
  for (const q of quads) fillQuad(buf, W, H, q.pts, lerpColor(colorscale, q.t));

  // Axis box: the floor (y = -0.5) rectangle in (x,z) space.
  const axis: RGBA = { r: 0x6b, g: 0x6d, b: 0x77, a: 1 };
  const floor = [-0.5, 0.5].flatMap((x) => [-0.5, 0.5].map((z) => project({ x, y: -0.5, z }, rotY, rotX, cx, cy, scale, dist)));
  // corners order: (x=-.5,z=-.5),(-.5,.5),(.5,.5),(.5,-.5)
  const order = [0, 1, 3, 2];
  for (let e = 0; e < 4; e++) {
    const a = floor[order[e]], b = floor[order[(e + 1) % 4]];
    line(buf, W, H, a.x, a.y, b.x, b.y, axis);
  }
  // Back-left vertical edges to give depth.
  const base = project({ x: -0.5, y: -0.5, z: -0.5 }, rotY, rotX, cx, cy, scale, dist);
  const top = project({ x: -0.5, y: 0.5, z: -0.5 }, rotY, rotX, cx, cy, scale, dist);
  line(buf, W, H, base.x, base.y, top.x, top.y, axis);

  if (ssaa === 1) return encodePng(outW, outH, buf);
  // Downsample (box filter) for anti-aliasing.
  const out = new Uint8Array(outW * outH * 4);
  for (let y = 0; y < outH; y++) {
    for (let x = 0; x < outW; x++) {
      let r = 0, g = 0, b = 0, a = 0, n = 0;
      for (let dy = 0; dy < ssaa; dy++) for (let dx = 0; dx < ssaa; dx++) {
        const sx = x * ssaa + dx, sy = y * ssaa + dy;
        const i = (sy * W + sx) * 4;
        r += buf[i]; g += buf[i + 1]; b += buf[i + 2]; a += buf[i + 3]; n++;
      }
      const o = (y * outW + x) * 4;
      out[o] = r / n; out[o + 1] = g / n; out[o + 2] = b / n; out[o + 3] = a / n;
    }
  }
  return encodePng(outW, outH, out);
}
