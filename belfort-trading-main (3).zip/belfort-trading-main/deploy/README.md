# Deploying Belfort Trading on the VPS

Target box: 12 vCPU, 32 GB RAM, 1 TB disk, 190 GB egress/month. Ubuntu 22.04 or
24.04 assumed; adjust package names for anything else.

The site itself is static, so nginx serves it straight off disk. The moving
parts are the three small services behind it.

```
                 Cloudflare (DNS, TLS, cache, WAF)
                              |
                          nginx :443
        ┌─────────────────────┼──────────────────────┐
        │                     │                      │
   static files          /v1/*  ──────────►    /api/lean/*
   (the repo)            aiproxy :8790        lean-runner :8788
                         AI key in env        shared secret
                                                     │
                                          /srv/marketdata (Databento, L2)
                                          never served over HTTP
```

## Why Cloudflare in front

190 GB a month sounds like plenty until the homepage ships Plotly (4.5 MB) and
Monaco to every visitor. Cached at the edge, those bytes leave Cloudflare, not
your VPS. It also hides the origin IP, absorbs floods, and terminates TLS.

It is free and it is the single highest-leverage thing on this list.

## First run

On a clean box, as root:

```bash
git clone https://github.com/blndhm/belfort-trading.git /srv/belfort
cd /srv/belfort/deploy
bash setup.sh yourdomain.com
```

`setup.sh` is idempotent - safe to re-run. It creates the service users, the
directories, the firewall rules, the systemd units and the nginx site. It does
**not** put any secret on disk; that is the next step.

## Secrets

Copy the template and fill it in **on the server only**:

```bash
cp /srv/belfort/deploy/env.example /etc/belfort/belfort.env
chmod 600 /etc/belfort/belfort.env
nano /etc/belfort/belfort.env
```

| Variable | What it is |
| --- | --- |
| `AI_API_KEY` | Upstream LLM key. Spends money - see the warning below. |
| `AI_UPSTREAM` | Upstream origin, e.g. `https://api.openai.com`. |
| `LEAN_KEY` | Shared secret between the browser and the Lean runner. |
| `ALLOWED_ORIGINS` | Comma-separated origins allowed to call `/v1/*`. |

Never commit this file. `.gitignore` already covers `*.env`, `*.key`, `*.token`.

Then:

```bash
systemctl enable --now belfort-aiproxy belfort-lean
systemctl reload nginx
```

## TLS

With Cloudflare proxying (orange cloud), use an origin certificate: generate one
in the Cloudflare dashboard, drop the pair at `/etc/ssl/belfort/`, and set SSL
mode to **Full (strict)**. Nothing to renew for 15 years.

Without Cloudflare:

```bash
apt install certbot python3-certbot-nginx
certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

## Deploying a change

```bash
/srv/belfort/deploy/deploy.sh
```

Pulls `main`, rebuilds the bundles if `backtester-src/` or `mcp/` changed, and
restarts only the services whose files moved. Static changes need no restart at
all - nginx reads them off disk.

## Market data

Databento and the level-2 archive live at `/srv/marketdata`, owned by
`belfort-data`, mode 750. **It is never inside the web root.** Anything the
browser needs goes through an authenticated API that reads from there; there is
no path from a URL to a raw file.

Watch the disk. Level-2 for a single liquid symbol-year runs to tens of GB
uncompressed. Keep it in DBN or Parquet with zstd, and put a retention policy in
place before the disk decides one for you:

```bash
df -h /srv/marketdata          # check weekly
du -sh /srv/marketdata/*       # what is actually big
```

`setup.sh` installs a disk alarm at 85%.

## The AI key is the thing that can cost you money

An open `/v1/*` proxy with a working key is a faucet. Anyone who finds it can
drain the account, and they will - these get scanned for. The proxy therefore:

- refuses requests whose `Origin` is not in `ALLOWED_ORIGINS`
- rate-limits per IP (nginx `limit_req`, 10 requests/minute, burst 5)
- never returns the key, only the completion

That is the floor, not the ceiling. Before you let the public near it, put the
endpoint behind a login and meter it per account - the browser can still be
lying about `Origin`, and a rate limit only slows an attacker down.

## Security checklist

`setup.sh` does the first five. The rest are yours.

- [x] SSH: key-only, root login disabled, password auth off
- [x] `ufw`: 22, 80, 443 in; everything else closed
- [x] `fail2ban` on sshd
- [x] `unattended-upgrades` for security patches
- [x] Services run as unprivileged users under hardened systemd units
      (`NoNewPrivileges`, `PrivateTmp`, `ProtectSystem=strict`, read-only
      access to everything they do not need to write)
- [ ] Change the SSH port only if you enjoy it; it stops noise, not attackers
- [ ] Off-box backups of `/etc/belfort` and anything user-generated
- [ ] Monitoring: at minimum a cron that alerts on service down and disk full
- [ ] Rotate `AI_API_KEY` and `LEAN_KEY` on any suspicion, and after anyone
      leaves the project

## What is still missing for a real product

Hosting does not fix these; they need building:

- Auth is `localStorage`-only. Nothing behind it is private, on any host.
- No server-side user store, so no per-account metering of AI or data.
- Stripe is Payment Links only - no webhooks, so entitlements are not verified
  server-side.

Until those land, treat the deployment as a demo that happens to be public.
