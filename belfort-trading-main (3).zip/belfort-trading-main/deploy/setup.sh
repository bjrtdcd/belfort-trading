#!/usr/bin/env bash
# Belfort Trading - VPS bootstrap. Idempotent: safe to run again.
#
#   bash setup.sh yourdomain.com
#
# Creates service users, directories, firewall rules, systemd units and the
# nginx site. Installs no secrets - see deploy/README.md for that step.
set -euo pipefail

DOMAIN="${1:-}"
if [ -z "$DOMAIN" ]; then
  echo "usage: bash setup.sh yourdomain.com" >&2
  exit 1
fi
if [ "$(id -u)" -ne 0 ]; then
  echo "run as root" >&2
  exit 1
fi

REPO=/srv/belfort
DATA=/srv/marketdata
ENVDIR=/etc/belfort
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

say() { printf '\n\033[1m== %s\033[0m\n' "$1"; }

say "Packages"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq nginx ufw fail2ban unattended-upgrades curl git ca-certificates jq
if ! command -v node >/dev/null; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y -qq nodejs
fi
node --version

say "Users and directories"
id -u belfort-app  >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin belfort-app
id -u belfort-data >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin belfort-data
mkdir -p "$REPO" "$DATA" "$ENVDIR"
chown -R root:root "$REPO"          # nginx only needs to read it
chown -R belfort-data:belfort-data "$DATA"
chmod 750 "$DATA"                   # market data is not world-readable
chmod 750 "$ENVDIR"

say "Firewall"
ufw --force reset >/dev/null
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp comment 'ssh'
ufw allow 80/tcp comment 'http'
ufw allow 443/tcp comment 'https'
ufw --force enable
ufw status verbose

say "SSH hardening"
SSHD=/etc/ssh/sshd_config.d/99-belfort.conf
cat > "$SSHD" <<'EOF'
PermitRootLogin prohibit-password
PasswordAuthentication no
KbdInteractiveAuthentication no
X11Forwarding no
MaxAuthTries 3
EOF
# Refuse to lock the operator out: only apply if a key is already installed.
if [ -s /root/.ssh/authorized_keys ] || ls /home/*/.ssh/authorized_keys >/dev/null 2>&1; then
  systemctl reload ssh 2>/dev/null || systemctl reload sshd
  echo "password auth disabled"
else
  rm -f "$SSHD"
  echo "!! No authorized_keys found - left password auth ON."
  echo "!! Install your key, then re-run this script."
fi

say "fail2ban"
cat > /etc/fail2ban/jail.d/belfort.conf <<'EOF'
[sshd]
enabled = true
maxretry = 4
bantime = 1h
findtime = 10m
EOF
systemctl enable --now fail2ban
systemctl restart fail2ban

say "Automatic security updates"
dpkg-reconfigure -f noninteractive unattended-upgrades

say "systemd units"
install -m 644 "$HERE/systemd/belfort-aiproxy.service" /etc/systemd/system/
install -m 644 "$HERE/systemd/belfort-lean.service" /etc/systemd/system/
systemctl daemon-reload

say "nginx site"
sed "s/DOMAIN/$DOMAIN/g" "$HERE/nginx/belfort.conf" > /etc/nginx/sites-available/belfort.conf
ln -sf /etc/nginx/sites-available/belfort.conf /etc/nginx/sites-enabled/belfort.conf
rm -f /etc/nginx/sites-enabled/default
mkdir -p /etc/ssl/belfort
if [ ! -f /etc/ssl/belfort/origin.pem ]; then
  echo "!! No certificate at /etc/ssl/belfort/origin.pem"
  echo "!! Install a Cloudflare origin cert, or run certbot, then: systemctl reload nginx"
else
  nginx -t && systemctl reload nginx
fi

say "Disk alarm"
cat > /etc/cron.daily/belfort-disk <<'EOF'
#!/bin/sh
# Market data will fill 1 TB faster than anyone expects.
USE=$(df --output=pcent /srv/marketdata | tail -1 | tr -dc '0-9')
[ "$USE" -ge 85 ] && logger -t belfort "DISK WARNING: /srv/marketdata at ${USE}%"
exit 0
EOF
chmod +x /etc/cron.daily/belfort-disk

say "Done"
cat <<EOF

Next:
  1. cp $REPO/deploy/env.example $ENVDIR/belfort.env
     chmod 600 $ENVDIR/belfort.env      # then fill in the keys
  2. systemctl enable --now belfort-aiproxy belfort-lean
  3. Point DNS at this box, install the TLS cert, systemctl reload nginx

Check with:
  systemctl status belfort-aiproxy belfort-lean nginx
  journalctl -u belfort-aiproxy -f
EOF
