#!/usr/bin/env bash
# Pull main and restart only what changed. Run as root on the VPS.
set -euo pipefail
cd /srv/belfort

BEFORE=$(git rev-parse HEAD)
git fetch origin main
git reset --hard origin/main
AFTER=$(git rev-parse HEAD)

if [ "$BEFORE" = "$AFTER" ]; then
  echo "already up to date at ${AFTER:0:7}"
  exit 0
fi

CHANGED=$(git diff --name-only "$BEFORE" "$AFTER")
echo "$CHANGED" | sed 's/^/  /'

# Bundles only need rebuilding when their sources move.
if echo "$CHANGED" | grep -qE '^(backtester-src/|mcp/|package(-lock)?\.json)'; then
  echo "rebuilding bundles"
  npm ci --omit=dev --silent || npm install --silent
  npm run build
fi

echo "$CHANGED" | grep -q '^server/aiproxy/'     && systemctl restart belfort-aiproxy && echo "restarted aiproxy"
echo "$CHANGED" | grep -qE '^(server/lean-runner/|lean/)' && systemctl restart belfort-lean && echo "restarted lean"
echo "$CHANGED" | grep -q '^deploy/nginx/'       && nginx -t && systemctl reload nginx && echo "reloaded nginx"

echo "now at ${AFTER:0:7}"
