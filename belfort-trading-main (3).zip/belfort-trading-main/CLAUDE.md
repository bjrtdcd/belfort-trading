# Belfort Trading - working context

Read this first. It is the state of the project, the things that are easy to get
wrong, and the way the owner wants work done. Keep it current: if you change
something here in a way that outdates this file, update the file in the same
commit.

## What this is

A static site. No application server, no build step for the pages themselves.
Everything runs in the browser except three small Node services on the VPS.

The product, in one line: paste a trade log, get the grade a prop-firm evaluator
would give it, then build the next version in a workspace.

## Live right now

| Where | What |
| --- | --- |
| `http://152.53.170.196/` | The current site, served from the VPS |
| `http://152.53.170.196/v2/` | **The design direction.** Cleaner shell, live models, tabbed report |
| GitHub | `blndhm/belfort-trading`, private, branch `main` |

`v2/` is the agreed direction and is where new front-end work goes. The old
pages at the root still exist and still work; they have not been replaced yet.

## The VPS

Debian 13. 12 cores, 32 GB RAM, 1 TB disk. `ssh belfort` from the owner's
machine (key at `~/.ssh/belfort_vps`, config already written).

```
/srv/belfort              the repo, pulled from main, served by nginx
/belfort/data/parquet     182 GB of NQ MBP-10 depth, 2024-2026, root:belfort-data 750
/etc/belfort/belfort.env  secrets, 600, never in git
```

Services: `nginx`, `belfort-lean` (:8788, working), `belfort-aiproxy` (:8790,
parked until an AI key exists). Deploy with `cd /srv/belfort && git pull`, or
`deploy/deploy.sh` which restarts only what changed. Full runbook in
`deploy/README.md`.

Tailscale is installed by the owner and **its setup wipes ufw rules**. If the
site is unreachable but `curl 127.0.0.1` works on the box, check
`ufw status numbered` for the missing 80/443 rules.

## What works and what does not

Do not describe any of the second list as working, in the product or to the owner.

**Works:** the backtester and its whole engine; GitHub linking with a personal
access token; the Quant Copilot workspace, editor and backtest queue; the Lean
runner on the VPS.

**Does not:**
- **Auth is `localStorage` only.** Accounts are per-browser and per-origin. On
  plain HTTP `crypto.subtle` is unavailable, so the password "hash" silently
  falls back to `plain:<password>`. This is fixed by HTTPS, not by patching.
- `admin@admin.com` no longer signs in, but `workspace/index.html` still gates
  the Admin tab on that address. Signing **up** with it is the current way in.
- Stripe has no payment links configured, so checkout goes nowhere.
- The Copilot agent needs an OpenAI-compatible endpoint. No key ships in the
  repo and none should.
- No HTTPS yet: waiting on a domain.

## Deprecated, do not build on

- **GitHub Codespaces workspaces.** `js/codespaces.js` and
  `js/codespace-creator.js` are legacy. Workspaces run in the web itself now
  (`workspace/ide/`, `quant-copilot/`). Do not add features to the Codespaces path.
- `css/theme-mono.css` was deleted; the monochrome direction was reversed.
- `debbugingplatformpartnottoucit/` is the owner's internal page. Leave it alone.

## Conventions

- **Nothing is ever faked.** No seeded fake billing, no invented metrics, no
  simulated success. If a thing is not configured, the UI says so. This has been
  a recurring correction; treat it as the first rule.
- Hand-written JS is plain ES5-ish, no framework, no bundler. Only
  `backtester-src/*.ts` and `mcp/` compile, via `npm run build`.
- `v2/assets/shell.js` renders the header and footer from **one array**. The old
  site hardcoded its nav in five files and the order drifted between pages;
  never reintroduce that.
- Asset URLs carry `?v=belfort-YYYYMMDD`. Bump it when editing a file whose name
  is content-hashed, or returning visitors get the stale copy.
- No em dashes in user-visible copy. The owner reads them as AI-written.
- Charts on marketing pages are hand-drawn SVG/canvas in `v2/assets/viz.js`, not
  Plotly. Plotly is 4.5 MB and the box has 190 GB of monthly bandwidth.

## Working agreement

- **Never push without being asked.** Commit locally, say what changed, wait.
  Branch for anything experimental.
- `git fetch` before starting. Other sessions push to this repo, sometimes
  several commits an hour.
- Never accept or use a password, API key or token. The owner installs those
  himself on the box or in his browser. If one is pasted in chat, say it is
  burned and needs rotating.
- The owner reviews visually. Deploy previews to the VPS and give a URL rather
  than describing the change.

## Where the rest is written down

- `NOTES.md` - what changed and why, newest at the top. Read before large work.
- `README.md` - repo layout and the integration details.
- `deploy/README.md` - the VPS runbook and the security checklist.
- `mockup/README.md` - the original redesign mockups.
