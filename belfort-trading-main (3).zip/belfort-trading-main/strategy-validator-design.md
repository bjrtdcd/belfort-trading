# Strategy Validator Design

## Goal
Add a dedicated `/strategy-validator/` page to the Belfort Trading static export. The page accepts a trade-log CSV and presents a Verdict-style strategy health report matching the product language on the homepage.

## User flow
1. The user opens Strategy Validator from the homepage or navigation.
2. The user uploads a CSV or pastes CSV text.
3. The page detects common trade-result columns, validates the input, and calculates the report in the browser.
4. The page displays the Verdict grade, performance metrics, charts, risk/robustness summary, regime breakdown when date data is available, and a Monte Carlo outcome distribution.
5. Invalid files show an actionable error without leaving the page.

## Metrics
- Trade count
- Win rate
- Net return / total P&L
- Average trade / expectancy
- Profit factor
- Maximum drawdown
- Risk summary based on loss frequency, drawdown, and outcome dispersion
- Verdict grade from A–F based on available metrics
- Monte Carlo terminal-outcome percentiles generated from the supplied trade returns

## Input handling
The parser supports common aliases for P&L/return and date columns, including `pnl`, `profit`, `return`, `profit_pct`, `entry`, `exit`, and `date`. A usable file must contain at least one numeric P&L or return column and two valid trade rows. Date-based sections are omitted when no usable date column exists.

## Technical approach
Keep the page dependency-free and client-side. Reuse the existing Belfort Trading CSS files and visual conventions. Add a dedicated static HTML route, a small inline module for CSV parsing/calculation/rendering, and homepage/navigation links. No authentication changes, external APIs, or server-side persistence are introduced.

## Failure handling
- Empty input: request a CSV or pasted data.
- Missing numeric result column: list the accepted column names.
- Too few valid trades: explain the minimum required rows.
- Malformed rows: ignore invalid rows only when enough valid trades remain; report the count ignored.
- Monte Carlo and regime sections use explicit unavailable states when their input requirements are not met.

## Acceptance criteria
- `/strategy-validator/` loads from the restarted static server.
- A valid CSV produces metrics, grade, charts, and Monte Carlo output without a network request.
- Invalid input produces a visible error and does not throw an uncaught exception.
- Homepage/navigation exposes the new page.
- The old verification screen and unwanted demo wording remain absent.
