"""pine.py — a Pine Script (v5) SUBSET interpreter for the browser (Pyodide).

Vectorized evaluation via numpy/pandas: compiles + runs common stateless
indicator scripts on OHLCV bars and returns the plot series. Stateful constructs
(if / for / while / var with :=) raise a clear PineError so the agent can
translate to pandas instead of failing opaquely. NOT the full Pine language.

Supported: indicator/strategy/study header, plot(), built-in series
(close/open/high/low/volume/hl2/hlc3/ohlc4), ta.sma/ema/rsi/wma/highest/lowest/
stdev/crossover/crossunder/change/vwap, math.*, nz, arithmetic, comparisons,
and/or/not, the ternary `cond ? a : b`, `x[n]` history, `=`/`:=` assignment,
input() (default value).
"""
import re, math, json
import numpy as np  # top-level so Pyodide's loadPackagesFromImports pre-loads it
try:
    import pandas as pd
except ImportError:
    pd = None


class PineError(Exception):
    pass


def parse_bars(csv):
    bars = []
    for line in (csv or '').strip().splitlines():
        line = line.strip()
        if not line or line.lower().startswith(('symbol', 'date', 'ticker', 'open')):
            continue
        parts = [p.strip() for p in line.replace(';', ',').split(',')]
        if len(parts) < 5:
            continue
        try:
            o, h, l, c = float(parts[1]), float(parts[2]), float(parts[3]), float(parts[4])
            v = float(parts[5]) if len(parts) > 5 and parts[5] else 0.0
            bars.append((parts[0], o, h, l, c, v))
        except ValueError:
            continue
    bars.sort(key=lambda b: b[0])
    return bars


def default_bars():
    import random, datetime
    random.seed(42)
    bars = []
    price = 400.0
    d = datetime.date(2023, 1, 3)
    for _ in range(252):
        price = max(1.0, price * (1 + random.gauss(0.0004, 0.011)))
        o = price * (1 + random.gauss(0, 0.003))
        c = price
        h = max(o, c) * (1 + abs(random.gauss(0, 0.003)))
        l = min(o, c) * (1 - abs(random.gauss(0, 0.003)))
        bars.append((d.isoformat(), round(o, 2), round(h, 2), round(l, 2), round(c, 2), 1000000))
        d += datetime.timedelta(days=1 if d.weekday() < 4 else 3)
    return bars


def _strip_comment(line):
    in_s = False
    q = ''
    for i, ch in enumerate(line):
        if in_s:
            if ch == q:
                in_s = False
        elif ch in ('"', "'"):
            in_s = True
            q = ch
        elif ch == '/' and i + 1 < len(line) and line[i + 1] == '/':
            return line[:i].rstrip()
    return line


def _expr(s):
    s = s.replace('true', 'True').replace('false', 'False').replace(' na ', ' np.nan ').replace('(na)', '(np.nan)')
    s = re.sub(r'\bna\b(?!me)', 'np.nan', s)
    # ternary: cond ? a : b  ->  np.where(cond, a, b)  (vectorized)
    if '?' in s and re.search(r'\?:|.*\?.*:', s):
        m = re.match(r'^(.*?)\?(.*?):(.*)$', s)
        if m:
            s = 'np.where(' + m.group(1).strip() + ', ' + m.group(2).strip() + ', ' + m.group(3).strip() + ')'
    # ta.X(  ->  X(
    s = re.sub(r'\bta\.(\w+)\s*\(', r'\1(', s)
    # math.X -> np.X (mapped)
    s = re.sub(r'\bmath\.(abs|max|min|sqrt|pow|floor|ceil|round|log|exp|sign)\b', r'np.\1', s)
    s = re.sub(r'\bmath\.(max|min)\s*\(', lambda m: 'np.%simum(' % ('max' if m.group(1) == 'max' else 'min'), s)
    # history x[n] -> shift(x, n)
    s = re.sub(r'([a-zA-Z_]\w*)\s*\[\s*(\d+)\s*\]', r'shift(\1, \2)', s)
    return s


def _first_arg(args):
    depth = 0
    in_s = False
    q = ''
    for i, ch in enumerate(args):
        if in_s:
            if ch == q:
                in_s = False
        elif ch in ('"', "'"):
            in_s = True
            q = ch
        elif ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        elif ch == ',' and depth == 0:
            return args[:i]
    return args


def _transform(code):
    title = 'Pine Script'
    out = []
    for raw in code.splitlines():
        ln = _strip_comment(raw)
        s = ln.strip()
        if not s:
            continue
        hd = re.match(r'@(?:version=\d+\s*)?$', s)
        m = re.match(r'(?:indicator|strategy|study)\s*\(\s*["\'](.*?)["\']', s)
        if m:
            title = m.group(1)
            continue
        if re.match(r'@version', s):
            continue
        if re.match(r'(var|varip)\s+', s) or re.match(r'if\b', s) or re.match(r'for\b', s) or re.match(r'while\b', s) or re.match(r'switch\b', s):
            raise PineError('unsupported stateful construct: "' + s[:50] + '" — translate to pandas and use run_python')
        if re.match(r'(plotshape|plotchar|hline|bgcolor|fill|alertcondition|alert|color\.|ta\.|request\.|str\.|array\.|matrix\.|table\.)', s) and not re.match(r'plot\s*\(', s) and not re.match(r'[a-zA-Z_]\w*\s*:?=', s):
            if re.match(r'(plotshape|plotchar)\s*\(', s) or re.match(r'(hline|bgcolor|fill|alertcondition|alert)\s*\(', s):
                continue  # ignored (no series output)
        # input(...) -> first arg
        s = re.sub(r'input\s*\(\s*([^,)]+)(?:,[^)]*)?\)', r'(\1)', s)
        # plot(series, title=..., color=...) -> __plot(title, series)
        pm = re.match(r'plot\s*\((.*)\)\s*$', s)
        if pm:
            args = pm.group(1)
            tm = re.search(r'title\s*=\s*["\'](.*?)["\']', args)
            pname = tm.group(1) if tm else None
            series_expr = _expr(_first_arg(args))
            out.append('__plot(' + json.dumps(pname) + ', ' + series_expr + ')')
            continue
        if re.match(r'(plotshape|plotchar|hline|bgcolor|fill|alertcondition|alert)\s*\(', s):
            continue
        am = re.match(r'([a-zA-Z_]\w*)\s*:?=\s*(.*)$', s)
        if am:
            out.append(am.group(1) + ' = ' + _expr(am.group(2)))
            continue
        # destructuring: [a, b, c] = expr  ->  a, b, c = expr
        dm = re.match(r'\[([a-zA-Z_][\w, ]*)\]\s*:?=\s*(.*)$', s)
        if dm:
            out.append(dm.group(1) + ' = ' + _expr(dm.group(2)))
            continue
        # bare call (e.g., alertcondition) — skip
    return title, out


def run_pine(code, bars=None):
    import numpy as np
    try:
        import pandas as pd
    except ImportError:
        raise PineError('pandas required (Pyodide provides it)')
    if not bars:
        bars = default_bars()
    if len(bars) < 5:
        raise PineError('need at least 5 bars of data')
    n = len(bars)
    o = np.array([b[1] for b in bars], float)
    h = np.array([b[2] for b in bars], float)
    l = np.array([b[3] for b in bars], float)
    c = np.array([b[4] for b in bars], float)
    v = np.array([b[5] for b in bars], float)
    hl2 = (h + l) / 2.0
    hlc3 = (h + l + c) / 3.0
    ohlc4 = (o + h + l + c) / 4.0

    def _s(x):
        return pd.Series(x) if not isinstance(x, pd.Series) else x

    def sma(x, nn):
        return _s(x).rolling(int(nn)).mean().values
    def ema(x, nn):
        return _s(x).ewm(span=int(nn), adjust=False).mean().values
    def rsi(x, nn):
        nn = int(nn)
        d = _s(x).diff()
        gain = d.clip(lower=0).ewm(alpha=1.0 / nn, adjust=False).mean()
        loss = (-d.clip(upper=0)).ewm(alpha=1.0 / nn, adjust=False).mean()
        rs = gain / loss.replace(0, np.nan)
        return (100 - 100 / (1 + rs)).fillna(100).values
    def wma(x, nn):
        nn = int(nn)
        w = np.arange(1, nn + 1)
        return _s(x).rolling(nn).apply(lambda vv: np.dot(vv, w) / w.sum(), raw=True).values
    def highest(x, nn):
        return _s(x).rolling(int(nn)).max().values
    def lowest(x, nn):
        return _s(x).rolling(int(nn)).min().values
    def stdev(x, nn):
        return _s(x).rolling(int(nn)).std().values
    def vwap(x=None, nn=None):
        # simple rolling VWAP over the full session (cumulative)
        return (v * c).cumsum() / v.cumsum().replace(0, np.nan)
    def crossover(a, b):
        a, b = _s(a), _s(b)
        return (((a > b) & (a.shift(1) <= b.shift(1))).astype(float)).values
    def crossunder(a, b):
        a, b = _s(a), _s(b)
        return (((a < b) & (a.shift(1) >= b.shift(1))).astype(float)).values
    def change(x, nn=1):
        return _s(x).diff(int(nn)).values
    def shift(x, nn):
        return _s(x).shift(int(nn)).values
    def nz(x, y=0):
        return _s(x).fillna(y).values
    def atr(nn):
        nn = int(nn)
        tr = pd.concat([_s(h) - _s(l), (_s(h) - _s(c).shift()).abs(), (_s(l) - _s(c).shift()).abs()], axis=1).max(axis=1)
        return tr.ewm(alpha=1.0 / nn, adjust=False).mean().values
    def macd(x, fast=12, slow=26, signal=9):
        e1 = _s(x).ewm(span=int(fast), adjust=False).mean()
        e2 = _s(x).ewm(span=int(slow), adjust=False).mean()
        macd_line = e1 - e2
        sig = macd_line.ewm(span=int(signal), adjust=False).mean()
        return macd_line.values, sig.values, (macd_line - sig).values

    plots = []
    plot_idx = [0]

    def __plot(name, x):
        plot_idx[0] += 1
        try:
            arr = list(x)
        except Exception:
            arr = list(np.asarray(x).flatten())
        plots.append({'name': name or ('plot ' + str(plot_idx[0])), 'y': [None if (val is None or (isinstance(val, float) and math.isnan(val))) else round(float(val), 4) for val in arr]})

    title, stmts = _transform(code)
    ns = {
        'np': np, 'pd': pd, 'close': c, 'open': o, 'high': h, 'low': l, 'volume': v,
        'hl2': hl2, 'hlc3': hlc3, 'ohlc4': ohlc4, 'time': list(range(n)),
        'sma': sma, 'ema': ema, 'rsi': rsi, 'wma': wma, 'highest': highest, 'lowest': lowest,
        'stdev': stdev, 'vwap': vwap, 'crossover': crossover, 'crossunder': crossunder,
        'change': change, 'shift': shift, 'nz': nz, 'atr': atr, 'macd': macd,
        '__plot': __plot, 'input': lambda *a, **k: a[0] if a else 0,
    }
    src = '\n'.join(stmts)
    try:
        exec(src, ns)
    except PineError:
        raise
    except Exception as e:
        raise PineError('compile/run error: ' + str(e) + ' — in:\n' + src[:300])
    return {'title': title, 'plots': plots, 'bars': n, 'statements': len(stmts)}
