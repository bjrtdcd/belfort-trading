/* =====================================================================
   Backtest report - tabbed frame and PDF export
   =====================================================================
   The report was one long column with a rail beside it: the verdict
   scrolled away, and everything else was five screens below. This pins
   the answer to the top and splits the rest into tabs, so nothing worth
   reading is more than one click from the grade.

   The report itself is untouched: report-v2.js still fills the same
   element ids. This only rearranges the sections around them.
   ===================================================================== */
(function () {
  'use strict';

  // Which sections live under which tab. Order matters.
  var TABS = [
    { id: 'summary', label: 'Summary', sections: ['rv-equity-sec', 'rv-calendar'] },
    { id: 'montecarlo', label: 'Monte Carlo', sections: ['rv-mc-sec', 'rv-3d-sec', 'rv-regimes'] },
    { id: 'risk', label: 'Risk', sections: ['rv-risk', 'rv-robust'] },
    { id: 'propfirms', label: 'Prop firms', sections: ['rv-prop'] },
    { id: 'charts', label: 'Charts', sections: ['rv-analysis'] },
    { id: 'data', label: 'Data', sections: ['rv-numbers', 'rv-tradelog'] },
  ];

  function build() {
    var body = document.querySelector('.rv-body');
    var overview = document.getElementById('rv-overview');
    if (!body || !overview) return;

    var rail = body.querySelector('.rv-rail');
    if (rail) rail.remove();
    body.style.display = 'block';   // the two-column frame is gone

    // the verdict and figures stay pinned above the tabs
    var pinned = document.createElement('div');
    pinned.className = 'rp-pinned';
    pinned.appendChild(overview);
    body.parentNode.insertBefore(pinned, body);

    // tab bar
    var bar = document.createElement('div');
    bar.className = 'rp-tabs';
    bar.setAttribute('role', 'tablist');
    TABS.forEach(function (t) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'rp-tab';
      b.dataset.tab = t.id;
      b.setAttribute('role', 'tab');
      b.textContent = t.label;
      bar.appendChild(b);
    });

    var actions = document.createElement('div');
    actions.className = 'rp-actions';
    actions.innerHTML = '<button type="button" class="rv-btn" id="rp-expand">Expand all</button>'
      + '<button type="button" class="rv-btn primary" id="rp-pdf">Download PDF</button>';
    bar.appendChild(actions);
    body.parentNode.insertBefore(bar, body);

    // wrap each tab's sections in a panel
    var panels = {};
    TABS.forEach(function (t) {
      var panel = document.createElement('div');
      panel.className = 'rp-panel';
      panel.dataset.panel = t.id;
      t.sections.forEach(function (id) {
        var sec = document.getElementById(id);
        if (sec) panel.appendChild(sec);
      });
      body.appendChild(panel);
      panels[t.id] = panel;
    });

    function show(id) {
      TABS.forEach(function (t) {
        var on = t.id === id;
        panels[t.id].classList.toggle('on', on);
        var btn = bar.querySelector('[data-tab="' + t.id + '"]');
        if (btn) {
          btn.classList.toggle('on', on);
          btn.setAttribute('aria-selected', on ? 'true' : 'false');
        }
      });
      history.replaceState({}, '', '#' + id);
      // Plotly sizes to a hidden container as zero, so nudge it on reveal
      panels[id].querySelectorAll('.js-plotly-plot').forEach(function (p) {
        if (window.Plotly) try { Plotly.Plots.resize(p); } catch (e) {}
      });
    }

    bar.addEventListener('click', function (e) {
      var b = e.target.closest('[data-tab]');
      if (b) show(b.dataset.tab);
    });

    show(TABS.some(function (t) { return '#' + t.id === location.hash; })
      ? location.hash.slice(1) : 'summary');

    // ── expand every fold, drawing what has not been drawn ────────────
    function expandAll() {
      var dets = document.querySelectorAll('details.rv-more');
      dets.forEach(function (d) {
        if (!d.open) { d.open = true; d.dispatchEvent(new Event('toggle')); }
      });
      return new Promise(function (res) { setTimeout(res, 900 + dets.length * 120); });
    }

    document.getElementById('rp-expand').addEventListener('click', function () {
      expandAll();
      document.querySelectorAll('.rp-panel').forEach(function (p) { p.classList.add('on'); });
    });

    // ── PDF: show everything, let the browser print to file ───────────
    //     No jsPDF or html2canvas: they add a megabyte and render charts
    //     worse than the print pipeline already does.
    document.getElementById('rp-pdf').addEventListener('click', async function () {
      var btn = this;
      btn.disabled = true;
      btn.textContent = 'Preparing…';
      document.body.classList.add('rp-printing');
      document.querySelectorAll('.rp-panel').forEach(function (p) { p.classList.add('on'); });
      await expandAll();
      // let every chart settle at its printed width
      document.querySelectorAll('.js-plotly-plot').forEach(function (p) {
        if (window.Plotly) try { Plotly.Plots.resize(p); } catch (e) {}
      });
      await new Promise(function (r) { setTimeout(r, 700); });
      window.print();
      setTimeout(function () {
        document.body.classList.remove('rp-printing');
        show(location.hash.slice(1) || 'summary');
        btn.disabled = false;
        btn.textContent = 'Download PDF';
      }, 800);
    });
  }

  // report-v2.js fills the sections on DOMContentLoaded; run after it
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { setTimeout(build, 60); });
  } else setTimeout(build, 60);
})();
