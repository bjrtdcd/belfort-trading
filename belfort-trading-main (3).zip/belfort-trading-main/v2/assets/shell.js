/* =====================================================================
   Belfort Trading v2 - shared shell
   =====================================================================
   The header and footer are rendered here, on every page, from these two
   arrays. That is the whole point: the old site hardcoded its nav in five
   files and the order drifted, so the row rearranged itself as you moved
   between pages. One source, one order, everywhere.

   Also handles: the current-page marker, the mobile drawer, and the
   signed-in swap (account menu instead of the sign-in pair).
   ===================================================================== */
(function () {
  'use strict';

  // Ordered by how often people need them, and never reordered per page.
  var NAV = [
    { label: 'Backtester', href: '/v2/backtester/' },
    { label: 'Copilot',    href: '/v2/copilot/' },
    { label: 'Workspace',  href: '/v2/workspace/' },
    { label: 'Pricing',    href: '/v2/pricing/' },
  ];

  var FOOTER = [
    {
      title: 'Product',
      links: [
        { label: 'Backtester', href: '/v2/backtester/' },
        { label: 'Quant Copilot', href: '/v2/copilot/' },
        { label: 'Workspace', href: '/v2/workspace/' },
        { label: 'Pricing', href: '/v2/pricing/' },
      ],
    },
    {
      title: 'Resources',
      links: [
        { label: 'Classic report', href: '/strategy-validator/classic/' },
        { label: 'Status', href: '/v2/status/' },
      ],
    },
    {
      title: 'Legal',
      links: [
        { label: 'Terms', href: '/terms/' },
        { label: 'Privacy', href: '/privacy/' },
        { label: 'Disclaimer', href: '/disclaimer/' },
        { label: 'License', href: '/license/' },
      ],
    },
  ];

  var AUTH_KEY = 'quantpad-authenticated';
  var here = location.pathname.replace(/index\.html$/, '');

  function current(href) {
    if (href === '/v2/') return here === '/v2/' || here === '/v2';
    return here.indexOf(href) === 0;
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return c === '&' ? '&amp;' : c === '<' ? '&lt;' : c === '>' ? '&gt;' : '&quot;';
    });
  }

  function navLinks(cls) {
    return NAV.map(function (item) {
      return '<a class="' + (cls || '') + '" href="' + item.href + '"'
        + (current(item.href) ? ' aria-current="page"' : '') + '>' + esc(item.label) + '</a>';
    }).join('');
  }

  function authArea() {
    var email = localStorage.getItem(AUTH_KEY);
    if (!email) {
      return '<a class="btn btn-ghost" href="/sign-in/">Sign in</a>'
        + '<a class="btn btn-primary" href="/sign-up/">Get started</a>';
    }
    var name = localStorage.getItem('quantpad-display-name') || email.split('@')[0];
    return '<a class="btn btn-ghost" href="/v2/workspace/">' + esc(name) + '</a>'
      + '<button class="btn btn-outline" type="button" data-signout>Sign out</button>';
  }

  function header() {
    var el = document.createElement('header');
    el.className = 'hdr';
    el.innerHTML =
      '<div class="wrap hdr-in">'
      + '<a class="brand" href="/v2/"><img src="/images/quantpad-icon.svg" alt="">Belfort Trading</a>'
      + '<nav class="nav" aria-label="Primary">' + navLinks() + '</nav>'
      + '<div class="hdr-right">' + authArea()
      + '<button class="hdr-toggle" type="button" aria-label="Menu" aria-expanded="false">'
      + '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M3 12h18M3 18h18"/></svg>'
      + '</button></div></div>'
      + '<div class="drawer" id="drawer">' + navLinks()
      + '<div class="drawer-cta">' + authArea() + '</div></div>';
    return el;
  }

  function footer() {
    var el = document.createElement('footer');
    el.className = 'ftr';
    el.innerHTML =
      '<div class="wrap"><div class="ftr-cols">'
      + '<div><div class="brand" style="margin-bottom:14px;"><img src="/images/quantpad-icon.svg" alt="">Belfort Trading</div>'
      + '<p class="ftr-note">Backtest a trade log, stress-test it, and build the next version '
      + 'in a workspace on your own GitHub account.</p></div>'
      + FOOTER.map(function (col) {
          return '<div><h4>' + esc(col.title) + '</h4>'
            + col.links.map(function (l) { return '<a href="' + l.href + '">' + esc(l.label) + '</a>'; }).join('')
            + '</div>';
        }).join('')
      + '</div><div class="ftr-base"><span>&copy; ' + new Date().getFullYear() + ' Belfort Trading</span>'
      + '<span>Research software. Not financial advice.</span></div></div>';
    return el;
  }

  function mount() {
    var body = document.body;
    body.insertBefore(header(), body.firstChild);
    var main = document.querySelector('main');
    (main ? main.parentNode : body).insertBefore(footer(), main ? main.nextSibling : null);

    var toggle = document.querySelector('.hdr-toggle');
    var drawer = document.getElementById('drawer');
    toggle.addEventListener('click', function () {
      var open = drawer.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });

    Array.prototype.forEach.call(document.querySelectorAll('[data-signout]'), function (b) {
      b.addEventListener('click', function () {
        localStorage.removeItem(AUTH_KEY);
        location.reload();
      });
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount);
  else mount();
})();
