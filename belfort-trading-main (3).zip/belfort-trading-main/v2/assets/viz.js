/* =====================================================================
   Belfort Trading v2 - live models
   =====================================================================
   Every figure on these pages is computed here, in the visitor's browser,
   from one bundled 24-trade sample log. Nothing is a picture of a chart.

   Deliberately dependency-free: Plotly is 4.5 MB, which is a poor trade
   on a landing page that has 190 GB of monthly bandwidth to live within.
   These are a few hundred lines of SVG and canvas instead, drawn on the
   same seeded RNG the product uses, so the marketing numbers and the
   product numbers cannot drift apart.

   Draws only when a block scrolls into view, and skips the animation
   entirely when the visitor asks for reduced motion.
   ===================================================================== */
(function () {
  'use strict';

  var REDUCED = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var NS = 'http://www.w3.org/2000/svg';

  // The bundled sample: 24 real trades from the example log the backtester ships.
  var TRADES = [2400, -285, 690, 488, -3500, 885, -195, 672, 2300, -435,
                608, 773, -308, 536, 2200, -3500, 704, 2200, -263, 392,
                2200, -3500, 760, 584];

  var COLORS = {
    accent: '#7c83ff', accentSoft: 'rgba(124,131,255,.16)',
    gain: '#34d399', loss: '#fb7185',
    line: '#212124', fg3: '#71717A', fg2: '#A1A1AA',
  };

  // ── seeded RNG, same generator the engine uses ──────────────────────
  function mulberry32(a) {
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      var t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }

  // Block bootstrap: resample runs of trades, so streaks survive.
  function bootstrap(trades, paths, block, seed) {
    var rnd = mulberry32(seed || 42), out = [];
    for (var p = 0; p < paths; p++) {
      var eq = 0, path = [0];
      for (var i = 0; i < trades.length; i += block) {
        var start = Math.floor(rnd() * trades.length);
        for (var k = 0; k < block && i + k < trades.length; k++) {
          eq += trades[(start + k) % trades.length];
          path.push(eq);
        }
      }
      out.push(path);
    }
    return out;
  }

  function percentile(sorted, f) { return sorted[Math.floor(f * (sorted.length - 1))]; }

  function el(tag, attrs) {
    var n = document.createElementNS(NS, tag);
    for (var k in attrs) n.setAttribute(k, attrs[k]);
    return n;
  }

  function svg(host, w, h) {
    host.innerHTML = '';
    var s = el('svg', { viewBox: '0 0 ' + w + ' ' + h, width: '100%', height: '100%',
                        preserveAspectRatio: 'none', role: 'img' });
    host.appendChild(s);
    return s;
  }

  function scale(vals, w, h, pad) {
    pad = pad || 0;
    var min = Math.min.apply(null, vals), max = Math.max.apply(null, vals);
    if (min === max) { min -= 1; max += 1; }
    return {
      x: function (i, n) { return (i / (n - 1)) * w; },
      y: function (v) { return h - pad - ((v - min) / (max - min)) * (h - pad * 2); },
      min: min, max: max,
    };
  }

  function pathFrom(points) {
    return points.map(function (p, i) { return (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1); }).join(' ');
  }

  // Draw a line in, left to right.
  function animate(node, ms) {
    if (REDUCED) return;
    var len = node.getTotalLength ? node.getTotalLength() : 0;
    if (!len) return;
    node.style.strokeDasharray = len;
    node.style.strokeDashoffset = len;
    node.style.transition = 'stroke-dashoffset ' + (ms || 1400) + 'ms cubic-bezier(.22,1,.36,1)';
    requestAnimationFrame(function () { node.style.strokeDashoffset = 0; });
  }

  // ── 1. Monte Carlo fan: the hero ────────────────────────────────────
  function fan(host) {
    var W = 800, H = 320;
    var paths = bootstrap(TRADES, 400, 4, 7);
    var steps = paths[0].length;

    var lo = [], mid = [], hi = [];
    for (var i = 0; i < steps; i++) {
      var col = paths.map(function (p) { return p[i]; }).sort(function (a, b) { return a - b; });
      lo.push(percentile(col, .05)); mid.push(percentile(col, .5)); hi.push(percentile(col, .95));
    }
    var actual = [0];
    TRADES.reduce(function (acc, t) { var v = acc + t; actual.push(v); return v; }, 0);

    var all = lo.concat(hi, actual);
    var s = scale(all, W, H, 14);
    var g = svg(host, W, H);

    // zero line
    g.appendChild(el('line', { x1: 0, x2: W, y1: s.y(0), y2: s.y(0), stroke: COLORS.line, 'stroke-width': 1 }));

    // envelope
    var band = hi.map(function (v, i) { return [s.x(i, steps), s.y(v)]; })
      .concat(lo.map(function (v, i) { return [s.x(steps - 1 - i, steps), s.y(v)]; }));
    var poly = el('path', { d: pathFrom(band) + ' Z', fill: COLORS.accentSoft, stroke: 'none' });
    poly.style.opacity = REDUCED ? 1 : 0;
    g.appendChild(poly);
    if (!REDUCED) {
      poly.style.transition = 'opacity 900ms ease-out 250ms';
      requestAnimationFrame(function () { poly.style.opacity = 1; });
    }

    // a few individual paths, faint
    for (var p = 0; p < 26; p++) {
      var pts = paths[p * 13 % paths.length].map(function (v, i) { return [s.x(i, steps), s.y(v)]; });
      var line = el('path', { d: pathFrom(pts), fill: 'none', stroke: COLORS.accent,
                              'stroke-width': .7, opacity: .16 });
      g.appendChild(line);
      animate(line, 1600 + p * 20);
    }

    // median and the actual run
    var medPts = mid.map(function (v, i) { return [s.x(i, steps), s.y(v)]; });
    var med = el('path', { d: pathFrom(medPts), fill: 'none', stroke: COLORS.accent, 'stroke-width': 2 });
    g.appendChild(med); animate(med, 1500);

    var actPts = actual.map(function (v, i) { return [s.x(i, actual.length), s.y(v)]; });
    var act = el('path', { d: pathFrom(actPts), fill: 'none', stroke: '#F4F4F5',
                           'stroke-width': 1.6, 'stroke-dasharray': '4 3' });
    g.appendChild(act); animate(act, 1900);

    host.dataset.caption = '400 resampled orderings of the same 24 trades. Band is the 5th to 95th '
      + 'percentile, solid line the median, dotted the run that actually happened.';
  }

  // ── 1b. the same fan, but simulated in front of you ─────────────────
  //     Paths arrive one at a time over ~20 seconds and the envelope
  //     tightens as they do, so the page shows the work rather than the
  //     finished picture. The counter is the real path count.
  function liveFan(host) {
    var W = 800, H = 320, TOTAL = 400, SECONDS = 20;
    var paths = bootstrap(TRADES, TOTAL, 4, 7);
    var steps = paths[0].length;

    var actual = [0];
    TRADES.reduce(function (acc, t) { var v = acc + t; actual.push(v); return v; }, 0);

    // fix the scale up front from the finished distribution, so the axes
    // do not jump around while it fills in
    var flat = [].concat.apply([], paths).concat(actual);
    var s = scale(flat, W, H, 14);
    var g = svg(host, W, H);

    g.appendChild(el('line', { x1: 0, x2: W, y1: s.y(0), y2: s.y(0), stroke: COLORS.line, 'stroke-width': 1 }));
    var band = el('path', { fill: COLORS.accentSoft, stroke: 'none' });
    g.appendChild(band);
    var faint = el('g', { opacity: .18 });
    g.appendChild(faint);
    var med = el('path', { fill: 'none', stroke: COLORS.accent, 'stroke-width': 2 });
    g.appendChild(med);
    var act = el('path', { d: pathFrom(actual.map(function (v, i) { return [s.x(i, actual.length), s.y(v)]; })),
                           fill: 'none', stroke: '#F4F4F5', 'stroke-width': 1.6, 'stroke-dasharray': '4 3' });
    g.appendChild(act);

    var counter = host.parentNode.querySelector('[data-viz-counter]');
    var done = 0;
    var byStep = [];
    for (var i = 0; i < steps; i++) byStep.push([]);

    function redraw() {
      var lo = [], mid = [], hi = [];
      for (var i = 0; i < steps; i++) {
        var col = byStep[i].slice().sort(function (a, b) { return a - b; });
        lo.push(percentile(col, .05)); mid.push(percentile(col, .5)); hi.push(percentile(col, .95));
      }
      var poly = hi.map(function (v, i) { return [s.x(i, steps), s.y(v)]; })
        .concat(lo.map(function (v, i) { return [s.x(steps - 1 - i, steps), s.y(v)]; }));
      band.setAttribute('d', pathFrom(poly) + ' Z');
      med.setAttribute('d', pathFrom(mid.map(function (v, i) { return [s.x(i, steps), s.y(v)]; })));
    }

    if (REDUCED) {
      paths.forEach(function (p) { p.forEach(function (v, i) { byStep[i].push(v); }); });
      done = TOTAL; redraw();
      if (counter) counter.textContent = TOTAL + ' / ' + TOTAL + ' paths';
      return;
    }

    // one batch every frame-ish, spread across SECONDS
    var perTick = Math.max(1, Math.round(TOTAL / (SECONDS * 12)));
    var timer = setInterval(function () {
      for (var n = 0; n < perTick && done < TOTAL; n++, done++) {
        var p = paths[done];
        p.forEach(function (v, i) { byStep[i].push(v); });
        if (done % 9 === 0) {
          var line = el('path', {
            d: pathFrom(p.map(function (v, i) { return [s.x(i, steps), s.y(v)]; })),
            fill: 'none', stroke: COLORS.accent, 'stroke-width': .7,
          });
          faint.appendChild(line);
        }
      }
      redraw();
      if (counter) counter.textContent = done + ' / ' + TOTAL + ' paths';
      if (done >= TOTAL) {
        clearInterval(timer);
        if (counter) counter.textContent = TOTAL + ' paths · complete';
      }
    }, 1000 / 12);
  }

  // ── 2. Terminal outcome distribution ────────────────────────────────
  function dist(host) {
    var W = 320, H = 120;
    var paths = bootstrap(TRADES, 1200, 4, 11);
    var finals = paths.map(function (p) { return p[p.length - 1]; });
    var min = Math.min.apply(null, finals), max = Math.max.apply(null, finals);
    var bins = 34, counts = new Array(bins).fill(0);
    finals.forEach(function (v) {
      var b = Math.min(bins - 1, Math.floor((v - min) / (max - min) * bins));
      counts[b]++;
    });
    var peak = Math.max.apply(null, counts);
    var g = svg(host, W, H);
    var bw = W / bins;
    counts.forEach(function (c, i) {
      var h = (c / peak) * (H - 16);
      var v = min + (i + .5) / bins * (max - min);
      var r = el('rect', { x: (i * bw + .6).toFixed(1), y: (H - h).toFixed(1),
                           width: (bw - 1.2).toFixed(1), height: h.toFixed(1),
                           fill: v >= 0 ? COLORS.accent : COLORS.loss, opacity: .8 });
      g.appendChild(r);
      if (!REDUCED) {
        r.style.transformOrigin = 'bottom';
        r.style.transform = 'scaleY(0)';
        r.style.transition = 'transform 600ms cubic-bezier(.22,1,.36,1) ' + (i * 14) + 'ms';
        requestAnimationFrame(function () { r.style.transform = 'scaleY(1)'; });
      }
    });
    var zero = ((0 - min) / (max - min)) * W;
    g.appendChild(el('line', { x1: zero, x2: zero, y1: 0, y2: H, stroke: COLORS.fg3,
                               'stroke-width': 1, 'stroke-dasharray': '3 3' }));
    var profitable = finals.filter(function (v) { return v > 0; }).length / finals.length;
    host.dataset.stat = Math.round(profitable * 100) + '% of paths end in profit';
  }

  // ── 3. Prop-firm pass rates, simulated against real rule sets ───────
  var FIRMS = [
    { name: 'FTMO 100k', target: 10000, dd: 10000, days: 30 },
    { name: 'FTMO 50k', target: 5000, dd: 5000, days: 30 },
    { name: 'Apex 100k', target: 6000, dd: 3000, days: 45 },
    { name: 'Topstep 50k', target: 3000, dd: 2000, days: 15 },
    { name: 'E8 100k', target: 8000, dd: 8000, days: 30 },
  ];

  function passRate(firm, runs, seed) {
    var rnd = mulberry32(seed), pass = 0;
    for (var r = 0; r < runs; r++) {
      var eq = 0, peak = 0, done = false;
      // one trading day is roughly two trades in this sample
      for (var d = 0; d < firm.days * 2 && !done; d++) {
        eq += TRADES[Math.floor(rnd() * TRADES.length)];
        peak = Math.max(peak, eq);
        if (eq <= -firm.dd) { done = true; }
        else if (eq >= firm.target) { pass++; done = true; }
      }
    }
    return pass / runs;
  }

  function passBars(host) {
    var rates = FIRMS.map(function (f, i) { return { name: f.name, rate: passRate(f, 400, 21 + i) }; });
    host.innerHTML = '';
    rates.forEach(function (r, i) {
      var row = document.createElement('div');
      row.className = 'viz-bar';
      row.innerHTML = '<span class="viz-bar-l">' + r.name + '</span>'
        + '<span class="viz-bar-track"><i></i></span>'
        + '<span class="viz-bar-v mono">' + (r.rate * 100).toFixed(0) + '%</span>';
      host.appendChild(row);
      var fill = row.querySelector('i');
      fill.style.background = r.rate > .4 ? COLORS.gain : r.rate > .15 ? COLORS.accent : COLORS.loss;
      if (REDUCED) { fill.style.width = (r.rate * 100) + '%'; }
      else {
        fill.style.width = '0%';
        fill.style.transition = 'width 900ms cubic-bezier(.22,1,.36,1) ' + (i * 90) + 'ms';
        requestAnimationFrame(function () { fill.style.width = (r.rate * 100) + '%'; });
      }
    });
  }

  // ── 4. Weekly P&L heat strip ────────────────────────────────────────
  function heat(host) {
    var rnd = mulberry32(5), weeks = [];
    for (var w = 0; w < 52; w++) {
      var sum = 0;
      for (var t = 0; t < 4; t++) sum += TRADES[Math.floor(rnd() * TRADES.length)];
      weeks.push(sum);
    }
    var max = Math.max.apply(null, weeks.map(Math.abs));
    host.innerHTML = '';
    weeks.forEach(function (v, i) {
      var cell = document.createElement('i');
      var a = Math.min(1, Math.abs(v) / max);
      cell.style.background = v >= 0
        ? 'rgba(52,211,153,' + (0.12 + a * 0.75) + ')'
        : 'rgba(251,113,133,' + (0.12 + a * 0.75) + ')';
      cell.title = 'Week ' + (i + 1) + ': ' + (v >= 0 ? '+' : '') + Math.round(v);
      host.appendChild(cell);
      if (!REDUCED) {
        cell.style.opacity = 0;
        cell.style.transition = 'opacity 400ms ease-out ' + (i * 12) + 'ms';
        requestAnimationFrame(function () { cell.style.opacity = 1; });
      }
    });
  }

  // ── 5. Risk surface: sorted paths as a wireframe ────────────────────
  function surface(host) {
    var c = document.createElement('canvas');
    var W = host.clientWidth || 640, H = host.clientHeight || 300;
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    c.width = W * dpr; c.height = H * dpr;
    c.style.width = '100%'; c.style.height = '100%';
    host.innerHTML = ''; host.appendChild(c);
    var ctx = c.getContext('2d');
    ctx.scale(dpr, dpr);

    var paths = bootstrap(TRADES, 220, 4, 3)
      .sort(function (a, b) { return a[a.length - 1] - b[b.length - 1]; });
    var rows = [];
    for (var i = 0; i < paths.length; i += 6) rows.push(paths[i]);

    var all = [].concat.apply([], rows);
    var min = Math.min.apply(null, all), max = Math.max.apply(null, all);
    var steps = rows[0].length;

    function project(xi, yi, v) {
      var x = (xi / (steps - 1)) * (W * 0.72) + (yi / rows.length) * (W * 0.22) + W * 0.03;
      var depth = (yi / rows.length) * (H * 0.34);
      var y = H * 0.86 - depth - ((v - min) / (max - min)) * (H * 0.5);
      return [x, y];
    }

    // draw in, then keep turning slowly so the shape reads as a solid
    var drawn = 0, spin = 0, visible = true;
    if (host.__spinObserver) host.__spinObserver.disconnect();
    host.__spinObserver = new IntersectionObserver(function (es) {
      visible = es[0].isIntersecting;
      if (visible) requestAnimationFrame(frame);
    });
    host.__spinObserver.observe(host);

    function frame() {
      var upto = REDUCED ? rows.length : Math.min(rows.length, drawn += 1);
      if (!REDUCED && upto >= rows.length) spin += 0.0016;   // a slow idle orbit
      var skew = Math.sin(spin) * 0.09;

      ctx.clearRect(0, 0, W, H);
      for (var yi = 0; yi < upto; yi++) {
        var row = rows[yi], final = row[row.length - 1];
        ctx.beginPath();
        for (var xi = 0; xi < steps; xi++) {
          var p = project(xi, yi, row[xi]);
          // shear the whole surface a little as it turns
          var px = p[0] + (p[1] - H * 0.5) * skew;
          xi ? ctx.lineTo(px, p[1]) : ctx.moveTo(px, p[1]);
        }
        var t = yi / rows.length;
        ctx.strokeStyle = final >= 0
          ? 'rgba(' + Math.round(124 + t * -70) + ',' + Math.round(131 + t * 80) + ',255,' + (0.25 + t * 0.5) + ')'
          : 'rgba(251,113,133,' + (0.5 - t * 0.2) + ')';
        ctx.lineWidth = 1;
        ctx.stroke();
      }
      if (!REDUCED && visible) requestAnimationFrame(frame);
    }
    frame();
  }

  // ── mount: draw when visible, once ──────────────────────────────────
  var KINDS = { fan: fan, livefan: liveFan, dist: dist, bars: passBars, heat: heat, surface: surface };

  function mount() {
    var nodes = document.querySelectorAll('[data-viz]');
    if (!nodes.length) return;
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (!e.isIntersecting || e.target.dataset.drawn) return;
        e.target.dataset.drawn = '1';
        var fn = KINDS[e.target.dataset.viz];
        if (!fn) return;
        try { fn(e.target); } catch (err) { e.target.style.display = 'none'; }
        var cap = e.target.dataset.caption, stat = e.target.dataset.stat;
        var note = e.target.nextElementSibling;
        if (note && note.classList.contains('viz-note')) {
          if (stat) note.textContent = stat;
          else if (cap) note.textContent = cap;
        }
        io.unobserve(e.target);
      });
    }, { rootMargin: '80px' });
    Array.prototype.forEach.call(nodes, function (n) { io.observe(n); });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount);
  else mount();
})();
