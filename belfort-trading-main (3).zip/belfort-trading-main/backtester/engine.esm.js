// backtester-src/csv.ts
var normalize = (value) => String(value || "").trim().toLowerCase().replace(/[%$£€]/g, "").replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");
var RESULT_ALIASES = [
  "pnl",
  "profit",
  "profit_loss",
  "net_pnl",
  "net_profit",
  "net_return",
  "return",
  "returns",
  "ret",
  "r",
  "r_multiple",
  "r_multiple_points",
  "profit_pct",
  "return_pct",
  "pnl_pct",
  "net"
];
var DATE_ALIASES = [
  "date",
  "datetime",
  "timestamp",
  "time",
  "entry_date",
  "entry_time",
  "exit_date",
  "exit_time",
  "opened_at",
  "closed_at",
  "open_time",
  "close_time"
];
var ENTRY_ALIASES = ["entry", "entry_price", "open", "open_price", "entry_price_1", "price_1", "buy_price"];
var EXIT_ALIASES = ["exit", "exit_price", "close", "close_price", "exit_price_1", "price_2", "sell_price"];
var SIZE_ALIASES = ["size", "quantity", "qty", "shares", "contracts", "units", "lots"];
var DIRECTION_ALIASES = ["direction", "side", "position", "type", "action", "signal"];
var FEE_ALIASES = ["fee", "fees", "commission", "commissions", "cost", "slippage"];
var QUANTITY_RE = /^([0-9.]+)(m|k|klote|lot)?$/i;
var SHORT_RE = /^(short|sell|s|bajista|put)$/i;
var LONG_RE = /^(long|buy|l|call)$/i;
function parseNumber(raw) {
  const value = String(raw ?? "").trim();
  if (!value) return NaN;
  const negative = /^\(.*\)$/.test(value);
  let cleaned = value.replace(/[()$£€,%\s]/g, "");
  cleaned = cleaned.replace(/(\d)[,.](\d)/g, "$1.$2");
  const parsed = Number(cleaned);
  if (Number.isNaN(parsed)) {
    const match = value.replace(/[()$£€,\s]/g, "").match(/^[+-]?(\d+)$/);
    return match ? negative ? -Number(match[1]) : Number(match[1]) : NaN;
  }
  return negative ? -parsed : parsed;
}
function parseSize(raw) {
  const value = String(raw ?? "").trim();
  if (!value) return null;
  const match = value.match(QUANTITY_RE);
  if (!match) return null;
  let number = parseFloat(match[1]);
  if (Number.isNaN(number)) return null;
  const suffix = (match[2] || "").toLowerCase();
  if (suffix === "k") number *= 1e3;
  else if (suffix === "m") number *= 1e6;
  return number;
}
function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];
    const next = text[i + 1];
    if (char === '"' && quoted && next === '"') {
      cell += '"';
      i += 1;
      continue;
    }
    if (char === '"') {
      quoted = !quoted;
      continue;
    }
    if (char === "," && !quoted) {
      row.push(cell);
      cell = "";
      continue;
    }
    if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && next === "\n") i += 1;
      row.push(cell);
      if (row.some((v) => v.trim())) rows.push(row);
      row = [];
      cell = "";
      continue;
    }
    cell += char;
  }
  if (cell.length || row.length) {
    row.push(cell);
    if (row.some((v) => v.trim())) rows.push(row);
  }
  return rows;
}
function findIndex(headers, aliases) {
  for (const alias of aliases) {
    const index = headers.indexOf(alias);
    if (index >= 0) return index;
  }
  return -1;
}
function isTradingViewFormat(headers) {
  return headers.includes("type") && headers.includes("price") && headers.includes("date_time");
}
function parseTradingViewTradeList(rows) {
  const headers = rows[0].map(normalize);
  const typeIdx = headers.indexOf("type");
  const dateIdx = headers.indexOf("date_time");
  const priceIdx = headers.indexOf("price");
  const qtyIdx = headers.indexOf("qty") >= 0 ? headers.indexOf("qty") : headers.indexOf("quantity");
  const pnlIdx = headers.indexOf("p_l");
  const tradeNumIdx = headers.indexOf("trade");
  if (typeIdx < 0 || priceIdx < 0 || dateIdx < 0) return null;
  const groups = /* @__PURE__ */ new Map();
  for (let r = 1; r < rows.length; r += 1) {
    const row = rows[r];
    if (!row.some((v) => v.trim())) continue;
    const key = tradeNumIdx >= 0 && row[tradeNumIdx] ? row[tradeNumIdx].trim() : String(r);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(row);
  }
  const trades = [];
  groups.forEach((group) => {
    let entry = group.find((row) => /entry/i.test(row[typeIdx] || ""));
    let exit = group.find((row) => /exit/i.test(row[typeIdx] || ""));
    if (!entry && !exit) {
      entry = group[0];
      exit = group[group.length - 1];
    }
    if (!entry || !exit) return;
    const typeStr = (entry[typeIdx] || "").toLowerCase();
    const direction = /short/.test(typeStr) ? "short" : /long/.test(typeStr) ? "long" : "unknown";
    const entryPrice = parseNumber(entry[priceIdx]);
    const exitPrice = parseNumber(exit[priceIdx]);
    const qty = qtyIdx >= 0 ? parseSize((entry[qtyIdx] || exit[qtyIdx] || "").trim()) : null;
    const size = qty ?? 1;
    let pnl = pnlIdx >= 0 ? parseNumber(exit[pnlIdx] || "") : NaN;
    if (!Number.isFinite(pnl) && Number.isFinite(entryPrice) && Number.isFinite(exitPrice)) {
      const sign = direction === "short" ? -1 : 1;
      pnl = (exitPrice - entryPrice) * sign * size;
    }
    if (!Number.isFinite(pnl)) return;
    const rawDate = (exit[dateIdx] || "").trim();
    let date = null;
    if (rawDate) {
      const parsed = new Date(rawDate);
      if (!Number.isNaN(parsed.getTime())) date = parsed.toISOString();
    }
    trades.push({
      row: 0,
      date,
      direction,
      entry: Number.isFinite(entryPrice) ? entryPrice : null,
      exit: Number.isFinite(exitPrice) ? exitPrice : null,
      size: qtyIdx >= 0 ? qty : null,
      fee: 0,
      pnl
    });
  });
  trades.sort((a, b) => {
    if (a.date && b.date) return new Date(a.date).getTime() - new Date(b.date).getTime();
    return 0;
  });
  trades.forEach((trade, index) => {
    trade.row = index + 2;
  });
  return trades;
}
function buildTradeLog(text) {
  const rows = parseCsv(text);
  if (rows.length < 2) {
    throw new Error("Add a header row and at least two trade rows to run a backtest.");
  }
  const headers = rows[0].map(normalize);
  if (isTradingViewFormat(headers)) {
    const tvTrades = parseTradingViewTradeList(rows);
    if (tvTrades && tvTrades.length >= 2) {
      return {
        trades: tvTrades,
        ignored: 0,
        detected: ["tradingview", "date", "entry", "exit", "size", "direction"],
        derivedPnl: false,
        hasDates: tvTrades.some((trade) => trade.date !== null)
      };
    }
    throw new Error(
      "TradingView trade list detected but fewer than two complete trades were found. Each trade needs both an Entry and an Exit fill."
    );
  }
  const resultIndex = findIndex(headers, RESULT_ALIASES);
  const dateIndex = findIndex(headers, DATE_ALIASES);
  const entryIndex = findIndex(headers, ENTRY_ALIASES);
  const exitIndex = findIndex(headers, EXIT_ALIASES);
  const sizeIndex = findIndex(headers, SIZE_ALIASES);
  const directionIndex = findIndex(headers, DIRECTION_ALIASES);
  const feeIndex = findIndex(headers, FEE_ALIASES);
  if (resultIndex < 0 && (entryIndex < 0 || exitIndex < 0)) {
    throw new Error(
      "No usable result column. Include pnl/profit/return, or entry and exit price columns."
    );
  }
  const trades = [];
  let ignored = 0;
  let derived = false;
  const detected = [];
  if (resultIndex >= 0) detected.push(headers[resultIndex]);
  if (dateIndex >= 0) detected.push("date");
  if (entryIndex >= 0) detected.push("entry");
  if (exitIndex >= 0) detected.push("exit");
  if (sizeIndex >= 0) detected.push("size");
  if (directionIndex >= 0) detected.push("direction");
  if (feeIndex >= 0) detected.push("fee");
  for (let r = 1; r < rows.length; r += 1) {
    const values = rows[r];
    const read = (index) => index >= 0 && index < values.length ? values[index] : "";
    let pnl = NaN;
    if (resultIndex >= 0) {
      pnl = parseNumber(read(resultIndex));
    }
    if (!Number.isFinite(pnl) && entryIndex >= 0 && exitIndex >= 0) {
      const entry2 = parseNumber(read(entryIndex));
      const exit2 = parseNumber(read(exitIndex));
      const size2 = sizeIndex >= 0 ? parseSize(read(sizeIndex)) : 1;
      if (Number.isFinite(entry2) && Number.isFinite(exit2)) {
        const directionRaw2 = read(directionIndex);
        const direction2 = SHORT_RE.test(directionRaw2) ? -1 : 1;
        pnl = (exit2 - entry2) * direction2 * (size2 ?? 1);
        derived = true;
      }
    }
    if (!Number.isFinite(pnl)) {
      ignored += 1;
      continue;
    }
    const rawDate = read(dateIndex).trim();
    let date = null;
    if (rawDate) {
      const parsed = new Date(rawDate);
      if (!Number.isNaN(parsed.getTime())) date = parsed.toISOString();
    }
    const fee = feeIndex >= 0 ? parseNumber(read(feeIndex)) : 0;
    const directionRaw = read(directionIndex);
    let direction = "unknown";
    if (directionRaw) {
      if (LONG_RE.test(directionRaw)) direction = "long";
      else if (SHORT_RE.test(directionRaw)) direction = "short";
    }
    const entry = entryIndex >= 0 ? parseNumber(read(entryIndex)) : null;
    const exit = exitIndex >= 0 ? parseNumber(read(exitIndex)) : null;
    const size = sizeIndex >= 0 ? parseSize(read(sizeIndex)) : null;
    trades.push({
      row: r + 1,
      date,
      direction,
      entry: Number.isFinite(entry) ? entry : null,
      exit: Number.isFinite(exit) ? exit : null,
      size,
      fee: Number.isFinite(fee) ? fee : 0,
      pnl: pnl - (Number.isFinite(fee) ? fee : 0)
    });
  }
  if (trades.length < 2) {
    throw new Error("At least two valid trade rows are required after parsing.");
  }
  return {
    trades,
    ignored,
    detected,
    derivedPnl: derived,
    hasDates: trades.some((trade) => trade.date !== null)
  };
}

// backtester-src/metrics.ts
function computeMetrics(log) {
  const trades = log.trades;
  const returns = trades.map((trade) => trade.pnl);
  const wins = returns.filter((value) => value > 0);
  const losses = returns.filter((value) => value < 0);
  const count = returns.length;
  const winCount = wins.length;
  const lossCount = losses.length;
  const winRate = count > 0 ? winCount / count : 0;
  const grossWins = wins.reduce((total, value) => total + value, 0);
  const grossLosses = Math.abs(losses.reduce((total, value) => total + value, 0));
  const netPnl = returns.reduce((total, value) => total + value, 0);
  const expectancy = count > 0 ? netPnl / count : 0;
  let equity = 0;
  const equitySeries = [];
  const drawdownSeries = [];
  const tradeDates = [];
  const monthlyMap = /* @__PURE__ */ new Map();
  let peak = 0;
  let maxDrawdown = 0;
  for (let i = 0; i < returns.length; i += 1) {
    const value = returns[i];
    equity += value;
    equitySeries.push(equity);
    peak = Math.max(peak, equity);
    const drawdown = equity - peak;
    drawdownSeries.push(drawdown);
    maxDrawdown = Math.min(maxDrawdown, drawdown);
    const trade = trades[i];
    const iso = trade.date ?? null;
    tradeDates.push(iso);
    if (iso) {
      const parsed = new Date(iso);
      if (!Number.isNaN(parsed.getTime())) {
        const key = `${parsed.getFullYear()}-${parsed.getMonth()}`;
        monthlyMap.set(key, (monthlyMap.get(key) || 0) + value);
      }
    }
  }
  const monthlyReturns = Array.from(monthlyMap.entries()).map(([key, pnl]) => {
    const [year, month] = key.split("-").map(Number);
    return { year, month, pnl };
  }).sort((a, b) => a.year !== b.year ? a.year - b.year : a.month - b.month);
  const tradeDetails = trades.map((trade, i) => ({
    index: i + 1,
    date: trade.date,
    direction: trade.direction,
    entry: trade.entry,
    exit: trade.exit,
    size: trade.size,
    pnl: returns[i],
    equity: equitySeries[i],
    drawdown: drawdownSeries[i]
  }));
  let maxConsecutiveWins = 0;
  let maxConsecutiveLosses = 0;
  let currentWins = 0;
  let currentLosses = 0;
  for (const value of returns) {
    if (value > 0) {
      currentWins += 1;
      currentLosses = 0;
      maxConsecutiveWins = Math.max(maxConsecutiveWins, currentWins);
    } else if (value < 0) {
      currentLosses += 1;
      currentWins = 0;
      maxConsecutiveLosses = Math.max(maxConsecutiveLosses, currentLosses);
    }
  }
  const mean = expectancy;
  const variance = count > 0 ? returns.reduce((total, value) => total + (value - mean) ** 2, 0) / count : 0;
  const standardDeviation = Math.sqrt(variance);
  const dated = trades.filter((trade) => trade.date !== null).sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
  );
  let avgHoldMs = null;
  if (dated.length > 1) {
    let totalHold = 0;
    let pairs = 0;
    for (let i = 1; i < dated.length; i += 1) {
      const current = new Date(dated[i].date).getTime();
      const previous = new Date(dated[i - 1].date).getTime();
      if (Number.isFinite(current) && Number.isFinite(previous)) {
        totalHold += current - previous;
        pairs += 1;
      }
    }
    if (pairs > 0) avgHoldMs = totalHold / pairs;
  }
  const bestTrade = returns.length > 0 ? Math.max(...returns) : 0;
  const worstTrade = returns.length > 0 ? Math.min(...returns) : 0;
  const positivePathsPct = winRate;
  const sharpeLike = standardDeviation > 0 ? mean / standardDeviation * Math.sqrt(Math.max(count, 1)) : 0;
  const rExpectancy = standardDeviation > 0 ? expectancy / standardDeviation : 0;
  const score = gradeScore({
    expectancy,
    profitFactor: grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? 3 : 0,
    winRate,
    maxDrawdownAbs: Math.abs(maxDrawdown),
    grossWins,
    count,
    positivePathsPct,
    sharpeLike,
    rExpectancy,
    maxConsecutiveLosses
  });
  return {
    count,
    winCount,
    lossCount,
    winRate,
    grossWins,
    grossLosses,
    profitFactor: grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? Infinity : 0,
    netPnl,
    expectancy,
    rExpectancy: standardDeviation > 0 ? expectancy / standardDeviation : 0,
    standardDeviation,
    sharpeLike: standardDeviation > 0 ? mean / standardDeviation * Math.sqrt(Math.max(count, 1)) : 0,
    maxDrawdown: Math.abs(maxDrawdown),
    maxDrawdownPct: peak > 0 ? Math.abs(maxDrawdown) / peak : 0,
    maxConsecutiveWins,
    maxConsecutiveLosses,
    avgHoldMs,
    bestTrade,
    worstTrade,
    equity: equitySeries,
    drawdownSeries,
    returns,
    tradeDates,
    monthlyReturns,
    tradeDetails,
    grade: score.grade,
    gradeLabel: score.label,
    gradeScore: score.score,
    gradeBreakdown: score.breakdown,
    gradeAdvice: score.advice
  };
}
function gradeScore(metrics) {
  const subs = [];
  let prof = 0;
  if (metrics.expectancy > 0) prof += 10;
  if (metrics.profitFactor >= 2) prof += 15;
  else if (metrics.profitFactor >= 1.5) prof += 10;
  else if (metrics.profitFactor >= 1.15) prof += 4;
  subs.push({ category: "Profitability", score: prof, max: 25 });
  let cons = 0;
  if (metrics.winRate >= 0.55) cons += 10;
  else if (metrics.winRate >= 0.45) cons += 6;
  else if (metrics.winRate >= 0.35) cons += 3;
  if (metrics.positivePathsPct >= 0.7) cons += 10;
  else if (metrics.positivePathsPct >= 0.55) cons += 6;
  else if (metrics.positivePathsPct >= 0.4) cons += 3;
  subs.push({ category: "Consistency", score: cons, max: 20 });
  let risk = 0;
  if (metrics.grossWins > 0) {
    if (metrics.maxDrawdownAbs <= metrics.grossWins * 0.25) risk += 15;
    else if (metrics.maxDrawdownAbs <= metrics.grossWins * 0.5) risk += 10;
    else if (metrics.maxDrawdownAbs <= metrics.grossWins) risk += 4;
  }
  if (metrics.maxConsecutiveLosses <= 3) risk += 10;
  else if (metrics.maxConsecutiveLosses <= 5) risk += 6;
  else if (metrics.maxConsecutiveLosses <= 8) risk += 2;
  subs.push({ category: "Risk control", score: risk, max: 25 });
  let rob = 0;
  if (metrics.sharpeLike >= 2) rob += 10;
  else if (metrics.sharpeLike >= 1.2) rob += 7;
  else if (metrics.sharpeLike >= 0.6) rob += 3;
  if (metrics.rExpectancy >= 0.3) rob += 10;
  else if (metrics.rExpectancy >= 0.15) rob += 6;
  else if (metrics.rExpectancy >= 0.05) rob += 2;
  subs.push({ category: "Robustness", score: rob, max: 20 });
  let samp = 0;
  if (metrics.count >= 200) samp += 10;
  else if (metrics.count >= 100) samp += 8;
  else if (metrics.count >= 50) samp += 5;
  else if (metrics.count >= 20) samp += 3;
  else if (metrics.count >= 5) samp += 1;
  subs.push({ category: "Sample size", score: samp, max: 10 });
  const score = subs.reduce((a, s) => a + s.score, 0);
  const grade = score >= 88 ? "A" : score >= 74 ? "B" : score >= 58 ? "C" : score >= 40 ? "D" : "F";
  const labels = {
    A: "Strong evidence",
    B: "Promising evidence",
    C: "Mixed evidence",
    D: "Weak evidence",
    F: "Needs work"
  };
  const advice = [];
  if (prof < 15) advice.push("Improve profitability: filter trades with weak edge or tighten stops to lift profit factor above 1.5.");
  if (cons < 12) advice.push("Raise consistency: review losing streaks and entry timing (see autocorrelation) to push the win rate above 50%.");
  if (risk < 15) advice.push("Tighten risk control: reduce position size or add a hard stop to cap drawdown and consecutive losses.");
  if (rob < 12) advice.push("Strengthen robustness: the risk-adjusted return is thin \u2014 favor higher-expectancy setups to improve the Sharpe-like ratio.");
  if (samp < 5) advice.push("Gather more trades: the sample is small, so every metric here carries low confidence.");
  return { score, grade, label: labels[grade], breakdown: subs, advice };
}

// backtester-src/rng.ts
function mulberry32(seed) {
  let state = seed >>> 0;
  return () => {
    state = state + 1831565813 >>> 0;
    let value = state;
    value = Math.imul(value ^ value >>> 15, value | 1);
    value ^= value + Math.imul(value ^ value >>> 7, value | 61);
    return ((value ^ value >>> 14) >>> 0) / 4294967296;
  };
}
function hashSeed(values) {
  let seed = 2166136261;
  for (let i = 0; i < values.length; i += 1) {
    const bits = Math.round(values[i] * 100) | 0;
    seed = (seed ^ bits) * 16777619 >>> 0;
    seed = (seed ^ i * 2654435761) >>> 0;
  }
  return seed >>> 0;
}
function shuffle(array, random) {
  const copy = array.slice();
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(random() * (i + 1));
    const swap = copy[i];
    copy[i] = copy[j];
    copy[j] = swap;
  }
  return copy;
}

// backtester-src/montecarlo.ts
function runMonteCarlo(returns, config, startingBalance = 0) {
  if (returns.length < 2) {
    throw new Error("At least two trades are required for Monte Carlo.");
  }
  const paths = Math.min(Math.max(config.paths, 10), 5e3);
  const blockSize = Math.min(Math.max(config.blockSize, 1), Math.max(returns.length, 1));
  const random = mulberry32(config.seed);
  const numberOfBlocks = Math.ceil(returns.length / blockSize);
  const pathEquity = [];
  const terminals = [];
  const drawdowns = [];
  for (let path = 0; path < paths; path += 1) {
    const blocks = [];
    for (let block = 0; block < numberOfBlocks; block += 1) {
      const start = Math.floor(random() * returns.length);
      for (let offset = 0; offset < blockSize; offset += 1) {
        blocks.push(returns[(start + offset) % returns.length]);
      }
    }
    const sampled = blocks.slice(0, returns.length);
    let equity = startingBalance;
    const series = [];
    let peak = startingBalance;
    let maxDrawdown = 0;
    for (const value of sampled) {
      equity += value;
      series.push(equity);
      peak = Math.max(peak, equity);
      maxDrawdown = Math.max(maxDrawdown, peak - equity);
    }
    pathEquity.push(series);
    terminals.push(equity);
    drawdowns.push(maxDrawdown);
  }
  const sorted = terminals.slice().sort((a, b) => a - b);
  const sortedDrawdowns = drawdowns.slice().sort((a, b) => a - b);
  const positivePaths = terminals.filter((value) => value > startingBalance).length;
  return {
    config,
    terminals,
    paths: pathEquity,
    p5: percentile(sorted, 0.05),
    p50: percentile(sorted, 0.5),
    p95: percentile(sorted, 0.95),
    positivePaths,
    positivePathsPct: positivePaths / paths,
    riskOfRuinPct: percentile(sorted, 0.05) < startingBalance ? lowTailRisk(terminals, startingBalance) : 0,
    drawdownPercentiles: {
      p50: percentile(sortedDrawdowns, 0.5),
      p95: percentile(sortedDrawdowns, 0.95)
    }
  };
}
function percentile(sorted, fraction) {
  if (sorted.length === 0) return 0;
  const index = Math.min(sorted.length - 1, Math.floor(sorted.length * fraction));
  return sorted[index];
}
function lowTailRisk(terminals, startingBalance) {
  const loss = terminals.filter((value) => value < startingBalance).length;
  return loss / terminals.length * 100;
}

// backtester-src/propfirm.ts
var PROP_FIRM_PRESETS = [
  {
    name: "FTMO 100k",
    accountSize: 1e5,
    profitTarget: 1e4,
    maxDailyLoss: 5e3,
    maxTotalDrawdown: 1e4,
    evaluationDays: 30,
    payoutPct: 80,
    challengeFee: 549,
    minPayout: 1e3,
    payoutDays: 14,
    trailingDrawdown: false,
    resetFee: 549,
    scaling: 1,
    phases: 1,
    consistencyPct: 50
  },
  {
    name: "FTMO 50k",
    accountSize: 5e4,
    profitTarget: 5e3,
    maxDailyLoss: 2500,
    maxTotalDrawdown: 5e3,
    evaluationDays: 30,
    payoutPct: 80,
    challengeFee: 299,
    minPayout: 500,
    payoutDays: 14,
    trailingDrawdown: false,
    resetFee: 299,
    scaling: 1,
    phases: 1,
    consistencyPct: 50
  },
  {
    name: "Apex 100k",
    accountSize: 1e5,
    profitTarget: 6e3,
    maxDailyLoss: 4500,
    maxTotalDrawdown: 5e3,
    evaluationDays: 30,
    payoutPct: 90,
    challengeFee: 150,
    minPayout: 500,
    payoutDays: 1,
    trailingDrawdown: false,
    resetFee: 150,
    scaling: 1,
    phases: 1,
    consistencyPct: 0
  },
  {
    name: "Topstep 50k",
    accountSize: 5e4,
    profitTarget: 3e3,
    maxDailyLoss: 2e3,
    maxTotalDrawdown: 2e3,
    evaluationDays: 15,
    payoutPct: 100,
    challengeFee: 165,
    minPayout: 500,
    payoutDays: 5,
    trailingDrawdown: true,
    resetFee: 165,
    scaling: 1,
    phases: 1,
    consistencyPct: 50
  },
  {
    name: "E8 100k",
    accountSize: 1e5,
    profitTarget: 8e3,
    maxDailyLoss: 3e3,
    maxTotalDrawdown: 6e3,
    evaluationDays: 30,
    payoutPct: 100,
    challengeFee: 599,
    minPayout: 500,
    payoutDays: 7,
    trailingDrawdown: false,
    resetFee: 599,
    scaling: 2,
    phases: 1,
    consistencyPct: 50
  }
];
function defaultPropFirmConfig() {
  return { ...PROP_FIRM_PRESETS[0] };
}
function tradesPerDay(trades) {
  const days = /* @__PURE__ */ new Set();
  for (const trade of trades) {
    if (trade.date) days.add(trade.date.slice(0, 10));
  }
  return Math.max(days.size, 1);
}
function runPropFirmSimulation(trades, config, options) {
  const runs = Math.min(Math.max(options.runs, 10), 1e4);
  const random = mulberry32(options.seed);
  const baseline = options.strategyBaseline && options.strategyBaseline > 0 ? options.strategyBaseline : config.accountSize;
  const scale = config.accountSize / baseline;
  const pnl = trades.map((trade) => trade.pnl * scale);
  const actualDays = tradesPerDay(trades);
  const tradesPerDayCount = pnl.length / actualDays;
  const dailyLossLimit = config.maxDailyLoss;
  const totalDrawdownLimit = config.maxTotalDrawdown;
  const target = config.profitTarget;
  let passCount = 0;
  let daysToTargetTotal = 0;
  let daysToTargetCount = 0;
  let profitAtPassTotal = 0;
  const failures = {
    "Daily loss breach": 0,
    "Max total drawdown breach": 0,
    "Consistency rule breach": 0,
    "Evaluation period expired": 0
  };
  const consistencyLimit = config.consistencyPct > 0 && config.consistencyPct < 100 ? config.consistencyPct / 100 * config.profitTarget : Infinity;
  const sampleRuns = [];
  let passSamples = 0;
  const failByReason = {};
  const MAX_PASS_SAMPLES = 12;
  const MAX_FAIL_PER_REASON = 4;
  const SAFETY_CAP = config.evaluationDays * Math.max(1, Math.ceil(tradesPerDayCount)) * 50;
  for (let run = 0; run < runs; run += 1) {
    let order = shuffle(pnl, random);
    let cursor = 0;
    let balance = config.accountSize;
    let peak = config.accountSize;
    let trough = config.accountSize;
    let dailyNet = 0;
    let maxDailyProfit = 0;
    let tradesToday = 0;
    let day = 1;
    let result = "fail";
    let failureReason = "Evaluation period expired";
    const runEquity = [config.accountSize];
    for (let iter = 0; iter < SAFETY_CAP; iter += 1) {
      if (cursor >= order.length) {
        order = shuffle(pnl, random);
        cursor = 0;
      }
      if (tradesToday >= tradesPerDayCount && day < config.evaluationDays) {
        day += 1;
        dailyNet = 0;
        tradesToday = 0;
      }
      const pnlThisTrade = order[cursor];
      cursor += 1;
      tradesToday += 1;
      balance += pnlThisTrade;
      dailyNet += pnlThisTrade;
      if (dailyNet > maxDailyProfit) maxDailyProfit = dailyNet;
      runEquity.push(balance);
      peak = Math.max(peak, balance);
      trough = Math.min(trough, balance);
      if (dailyNet <= -dailyLossLimit) {
        result = "fail";
        failureReason = "Daily loss breach";
        break;
      }
      if (peak - balance >= totalDrawdownLimit) {
        result = "fail";
        failureReason = "Max total drawdown breach";
        break;
      }
      if (balance - config.accountSize >= target) {
        if (maxDailyProfit > consistencyLimit) {
          result = "fail";
          failureReason = "Consistency rule breach";
        } else {
          result = "pass";
        }
        break;
      }
      if (day >= config.evaluationDays && tradesToday >= tradesPerDayCount) {
        result = "fail";
        failureReason = "Evaluation period expired";
        break;
      }
    }
    if (result === "pass") {
      passCount += 1;
      daysToTargetTotal += day;
      daysToTargetCount += 1;
      profitAtPassTotal += balance - config.accountSize;
    } else {
      failures[failureReason] = (failures[failureReason] || 0) + 1;
    }
    const wantSample = result === "pass" && passSamples < MAX_PASS_SAMPLES || result === "fail" && (failByReason[failureReason] || 0) < MAX_FAIL_PER_REASON;
    if (wantSample) {
      sampleRuns.push({
        equity: runEquity,
        outcome: result,
        reason: result === "pass" ? "Target reached" : failureReason,
        days: day,
        peak,
        trough,
        terminal: balance,
        accountSize: config.accountSize,
        profitTarget: target,
        maxDrawdown: config.maxTotalDrawdown
      });
      if (result === "pass") passSamples += 1;
      else failByReason[failureReason] = (failByReason[failureReason] || 0) + 1;
    }
  }
  const passRate = passCount / runs;
  const avgProfitAtPass = passCount > 0 ? profitAtPassTotal / passCount : null;
  const profitAtPass = avgProfitAtPass !== null ? avgProfitAtPass : config.profitTarget;
  const payoutPerPass = profitAtPass * config.payoutPct / 100;
  const effectivePayout = payoutPerPass >= config.minPayout ? payoutPerPass : 0;
  const expectedValue = passRate * effectivePayout - (1 - passRate) * config.challengeFee;
  const failureList = Object.entries(failures).map(([reason, count]) => ({ reason, count, pct: count / runs })).filter((failure) => failure.count > 0).sort((a, b) => b.count - a.count);
  return {
    config,
    passRatePct: passRate * 100,
    failRatePct: (1 - passRate) * 100,
    averageDaysToTarget: daysToTargetCount > 0 ? daysToTargetTotal / daysToTargetCount : null,
    avgProfitAtPass,
    expectedValue,
    payoutProbabilityPct: passRate * 100,
    failures: failureList,
    runs,
    passCount,
    sampleRuns
  };
}

// backtester-src/sample.ts
var SAMPLE_TRADE_LOG = (() => {
  const header = "Trade #,Type,Signal,Date/Time,Price,Qty,P&L,Cumulative P&L,Drawdown,Run-up,Cumulative P&L %,Buy & Hold %,Trade #";
  const rows = [header];
  const data = [
    [1, "long", "2025-01-03 09:30", "2025-01-05 16:00", 4200.5, 15, 2400],
    [2, "short", "2025-01-07 10:00", "2025-01-08 11:00", 4300, 15, -285],
    [3, "long", "2025-01-10 09:30", "2025-01-12 15:00", 4250, 15, 690],
    [4, "long", "2025-01-14 10:00", "2025-01-15 14:00", 4280, 8, 488],
    [5, "short", "2025-01-17 10:00", "2025-01-17 15:00", 4310, 15, -3500],
    [6, "long", "2025-01-22 09:30", "2025-01-24 16:00", 4260, 15, 885],
    [7, "short", "2025-01-27 10:00", "2025-01-28 11:00", 4340, 15, -195],
    [8, "long", "2025-01-31 09:30", "2025-02-03 15:00", 4270, 8, 672],
    [9, "long", "2025-02-04 09:30", "2025-02-06 16:00", 4290, 15, 2300],
    [10, "short", "2025-02-07 10:00", "2025-02-10 11:00", 4380, 15, -435],
    [11, "long", "2025-02-12 09:30", "2025-02-14 15:00", 4300, 8, 608],
    [12, "long", "2025-02-18 09:30", "2025-02-20 16:00", 4310, 15, 773],
    [13, "short", "2025-02-21 10:00", "2025-02-24 11:00", 4400, 15, -308],
    [14, "long", "2025-02-26 09:30", "2025-02-28 15:00", 4320, 8, 536],
    [15, "long", "2025-03-03 09:30", "2025-03-05 16:00", 4300, 15, 2200],
    [16, "short", "2025-03-06 10:00", "2025-03-07 11:00", 4450, 15, -3500],
    [17, "long", "2025-03-11 09:30", "2025-03-13 15:00", 4340, 8, 704],
    [18, "long", "2025-03-17 09:30", "2025-03-19 16:00", 4360, 15, 2200],
    [19, "short", "2025-03-20 10:00", "2025-03-21 11:00", 4420, 15, -263],
    [20, "long", "2025-03-26 09:30", "2025-03-28 15:00", 4350, 8, 392],
    [21, "long", "2025-04-02 09:30", "2025-04-04 16:00", 4380, 15, 2200],
    [22, "short", "2025-04-08 10:00", "2025-04-09 11:00", 4480, 15, -3500],
    [23, "long", "2025-04-15 09:30", "2025-04-17 15:00", 4400, 8, 760],
    [24, "long", "2025-04-22 09:30", "2025-04-24 16:00", 4410, 8, 584]
  ];
  let cum = 0;
  for (const [num, dir, entryDate, exitDate, entry, qty, pnl] of data) {
    const exit = dir === "long" ? entry + pnl / qty : entry - pnl / qty;
    const entryType = dir === "long" ? "Entry long" : "Entry short";
    const exitType = dir === "long" ? "Exit long" : "Exit short";
    rows.push(`${num},${entryType},,${entryDate},${entry},${qty},,,,,,, ,${num}`);
    cum += pnl;
    rows.push(`${num},${exitType},,${exitDate},${exit.toFixed(2)},${qty},${pnl.toFixed(2)},${cum.toFixed(2)},,,,, ,${num}`);
  }
  return rows.join("\n");
})();
export {
  PROP_FIRM_PRESETS,
  SAMPLE_TRADE_LOG,
  buildTradeLog,
  computeMetrics,
  defaultPropFirmConfig,
  hashSeed,
  mulberry32,
  parseCsv,
  runMonteCarlo,
  runPropFirmSimulation
};
