(() => {
  // backtester-src/csv.ts
  var normalize = (value) => String(value || "").trim().toLowerCase().replace(/[%$£€]/g, "").replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");
  var RESULT_ALIASES = [
    "pnl",
    "profit",
    "profit_loss",
    "profitloss",
    "net_pnl",
    "net_profit",
    "net_return",
    "return",
    "returns",
    "ret",
    "r",
    "r_multiple",
    "r_multiple_points",
    "profit_pct",
    "return_pct",
    "pnl_pct",
    "net",
    "realized_pnl",
    "pl",
    "gain",
    "gains"
  ];
  var DATE_ALIASES = [
    "date",
    "datetime",
    "date_time",
    "date_time_1",
    "timestamp",
    "time",
    "trade_date",
    "entry_date",
    "entry_time",
    "exit_date",
    "exit_time",
    "open_time",
    "close_time",
    "opened_at",
    "closed_at",
    "open_date",
    "close_date"
  ];
  var ENTRY_ALIASES = ["entry", "entry_price", "avg_entry_price", "open", "open_price", "entry_price_1", "price_1", "buy_price", "entry_fill_price"];
  var EXIT_ALIASES = ["exit", "exit_price", "avg_exit_price", "close", "close_price", "exit_price_1", "price_2", "sell_price", "exit_fill_price"];
  var SIZE_ALIASES = ["size", "quantity", "qty", "shares", "contracts", "units", "lots", "volume", "position"];
  var DIRECTION_ALIASES = ["direction", "side", "position", "type", "action", "signal", "b_s", "long_short"];
  var FEE_ALIASES = ["fee", "fees", "commission", "commissions", "comm", "cost", "slippage", "swap"];
  var QUANTITY_RE = /^([0-9.]+)(m|k|klote|lot)?$/i;
  var SHORT_RE = /^(short|sell|s|bajista|put)$/i;
  var LONG_RE = /^(long|buy|l|call)$/i;
  function parseNumber(raw) {
    const value = String(raw ?? "").trim();
    if (!value) return NaN;
    const negative = /^\(.*\)$/.test(value);
    let cleaned = value.replace(/[()$£€,%\s]/g, "");
    cleaned = cleaned.replace(/(\d)[,.](\d)/g, "$1.$2");
    const parsed = Number(cleaned);
    if (Number.isNaN(parsed)) {
      const match = value.replace(/[()$£€,\s]/g, "").match(/^[+-]?(\d+)$/);
      return match ? negative ? -Number(match[1]) : Number(match[1]) : NaN;
    }
    return negative ? -parsed : parsed;
  }
  function parseSize(raw) {
    const value = String(raw ?? "").trim();
    if (!value) return null;
    const match = value.match(QUANTITY_RE);
    if (!match) return null;
    let number2 = parseFloat(match[1]);
    if (Number.isNaN(number2)) return null;
    const suffix = (match[2] || "").toLowerCase();
    if (suffix === "k") number2 *= 1e3;
    else if (suffix === "m") number2 *= 1e6;
    return number2;
  }
  function parseDate(raw) {
    const s = String(raw ?? "").trim();
    if (!s) return null;
    const base = new Date(s);
    if (!Number.isNaN(base.getTime())) return base.toISOString();
    let m = s.match(/^(\d{4})[.\/-](\d{1,2})[.\/-](\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?)?$/i);
    if (m) {
      let h = m[4] ? +m[4] : 0;
      if (m[7]) h = h % 12 + (/PM/i.test(m[7]) ? 12 : 0);
      const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], h, m[5] ? +m[5] : 0, m[6] ? +m[6] : 0));
      if (!Number.isNaN(d.getTime())) return d.toISOString();
    }
    m = s.match(/^(\d{1,2})[\/.](\d{1,2})[\/.](\d{2,4})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?)?$/i);
    if (m) {
      let yr = +m[3];
      if (yr < 100) yr += 2e3;
      let mo = +m[1], da = +m[2];
      if (mo > 12) {
        const t = mo;
        mo = da;
        da = t;
      }
      let h = m[4] ? +m[4] : 0;
      if (m[7]) h = h % 12 + (/PM/i.test(m[7]) ? 12 : 0);
      const d = new Date(Date.UTC(yr, mo - 1, da, h, m[5] ? +m[5] : 0, m[6] ? +m[6] : 0));
      if (!Number.isNaN(d.getTime())) return d.toISOString();
    }
    return null;
  }
  function detectPlatform(headers) {
    if (headers.includes("instrument")) return "ninjatrader";
    if (headers.includes("swap") || headers.includes("volume") && headers.includes("commission")) return "metatrader";
    if (headers.includes("contracts") && (headers.includes("signal") || headers.includes("profit_loss") || headers.includes("profitloss"))) return "multicharts";
    if (headers.includes("type") && headers.includes("price") && headers.includes("date_time")) return "tradingview";
    if (headers.includes("order_id") || headers.includes("ticket")) return "metatrader";
    return null;
  }
  function parseCsv(text) {
    const rows = [];
    let row = [];
    let cell = "";
    let quoted = false;
    for (let i = 0; i < text.length; i += 1) {
      const char = text[i];
      const next = text[i + 1];
      if (char === '"' && quoted && next === '"') {
        cell += '"';
        i += 1;
        continue;
      }
      if (char === '"') {
        quoted = !quoted;
        continue;
      }
      if (char === "," && !quoted) {
        row.push(cell);
        cell = "";
        continue;
      }
      if ((char === "\n" || char === "\r") && !quoted) {
        if (char === "\r" && next === "\n") i += 1;
        row.push(cell);
        if (row.some((v) => v.trim())) rows.push(row);
        row = [];
        cell = "";
        continue;
      }
      cell += char;
    }
    if (cell.length || row.length) {
      row.push(cell);
      if (row.some((v) => v.trim())) rows.push(row);
    }
    return rows;
  }
  function findIndex(headers, aliases) {
    for (const alias of aliases) {
      const index = headers.indexOf(alias);
      if (index >= 0) return index;
    }
    return -1;
  }
  function isTradingViewFormat(headers) {
    return headers.includes("type") && headers.includes("price") && headers.includes("date_time");
  }
  function parseTradingViewTradeList(rows) {
    const headers = rows[0].map(normalize);
    const typeIdx = headers.indexOf("type");
    const dateIdx = headers.indexOf("date_time");
    const priceIdx = headers.indexOf("price");
    const qtyIdx = headers.indexOf("qty") >= 0 ? headers.indexOf("qty") : headers.indexOf("quantity");
    const pnlIdx = headers.indexOf("p_l");
    const tradeNumIdx = headers.indexOf("trade");
    if (typeIdx < 0 || priceIdx < 0 || dateIdx < 0) return null;
    const groups = /* @__PURE__ */ new Map();
    for (let r = 1; r < rows.length; r += 1) {
      const row = rows[r];
      if (!row.some((v) => v.trim())) continue;
      const key = tradeNumIdx >= 0 && row[tradeNumIdx] ? row[tradeNumIdx].trim() : String(r);
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(row);
    }
    const trades = [];
    groups.forEach((group) => {
      let entry = group.find((row) => /entry/i.test(row[typeIdx] || ""));
      let exit = group.find((row) => /exit/i.test(row[typeIdx] || ""));
      if (!entry && !exit) {
        entry = group[0];
        exit = group[group.length - 1];
      }
      if (!entry || !exit) return;
      const typeStr = (entry[typeIdx] || "").toLowerCase();
      const direction = /short/.test(typeStr) ? "short" : /long/.test(typeStr) ? "long" : "unknown";
      const entryPrice = parseNumber(entry[priceIdx]);
      const exitPrice = parseNumber(exit[priceIdx]);
      const qty = qtyIdx >= 0 ? parseSize((entry[qtyIdx] || exit[qtyIdx] || "").trim()) : null;
      const size = qty ?? 1;
      let pnl = pnlIdx >= 0 ? parseNumber(exit[pnlIdx] || "") : NaN;
      if (!Number.isFinite(pnl) && Number.isFinite(entryPrice) && Number.isFinite(exitPrice)) {
        const sign = direction === "short" ? -1 : 1;
        pnl = (exitPrice - entryPrice) * sign * size;
      }
      if (!Number.isFinite(pnl)) return;
      const rawDate = (exit[dateIdx] || "").trim();
      const date = parseDate(rawDate);
      trades.push({
        row: 0,
        date,
        direction,
        entry: Number.isFinite(entryPrice) ? entryPrice : null,
        exit: Number.isFinite(exitPrice) ? exitPrice : null,
        size: qtyIdx >= 0 ? qty : null,
        fee: 0,
        pnl
      });
    });
    trades.sort((a, b) => {
      if (a.date && b.date) return new Date(a.date).getTime() - new Date(b.date).getTime();
      return 0;
    });
    trades.forEach((trade, index) => {
      trade.row = index + 2;
    });
    return trades;
  }
  function buildTradeLog(text) {
    const rows = parseCsv(text);
    if (rows.length < 2) {
      throw new Error("Add a header row and at least two trade rows to run a backtest.");
    }
    const headers = rows[0].map(normalize);
    if (isTradingViewFormat(headers)) {
      const tvTrades = parseTradingViewTradeList(rows);
      if (tvTrades && tvTrades.length >= 2) {
        const platform2 = detectPlatform(headers) || "tradingview";
        return {
          trades: tvTrades,
          ignored: 0,
          detected: [platform2, "date", "entry", "exit", "size", "direction"],
          derivedPnl: false,
          hasDates: tvTrades.some((trade) => trade.date !== null)
        };
      }
      throw new Error(
        "TradingView trade list detected but fewer than two complete trades were found. Each trade needs both an Entry and an Exit fill."
      );
    }
    const resultIndex = findIndex(headers, RESULT_ALIASES);
    const dateIndex = findIndex(headers, DATE_ALIASES);
    const entryIndex = findIndex(headers, ENTRY_ALIASES);
    const exitIndex = findIndex(headers, EXIT_ALIASES);
    const sizeIndex = findIndex(headers, SIZE_ALIASES);
    const directionIndex = findIndex(headers, DIRECTION_ALIASES);
    const feeIndex = findIndex(headers, FEE_ALIASES);
    if (resultIndex < 0 && (entryIndex < 0 || exitIndex < 0)) {
      throw new Error(
        "No usable result column. Include pnl/profit/return, or entry and exit price columns."
      );
    }
    const trades = [];
    let ignored = 0;
    let derived = false;
    const detected = [];
    const platform = detectPlatform(headers);
    if (platform) detected.push(platform);
    if (resultIndex >= 0) detected.push(headers[resultIndex]);
    if (dateIndex >= 0) detected.push("date");
    if (entryIndex >= 0) detected.push("entry");
    if (exitIndex >= 0) detected.push("exit");
    if (sizeIndex >= 0) detected.push("size");
    if (directionIndex >= 0) detected.push("direction");
    if (feeIndex >= 0) detected.push("fee");
    for (let r = 1; r < rows.length; r += 1) {
      const values = rows[r];
      const read = (index) => index >= 0 && index < values.length ? values[index] : "";
      let pnl = NaN;
      if (resultIndex >= 0) {
        pnl = parseNumber(read(resultIndex));
      }
      if (!Number.isFinite(pnl) && entryIndex >= 0 && exitIndex >= 0) {
        const entry2 = parseNumber(read(entryIndex));
        const exit2 = parseNumber(read(exitIndex));
        const size2 = sizeIndex >= 0 ? parseSize(read(sizeIndex)) : 1;
        if (Number.isFinite(entry2) && Number.isFinite(exit2)) {
          const directionRaw2 = read(directionIndex);
          const direction2 = SHORT_RE.test(directionRaw2) ? -1 : 1;
          pnl = (exit2 - entry2) * direction2 * (size2 ?? 1);
          derived = true;
        }
      }
      if (!Number.isFinite(pnl)) {
        ignored += 1;
        continue;
      }
      const rawDate = read(dateIndex).trim();
      const date = parseDate(rawDate);
      const fee = feeIndex >= 0 ? parseNumber(read(feeIndex)) : 0;
      const directionRaw = read(directionIndex);
      let direction = "unknown";
      if (directionRaw) {
        if (LONG_RE.test(directionRaw)) direction = "long";
        else if (SHORT_RE.test(directionRaw)) direction = "short";
      }
      const entry = entryIndex >= 0 ? parseNumber(read(entryIndex)) : null;
      const exit = exitIndex >= 0 ? parseNumber(read(exitIndex)) : null;
      const size = sizeIndex >= 0 ? parseSize(read(sizeIndex)) : null;
      trades.push({
        row: r + 1,
        date,
        direction,
        entry: Number.isFinite(entry) ? entry : null,
        exit: Number.isFinite(exit) ? exit : null,
        size,
        fee: Number.isFinite(fee) ? fee : 0,
        pnl: pnl - (Number.isFinite(fee) ? fee : 0)
      });
    }
    if (trades.length < 2) {
      throw new Error("At least two valid trade rows are required after parsing.");
    }
    return {
      trades,
      ignored,
      detected,
      derivedPnl: derived,
      hasDates: trades.some((trade) => trade.date !== null)
    };
  }

  // backtester-src/metrics.ts
  function percentileSorted(sorted, fraction) {
    if (sorted.length === 0) return 0;
    const idx = Math.min(sorted.length - 1, Math.floor(sorted.length * fraction));
    return sorted[idx];
  }
  function mean(arr) {
    if (arr.length === 0) return 0;
    let s = 0;
    for (let i = 0; i < arr.length; i += 1) s += arr[i];
    return s / arr.length;
  }
  function variance(arr, m) {
    if (arr.length < 2) return 0;
    const mu = m == null ? mean(arr) : m;
    let s = 0;
    for (let i = 0; i < arr.length; i += 1) {
      const d = arr[i] - mu;
      s += d * d;
    }
    return s / arr.length;
  }
  function stddev(arr, m) {
    return Math.sqrt(variance(arr, m));
  }
  function sampleSkew(arr, m) {
    if (arr.length < 3) return 0;
    const sd = stddev(arr, m);
    if (sd === 0) return 0;
    let s = 0;
    for (let i = 0; i < arr.length; i += 1) {
      const d = (arr[i] - m) / sd;
      s += d * d * d;
    }
    const n = arr.length;
    const g1 = Math.sqrt(n * (n - 1)) / (n - 2) * (s / n);
    return Number.isFinite(g1) ? g1 : 0;
  }
  function sampleKurtosis(arr, m) {
    if (arr.length < 4) return 0;
    const sd = stddev(arr, m);
    if (sd === 0) return 0;
    let s = 0;
    for (let i = 0; i < arr.length; i += 1) {
      const d = (arr[i] - m) / sd;
      s += d * d * d * d;
    }
    const n = arr.length;
    const m4 = s / n;
    const g2 = (n - 1) / ((n - 2) * (n - 3)) * ((n + 1) * m4 - 3 * (n - 1));
    return Number.isFinite(g2) ? g2 : 0;
  }
  function computeMetrics(log, opts = {}) {
    const trades = log.trades;
    const returns = trades.map((trade) => trade.pnl);
    const wins = returns.filter((value) => value > 0);
    const losses = returns.filter((value) => value < 0);
    const count = returns.length;
    const winCount = wins.length;
    const lossCount = losses.length;
    const winRate = count > 0 ? winCount / count : 0;
    const grossWins = wins.reduce((total, value) => total + value, 0);
    const grossLosses = Math.abs(losses.reduce((total, value) => total + value, 0));
    const netPnl = returns.reduce((total, value) => total + value, 0);
    const expectancy = count > 0 ? netPnl / count : 0;
    let equity = 0;
    const equitySeries = [];
    const drawdownSeries = [];
    const drawdownPctSeries = [];
    const tradeDates = [];
    const monthlyMap = /* @__PURE__ */ new Map();
    let peak = 0;
    let maxDrawdown = 0;
    let currentDdDuration = 0;
    let maxDrawdownDuration = 0;
    let longestDdStartIdx = -1;
    let longestDdEndIdx = -1;
    let ulcerSqSum = 0;
    for (let i = 0; i < returns.length; i += 1) {
      const value = returns[i];
      equity += value;
      equitySeries.push(equity);
      const prevPeak = peak;
      peak = Math.max(peak, equity);
      const drawdown = equity - peak;
      drawdownSeries.push(drawdown);
      const ddPct = peak > 0 ? drawdown / peak * 100 : 0;
      drawdownPctSeries.push(ddPct);
      ulcerSqSum += ddPct * ddPct;
      maxDrawdown = Math.min(maxDrawdown, drawdown);
      if (drawdown < 0) {
        if (prevPeak === peak) {
          currentDdDuration += 1;
        } else {
          currentDdDuration = 1;
        }
        if (currentDdDuration > maxDrawdownDuration) {
          maxDrawdownDuration = currentDdDuration;
          longestDdEndIdx = i;
          longestDdStartIdx = i - currentDdDuration + 1;
        }
      } else {
        currentDdDuration = 0;
      }
      const trade = trades[i];
      const iso = trade.date ?? null;
      tradeDates.push(iso);
      if (iso) {
        const parsed = new Date(iso);
        if (!Number.isNaN(parsed.getTime())) {
          const key = `${parsed.getFullYear()}-${parsed.getMonth()}`;
          monthlyMap.set(key, (monthlyMap.get(key) || 0) + value);
        }
      }
    }
    const monthlyReturns = Array.from(monthlyMap.entries()).map(([key, pnl]) => {
      const [year, month] = key.split("-").map(Number);
      return { year, month, pnl };
    }).sort((a, b) => a.year !== b.year ? a.year - b.year : a.month - b.month);
    const tradeDetails = trades.map((trade, i) => ({
      index: i + 1,
      date: trade.date,
      direction: trade.direction,
      entry: trade.entry,
      exit: trade.exit,
      size: trade.size,
      pnl: returns[i],
      equity: equitySeries[i],
      drawdown: drawdownSeries[i]
    }));
    let maxConsecutiveWins = 0;
    let maxConsecutiveLosses = 0;
    let currentWins = 0;
    let currentLosses = 0;
    for (const value of returns) {
      if (value > 0) {
        currentWins += 1;
        currentLosses = 0;
        maxConsecutiveWins = Math.max(maxConsecutiveWins, currentWins);
      } else if (value < 0) {
        currentLosses += 1;
        currentWins = 0;
        maxConsecutiveLosses = Math.max(maxConsecutiveLosses, currentLosses);
      }
    }
    const mean2 = expectancy;
    const variance2 = count > 0 ? returns.reduce((total, value) => total + (value - mean2) ** 2, 0) / count : 0;
    const standardDeviation = Math.sqrt(variance2);
    const dated = trades.filter((trade) => trade.date !== null).sort(
      (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
    );
    let avgHoldMs = null;
    if (dated.length > 1) {
      let totalHold = 0;
      let pairs = 0;
      for (let i = 1; i < dated.length; i += 1) {
        const current = new Date(dated[i].date).getTime();
        const previous = new Date(dated[i - 1].date).getTime();
        if (Number.isFinite(current) && Number.isFinite(previous)) {
          totalHold += current - previous;
          pairs += 1;
        }
      }
      if (pairs > 0) avgHoldMs = totalHold / pairs;
    }
    const bestTrade = returns.length > 0 ? Math.max(...returns) : 0;
    const worstTrade = returns.length > 0 ? Math.min(...returns) : 0;
    const positivePathsPct = winRate;
    const sharpeLike = standardDeviation > 0 ? mean2 / standardDeviation * Math.sqrt(Math.max(count, 1)) : 0;
    const rExpectancy = standardDeviation > 0 ? expectancy / standardDeviation : 0;
    const score = gradeScore({
      expectancy,
      profitFactor: grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? 3 : 0,
      winRate,
      maxDrawdownAbs: Math.abs(maxDrawdown),
      grossWins,
      count,
      positivePathsPct,
      sharpeLike,
      rExpectancy,
      maxConsecutiveLosses
    });
    const MS_PER_YEAR = 365.25 * 24 * 3600 * 1e3;
    let tradesPerYear = 252;
    if (avgHoldMs && avgHoldMs > 0) {
      tradesPerYear = Math.min(Math.max(MS_PER_YEAR / avgHoldMs, 1), 25e4);
    }
    const annualizedReturn = expectancy * tradesPerYear;
    const annualizedVolatility = standardDeviation * Math.sqrt(tradesPerYear);
    const sharpe = standardDeviation > 0 ? expectancy / standardDeviation * Math.sqrt(tradesPerYear) : 0;
    const downsideReturns = returns.filter((r) => r < 0);
    const downsideDeviation = downsideReturns.length > 0 ? Math.sqrt(downsideReturns.reduce((s, r) => s + r * r, 0) / Math.max(count, 1)) : 0;
    const sortino = downsideDeviation > 0 ? expectancy / downsideDeviation * Math.sqrt(tradesPerYear) : 0;
    const maxDrawdownAbs = Math.abs(maxDrawdown);
    const calmar = maxDrawdownAbs > 0 ? annualizedReturn / maxDrawdownAbs : 0;
    const omega = grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? Infinity : 0;
    const recoveryFactor = maxDrawdownAbs > 0 ? netPnl / maxDrawdownAbs : 0;
    const gainPain = grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? Infinity : 0;
    const ulcerIndex = count > 0 ? Math.sqrt(ulcerSqSum / count) : 0;
    const sortedReturns = returns.slice().sort((a, b) => a - b);
    const p5 = percentileSorted(sortedReturns, 0.05);
    const p95 = percentileSorted(sortedReturns, 0.95);
    const tailRatio = p5 < 0 ? Math.abs(p95) / Math.abs(p5) : 0;
    const valueAtRisk95 = Math.abs(p5);
    const tailCount = Math.max(1, Math.floor(count * 0.05));
    let cvarSum = 0;
    for (let i = 0; i < tailCount; i += 1) cvarSum += sortedReturns[i] || 0;
    const cvar95 = Math.abs(cvarSum / tailCount);
    let maxDrawdownDurationDays = null;
    if (longestDdStartIdx >= 0 && longestDdEndIdx >= longestDdStartIdx) {
      const startIso = tradeDates[longestDdStartIdx];
      const endIso = tradeDates[longestDdEndIdx];
      if (startIso && endIso) {
        const t0 = new Date(startIso).getTime();
        const t1 = new Date(endIso).getTime();
        if (Number.isFinite(t0) && Number.isFinite(t1) && t1 >= t0) {
          maxDrawdownDurationDays = (t1 - t0) / (24 * 3600 * 1e3);
        }
      }
    }
    const avgWin = winCount > 0 ? grossWins / winCount : 0;
    const avgLoss = lossCount > 0 ? -(grossLosses / lossCount) : 0;
    const winLossRatio = avgLoss < 0 ? avgWin / Math.abs(avgLoss) : 0;
    const skewness = sampleSkew(returns, mean2);
    const kurtosis = sampleKurtosis(returns, mean2) + 3;
    let benchmark = null;
    let beta = null;
    let alpha = null;
    let informationRatio = null;
    if (opts.benchmark && opts.benchmark.returns && opts.benchmark.returns.length > 1) {
      benchmark = opts.benchmark.name;
      const br = opts.benchmark.returns;
      const n = Math.min(returns.length, br.length);
      if (n > 2) {
        let bmSum = 0;
        for (let i = 0; i < n; i += 1) bmSum += br[i];
        const bmMean = bmSum / n;
        let bmVarSum = 0;
        for (let i = 0; i < n; i += 1) bmVarSum += (br[i] - bmMean) ** 2;
        const bmVar = bmVarSum / n;
        if (bmVar > 0) {
          let cov = 0;
          for (let i = 0; i < n; i += 1) cov += (returns[i] - expectancy) * (br[i] - bmMean);
          cov /= n;
          beta = cov / bmVar;
          alpha = expectancy - beta * bmMean;
          const active = [];
          for (let i = 0; i < n; i += 1) active.push(returns[i] - br[i]);
          let activeSum = 0;
          for (let i = 0; i < active.length; i += 1) activeSum += active[i];
          const activeMean = activeSum / active.length;
          let activeVarSum = 0;
          for (let i = 0; i < active.length; i += 1) activeVarSum += (active[i] - activeMean) ** 2;
          const activeStd = Math.sqrt(activeVarSum / Math.max(active.length, 1));
          informationRatio = activeStd > 0 ? activeMean / activeStd * Math.sqrt(tradesPerYear) : 0;
        }
      }
    }
    let turnover = null;
    const sizedTrades = trades.filter((t) => t.entry != null && t.size != null);
    if (sizedTrades.length > 0 && peak > 0) {
      let notional = 0;
      for (const t of sizedTrades) {
        const sz = Math.abs(t.size);
        const px = Math.abs(t.entry);
        notional += sz * px;
      }
      turnover = notional / peak;
    }
    return {
      count,
      winCount,
      lossCount,
      winRate,
      grossWins,
      grossLosses,
      profitFactor: grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? Infinity : 0,
      netPnl,
      expectancy,
      rExpectancy: standardDeviation > 0 ? expectancy / standardDeviation : 0,
      standardDeviation,
      sharpeLike: standardDeviation > 0 ? mean2 / standardDeviation * Math.sqrt(Math.max(count, 1)) : 0,
      maxDrawdown: Math.abs(maxDrawdown),
      maxDrawdownPct: peak > 0 ? Math.abs(maxDrawdown) / peak : 0,
      maxConsecutiveWins,
      maxConsecutiveLosses,
      avgHoldMs,
      bestTrade,
      worstTrade,
      equity: equitySeries,
      drawdownSeries,
      returns,
      tradeDates,
      monthlyReturns,
      tradeDetails,
      grade: score.grade,
      gradeLabel: score.label,
      gradeScore: score.score,
      gradeBreakdown: score.breakdown,
      gradeAdvice: score.advice,
      tradesPerYear,
      annualizedReturn,
      annualizedVolatility,
      sharpe,
      sortino,
      calmar,
      omega,
      tailRatio,
      valueAtRisk95,
      cvar95,
      maxDrawdownDuration,
      maxDrawdownDurationDays,
      recoveryFactor,
      ulcerIndex,
      gainPain,
      avgWin,
      avgLoss,
      winLossRatio,
      skewness,
      kurtosis,
      benchmark,
      beta,
      alpha,
      informationRatio,
      turnover
    };
  }
  function gradeScore(metrics) {
    const subs = [];
    let prof = 0;
    if (metrics.expectancy > 0) prof += 10;
    if (metrics.profitFactor >= 2) prof += 15;
    else if (metrics.profitFactor >= 1.5) prof += 10;
    else if (metrics.profitFactor >= 1.15) prof += 4;
    subs.push({ category: "Profitability", score: prof, max: 25 });
    let cons = 0;
    if (metrics.winRate >= 0.55) cons += 10;
    else if (metrics.winRate >= 0.45) cons += 6;
    else if (metrics.winRate >= 0.35) cons += 3;
    if (metrics.positivePathsPct >= 0.7) cons += 10;
    else if (metrics.positivePathsPct >= 0.55) cons += 6;
    else if (metrics.positivePathsPct >= 0.4) cons += 3;
    subs.push({ category: "Consistency", score: cons, max: 20 });
    let risk = 0;
    if (metrics.grossWins > 0) {
      if (metrics.maxDrawdownAbs <= metrics.grossWins * 0.25) risk += 15;
      else if (metrics.maxDrawdownAbs <= metrics.grossWins * 0.5) risk += 10;
      else if (metrics.maxDrawdownAbs <= metrics.grossWins) risk += 4;
    }
    if (metrics.maxConsecutiveLosses <= 3) risk += 10;
    else if (metrics.maxConsecutiveLosses <= 5) risk += 6;
    else if (metrics.maxConsecutiveLosses <= 8) risk += 2;
    subs.push({ category: "Risk control", score: risk, max: 25 });
    let rob = 0;
    if (metrics.sharpeLike >= 2) rob += 10;
    else if (metrics.sharpeLike >= 1.2) rob += 7;
    else if (metrics.sharpeLike >= 0.6) rob += 3;
    if (metrics.rExpectancy >= 0.3) rob += 10;
    else if (metrics.rExpectancy >= 0.15) rob += 6;
    else if (metrics.rExpectancy >= 0.05) rob += 2;
    subs.push({ category: "Robustness", score: rob, max: 20 });
    let samp = 0;
    if (metrics.count >= 200) samp += 10;
    else if (metrics.count >= 100) samp += 8;
    else if (metrics.count >= 50) samp += 5;
    else if (metrics.count >= 20) samp += 3;
    else if (metrics.count >= 5) samp += 1;
    subs.push({ category: "Sample size", score: samp, max: 10 });
    const score = subs.reduce((a, s) => a + s.score, 0);
    const grade = score >= 88 ? "A" : score >= 74 ? "B" : score >= 58 ? "C" : score >= 40 ? "D" : "F";
    const labels = {
      A: "Strong evidence",
      B: "Promising evidence",
      C: "Mixed evidence",
      D: "Weak evidence",
      F: "Needs work"
    };
    const advice = [];
    if (prof < 15) advice.push("Improve profitability: filter trades with weak edge or tighten stops to lift profit factor above 1.5.");
    if (cons < 12) advice.push("Raise consistency: review losing streaks and entry timing (see autocorrelation) to push the win rate above 50%.");
    if (risk < 15) advice.push("Tighten risk control: reduce position size or add a hard stop to cap drawdown and consecutive losses.");
    if (rob < 12) advice.push("Strengthen robustness: the risk-adjusted return is thin \u2014 favor higher-expectancy setups to improve the Sharpe-like ratio.");
    if (samp < 5) advice.push("Gather more trades: the sample is small, so every metric here carries low confidence.");
    return { score, grade, label: labels[grade], breakdown: subs, advice };
  }

  // backtester-src/rng.ts
  function mulberry32(seed) {
    let state = seed >>> 0;
    return () => {
      state = state + 1831565813 >>> 0;
      let value = state;
      value = Math.imul(value ^ value >>> 15, value | 1);
      value ^= value + Math.imul(value ^ value >>> 7, value | 61);
      return ((value ^ value >>> 14) >>> 0) / 4294967296;
    };
  }
  function hashSeed(values) {
    let seed = 2166136261;
    for (let i = 0; i < values.length; i += 1) {
      const bits = Math.round(values[i] * 100) | 0;
      seed = (seed ^ bits) * 16777619 >>> 0;
      seed = (seed ^ i * 2654435761) >>> 0;
    }
    return seed >>> 0;
  }
  function shuffle(array, random) {
    const copy = array.slice();
    for (let i = copy.length - 1; i > 0; i -= 1) {
      const j = Math.floor(random() * (i + 1));
      const swap = copy[i];
      copy[i] = copy[j];
      copy[j] = swap;
    }
    return copy;
  }

  // backtester-src/montecarlo.ts
  function runMonteCarlo(returns, config, startingBalance = 0) {
    if (returns.length < 2) {
      throw new Error("At least two trades are required for Monte Carlo.");
    }
    const paths = Math.min(Math.max(config.paths, 10), 5e3);
    const blockSize = Math.min(Math.max(config.blockSize, 1), Math.max(returns.length, 1));
    const random = mulberry32(config.seed);
    const numberOfBlocks = Math.ceil(returns.length / blockSize);
    const pathEquity = [];
    const terminals = [];
    const drawdowns = [];
    for (let path = 0; path < paths; path += 1) {
      const blocks = [];
      for (let block = 0; block < numberOfBlocks; block += 1) {
        const start = Math.floor(random() * returns.length);
        for (let offset = 0; offset < blockSize; offset += 1) {
          blocks.push(returns[(start + offset) % returns.length]);
        }
      }
      const sampled = blocks.slice(0, returns.length);
      let equity = startingBalance;
      const series = [];
      let peak = startingBalance;
      let maxDrawdown = 0;
      for (const value of sampled) {
        equity += value;
        series.push(equity);
        peak = Math.max(peak, equity);
        maxDrawdown = Math.max(maxDrawdown, peak - equity);
      }
      pathEquity.push(series);
      terminals.push(equity);
      drawdowns.push(maxDrawdown);
    }
    const sorted = terminals.slice().sort((a, b) => a - b);
    const sortedDrawdowns = drawdowns.slice().sort((a, b) => a - b);
    const positivePaths = terminals.filter((value) => value > startingBalance).length;
    return {
      config,
      terminals,
      paths: pathEquity,
      p5: percentile(sorted, 0.05),
      p50: percentile(sorted, 0.5),
      p95: percentile(sorted, 0.95),
      positivePaths,
      positivePathsPct: positivePaths / paths,
      riskOfRuinPct: percentile(sorted, 0.05) < startingBalance ? lowTailRisk(terminals, startingBalance) : 0,
      drawdownPercentiles: {
        p50: percentile(sortedDrawdowns, 0.5),
        p95: percentile(sortedDrawdowns, 0.95)
      }
    };
  }
  function percentile(sorted, fraction) {
    if (sorted.length === 0) return 0;
    const index = Math.min(sorted.length - 1, Math.floor(sorted.length * fraction));
    return sorted[index];
  }
  function lowTailRisk(terminals, startingBalance) {
    const loss = terminals.filter((value) => value < startingBalance).length;
    return loss / terminals.length * 100;
  }

  // backtester-src/propfirm.ts
  var PROP_FIRM_PRESETS = [
    {
      name: "FTMO 100k",
      accountSize: 1e5,
      profitTarget: 1e4,
      maxDailyLoss: 5e3,
      maxTotalDrawdown: 1e4,
      evaluationDays: 30,
      payoutPct: 80,
      challengeFee: 549,
      minPayout: 1e3,
      payoutDays: 14,
      trailingDrawdown: false,
      resetFee: 549,
      scaling: 1,
      phases: 1,
      consistencyPct: 50
    },
    {
      name: "FTMO 50k",
      accountSize: 5e4,
      profitTarget: 5e3,
      maxDailyLoss: 2500,
      maxTotalDrawdown: 5e3,
      evaluationDays: 30,
      payoutPct: 80,
      challengeFee: 299,
      minPayout: 500,
      payoutDays: 14,
      trailingDrawdown: false,
      resetFee: 299,
      scaling: 1,
      phases: 1,
      consistencyPct: 50
    },
    {
      name: "Apex 100k",
      accountSize: 1e5,
      profitTarget: 6e3,
      maxDailyLoss: 4500,
      maxTotalDrawdown: 5e3,
      evaluationDays: 30,
      payoutPct: 90,
      challengeFee: 150,
      minPayout: 500,
      payoutDays: 1,
      trailingDrawdown: false,
      resetFee: 150,
      scaling: 1,
      phases: 1,
      consistencyPct: 0
    },
    {
      name: "Topstep 50k",
      accountSize: 5e4,
      profitTarget: 3e3,
      maxDailyLoss: 2e3,
      maxTotalDrawdown: 2e3,
      evaluationDays: 15,
      payoutPct: 100,
      challengeFee: 165,
      minPayout: 500,
      payoutDays: 5,
      trailingDrawdown: true,
      resetFee: 165,
      scaling: 1,
      phases: 1,
      consistencyPct: 50
    },
    {
      name: "E8 100k",
      accountSize: 1e5,
      profitTarget: 8e3,
      maxDailyLoss: 3e3,
      maxTotalDrawdown: 6e3,
      evaluationDays: 30,
      payoutPct: 100,
      challengeFee: 599,
      minPayout: 500,
      payoutDays: 7,
      trailingDrawdown: false,
      resetFee: 599,
      scaling: 2,
      phases: 1,
      consistencyPct: 50
    }
  ];
  function tradesPerDay(trades) {
    const days = /* @__PURE__ */ new Set();
    for (const trade of trades) {
      if (trade.date) days.add(trade.date.slice(0, 10));
    }
    return Math.max(days.size, 1);
  }
  function runPropFirmSimulation(trades, config, options) {
    const runs = Math.min(Math.max(options.runs, 10), 1e4);
    const random = mulberry32(options.seed);
    const baseline = options.strategyBaseline && options.strategyBaseline > 0 ? options.strategyBaseline : config.accountSize;
    const scale = config.accountSize / baseline;
    const pnl = trades.map((trade) => trade.pnl * scale);
    const actualDays = tradesPerDay(trades);
    const tradesPerDayCount = pnl.length / actualDays;
    const dailyLossLimit = config.maxDailyLoss;
    const totalDrawdownLimit = config.maxTotalDrawdown;
    const target = config.profitTarget;
    let passCount = 0;
    let daysToTargetTotal = 0;
    let daysToTargetCount = 0;
    let profitAtPassTotal = 0;
    let daysPerAttemptTotal = 0;
    const passDaysList = [];
    const failures = {
      "Daily loss breach": 0,
      "Max total drawdown breach": 0,
      "Consistency rule breach": 0,
      "Evaluation period expired": 0
    };
    const consistencyLimit = config.consistencyPct > 0 && config.consistencyPct < 100 ? config.consistencyPct / 100 * config.profitTarget : Infinity;
    const sampleRuns = [];
    let passSamples = 0;
    const failByReason = {};
    const MAX_PASS_SAMPLES = 12;
    const MAX_FAIL_PER_REASON = 4;
    const SAFETY_CAP = config.evaluationDays * Math.max(1, Math.ceil(tradesPerDayCount)) * 50;
    for (let run = 0; run < runs; run += 1) {
      let order = shuffle(pnl, random);
      let cursor = 0;
      let balance = config.accountSize;
      let peak = config.accountSize;
      let trough = config.accountSize;
      let dailyNet = 0;
      let maxDailyProfit = 0;
      let tradesToday = 0;
      let day = 1;
      let result = "fail";
      let failureReason = "Evaluation period expired";
      const runEquity = [config.accountSize];
      for (let iter = 0; iter < SAFETY_CAP; iter += 1) {
        if (cursor >= order.length) {
          order = shuffle(pnl, random);
          cursor = 0;
        }
        if (tradesToday >= tradesPerDayCount && day < config.evaluationDays) {
          day += 1;
          dailyNet = 0;
          tradesToday = 0;
        }
        const pnlThisTrade = order[cursor];
        cursor += 1;
        tradesToday += 1;
        balance += pnlThisTrade;
        dailyNet += pnlThisTrade;
        if (dailyNet > maxDailyProfit) maxDailyProfit = dailyNet;
        runEquity.push(balance);
        peak = Math.max(peak, balance);
        trough = Math.min(trough, balance);
        if (dailyNet <= -dailyLossLimit) {
          result = "fail";
          failureReason = "Daily loss breach";
          break;
        }
        const totalBreach = config.trailingDrawdown ? peak - balance >= totalDrawdownLimit : balance <= config.accountSize - totalDrawdownLimit;
        if (totalBreach) {
          result = "fail";
          failureReason = "Max total drawdown breach";
          break;
        }
        if (balance - config.accountSize >= target) {
          if (maxDailyProfit > consistencyLimit) {
            result = "fail";
            failureReason = "Consistency rule breach";
          } else {
            result = "pass";
          }
          break;
        }
        if (day >= config.evaluationDays && tradesToday >= tradesPerDayCount) {
          result = "fail";
          failureReason = "Evaluation period expired";
          break;
        }
      }
      daysPerAttemptTotal += day;
      if (result === "pass") {
        passCount += 1;
        daysToTargetTotal += day;
        daysToTargetCount += 1;
        passDaysList.push(day);
        profitAtPassTotal += balance - config.accountSize;
      } else {
        failures[failureReason] = (failures[failureReason] || 0) + 1;
      }
      const wantSample = result === "pass" && passSamples < MAX_PASS_SAMPLES || result === "fail" && (failByReason[failureReason] || 0) < MAX_FAIL_PER_REASON;
      if (wantSample) {
        sampleRuns.push({
          equity: runEquity,
          outcome: result,
          reason: result === "pass" ? "Target reached" : failureReason,
          days: day,
          peak,
          trough,
          terminal: balance,
          accountSize: config.accountSize,
          profitTarget: target,
          maxDrawdown: config.maxTotalDrawdown
        });
        if (result === "pass") passSamples += 1;
        else failByReason[failureReason] = (failByReason[failureReason] || 0) + 1;
      }
    }
    const passRate = passCount / runs;
    const avgProfitAtPass = passCount > 0 ? profitAtPassTotal / passCount : null;
    const profitAtPass = avgProfitAtPass !== null ? avgProfitAtPass : config.profitTarget;
    const payoutPerPass = profitAtPass * config.payoutPct / 100;
    const effectivePayout = payoutPerPass >= config.minPayout ? payoutPerPass : 0;
    const expectedValue = passRate * effectivePayout - (1 - passRate) * config.challengeFee;
    const TRADING_DAYS_PER_YEAR = 252;
    const averageDaysToTarget = daysToTargetCount > 0 ? daysToTargetTotal / daysToTargetCount : null;
    const medianDaysToTarget = passDaysList.length ? passDaysList.slice().sort((a, b) => a - b)[Math.floor(passDaysList.length / 2)] : null;
    const avgDaysPerAttempt = daysPerAttemptTotal / runs;
    const attemptsPerYear = avgDaysPerAttempt > 0 ? TRADING_DAYS_PER_YEAR / avgDaysPerAttempt : 0;
    const evalsPassedPerYear = attemptsPerYear * passRate;
    const expectedAttemptsToPass = passRate > 0 ? 1 / passRate : Infinity;
    const expectedCostToPass = Number.isFinite(expectedAttemptsToPass) ? config.challengeFee + (expectedAttemptsToPass - 1) * config.resetFee : Infinity;
    const annualExpectedValue = attemptsPerYear * expectedValue;
    const annualExpectedPayout = evalsPassedPerYear * effectivePayout;
    const roiPerAttempt = config.challengeFee > 0 ? expectedValue / config.challengeFee : 0;
    const failureList = Object.entries(failures).map(([reason, count]) => ({ reason, count, pct: count / runs })).filter((failure) => failure.count > 0).sort((a, b) => b.count - a.count);
    return {
      config,
      passRatePct: passRate * 100,
      failRatePct: (1 - passRate) * 100,
      averageDaysToTarget,
      medianDaysToTarget,
      avgDaysPerAttempt,
      avgProfitAtPass,
      effectivePayout,
      expectedValue,
      payoutProbabilityPct: passRate * 100,
      attemptsPerYear,
      evalsPassedPerYear,
      expectedAttemptsToPass,
      expectedCostToPass,
      annualExpectedValue,
      annualExpectedPayout,
      roiPerAttempt,
      failures: failureList,
      runs,
      passCount,
      sampleRuns
    };
  }

  // backtester-src/animations.ts
  var ENTRY_DURATION = 0.9;
  var ENTRY_EASE = "power2.out";
  var INTRO_3D_DURATION = 1.4;
  var FADE_DURATION = 0.45;
  var STAGGER_MS = 70;
  var FRAME_MS = 25;
  var animationsEnabled = true;
  var autoRotateEnabled = true;
  function prefersReducedMotion() {
    return typeof window.matchMedia === "function" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }
  function setAnimationsEnabled(value) {
    animationsEnabled = value;
    if (!value) stopAllAnimations();
  }
  function animationsAreEnabled() {
    return animationsEnabled;
  }
  function setAutoRotateEnabled(value) {
    autoRotateEnabled = value;
    if (!value) stopIdleOrbits();
  }
  function detectKind(div) {
    const data = div.data || [];
    const first = data[0] || {};
    if (first.type === "pie") return "pie";
    if (first.type === "surface" || first.type === "mesh3d") return "surface3d";
    if (first.type === "scatter3d") return "scatter3d";
    if (first.type === "heatmap") return "heatmap";
    if (first.type === "histogram") return "histogram";
    if (first.type === "bar") return "bar";
    if (first.type === "box") return "box";
    return "line";
  }
  function dataRangeY(div) {
    let yMin = Infinity;
    let yMax = -Infinity;
    for (const tr of div.data || []) {
      if (!tr.y) continue;
      for (const v of tr.y) {
        if (Number.isFinite(v)) {
          yMin = Math.min(yMin, v);
          yMax = Math.max(yMax, v);
        }
      }
    }
    return Number.isFinite(yMin) && Number.isFinite(yMax) ? [yMin, yMax] : null;
  }
  function relayout(div, update) {
    try {
      Plotly.relayout(div, update);
    } catch {
    }
  }
  function restyle(div, update, traces) {
    try {
      Plotly.restyle(div, update, traces);
    } catch {
    }
  }
  function hasGsap() {
    return typeof gsap !== "undefined" && gsap && typeof gsap.to === "function";
  }
  function throttled(fn) {
    let last = 0;
    return () => {
      const now = performance.now();
      if (now - last < FRAME_MS) return;
      last = now;
      fn();
    };
  }
  function finalize(div) {
    for (const tween of [div.__anim, div.__fade, div.__idle]) {
      if (!tween) continue;
      try {
        tween.kill();
      } catch {
      }
    }
    div.__anim = void 0;
    div.__fade = void 0;
    div.__idle = void 0;
    idleDivs.delete(div);
    const restore = div.__restore;
    div.__restore = void 0;
    if (restore) restore();
    div.style.opacity = "";
  }
  function fadeIn(div) {
    if (!hasGsap()) return;
    div.style.opacity = "0";
    div.__fade = gsap.to(div, {
      opacity: 1,
      duration: FADE_DURATION,
      ease: "power1.out",
      onComplete: () => {
        div.__fade = void 0;
        div.style.opacity = "";
      }
    });
  }
  var ORBIT_RADIUS = 1.75;
  var ORBIT_HEIGHT = 0.85;
  var START_ANGLE = -Math.PI / 4;
  function setCamera(div, angle, radius) {
    relayout(div, {
      "scene.camera.eye": { x: radius * Math.cos(angle), y: radius * Math.sin(angle), z: ORBIT_HEIGHT }
    });
  }
  function startIdleOrbit(div, fromAngle) {
    if (!animationsEnabled || !autoRotateEnabled || prefersReducedMotion() || !hasGsap()) return;
    const obj = { a: fromAngle };
    div.__idle = gsap.to(obj, {
      a: fromAngle + 2 * Math.PI,
      duration: 44,
      ease: "none",
      repeat: -1,
      onUpdate: throttled(() => setCamera(div, obj.a, ORBIT_RADIUS))
    });
    idleDivs.add(div);
  }
  function animateCameraIntro(div) {
    const obj = { a: START_ANGLE - 0.7, r: ORBIT_RADIUS * 1.6 };
    div.__restore = () => setCamera(div, START_ANGLE, ORBIT_RADIUS);
    setCamera(div, obj.a, obj.r);
    div.__anim = gsap.to(obj, {
      a: START_ANGLE,
      r: ORBIT_RADIUS,
      duration: INTRO_3D_DURATION,
      ease: ENTRY_EASE,
      onUpdate: throttled(() => setCamera(div, obj.a, obj.r)),
      onComplete: () => {
        setCamera(div, START_ANGLE, ORBIT_RADIUS);
        div.__anim = void 0;
        div.__restore = void 0;
        startIdleOrbit(div, START_ANGLE);
      }
    });
  }
  function animateXReveal(div) {
    const xa = div.layout?.xaxis || {};
    const range = xa.range || [0, 1];
    const lo = Number(range[0]);
    const hi = Number(range[1]);
    if (!Number.isFinite(lo) || !Number.isFinite(hi) || hi <= lo) return;
    const yRange = dataRangeY(div);
    const settle = () => {
      const fin = { "xaxis.range": [lo, hi] };
      if (yRange) fin["yaxis.range"] = yRange;
      relayout(div, fin);
    };
    div.__restore = settle;
    const obj = { t: 0 };
    div.__anim = gsap.to(obj, {
      t: 1,
      duration: ENTRY_DURATION,
      ease: ENTRY_EASE,
      onUpdate: throttled(() => {
        const upd = { "xaxis.range": [lo, lo + obj.t * (hi - lo)] };
        if (yRange) upd["yaxis.range"] = yRange;
        relayout(div, upd);
      }),
      onComplete: () => {
        settle();
        div.__anim = void 0;
        div.__restore = void 0;
      }
    });
  }
  function animateBarGrow(div) {
    const origY = (div.data || []).map((tr) => tr.y ? tr.y.slice() : null);
    const yRange = dataRangeY(div);
    const settle = () => {
      restyle(div, { y: origY });
      if (yRange) relayout(div, { "yaxis.range": yRange });
    };
    div.__restore = settle;
    const baseline = yRange ? Math.min(0, yRange[0]) : 0;
    relayout(div, { "yaxis.range": [baseline, yRange ? yRange[1] : 1] });
    const obj = { t: 0 };
    div.__anim = gsap.to(obj, {
      t: 1,
      duration: ENTRY_DURATION,
      ease: ENTRY_EASE,
      onUpdate: throttled(() => {
        restyle(div, { y: origY.map((y) => y ? y.map((v) => v * obj.t) : null) });
      }),
      onComplete: () => {
        settle();
        div.__anim = void 0;
        div.__restore = void 0;
      }
    });
  }
  function animatePieSweep(div) {
    const tr = (div.data || [])[0];
    if (!tr || !tr.values) return;
    const finalValues = tr.values.slice();
    const settle = () => {
      tr.values = finalValues;
      restyle(div, { values: [finalValues] }, [0]);
    };
    div.__restore = settle;
    const obj = { t: 0 };
    div.__anim = gsap.to(obj, {
      t: 1,
      duration: ENTRY_DURATION,
      ease: ENTRY_EASE,
      onUpdate: throttled(() => {
        tr.values = finalValues.map((v) => v * obj.t);
        restyle(div, { values: [tr.values] }, [0]);
      }),
      onComplete: () => {
        settle();
        div.__anim = void 0;
        div.__restore = void 0;
      }
    });
  }
  function animateScatterPop(div) {
    const origSizes = (div.data || []).map((tr) => tr.marker && tr.marker.size != null ? tr.marker.size : null);
    const settle = () => {
      restyle(div, { "marker.size": origSizes });
    };
    div.__restore = settle;
    const scale = (factor) => origSizes.map((s) => {
      if (s == null) return 8 * factor;
      if (Array.isArray(s)) return s.map((v) => v * factor);
      return s * factor;
    });
    const obj = { t: 0.25 };
    restyle(div, { "marker.size": scale(obj.t) });
    div.__anim = gsap.to(obj, {
      t: 1,
      duration: ENTRY_DURATION,
      ease: ENTRY_EASE,
      onUpdate: throttled(() => {
        restyle(div, { "marker.size": scale(obj.t) });
      }),
      onComplete: () => {
        settle();
        div.__anim = void 0;
        div.__restore = void 0;
      }
    });
  }
  function fallbackReveal(div) {
    const xa = div.layout?.xaxis || {};
    const range = xa.range || [0, 1];
    const lo = Number(range[0]);
    const hi = Number(range[1]);
    if (!Number.isFinite(lo) || !Number.isFinite(hi) || hi <= lo) return;
    const yRange = dataRangeY(div);
    const N = 36;
    let i = 1;
    const tick = () => {
      if (!animationsEnabled) return;
      const k = lo + i / N * (hi - lo);
      const upd = { "xaxis.range": [lo, k] };
      if (yRange) upd["yaxis.range"] = yRange;
      relayout(div, upd);
      i += 1;
      if (i <= N) requestAnimationFrame(tick);
      else {
        const fin = { "xaxis.range": [lo, hi] };
        if (yRange) fin["yaxis.range"] = yRange;
        relayout(div, fin);
      }
    };
    requestAnimationFrame(tick);
  }
  function fallbackOrbit(div) {
    const N = 48;
    let i = 0;
    const tick = () => {
      if (!animationsEnabled) {
        setCamera(div, START_ANGLE, ORBIT_RADIUS);
        return;
      }
      const t = i / N;
      setCamera(div, START_ANGLE - 0.7 * (1 - t), ORBIT_RADIUS * (1.6 - 0.6 * t));
      i += 1;
      if (i <= N) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }
  function playAnimation(div) {
    const plot = div;
    if (!plot.data || !plot.layout) return;
    finalize(plot);
    if (!hasGsap()) {
      if (plot.layout.scene) fallbackOrbit(plot);
      else fallbackReveal(plot);
      return;
    }
    const kind = detectKind(plot);
    if (kind !== "surface3d" && kind !== "scatter3d") fadeIn(plot);
    switch (kind) {
      case "scatter3d":
      case "surface3d":
        animateCameraIntro(plot);
        break;
      case "pie":
        animatePieSweep(plot);
        break;
      case "bar":
        animateBarGrow(plot);
        break;
      case "scatter":
        animateScatterPop(plot);
        break;
      case "histogram":
      case "heatmap":
      case "box":
      case "line":
      default:
        animateXReveal(plot);
        break;
    }
  }
  var autoState = /* @__PURE__ */ new WeakMap();
  var idleDivs = /* @__PURE__ */ new Set();
  var liveDivs = /* @__PURE__ */ new Set();
  var autoObserver = null;
  var pending = [];
  var flushTimer = 0;
  function stopIdleOrbits() {
    for (const div of Array.from(idleDivs)) {
      if (div.__idle) {
        try {
          div.__idle.kill();
        } catch {
        }
        div.__idle = void 0;
      }
    }
    idleDivs.clear();
  }
  function stopAllAnimations() {
    pending = [];
    if (flushTimer) {
      window.clearTimeout(flushTimer);
      flushTimer = 0;
    }
    for (const div of Array.from(liveDivs)) finalize(div);
    stopIdleOrbits();
  }
  function flushPending() {
    flushTimer = 0;
    const batch = pending;
    pending = [];
    batch.forEach((div, index) => {
      window.setTimeout(() => {
        if (!animationsEnabled) return;
        playAnimation(div);
      }, index * STAGGER_MS);
    });
  }
  function enqueue(div) {
    pending.push(div);
    if (!flushTimer) flushTimer = window.setTimeout(flushPending, 40);
  }
  function ensureObserver() {
    if (autoObserver) return autoObserver;
    if (typeof IntersectionObserver === "undefined") return null;
    autoObserver = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          const div = entry.target;
          const state = autoState.get(div);
          if (!state) continue;
          if (entry.isIntersecting) {
            if (state.armed && animationsEnabled) {
              state.armed = false;
              enqueue(div);
            }
          } else if (div.__idle) {
            try {
              div.__idle.kill();
            } catch {
            }
            div.__idle = void 0;
            idleDivs.delete(div);
          }
        }
      },
      { threshold: 0.2 }
    );
    return autoObserver;
  }
  function armAutoplay(div) {
    const plot = div;
    liveDivs.add(plot);
    if (!animationsEnabled || prefersReducedMotion()) return;
    const observer = ensureObserver();
    if (!observer) return;
    autoState.set(plot, { armed: true });
    observer.unobserve(plot);
    observer.observe(plot);
  }
  function rearmAll() {
    if (!animationsEnabled) return;
    for (const div of Array.from(liveDivs)) armAutoplay(div);
  }
  function releaseAutoplay(div) {
    const plot = div;
    finalize(plot);
    liveDivs.delete(plot);
    autoState.delete(plot);
    if (autoObserver) autoObserver.unobserve(plot);
  }

  // backtester-src/render.ts
  var lastData3D = null;
  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== void 0) node.textContent = text;
    return node;
  }
  function number(value, digits = 2) {
    return Number.isFinite(value) ? value.toLocaleString(void 0, { maximumFractionDigits: digits }) : "\u2014";
  }
  function signed(value, digits = 2) {
    if (!Number.isFinite(value)) return "\u2014";
    return `${value >= 0 ? "+" : ""}${value.toLocaleString(void 0, { maximumFractionDigits: digits })}`;
  }
  function percent(value, digits = 1) {
    return Number.isFinite(value) ? `${(value * 100).toFixed(digits)}%` : "\u2014";
  }
  function toIsoDate(ms) {
    if (ms === null || !Number.isFinite(ms)) return "\u2014";
    const days = ms / 864e5;
    if (days >= 1) return `${days.toFixed(1)}d`;
    const hours = ms / 36e5;
    if (hours >= 1) return `${hours.toFixed(1)}h`;
    return `${(ms / 6e4).toFixed(0)}m`;
  }
  function theme() {
    const cs = getComputedStyle(document.documentElement);
    const raw = (name, fb) => cs.getPropertyValue(name).trim() || fb;
    const rgb = (name, fb) => `rgb(${raw(name, fb)})`;
    return {
      text: rgb("--color-text-primary", "229 231 235"),
      textSec: rgb("--color-text-secondary", "156 163 175"),
      grid: rgb("--color-border-primary", "31 41 55"),
      gridSoft: `rgba(${raw("--color-border-primary", "31 41 55").replace(/\s+/g, ",")},0.55)`,
      blue: "#7c83ff",
      green: "#34d399",
      red: "#fb7185",
      amber: "#fbbf24"
    };
  }
  function baseLayout(t) {
    return {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, system-ui, sans-serif", size: 12 },
      margin: { l: 52, r: 16, t: 12, b: 40 },
      showlegend: false,
      hovermode: "closest",
      hoverlabel: { bgcolor: "#0b1014", bordercolor: t.grid, font: { color: t.text, size: 12 } },
      xaxis: {
        gridcolor: t.gridSoft,
        gridwidth: 1,
        zerolinecolor: t.grid,
        zerolinewidth: 1,
        linecolor: t.gridSoft,
        ticklen: 4,
        tickcolor: "rgba(0,0,0,0)",
        automargin: true,
        tickfont: { color: t.textSec, size: 11 },
        title: { font: { color: t.textSec, size: 11 }, standoff: 10 }
      },
      yaxis: {
        gridcolor: t.gridSoft,
        gridwidth: 1,
        zerolinecolor: t.grid,
        zerolinewidth: 1,
        linecolor: "rgba(0,0,0,0)",
        ticklen: 4,
        tickcolor: "rgba(0,0,0,0)",
        automargin: true,
        tickfont: { color: t.textSec, size: 11 },
        title: { font: { color: t.textSec, size: 11 }, standoff: 12 }
      }
    };
  }
  function plotlyAvailable() {
    return typeof Plotly !== "undefined" && Plotly && typeof Plotly.react === "function";
  }
  function plotInto(div, data, layout) {
    if (!plotlyAvailable()) {
      div.innerHTML = "";
      const note = element("div", "plot-empty", "Plotly failed to load from the CDN. Check your connection and reload.");
      div.appendChild(note);
      return;
    }
    Plotly.react(div, data, layout, { displayModeBar: false, responsive: true });
    armAutoplay(div);
  }
  function bindClick(div, handler) {
    if (!plotlyAvailable()) return;
    const plotDiv = div;
    try {
      if (plotDiv.removeAllListeners) plotDiv.removeAllListeners("plotly_click");
    } catch {
    }
    if (plotDiv.on) {
      plotDiv.on("plotly_click", (event) => {
        if (event && event.points && event.points.length) handler(event.points[0]);
      });
    }
  }
  function detailPanel(id) {
    const d = element("div", "path-detail", void 0);
    d.id = id;
    fillDetail(d, "Click to inspect", [["Hint", "Click any point or path on the chart above."]]);
    return d;
  }
  function fillDetail(panel, title, rows) {
    panel.textContent = "";
    panel.appendChild(element("div", "path-detail-title", title));
    const grid2 = element("dl", "path-detail-grid", void 0);
    for (const [key, value] of rows) {
      grid2.appendChild(element("dt", void 0, key));
      grid2.appendChild(element("dd", void 0, value));
    }
    panel.appendChild(grid2);
  }
  function pct(sorted, fraction) {
    if (sorted.length === 0) return 0;
    const index = Math.min(sorted.length - 1, Math.floor(sorted.length * fraction));
    return sorted[index];
  }
  function varCvar(returns, alpha) {
    if (!returns.length) return { varVal: 0, cvar: 0 };
    const sorted = returns.slice().sort((a, b) => a - b);
    const idx = Math.max(0, Math.min(sorted.length - 1, Math.floor(sorted.length * alpha)));
    const varVal = -sorted[idx];
    const tail = sorted.slice(0, idx + 1);
    const cvar = tail.length ? -tail.reduce((a, b) => a + b, 0) / tail.length : varVal;
    return { varVal, cvar };
  }
  function payoutPerPassFor(propFirm) {
    const profit = propFirm.avgProfitAtPass !== null ? propFirm.avgProfitAtPass : propFirm.config.profitTarget;
    return profit * propFirm.config.payoutPct / 100;
  }
  function playChart(div) {
    if (!plotlyAvailable()) return;
    playAnimation(div);
  }
  var CHART_INFO = {
    "equity-chart": "Cumulative P&L over each trade. Dotted line = running peak. Markers are green (win) / red (loss). Click a marker for that trade\u2019s detail.",
    "pnl-chart": "Per-trade profit/loss as bars (green = win, red = loss). Click a bar for trade detail.",
    "pnl-vs-index-chart": "Each trade\u2019s P&L vs its number, with an OLS trend line. A flat/downward trend means the edge is decaying over time.",
    "returns-hist-chart": "Histogram of per-trade P&L. Left tail (red) = losses, right (green) = wins. Shows the shape of your edge.",
    "underwater-chart": "Drawdown from peak over time (red area). Deeper/longer = worse. A flat line near 0 = steadily making new highs.",
    "box-chart": "Box plots of winning vs losing trades. The box = middle 50%, whiskers = range. Compare win size vs loss size.",
    "rolling-sharpe-chart": "Rolling mean/std of returns (risk-adjusted return). Stable above 0 = consistent edge; dipping below 0 = trouble.",
    "rolling-chart": "Rolling expectancy (left axis) and win rate (right axis) over a window. Shows if the strategy\u2019s edge is stable or degrading.",
    "qq-chart": "Q-Q plot vs a normal distribution. Points on the dashed line = normal returns. Fat tails = bigger wins/losses than normal predicts.",
    "monthly-heatmap-chart": "Net P&L per calendar month (green = profit, red = loss). Reveals seasonality \u2014 which months carry or hurt the edge.",
    "cum-winrate-chart": "Cumulative win rate over time. A line settling near your final win rate = stable; big swings = inconsistent edge.",
    "direction-chart": "Total P&L split by long vs short trades. Shows which side carries the edge (or if one side is bleeding).",
    "dow-heatmap-chart": "Net P&L by day-of-week \xD7 month. Reveals timing edges (e.g. strong Mondays, weak Fridays).",
    "weekly-heatmap-chart": "Net P&L by week \xD7 weekday with a cold (loss) \u2192 hot (gain) scale. Spots recurring strong/weak days.",
    "acf-chart": "Return autocorrelation at lags 1\u201312. Bars beyond the dashed band = significant clustering (momentum) or alternation (mean-reversion).",
    "duration-pnl-chart": "Hold time (gap to next trade) vs P&L. If long holds are mostly losses, you\u2019re letting losers run; if short holds are winners, you\u2019re cutting winners early.",
    "loss-streaks-chart": "Distribution of consecutive-loss run lengths. Long streaks = psychological & capital risk; size for the worst case.",
    "strategy-kelly-chart": "Optimal risk-per-trade from your win rate & payoff (Kelly). Half/Quarter Kelly are safer in practice \u2014 full Kelly is volatile.",
    "monthly-bar-chart": "P&L per month as bars. Quick view of which months are weak (red) so you can investigate seasonal causes.",
    "cum-wl-chart": "Cumulative dollars from winners (green) and losers (red) separately. Shows if the edge is from many small wins or a few big ones.",
    "loss-recovery-chart": "Trades to reach a new equity high after each drawdown. Short bars = resilient; tall bars = slow recovery (risk of giving up).",
    "direction-over-time-chart": "Cumulative P&L of longs vs shorts over time. Diverging lines show which side is improving or degrading.",
    "mc-bands-chart": "Monte Carlo equity percentile bands (p5\u2013p95) across resampled paths. Wider band = more outcome uncertainty.",
    "mc-paths-chart": "24 sample Monte Carlo paths. Click a path for its terminal, max drawdown, and percentile rank.",
    "mc-dist-chart": "Histogram of terminal equity across all paths, with p5 / median / p95 markers.",
    "mc-dd-dist-chart": "Distribution of the worst drawdown each path endured. The right tail = worst-case drawdown risk.",
    "mc-sharpe-dist-chart": "Distribution of per-path Sharpe-like ratios. A mass below 0 = many paths are unprofitable on a risk-adjusted basis.",
    "mc-calmar-dist-chart": "Distribution of per-path Calmar (terminal / max drawdown). Higher = better return per unit of drawdown.",
    "mc-dd-duration-chart": "How long paths stay underwater (below peak). Long durations = painful drawdowns even if they recover.",
    "mc-ror-chart": "Probability the equity is below zero at each trade. Rising line = growing risk of ruin.",
    "mc-pop-chart": "Probability the equity is above zero at each trade. Falling line = edge fading over the backtest.",
    "mc-cdf-chart": "Cumulative distribution of terminal equity. Read off the percentile of any outcome (e.g. 50% of paths end below the median).",
    "mc-ttd-chart": "Which trade index each path hits its max drawdown. A mass early = front-loaded risk.",
    "mc-underwater-chart": "Average drawdown over time with a p5\u2013p95 band. Shows when (not just if) drawdowns cluster.",
    "mc-extreme-chart": "The single best and worst Monte Carlo paths vs the median. The gap = your best/worst plausible outcome.",
    "ev-waterfall-chart": "Per-attempt expected value: payout (green) minus cost (red) = net EV. Hover each bar for its breakdown.",
    "avg-path-chart": "Average sample-run balance over time with start / target / max-DD reference lines.",
    "prop-donut-chart": "Share of simulated runs that passed vs failed the firm rules.",
    "prop-payout-donut-chart": "Probability of getting a payout (pass) vs not. Center shows the pass %.",
    "prop-prob-chart": "Probability of at least one pass as you attempt more accounts. Dashed line = 95%.",
    "prop-growth-chart": "Expected cumulative net (your real money) over N account attempts, with a \xB11\u03C3 band.",
    "prop-evpr-chart": "EV per attempt across pass rates. Dashed = current pass rate; red = break-even pass rate (where EV = 0).",
    "prop-kelly-chart": "Expected log-growth vs the fraction of fee risked. Peak = optimal (Kelly) fraction \u2014 betting more or less is sub-optimal.",
    "prop-ror-chart": "Probability of losing every account as you attempt more (all fail). Decays toward 0 with more attempts.",
    "prop-payoff-chart": "Payout per pass vs the challenge fee. The ratio = how many fees one payout covers.",
    "prop-pf-chart": "Profit factor (expected payout / expected cost) across pass rates. Above 1 (dashed) = +EV.",
    "prop-runs-chart": "Sample run equity paths (green = pass, red = fail) with start/target/max-DD lines. Click a path for its outcome detail.",
    "prop-terminal-chart": "Distribution of run P&L, split pass (green) vs fail (red). Shows the spread of outcomes.",
    "prop-days-chart": "How many days passing runs took to hit the target. Left = fast passers.",
    "prop-failures-chart": "Count of each failure reason (daily loss / max DD / expired). Biggest bar = your main risk.",
    "fan-chart": "3D fan of Monte Carlo equity paths over time. Click a path for detail.",
    "surface-chart": "3D surface of drawdown across paths \xD7 trades. Peaks (red) = deepest drawdown zones.",
    "distribution-chart": "3D histogram of terminal outcomes across paths.",
    "trade-scatter-chart": "3D scatter of each trade: P&L vs gap-to-next, colored win/loss. Click a point for trade detail.",
    "equity-surface-chart": "3D surface of equity across paths \xD7 trades. Shows the full landscape of outcomes.",
    "var-chart": "3D histogram of trade returns with VaR-95 (amber) and VaR-99 (dark red) thresholds. Red tail = the worst 5%/1%.",
    "rolling-var-chart": "Rolling 95% VaR across window sizes over time. Higher surface = worse tail risk in that window.",
    "rolling-dd-chart": "Rolling max drawdown across window sizes. Peaks = where the deepest drawdowns cluster.",
    "risk-scatter-chart": "3D scatter of each trade\u2019s P&L vs its drawdown-from-peak. Click for trade risk detail.",
    "mc-maxdd-chart": "3D histogram of max drawdown per Monte Carlo path. The right tail = worst-case drawdown.",
    "mc-risk-scatter-chart": "3D scatter of each path\u2019s terminal equity vs its max drawdown. Click for path risk/return. Bottom-right = high-return, high-risk.",
    "mc-percentile-chart": "3D surface of equity percentiles (p5\u2013p95) over time. The full risk envelope.",
    "sharpe3d-chart": "Rolling Sharpe across window sizes over time. Stable green surface = consistent risk-adjusted edge.",
    "sortino3d-chart": "Rolling Sortino (downside-only risk-adjusted) across windows. Penalizes only downside volatility.",
    "acf3d-chart": "Autocorrelation across lags \xD7 window sizes. Reveals the serial structure of returns (trend vs reversal regime).",
    "density3d-chart": "Where equity spends time: path-count per equity-bin per trade. Peaks = the most-likely equity range at each point.",
    "calmar3d-chart": "Rolling Calmar (return / max drawdown) across windows. Higher = better return per unit of drawdown."
  };
  function chartCard(title, chartId, variant = "normal") {
    const card = element("article", `bt-card chart-card${variant === "wide" ? " span-2" : ""}`, void 0);
    const head = element("div", "card-head", void 0);
    head.appendChild(element("h3", void 0, title));
    const play = element("button", "chart-play", "\u25B6");
    play.type = "button";
    play.title = "Play animation";
    play.setAttribute("aria-label", "Play animation");
    const info = CHART_INFO[chartId];
    if (info) {
      const badge = element("span", "chart-info", "i");
      badge.appendChild(element("span", "chart-info-tip", info));
      head.appendChild(badge);
    }
    head.appendChild(play);
    card.appendChild(head);
    const cls = variant === "wide" ? "plot-chart plot-wide" : variant === "tall" ? "plot-chart plot-tall" : "plot-chart";
    const div = element("div", cls, void 0);
    div.id = chartId;
    card.appendChild(div);
    play.addEventListener("click", () => playChart(div));
    return { card, div };
  }
  function grid() {
    return element("div", "chart-grid", void 0);
  }
  function renderEquityChart(div, metrics, detail) {
    const t = theme();
    const x = metrics.equity.map((_, i) => i + 1);
    let runningPeak = 0;
    const peak = metrics.equity.map((v) => {
      runningPeak = Math.max(runningPeak, v);
      return runningPeak;
    });
    const markerColors = metrics.returns.map((v) => v >= 0 ? t.green : t.red);
    let maxEquityIdx = 0;
    let maxEquity = -Infinity;
    metrics.equity.forEach((v, i) => {
      if (v > maxEquity) {
        maxEquity = v;
        maxEquityIdx = i;
      }
    });
    const data = [
      {
        x,
        y: peak,
        name: "Peak",
        mode: "lines",
        line: { color: t.grid, width: 1, dash: "dot" },
        hovertemplate: "Peak %{y:,.2f}<extra></extra>"
      },
      {
        x,
        y: metrics.equity,
        name: "Equity",
        mode: "lines+markers",
        line: { color: t.blue, width: 2.5, shape: "linear" },
        marker: { color: markerColors, size: 5 },
        fill: "tozeroy",
        fillcolor: "rgba(124,131,255,0.14)",
        hovertemplate: "Trade #%{x}<br>Equity %{y:,.2f}<extra></extra>"
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Trade #" },
      yaxis: { ...layout.yaxis, title: "Equity" },
      shapes: [{ type: "line", x0: 0, x1: x.length, y0: 0, y1: 0, line: { color: t.grid, width: 1 } }],
      annotations: [
        { x: maxEquityIdx + 1, y: maxEquity, xref: "x", yref: "y", text: "peak", showarrow: true, arrowcolor: t.textSec, font: { color: t.textSec, size: 10 }, ay: -24 }
      ]
    });
    plotInto(div, data, layout);
    bindClick(div, (pt) => {
      const idx = pt.pointNumber;
      if (!Number.isInteger(idx) || idx < 0 || idx >= metrics.returns.length) return;
      const pnl = metrics.returns[idx];
      const eq = metrics.equity[idx];
      const dd = metrics.drawdownSeries[idx];
      fillDetail(detail, `Trade #${idx + 1}`, [
        ["P&L", signed(pnl)],
        ["Equity after", signed(eq)],
        ["Drawdown from peak", signed(dd)],
        ["Outcome", pnl > 0 ? "Win" : pnl < 0 ? "Loss" : "Flat"],
        ["Progress", `${idx + 1} / ${metrics.returns.length}`]
      ]);
    });
  }
  function renderUnderwaterDrawdown(div, metrics) {
    const t = theme();
    const x = metrics.drawdownSeries.map((_, i) => i + 1);
    const data = [
      {
        x,
        y: metrics.drawdownSeries,
        type: "scatter",
        mode: "lines",
        line: { color: t.red, width: 1.8 },
        fill: "tozeroy",
        fillcolor: "rgba(251,113,133,0.22)",
        hovertemplate: "Trade #%{x}<br>Drawdown %{y:,.2f}<extra></extra>"
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Trade #" },
      yaxis: { ...layout.yaxis, title: "Drawdown" }
    });
    plotInto(div, data, layout);
  }
  function renderPnlBars(div, metrics, detail) {
    const t = theme();
    const x = metrics.returns.map((_, i) => i + 1);
    const colors = metrics.returns.map((v) => v >= 0 ? t.green : t.red);
    const data = [
      {
        x,
        y: metrics.returns,
        type: "bar",
        marker: { color: colors },
        hovertemplate: "Trade #%{x}<br>P&L %{y:,.2f}<extra></extra>"
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Trade #" },
      yaxis: { ...layout.yaxis, title: "P&L" },
      bargap: 0.08
    });
    plotInto(div, data, layout);
    bindClick(div, (pt) => {
      const idx = pt.pointNumber;
      if (!Number.isInteger(idx) || idx < 0 || idx >= metrics.returns.length) return;
      const pnl = metrics.returns[idx];
      const eq = metrics.equity[idx];
      const dd = metrics.drawdownSeries[idx];
      fillDetail(detail, `Trade #${idx + 1}`, [
        ["P&L", signed(pnl)],
        ["Equity after", signed(eq)],
        ["Drawdown from peak", signed(dd)],
        ["Outcome", pnl > 0 ? "Win" : pnl < 0 ? "Loss" : "Flat"],
        ["Progress", `${idx + 1} / ${metrics.returns.length}`]
      ]);
    });
  }
  function renderMonteCarloBands(div, mc) {
    const t = theme();
    const len = mc.paths[0]?.length || 0;
    if (!len) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const indices = Array.from({ length: len }, (_, i) => i + 1);
    const p5 = [];
    const p25 = [];
    const p50 = [];
    const p75 = [];
    const p95 = [];
    for (let i = 0; i < len; i += 1) {
      const col = mc.paths.map((p) => p[i]).sort((a, b) => a - b);
      p5.push(pct(col, 0.05));
      p25.push(pct(col, 0.25));
      p50.push(pct(col, 0.5));
      p75.push(pct(col, 0.75));
      p95.push(pct(col, 0.95));
    }
    const data = [
      {
        x: indices,
        y: p95,
        name: "p95",
        mode: "lines",
        line: { color: t.green, width: 1 },
        hovertemplate: "p95 %{y:,.2f}<extra></extra>"
      },
      {
        x: indices,
        y: p5,
        name: "p5\u2013p95",
        mode: "lines",
        fill: "tonexty",
        fillcolor: "rgba(52,211,153,0.12)",
        line: { color: t.green, width: 1 },
        hovertemplate: "p5 %{y:,.2f}<extra>p5\u2013p95 band</extra>"
      },
      {
        x: indices,
        y: p75,
        name: "p75",
        mode: "lines",
        line: { color: t.blue, width: 1 },
        hovertemplate: "p75 %{y:,.2f}<extra></extra>"
      },
      {
        x: indices,
        y: p25,
        name: "p25\u2013p75",
        mode: "lines",
        fill: "tonexty",
        fillcolor: "rgba(124,131,255,0.20)",
        line: { color: t.blue, width: 1 },
        hovertemplate: "p25 %{y:,.2f}<extra>p25\u2013p75 band</extra>"
      },
      {
        x: indices,
        y: p50,
        name: "Median",
        mode: "lines",
        line: { color: t.text, width: 2.5 },
        hovertemplate: "Median %{y:,.2f}<extra></extra>"
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Trade #" },
      yaxis: { ...layout.yaxis, title: "Equity" },
      shapes: [
        { type: "line", x0: 0, x1: len, y0: 0, y1: 0, line: { color: t.grid, width: 1 } }
      ]
    });
    plotInto(div, data, layout);
  }
  function renderMonteCarloPaths(div, mc, detail) {
    const t = theme();
    const total = mc.paths.length;
    if (!total || !mc.paths[0]?.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const sampleCount = Math.min(24, total);
    const step = total / sampleCount;
    const sampled = [];
    const data = [];
    for (let i = 0; i < sampleCount; i += 1) {
      const idx = Math.min(total - 1, Math.round(i * step));
      const path = mc.paths[idx];
      sampled.push({ idx, path });
      const terminal = path[path.length - 1];
      data.push({
        x: path.map((_, j) => j + 1),
        y: path,
        mode: "lines",
        line: { color: terminal >= 0 ? t.green : t.red, width: 1.6 },
        opacity: 0.6,
        hovertemplate: `Path ${idx + 1}<br>Trade %{x}<br>Equity %{y:,.2f}<extra></extra>`,
        name: `Path ${idx + 1}`
      });
    }
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Trade #" },
      yaxis: { ...layout.yaxis, title: "Equity" },
      shapes: [
        { type: "line", x0: 0, x1: mc.paths[0].length, y0: 0, y1: 0, line: { color: t.grid, width: 1 } }
      ]
    });
    plotInto(div, data, layout);
    bindClick(div, (pt) => {
      const entry = sampled[pt.curveNumber];
      if (!entry) return;
      const path = entry.path;
      const terminal = path[path.length - 1];
      let peak = 0;
      let trough = 0;
      let runPeak = 0;
      let maxDd = 0;
      for (const v of path) {
        runPeak = Math.max(runPeak, v);
        maxDd = Math.max(maxDd, runPeak - v);
        peak = Math.max(peak, v);
        trough = Math.min(trough, v);
      }
      const rankBelow = mc.terminals.filter((value) => value <= terminal).length;
      const rankPct = rankBelow / Math.max(mc.terminals.length, 1) * 100;
      fillDetail(detail, `Monte Carlo path #${entry.idx + 1}`, [
        ["Terminal equity", signed(terminal)],
        ["Min equity", signed(trough)],
        ["Max equity", signed(peak)],
        ["Max drawdown", signed(-maxDd)],
        ["Rank (terminal)", `${rankPct.toFixed(0)}% at or below`],
        ["Outcome", terminal >= 0 ? "Positive" : "Negative"],
        ["Path length", `${path.length} trades`]
      ]);
    });
  }
  function renderTerminalDistribution(div, mc) {
    const t = theme();
    if (!mc.terminals.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const data = [
      {
        x: mc.terminals,
        type: "histogram",
        marker: { color: t.blue, line: { color: "rgba(0,0,0,0)", width: 0 } },
        hovertemplate: "Terminal %{x:,.2f}<br>Count %{y}<extra></extra>"
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Terminal equity" },
      yaxis: { ...layout.yaxis, title: "Count" },
      shapes: [
        { type: "line", x0: mc.p5, x1: mc.p5, y0: 0, y1: 1, yref: "paper", line: { color: t.red, width: 1.5, dash: "dash" } },
        { type: "line", x0: mc.p50, x1: mc.p50, y0: 0, y1: 1, yref: "paper", line: { color: t.text, width: 1.5 } },
        { type: "line", x0: mc.p95, x1: mc.p95, y0: 0, y1: 1, yref: "paper", line: { color: t.green, width: 1.5, dash: "dash" } }
      ],
      annotations: [
        { x: mc.p5, y: 1, yref: "paper", text: "p5", showarrow: false, yshift: 10, font: { color: t.red, size: 10 } },
        { x: mc.p50, y: 1, yref: "paper", text: "median", showarrow: false, yshift: 10, font: { color: t.text, size: 10 } },
        { x: mc.p95, y: 1, yref: "paper", text: "p95", showarrow: false, yshift: 10, font: { color: t.green, size: 10 } }
      ]
    });
    plotInto(div, data, layout);
  }
  function mcPathStats(mc) {
    return mc.paths.map((path) => {
      let peak = 0;
      let maxDd = 0;
      let min = Infinity;
      let max = -Infinity;
      let maxDdIdx = 0;
      let underwater = 0;
      let curUnder = 0;
      for (let i = 0; i < path.length; i += 1) {
        const v = path[i];
        peak = Math.max(peak, v);
        min = Math.min(min, v);
        max = Math.max(max, v);
        const dd = peak - v;
        if (dd > maxDd) {
          maxDd = dd;
          maxDdIdx = i;
        }
        if (v < peak) {
          curUnder += 1;
          underwater = Math.max(underwater, curUnder);
        } else {
          curUnder = 0;
        }
      }
      const terminal = path[path.length - 1];
      let mean2 = 0;
      let variance2 = 0;
      if (path.length > 1) {
        const rets = [];
        for (let i = 1; i < path.length; i += 1) rets.push(path[i] - path[i - 1]);
        mean2 = rets.reduce((a, b) => a + b, 0) / rets.length;
        variance2 = rets.reduce((a, b) => a + (b - mean2) ** 2, 0) / rets.length;
      }
      const std = Math.sqrt(variance2);
      const sharpe = std > 0 ? mean2 / std : 0;
      const calmar = maxDd > 0 ? terminal / maxDd : terminal > 0 ? Infinity : 0;
      return { terminal, maxDd, min, max, sharpe, calmar, timeToDd: maxDdIdx, underwater };
    });
  }
  function renderMcDrawdownDistribution(div, mc) {
    const t = theme();
    const stats = mcPathStats(mc);
    if (!stats.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const data = [{ x: stats.map((s) => s.maxDd), type: "histogram", marker: { color: t.red }, hovertemplate: "Max DD %{x:,.2f}<br>Paths %{y}<extra></extra>" }];
    const layout = baseLayout(t);
    Object.assign(layout, { xaxis: { ...layout.xaxis, title: "Max drawdown" }, yaxis: { ...layout.yaxis, title: "Paths" } });
    plotInto(div, data, layout);
  }
  function renderMcRiskOfRuin(div, mc) {
    const t = theme();
    const len = mc.paths[0]?.length || 0;
    if (!len) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const x = [];
    const y = [];
    for (let i = 0; i < len; i += 1) {
      let below = 0;
      for (const p of mc.paths) if (p[i] < 0) below += 1;
      x.push(i + 1);
      y.push(below / mc.paths.length);
    }
    const data = [{ x, y, type: "scatter", mode: "lines", line: { color: t.red, width: 2.5 }, fill: "tozeroy", fillcolor: "rgba(251,113,133,0.15)", hovertemplate: "Trade %{x}<br>Risk of ruin %{y:.1%}<extra></extra>" }];
    const layout = baseLayout(t);
    Object.assign(layout, { xaxis: { ...layout.xaxis, title: "Trade #" }, yaxis: { ...layout.yaxis, title: "P(equity < 0)", range: [0, 1], tickformat: ".0%" } });
    plotInto(div, data, layout);
  }
  function renderMcProbOfProfit(div, mc) {
    const t = theme();
    const len = mc.paths[0]?.length || 0;
    if (!len) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const x = [];
    const y = [];
    for (let i = 0; i < len; i += 1) {
      let above = 0;
      for (const p of mc.paths) if (p[i] > 0) above += 1;
      x.push(i + 1);
      y.push(above / mc.paths.length);
    }
    const data = [{ x, y, type: "scatter", mode: "lines", line: { color: t.green, width: 2.5 }, fill: "tozeroy", fillcolor: "rgba(52,211,153,0.15)", hovertemplate: "Trade %{x}<br>P(profit) %{y:.1%}<extra></extra>" }];
    const layout = baseLayout(t);
    Object.assign(layout, { xaxis: { ...layout.xaxis, title: "Trade #" }, yaxis: { ...layout.yaxis, title: "P(equity > 0)", range: [0, 1], tickformat: ".0%" } });
    plotInto(div, data, layout);
  }
  function renderMcSharpeDistribution(div, mc) {
    const t = theme();
    const stats = mcPathStats(mc).filter((s) => Number.isFinite(s.sharpe));
    if (!stats.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const data = [{ x: stats.map((s) => s.sharpe), type: "histogram", marker: { color: t.blue }, hovertemplate: "Sharpe %{x:,.2f}<br>Paths %{y}<extra></extra>" }];
    const layout = baseLayout(t);
    Object.assign(layout, { xaxis: { ...layout.xaxis, title: "Path Sharpe (mean / std)" }, yaxis: { ...layout.yaxis, title: "Paths" } });
    plotInto(div, data, layout);
  }
  function renderMcTerminalCDF(div, mc) {
    const t = theme();
    if (!mc.terminals.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const sorted = mc.terminals.slice().sort((a, b) => a - b);
    const n = sorted.length;
    const x = [];
    const y = [];
    for (let i = 0; i < n; i += 1) {
      x.push(sorted[i]);
      y.push((i + 1) / n);
    }
    const data = [{ x, y, type: "scatter", mode: "lines", line: { color: t.blue, width: 2.5, shape: "hv" }, hovertemplate: "Terminal \u2265 %{x:,.2f}<br>P %{y:.1%}<extra></extra>" }];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Terminal equity" },
      yaxis: { ...layout.yaxis, title: "Cumulative probability", range: [0, 1], tickformat: ".0%" },
      shapes: [{ type: "line", x0: 0, x1: 1, xref: "paper", y0: 0.5, y1: 0.5, line: { color: t.grid, width: 1, dash: "dot" } }],
      annotations: [{ x: 1, y: 0.5, xref: "paper", yref: "y", text: "median", showarrow: false, xanchor: "right", yshift: 8, font: { color: t.textSec, size: 10 } }]
    });
    plotInto(div, data, layout);
  }
  function renderMcUnderwaterEnvelope(div, mc) {
    const t = theme();
    const len = mc.paths[0]?.length || 0;
    if (!len) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const x = Array.from({ length: len }, (_, i) => i + 1);
    const cols = [];
    for (let i = 0; i < len; i += 1) {
      const col = mc.paths.map((p) => {
        let peak = 0;
        let dd = 0;
        for (let j = 0; j <= i; j += 1) {
          peak = Math.max(peak, p[j]);
          dd = peak - p[j];
        }
        return dd;
      }).sort((a, b) => a - b);
      cols.push(col);
    }
    const avg = cols.map((c) => c.reduce((a, b) => a + b, 0) / c.length);
    const p95 = cols.map((c) => pct(c, 0.95));
    const p5 = cols.map((c) => pct(c, 0.05));
    const data = [
      { x, y: p95, type: "scatter", mode: "lines", line: { color: t.red, width: 1 }, hoverinfo: "skip", showlegend: false },
      { x, y: p5, type: "scatter", mode: "lines", line: { color: t.red, width: 1 }, fill: "tonexty", fillcolor: "rgba(251,113,133,0.12)", hovertemplate: "p95 DD %{y:,.2f}<extra></extra>", name: "p5\u2013p95 DD" },
      { x, y: avg, type: "scatter", mode: "lines", line: { color: t.amber, width: 2.5 }, hovertemplate: "Trade %{x}<br>Avg DD %{y:,.2f}<extra></extra>", name: "Avg drawdown" }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, { xaxis: { ...layout.xaxis, title: "Trade #" }, yaxis: { ...layout.yaxis, title: "Drawdown" } });
    plotInto(div, data, layout);
  }
  function renderMcDrawdownDuration(div, mc) {
    const t = theme();
    const stats = mcPathStats(mc);
    if (!stats.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const data = [{ x: stats.map((s) => s.underwater), type: "histogram", marker: { color: t.amber }, hovertemplate: "Underwater %{x} trades<br>Paths %{y}<extra></extra>" }];
    const layout = baseLayout(t);
    Object.assign(layout, { xaxis: { ...layout.xaxis, title: "Max trades underwater" }, yaxis: { ...layout.yaxis, title: "Paths" } });
    plotInto(div, data, layout);
  }
  function renderMcCalmarDistribution(div, mc) {
    const t = theme();
    const stats = mcPathStats(mc).filter((s) => Number.isFinite(s.calmar));
    if (!stats.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const data = [{ x: stats.map((s) => s.calmar), type: "histogram", marker: { color: t.green }, hovertemplate: "Calmar %{x:,.2f}<br>Paths %{y}<extra></extra>" }];
    const layout = baseLayout(t);
    Object.assign(layout, { xaxis: { ...layout.xaxis, title: "Calmar (terminal / max DD)" }, yaxis: { ...layout.yaxis, title: "Paths" } });
    plotInto(div, data, layout);
  }
  function renderMcExtremePaths(div, mc) {
    const t = theme();
    if (!mc.paths.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const len = mc.paths[0].length;
    const x = Array.from({ length: len }, (_, i) => i + 1);
    let worstIdx = 0;
    let bestIdx = 0;
    for (let i = 0; i < mc.paths.length; i += 1) {
      const term = mc.paths[i][len - 1];
      if (term < mc.paths[worstIdx][len - 1]) worstIdx = i;
      if (term > mc.paths[bestIdx][len - 1]) bestIdx = i;
    }
    const p50 = [];
    for (let i = 0; i < len; i += 1) {
      const col = mc.paths.map((p) => p[i]).sort((a, b) => a - b);
      p50.push(pct(col, 0.5));
    }
    const data = [
      { x, y: mc.paths[bestIdx], type: "scatter", mode: "lines", line: { color: t.green, width: 2.5 }, hovertemplate: "Best path #%{text}<extra></extra>", text: [String(bestIdx + 1)], name: "Best" },
      { x, y: mc.paths[worstIdx], type: "scatter", mode: "lines", line: { color: t.red, width: 2.5 }, hovertemplate: "Worst path #%{text}<extra></extra>", text: [String(worstIdx + 1)], name: "Worst" },
      { x, y: p50, type: "scatter", mode: "lines", line: { color: t.textSec, width: 1.5, dash: "dash" }, hovertemplate: "Median %{y:,.2f}<extra></extra>", name: "Median" }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, { xaxis: { ...layout.xaxis, title: "Trade #" }, yaxis: { ...layout.yaxis, title: "Equity" } });
    plotInto(div, data, layout);
  }
  function renderMcTimeToDrawdown(div, mc) {
    const t = theme();
    const stats = mcPathStats(mc);
    if (!stats.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const data = [{ x: stats.map((s) => s.timeToDd + 1), type: "histogram", marker: { color: t.blue }, hovertemplate: "Max DD at trade %{x}<br>Paths %{y}<extra></extra>" }];
    const layout = baseLayout(t);
    Object.assign(layout, { xaxis: { ...layout.xaxis, title: "Trade # at max drawdown" }, yaxis: { ...layout.yaxis, title: "Paths" } });
    plotInto(div, data, layout);
  }
  function renderPropDonut(div, propFirm) {
    const t = theme();
    const data = [
      {
        values: [propFirm.passRatePct, propFirm.failRatePct],
        labels: ["Pass", "Fail"],
        type: "pie",
        hole: 0.62,
        marker: { colors: [t.green, t.red], line: { color: "rgba(0,0,0,0)", width: 0 } },
        textinfo: "percent",
        textfont: { color: t.text, size: 13 },
        hovertemplate: "%{label}: %{value:.1f}%<extra></extra>"
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      annotations: [
        {
          text: `<b>${propFirm.passRatePct.toFixed(0)}%</b><br>pass`,
          showarrow: false,
          font: { color: t.text, size: 18 }
        }
      ],
      margin: { l: 18, r: 18, t: 18, b: 18 }
    });
    plotInto(div, data, layout);
  }
  function renderFailureBar(div, propFirm) {
    const t = theme();
    if (!propFirm.failures.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const data = [
      {
        x: propFirm.failures.map((f) => f.reason),
        y: propFirm.failures.map((f) => f.count),
        type: "bar",
        marker: { color: t.red },
        hovertemplate: "%{x}<br>Count %{y}<extra></extra>",
        text: propFirm.failures.map((f) => `${(f.pct * 100).toFixed(0)}%`),
        textposition: "outside",
        textfont: { color: t.textSec, size: 11 }
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "", tickangle: -12 },
      yaxis: { ...layout.yaxis, title: "Count" },
      bargap: 0.25
    });
    plotInto(div, data, layout);
  }
  function renderPropSamplePaths(div, propFirm, detail) {
    const t = theme();
    const runs = propFirm.sampleRuns || [];
    if (!runs.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const data = runs.map((run, i) => ({
      x: run.equity.map((_, j) => j),
      y: run.equity,
      mode: "lines",
      line: { color: run.outcome === "pass" ? t.green : t.red, width: 1.6 },
      opacity: 0.6,
      hovertemplate: `Run ${i + 1} (${run.outcome.toUpperCase()}: ${run.reason})<br>Trade %{x}<br>Balance %{y:,.2f}<extra></extra>`,
      name: `Run ${i + 1}`
    }));
    const maxX = Math.max(...runs.map((r) => r.equity.length));
    data.push({
      x: runs.map((r) => r.equity.length - 1),
      y: runs.map((r) => r.terminal),
      mode: "markers",
      marker: {
        size: 9,
        color: runs.map((r) => r.outcome === "pass" ? t.green : t.red),
        line: { color: "rgb(11,16,20)", width: 1.5 }
      },
      hovertemplate: runs.map((r, i) => `Run ${i + 1} \u2014 ${r.outcome.toUpperCase()}<br>${r.reason}<br>Day ${r.days} \xB7 $${r.terminal.toFixed(0)}`),
      name: "Endpoints",
      showlegend: false
    });
    const targetLine = propFirm.config.accountSize + propFirm.config.profitTarget;
    const ddLimitLine = propFirm.config.accountSize - propFirm.config.maxTotalDrawdown;
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Trade #" },
      yaxis: { ...layout.yaxis, title: "Balance" },
      shapes: [
        { type: "line", x0: 0, x1: maxX - 1, y0: propFirm.config.accountSize, y1: propFirm.config.accountSize, line: { color: t.textSec, width: 1, dash: "dot" } },
        { type: "line", x0: 0, x1: maxX - 1, y0: targetLine, y1: targetLine, line: { color: t.green, width: 1.5, dash: "dash" } },
        { type: "line", x0: 0, x1: maxX - 1, y0: ddLimitLine, y1: ddLimitLine, line: { color: t.red, width: 1.5, dash: "dash" } }
      ],
      annotations: [
        { x: 0, y: propFirm.config.accountSize, text: "Start", showarrow: false, yshift: 8, font: { color: t.textSec, size: 10 }, xanchor: "left" },
        { x: 0, y: targetLine, text: "Target", showarrow: false, yshift: 8, font: { color: t.green, size: 10 }, xanchor: "left" },
        { x: 0, y: ddLimitLine, text: "Max DD", showarrow: false, yshift: -10, font: { color: t.red, size: 10 }, xanchor: "left" }
      ]
    });
    plotInto(div, data, layout);
    bindClick(div, (pt) => {
      const run = runs[pt.curveNumber];
      if (!run) return;
      const pnl = run.terminal - run.accountSize;
      const maxDd = run.peak - run.trough;
      fillDetail(detail, `Prop run #${pt.curveNumber + 1} \u2014 ${run.outcome === "pass" ? "PASSED" : "FAILED"}`, [
        ["Outcome", run.outcome === "pass" ? "Passed" : "Failed"],
        ["Reason", run.reason],
        ["Days", run.outcome === "pass" ? `${run.days} to target` : `Failed on day ${run.days}`],
        ["P&L", signed(pnl)],
        ["Terminal balance", number(run.terminal, 2)],
        ["Peak balance", number(run.peak, 2)],
        ["Trough balance", number(run.trough, 2)],
        ["Max drawdown", signed(-maxDd)],
        ["Account", number(run.accountSize, 0)],
        ["Target", `${number(run.profitTarget, 0)} (+${percent(run.profitTarget / run.accountSize, 1)})`],
        ["Max DD limit", number(run.maxDrawdown, 0)]
      ]);
    });
  }
  function renderReturnHistogram(div, metrics) {
    const t = theme();
    const wins = metrics.returns.filter((v) => v >= 0);
    const losses = metrics.returns.filter((v) => v < 0);
    const data = [
      {
        x: wins,
        type: "histogram",
        marker: { color: t.green },
        opacity: 0.78,
        hovertemplate: "Win %{x:,.2f}<br>Count %{y}<extra></extra>",
        name: "Wins"
      },
      {
        x: losses,
        type: "histogram",
        marker: { color: t.red },
        opacity: 0.78,
        hovertemplate: "Loss %{x:,.2f}<br>Count %{y}<extra></extra>",
        name: "Losses"
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      barmode: "overlay",
      xaxis: { ...layout.xaxis, title: "Trade P&L" },
      yaxis: { ...layout.yaxis, title: "Count" }
    });
    plotInto(div, data, layout);
  }
  function renderMonthlyHeatmap(div, metrics) {
    const t = theme();
    if (!metrics.monthlyReturns.length) {
      plotInto(div, [], baseLayout(t));
      const note = element("div", "plot-empty", "No dates in this trade log \u2014 monthly returns heatmap needs dated trades.");
      div.appendChild(note);
      return;
    }
    const years = Array.from(new Set(metrics.monthlyReturns.map((m) => m.year))).sort((a, b) => a - b);
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const z = years.map(
      (year) => Array.from({ length: 12 }, (_, month) => {
        const entry = metrics.monthlyReturns.find((m) => m.year === year && m.month === month);
        return entry ? entry.pnl : null;
      })
    );
    const data = [
      {
        type: "heatmap",
        z,
        x: monthNames,
        y: years.map(String),
        colorscale: [
          [0, t.red],
          [0.5, "#11161c"],
          [1, t.green]
        ],
        zmid: 0,
        hovertemplate: "%{x} %{y}<br>P&L %{z:,.2f}<extra></extra>",
        showscale: false,
        xgap: 2,
        ygap: 2
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      margin: { l: 50, r: 18, t: 10, b: 34 },
      xaxis: { gridcolor: "rgba(0,0,0,0)", zerolinecolor: "rgba(0,0,0,0)", tickfont: { color: t.textSec }, side: "bottom" },
      yaxis: { gridcolor: "rgba(0,0,0,0)", zerolinecolor: "rgba(0,0,0,0)", tickfont: { color: t.textSec }, automargin: true }
    });
    plotInto(div, data, layout);
  }
  function renderRollingMetrics(div, metrics) {
    const t = theme();
    const r = metrics.returns;
    const window2 = Math.max(5, Math.floor(r.length / 4));
    if (r.length < window2) {
      plotInto(div, [], baseLayout(t));
      const note = element("div", "plot-empty", `Need at least ${window2} trades for a rolling window of ${window2}.`);
      div.appendChild(note);
      return;
    }
    const x = [];
    const exp = [];
    const wr = [];
    for (let i = window2 - 1; i < r.length; i += 1) {
      const slice = r.slice(i - window2 + 1, i + 1);
      const mean2 = slice.reduce((a, b) => a + b, 0) / slice.length;
      const wins = slice.filter((v) => v > 0).length;
      x.push(i + 1);
      exp.push(mean2);
      wr.push(wins / slice.length);
    }
    const data = [
      {
        x,
        y: exp,
        type: "scatter",
        mode: "lines",
        line: { color: t.blue, width: 2 },
        yaxis: "y",
        hovertemplate: "Trade #%{x}<br>Expectancy %{y:,.2f}<extra></extra>",
        name: "Expectancy"
      },
      {
        x,
        y: wr,
        type: "scatter",
        mode: "lines",
        line: { color: t.amber, width: 2 },
        yaxis: "y2",
        hovertemplate: "Trade #%{x}<br>Win rate %{y:.0%}<extra></extra>",
        name: "Win rate"
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Trade #" },
      yaxis: { ...layout.yaxis, title: "Expectancy" },
      yaxis2: {
        gridcolor: "rgba(0,0,0,0)",
        zerolinecolor: "rgba(0,0,0,0)",
        tickfont: { color: t.amber },
        title: { text: "Win rate", font: { color: t.amber, size: 11 } },
        overlaying: "y",
        side: "right",
        range: [0, 1]
      }
    });
    plotInto(div, data, layout);
  }
  function renderTradingCalendar(container, metrics, detail) {
    container.textContent = "";
    if (!metrics.tradeDetails.length || !metrics.tradeDetails.some((t) => t.date)) {
      const note = element("div", "plot-empty", "No dates in this trade log \u2014 the trading calendar needs dated trades.");
      container.appendChild(note);
      return;
    }
    const byDay = /* @__PURE__ */ new Map();
    for (const t of metrics.tradeDetails) {
      if (!t.date) continue;
      const key = t.date.slice(0, 10);
      if (!byDay.has(key)) byDay.set(key, { pnl: 0, trades: [] });
      const entry = byDay.get(key);
      entry.pnl += t.pnl;
      entry.trades.push(t);
    }
    const months = /* @__PURE__ */ new Map();
    byDay.forEach((val, key) => {
      const monthKey = key.slice(0, 7);
      if (!months.has(monthKey)) months.set(monthKey, /* @__PURE__ */ new Map());
      months.get(monthKey).set(key, val);
    });
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    let maxAbs = 1;
    byDay.forEach((v) => {
      maxAbs = Math.max(maxAbs, Math.abs(v.pnl));
    });
    const sortedMonths = Array.from(months.keys()).sort();
    for (const monthKey of sortedMonths) {
      const [y, m] = monthKey.split("-").map(Number);
      const days = months.get(monthKey);
      let monthTotal = 0;
      days.forEach((v) => monthTotal += v.pnl);
      const monthHeader = element("div", "cal-month-header", void 0);
      monthHeader.appendChild(element("span", void 0, `${monthNames[m]} ${y}`));
      monthHeader.appendChild(element("span", `cal-month-total ${monthTotal >= 0 ? "pos" : "neg"}`, signed(monthTotal, 0)));
      container.appendChild(monthHeader);
      const grid2 = element("div", "cal-grid", void 0);
      ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].forEach(
        (d) => grid2.appendChild(element("div", "cal-dow", d))
      );
      const firstDay = new Date(y, m, 1).getDay();
      const daysInMonth = new Date(y, m + 1, 0).getDate();
      for (let i = 0; i < firstDay; i += 1) grid2.appendChild(element("div", "cal-cell cal-empty", ""));
      for (let d = 1; d <= daysInMonth; d += 1) {
        const dateStr = `${monthKey}-${String(d).padStart(2, "0")}`;
        const entry = days.get(dateStr);
        const cell = element("div", "cal-cell", void 0);
        if (entry) {
          cell.classList.add("cal-active");
          const intensity = Math.min(1, Math.abs(entry.pnl) / maxAbs);
          const color = entry.pnl >= 0 ? "52,211,153" : "251,113,133";
          cell.style.background = `rgba(${color}, ${(0.16 + intensity * 0.6).toFixed(3)})`;
          cell.appendChild(element("span", "cal-day", String(d)));
          cell.appendChild(element("span", `cal-pnl ${entry.pnl >= 0 ? "pos" : "neg"}`, signed(entry.pnl, 0)));
          cell.title = `${dateStr}: ${signed(entry.pnl)} (${entry.trades.length} trade${entry.trades.length > 1 ? "s" : ""})`;
          cell.addEventListener("click", () => {
            const rows = [
              ["Date", dateStr],
              ["Day P&L", signed(entry.pnl)],
              ["Trades", String(entry.trades.length)]
            ];
            entry.trades.forEach((tr) => {
              rows.push([`#${tr.index} ${tr.direction}`, `${signed(tr.pnl)} \u2192 ${signed(tr.equity)}`]);
            });
            fillDetail(detail, `Trading day \u2014 ${dateStr}`, rows);
          });
        } else {
          cell.classList.add("cal-inactive");
          cell.appendChild(element("span", "cal-day", String(d)));
        }
        grid2.appendChild(cell);
      }
      container.appendChild(grid2);
    }
  }
  function renderTradeLogTable(container, metrics) {
    container.textContent = "";
    const wrap = element("div", "trade-table-wrap", void 0);
    const table = element("table", "backtest-table", void 0);
    const thead = element("thead", void 0, void 0);
    const headRow = element("tr", void 0, void 0);
    ["#", "Date", "Dir", "Entry", "Exit", "Size", "P&L", "Equity", "DD"].forEach(
      (h) => headRow.appendChild(element("th", void 0, h))
    );
    thead.appendChild(headRow);
    table.appendChild(thead);
    const tbody = element("tbody", void 0, void 0);
    for (const t of metrics.tradeDetails) {
      const row = element("tr", void 0, void 0);
      row.appendChild(element("td", void 0, String(t.index)));
      row.appendChild(element("td", void 0, t.date ? new Date(t.date).toLocaleDateString() : "\u2014"));
      row.appendChild(element("td", `dir-${t.direction}`, t.direction));
      row.appendChild(element("td", void 0, t.entry !== null ? number(t.entry, 2) : "\u2014"));
      row.appendChild(element("td", void 0, t.exit !== null ? number(t.exit, 2) : "\u2014"));
      row.appendChild(element("td", void 0, t.size !== null ? number(t.size, 0) : "\u2014"));
      row.appendChild(element("td", `pnl ${t.pnl >= 0 ? "pos" : "neg"}`, signed(t.pnl)));
      row.appendChild(element("td", void 0, signed(t.equity)));
      row.appendChild(element("td", t.drawdown < 0 ? "pnl neg" : "", signed(t.drawdown)));
      tbody.appendChild(row);
    }
    table.appendChild(tbody);
    wrap.appendChild(table);
    container.appendChild(wrap);
  }
  function renderPassProbabilityCurve(div, propFirm) {
    const t = theme();
    const p = propFirm.passRatePct / 100;
    const x = Array.from({ length: 10 }, (_, i) => i + 1);
    const y = x.map((n) => 1 - Math.pow(1 - p, n));
    const data = [
      {
        x,
        y,
        type: "scatter",
        mode: "lines+markers",
        line: { color: t.blue, width: 2.5 },
        marker: { color: t.blue, size: 8 },
        hovertemplate: "%{x} accounts<br>%{y:.1%} chance of \u22651 pass<extra></extra>",
        name: "P(\u22651 pass)"
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Accounts attempted", dtick: 1 },
      yaxis: { ...layout.yaxis, title: "Probability", range: [0, 1], tickformat: ".0%" },
      shapes: [{ type: "line", x0: 0, x1: 10, y0: 0.95, y1: 0.95, line: { color: t.green, width: 1, dash: "dash" } }],
      annotations: [{ x: 10, y: 0.95, xref: "x", yref: "y", text: "95%", showarrow: false, xanchor: "right", yshift: 8, font: { color: t.green, size: 10 } }]
    });
    plotInto(div, data, layout);
  }
  function renderPayoutDonut(div, propFirm) {
    const t = theme();
    const passRate = propFirm.passRatePct / 100;
    const payoutPerPass = payoutPerPassFor(propFirm);
    const data = [
      {
        values: [propFirm.passRatePct, propFirm.failRatePct],
        labels: ["Payout", "No payout"],
        type: "pie",
        hole: 0.62,
        marker: { colors: [t.green, t.red], line: { color: "rgba(0,0,0,0)", width: 0 } },
        textinfo: "percent",
        textfont: { color: t.text, size: 13 },
        hovertemplate: "%{label}: %{value:.1f}%<extra></extra>"
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      annotations: [
        {
          text: `<b>${propFirm.passRatePct.toFixed(0)}%</b><br>payout`,
          showarrow: false,
          font: { color: t.text, size: 18 }
        }
      ],
      margin: { l: 18, r: 18, t: 18, b: 18 }
    });
    plotInto(div, data, layout);
  }
  function renderAccountGrowth(div, propFirm) {
    const t = theme();
    const passRate = propFirm.passRatePct / 100;
    const payoutPerPass = payoutPerPassFor(propFirm);
    const fee = propFirm.config.challengeFee;
    const ev = passRate * payoutPerPass - (1 - passRate) * fee;
    const sd1 = Math.sqrt(passRate * (1 - passRate)) * (payoutPerPass + fee);
    const N = 20;
    const xs = Array.from({ length: N }, (_, i) => i + 1);
    const mean2 = xs.map((n) => n * ev);
    const upper = xs.map((n) => n * ev + Math.sqrt(n) * sd1);
    const lower = xs.map((n) => n * ev - Math.sqrt(n) * sd1);
    const data = [
      {
        x: xs,
        y: upper,
        type: "scatter",
        mode: "lines",
        line: { color: t.green, width: 0 },
        hoverinfo: "skip",
        showlegend: false
      },
      {
        x: xs,
        y: lower,
        type: "scatter",
        mode: "lines",
        line: { color: t.green, width: 0 },
        fill: "tonexty",
        fillcolor: "rgba(52,211,153,0.12)",
        hovertemplate: "\u22121\u03C3 %{y:,.0f}<extra>\xB11\u03C3 band</extra>",
        name: "\xB11\u03C3"
      },
      {
        x: xs,
        y: mean2,
        type: "scatter",
        mode: "lines+markers",
        line: { color: t.blue, width: 2.5 },
        marker: { color: t.blue, size: 6 },
        hovertemplate: "%{x} accounts<br>Expected %{y:,.0f}<extra></extra>",
        name: "Expected"
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Accounts attempted", dtick: 2 },
      yaxis: { ...layout.yaxis, title: "Cumulative net ($)" },
      shapes: [{ type: "line", x0: 0, x1: N, y0: 0, y1: 0, line: { color: t.grid, width: 1 } }],
      annotations: [
        { x: N, y: ev * N, xref: "x", yref: "y", text: `EV $${(ev * N).toLocaleString(void 0, { maximumFractionDigits: 0 })}`, showarrow: true, arrowcolor: t.blue, font: { color: t.blue, size: 10 }, ax: -30, ay: -20 }
      ]
    });
    plotInto(div, data, layout);
  }
  function renderEvVsPassRate(div, propFirm) {
    const t = theme();
    const passRate = propFirm.passRatePct / 100;
    const payoutPerPass = payoutPerPassFor(propFirm);
    const fee = propFirm.config.challengeFee;
    const breakEven = fee > 0 ? fee / (fee + payoutPerPass) : 0;
    const xs = [];
    const ys = [];
    for (let i = 0; i <= 100; i += 1) {
      const p = i / 100;
      xs.push(p);
      ys.push(p * payoutPerPass - (1 - p) * fee);
    }
    const data = [
      { x: xs, y: ys, type: "scatter", mode: "lines", line: { color: t.blue, width: 2.5 }, hovertemplate: "Pass rate %{x:.0%}<br>EV %{y:,.0f}<extra></extra>" },
      { x: [passRate, passRate], y: [ys[0], ys[ys.length - 1]], type: "scatter", mode: "lines", line: { color: t.amber, width: 1.5, dash: "dash" }, hoverinfo: "skip", showlegend: false },
      { x: [breakEven, breakEven], y: [ys[0], ys[ys.length - 1]], type: "scatter", mode: "lines", line: { color: t.red, width: 1.5, dash: "dash" }, hoverinfo: "skip", showlegend: false }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Pass rate", tickformat: ".0%" },
      yaxis: { ...layout.yaxis, title: "EV per attempt ($)" },
      shapes: [{ type: "line", x0: 0, x1: 1, xref: "paper", y0: 0, y1: 0, line: { color: t.grid, width: 1 } }],
      annotations: [
        { x: passRate, y: 1, xref: "x", yref: "paper", text: `current ${percent(passRate)}`, showarrow: false, yshift: 8, font: { color: t.amber, size: 10 }, xanchor: "center" },
        { x: breakEven, y: 1, xref: "x", yref: "paper", text: `break-even ${percent(breakEven)}`, showarrow: false, yshift: 22, font: { color: t.red, size: 10 }, xanchor: "center" }
      ]
    });
    plotInto(div, data, layout);
  }
  function renderKellyGrowth(div, propFirm) {
    const t = theme();
    const passRate = propFirm.passRatePct / 100;
    const payoutPerPass = payoutPerPassFor(propFirm);
    const fee = propFirm.config.challengeFee;
    const b = fee > 0 ? payoutPerPass / fee : 0;
    const kelly = b > 0 ? (passRate * b - (1 - passRate)) / b : 0;
    const xs = [];
    const ys = [];
    for (let i = 0; i <= 100; i += 1) {
      const f = i / 100;
      xs.push(f);
      const g = passRate * Math.log(1 + f * b) + (1 - passRate) * Math.log(1 - f);
      ys.push(Number.isFinite(g) ? g : NaN);
    }
    const data = [
      { x: xs, y: ys, type: "scatter", mode: "lines", line: { color: t.blue, width: 2.5 }, hovertemplate: "Fraction %{x:.0%}<br>Log-growth %{y:,.4f}<extra></extra>" },
      { x: [Math.max(0, Math.min(1, kelly)), Math.max(0, Math.min(1, kelly))], y: [Math.min(...ys.filter((v) => Number.isFinite(v))), Math.max(...ys.filter((v) => Number.isFinite(v)))], type: "scatter", mode: "lines", line: { color: t.green, width: 1.5, dash: "dash" }, hoverinfo: "skip", showlegend: false }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Fraction of fee risked", tickformat: ".0%" },
      yaxis: { ...layout.yaxis, title: "Expected log-growth" },
      annotations: [{ x: Math.max(0, Math.min(1, kelly)), y: 1, xref: "x", yref: "paper", text: `Kelly ${percent(Math.max(0, kelly))}`, showarrow: false, yshift: 8, font: { color: t.green, size: 10 }, xanchor: "center" }]
    });
    plotInto(div, data, layout);
  }
  function renderRiskOfRuinAccounts(div, propFirm) {
    const t = theme();
    const passRate = propFirm.passRatePct / 100;
    const N = 15;
    const xs = Array.from({ length: N }, (_, i) => i + 1);
    const ys = xs.map((n) => Math.pow(1 - passRate, n));
    const data = [{ x: xs, y: ys, type: "scatter", mode: "lines+markers", line: { color: t.red, width: 2.5 }, marker: { color: t.red, size: 7 }, fill: "tozeroy", fillcolor: "rgba(251,113,133,0.12)", hovertemplate: "%{x} accounts<br>P(all fail) %{y:.1%}<extra></extra>" }];
    const layout = baseLayout(t);
    Object.assign(layout, { xaxis: { ...layout.xaxis, title: "Accounts attempted", dtick: 2 }, yaxis: { ...layout.yaxis, title: "P(lose all)", range: [0, 1], tickformat: ".0%" } });
    plotInto(div, data, layout);
  }
  function renderPayoffRatioBar(div, propFirm) {
    const t = theme();
    const payoutPerPass = payoutPerPassFor(propFirm);
    const fee = propFirm.config.challengeFee;
    const data = [{
      x: ["Payout per pass", "Challenge fee"],
      y: [payoutPerPass, fee],
      type: "bar",
      marker: { color: [t.green, t.red] },
      text: [`\xD7${(payoutPerPass / Math.max(fee, 1)).toFixed(1)} fee`, "1\xD7 fee"],
      textposition: "outside",
      textfont: { color: t.textSec, size: 11 },
      hovertemplate: "%{x}<br>$%{y:,.0f}<extra></extra>"
    }];
    const layout = baseLayout(t);
    Object.assign(layout, { yaxis: { ...layout.yaxis, title: "$" }, bargap: 0.3 });
    plotInto(div, data, layout);
  }
  function renderProfitFactorVsPassRate(div, propFirm) {
    const t = theme();
    const passRate = propFirm.passRatePct / 100;
    const payoutPerPass = payoutPerPassFor(propFirm);
    const fee = propFirm.config.challengeFee;
    const xs = [];
    const ys = [];
    for (let i = 1; i <= 100; i += 1) {
      const p = i / 100;
      xs.push(p);
      const cost = (1 - p) * fee;
      ys.push(cost > 0 ? p * payoutPerPass / cost : Infinity);
    }
    const data = [
      { x: xs, y: ys.map((v) => Number.isFinite(v) ? v : null), type: "scatter", mode: "lines", line: { color: t.blue, width: 2.5 }, hovertemplate: "Pass rate %{x:.0%}<br>Profit factor %{y:,.2f}<extra></extra>" },
      { x: [passRate, passRate], y: [0, Math.max(...ys.filter((v) => Number.isFinite(v)))], type: "scatter", mode: "lines", line: { color: t.amber, width: 1.5, dash: "dash" }, hoverinfo: "skip", showlegend: false }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Pass rate", tickformat: ".0%" },
      yaxis: { ...layout.yaxis, title: "Profit factor (payout / cost)" },
      shapes: [{ type: "line", x0: 0, x1: 1, xref: "paper", y0: 1, y1: 1, line: { color: t.grid, width: 1, dash: "dot" } }],
      annotations: [{ x: 1, y: 1, xref: "paper", yref: "y", text: "PF = 1 (break-even)", showarrow: false, xanchor: "right", yshift: 8, font: { color: t.textSec, size: 10 } }]
    });
    plotInto(div, data, layout);
  }
  function renderDaysToTarget(div, propFirm) {
    const t = theme();
    const passing = (propFirm.sampleRuns || []).filter((r) => r.outcome === "pass").map((r) => r.days);
    if (!passing.length) {
      plotInto(div, [], baseLayout(t));
      const note = element("div", "plot-empty", "No passing runs in the sample \u2014 try reshuffling.");
      div.appendChild(note);
      return;
    }
    const data = [
      {
        x: passing,
        type: "histogram",
        marker: { color: t.green },
        hovertemplate: "%{x} days<br>%{y} runs<extra></extra>"
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Days to target" },
      yaxis: { ...layout.yaxis, title: "Runs" }
    });
    plotInto(div, data, layout);
  }
  function renderPropTerminalDistribution(div, propFirm) {
    const t = theme();
    const runs = propFirm.sampleRuns || [];
    if (!runs.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const pass = runs.filter((r) => r.outcome === "pass").map((r) => r.terminal - r.accountSize);
    const fail = runs.filter((r) => r.outcome === "fail").map((r) => r.terminal - r.accountSize);
    const data = [
      { x: pass, type: "histogram", marker: { color: t.green }, opacity: 0.78, hovertemplate: "Pass %{x:,.2f}<br>%{y} runs<extra></extra>", name: "Pass" },
      { x: fail, type: "histogram", marker: { color: t.red }, opacity: 0.78, hovertemplate: "Fail %{x:,.2f}<br>%{y} runs<extra></extra>", name: "Fail" }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      barmode: "overlay",
      xaxis: { ...layout.xaxis, title: "Run P&L" },
      yaxis: { ...layout.yaxis, title: "Runs" }
    });
    plotInto(div, data, layout);
  }
  function renderEvWaterfall(div, propFirm) {
    const t = theme();
    const passRate = propFirm.passRatePct / 100;
    const payoutPerPass = payoutPerPassFor(propFirm);
    const expPayout = passRate * payoutPerPass;
    const expCost = (1 - passRate) * propFirm.config.challengeFee;
    const data = [
      {
        type: "waterfall",
        x: ["Expected payout", "Expected cost", "Net EV / attempt"],
        y: [expPayout, -expCost, 0],
        measure: ["relative", "relative", "total"],
        connector: { line: { color: t.grid, width: 1 } },
        increasing: { marker: { color: t.green }, xaxis: "x" },
        decreasing: { marker: { color: t.red } },
        totals: { marker: { color: t.blue } },
        hovertext: [
          `Payout: ${percent(passRate)} pass \xD7 $${number(payoutPerPass, 0)} payout = +$${number(expPayout, 0)}`,
          `Cost: ${percent(1 - passRate)} fail \xD7 $${number(propFirm.config.challengeFee, 0)} fee = \u2212$${number(expCost, 0)}`,
          `Net EV per attempt = $${number(propFirm.expectedValue, 0)}`
        ],
        hovertemplate: "%{hovertext}<extra></extra>",
        textposition: "outside",
        text: [`+${number(expPayout, 0)}`, `-${number(expCost, 0)}`, number(propFirm.expectedValue, 0)],
        textfont: { color: t.textSec, size: 11 }
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      yaxis: { ...layout.yaxis, title: "Per attempt ($)" },
      margin: { l: 60, r: 18, t: 18, b: 42 }
    });
    plotInto(div, data, layout);
  }
  function renderAverageEquityPath(div, propFirm) {
    const t = theme();
    const runs = propFirm.sampleRuns || [];
    if (!runs.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const maxLen = Math.max(...runs.map((r) => r.equity.length));
    const padded = runs.map((r) => {
      const last = r.equity[r.equity.length - 1];
      const arr = r.equity.slice();
      while (arr.length < maxLen) arr.push(last);
      return arr;
    });
    const x = Array.from({ length: maxLen }, (_, i) => i);
    const avg = x.map((_, i) => padded.reduce((s, p) => s + p[i], 0) / padded.length);
    const data = [
      {
        x,
        y: avg,
        type: "scatter",
        mode: "lines",
        line: { color: t.blue, width: 2.5 },
        hovertemplate: "Trade %{x}<br>Avg balance %{y:,.2f}<extra></extra>",
        name: "Average path"
      }
    ];
    const targetLine = propFirm.config.accountSize + propFirm.config.profitTarget;
    const ddLimitLine = propFirm.config.accountSize - propFirm.config.maxTotalDrawdown;
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Trade #" },
      yaxis: { ...layout.yaxis, title: "Balance" },
      shapes: [
        { type: "line", x0: 0, x1: maxLen - 1, y0: propFirm.config.accountSize, y1: propFirm.config.accountSize, line: { color: t.textSec, width: 1, dash: "dot" } },
        { type: "line", x0: 0, x1: maxLen - 1, y0: targetLine, y1: targetLine, line: { color: t.green, width: 1.5, dash: "dash" } },
        { type: "line", x0: 0, x1: maxLen - 1, y0: ddLimitLine, y1: ddLimitLine, line: { color: t.red, width: 1.5, dash: "dash" } }
      ],
      annotations: [
        { x: 0, y: propFirm.config.accountSize, text: "Start", showarrow: false, yshift: 8, font: { color: t.textSec, size: 10 }, xanchor: "left" },
        { x: 0, y: targetLine, text: "Target", showarrow: false, yshift: 8, font: { color: t.green, size: 10 }, xanchor: "left" },
        { x: 0, y: ddLimitLine, text: "Max DD", showarrow: false, yshift: -10, font: { color: t.red, size: 10 }, xanchor: "left" }
      ]
    });
    plotInto(div, data, layout);
  }
  function sectionTitle(text) {
    return element("h2", "section-title", text);
  }
  function invNormal(p) {
    const a = [-39.69683028665376, 220.9460984245205, -275.9285104469687, 138.357751867269, -30.66479806614716, 2.506628277459239];
    const b = [-54.47609879822406, 161.5858368580409, -155.6989798598866, 66.80131188771972, -13.28068155288572];
    const c = [-0.007784894002430293, -0.3223964458411511, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783];
    const d = [0.007784695709041462, 0.3224671290700398, 2.445134137142996, 3.754408661907416];
    const plow = 0.02425;
    const phigh = 1 - plow;
    if (p < plow) {
      const q2 = Math.sqrt(-2 * Math.log(p));
      return (((((c[0] * q2 + c[1]) * q2 + c[2]) * q2 + c[3]) * q2 + c[4]) * q2 + c[5]) / ((((d[0] * q2 + d[1]) * q2 + d[2]) * q2 + d[3]) * q2 + 1);
    }
    if (p <= phigh) {
      const q2 = p - 0.5;
      const r = q2 * q2;
      return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q2 / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
    }
    const q = Math.sqrt(-2 * Math.log(1 - p));
    return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
  }
  function renderReturnsBox(div, metrics) {
    const t = theme();
    const wins = metrics.returns.filter((v) => v > 0);
    const losses = metrics.returns.filter((v) => v < 0);
    const data = [
      {
        y: wins,
        type: "box",
        name: "Wins",
        boxpoints: "all",
        jitter: 0.3,
        pointpos: 0,
        marker: { color: t.green, size: 4 },
        line: { color: t.green },
        fillcolor: "rgba(52,211,153,0.16)",
        hovertemplate: "Win %{y:,.2f}<extra></extra>"
      },
      {
        y: losses,
        type: "box",
        name: "Losses",
        boxpoints: "all",
        jitter: 0.3,
        pointpos: 0,
        marker: { color: t.red, size: 4 },
        line: { color: t.red },
        fillcolor: "rgba(251,113,133,0.16)",
        hovertemplate: "Loss %{y:,.2f}<extra></extra>"
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      yaxis: { ...layout.yaxis, title: "P&L" },
      boxmode: "group"
    });
    plotInto(div, data, layout);
  }
  function renderRollingSharpe(div, metrics) {
    const t = theme();
    const r = metrics.returns;
    const w = Math.max(10, Math.floor(r.length / 3));
    if (r.length < w) {
      plotInto(div, [], baseLayout(t));
      const note = element("div", "plot-empty", `Need at least ${w} trades for a rolling window of ${w}.`);
      div.appendChild(note);
      return;
    }
    const x = [];
    const s = [];
    for (let i = w - 1; i < r.length; i += 1) {
      const slice = r.slice(i - w + 1, i + 1);
      const mean2 = slice.reduce((a, b) => a + b, 0) / slice.length;
      const variance2 = slice.reduce((a, b) => a + (b - mean2) ** 2, 0) / slice.length;
      const std = Math.sqrt(variance2);
      x.push(i + 1);
      s.push(std > 0 ? mean2 / std : 0);
    }
    const data = [
      {
        x,
        y: s,
        type: "scatter",
        mode: "lines",
        line: { color: t.blue, width: 2 },
        hovertemplate: "Trade #%{x}<br>Sharpe %{y:,.2f}<extra></extra>"
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Trade #" },
      yaxis: { ...layout.yaxis, title: "Rolling Sharpe" },
      shapes: [{ type: "line", x0: 0, x1: r.length, y0: 0, y1: 0, line: { color: t.grid, width: 1 } }]
    });
    plotInto(div, data, layout);
  }
  function renderQQ(div, metrics) {
    const t = theme();
    const r = metrics.returns.slice().sort((a, b) => a - b);
    const n = r.length;
    if (n < 3) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const mean2 = r.reduce((a, b) => a + b, 0) / n;
    const std = Math.sqrt(r.reduce((a, b) => a + (b - mean2) ** 2, 0) / n) || 1;
    const qx = [];
    for (let i = 0; i < n; i += 1) qx.push(invNormal((i + 0.5) / n) * std + mean2);
    const lo = Math.min(qx[0], r[0]);
    const hi = Math.max(qx[n - 1], r[n - 1]);
    const data = [
      {
        x: qx,
        y: r,
        type: "scatter",
        mode: "markers",
        marker: { color: t.blue, size: 5 },
        hovertemplate: "Observed %{y:,.2f}<br>Normal %{x:,.2f}<extra></extra>",
        name: "Returns"
      },
      {
        x: [lo, hi],
        y: [lo, hi],
        type: "scatter",
        mode: "lines",
        line: { color: t.grid, dash: "dash", width: 1.5 },
        hoverinfo: "skip",
        name: "Normal"
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Normal quantile" },
      yaxis: { ...layout.yaxis, title: "Observed return" }
    });
    plotInto(div, data, layout);
  }
  function renderCumulativeWinRate(div, metrics) {
    const t = theme();
    const r = metrics.returns;
    const x = [];
    const y = [];
    let wins = 0;
    for (let i = 0; i < r.length; i += 1) {
      if (r[i] > 0) wins += 1;
      x.push(i + 1);
      y.push(wins / (i + 1));
    }
    const data = [
      {
        x,
        y,
        type: "scatter",
        mode: "lines",
        line: { color: t.amber, width: 2.5 },
        hovertemplate: "Trade #%{x}<br>Win rate %{y:.1%}<extra></extra>"
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Trade #" },
      yaxis: { ...layout.yaxis, title: "Cumulative win rate", range: [0, 1] },
      shapes: [{ type: "line", x0: 0, x1: r.length, y0: 0.5, y1: 0.5, line: { color: t.grid, width: 1, dash: "dot" } }]
    });
    plotInto(div, data, layout);
  }
  function renderPnlVsIndex(div, metrics) {
    const t = theme();
    const y = metrics.returns;
    const n = y.length;
    const x = y.map((_, i) => i + 1);
    const colors = y.map((v) => v >= 0 ? t.green : t.red);
    const mx = (n + 1) / 2;
    const my = y.reduce((a, b) => a + b, 0) / n;
    let cov = 0;
    let varx = 0;
    for (let i = 0; i < n; i += 1) {
      cov += (x[i] - mx) * (y[i] - my);
      varx += (x[i] - mx) ** 2;
    }
    const slope = varx > 0 ? cov / varx : 0;
    const intercept = my - slope * mx;
    const trendY = x.map((xi) => intercept + slope * xi);
    const data = [
      {
        x,
        y,
        type: "scatter",
        mode: "markers",
        marker: { color: colors, size: 6 },
        hovertemplate: "Trade #%{x}<br>P&L %{y:,.2f}<extra></extra>",
        name: "Trades"
      },
      {
        x,
        y: trendY,
        type: "scatter",
        mode: "lines",
        line: { color: t.amber, width: 2, dash: "dash" },
        hovertemplate: "Trend %{y:,.2f}<extra></extra>",
        name: "OLS trend"
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Trade #" },
      yaxis: { ...layout.yaxis, title: "P&L" },
      shapes: [{ type: "line", x0: 0, x1: n, y0: 0, y1: 0, line: { color: t.grid, width: 1 } }]
    });
    plotInto(div, data, layout);
  }
  function renderDirectionBreakdown(div, metrics) {
    const t = theme();
    const longs = metrics.tradeDetails.filter((td) => td.direction === "long");
    const shorts = metrics.tradeDetails.filter((td) => td.direction === "short");
    if (!longs.length && !shorts.length) {
      plotInto(div, [], baseLayout(t));
      const note = element("div", "plot-empty", "No direction data in this trade log \u2014 long/short breakdown needs a direction column.");
      div.appendChild(note);
      return;
    }
    const longPnl = longs.reduce((a, td) => a + td.pnl, 0);
    const shortPnl = shorts.reduce((a, td) => a + td.pnl, 0);
    const longWinRate = longs.length ? longs.filter((td) => td.pnl > 0).length / longs.length * 100 : 0;
    const shortWinRate = shorts.length ? shorts.filter((td) => td.pnl > 0).length / shorts.length * 100 : 0;
    const data = [
      {
        x: ["Long", "Short"],
        y: [longPnl, shortPnl],
        type: "bar",
        marker: { color: [t.green, t.red] },
        text: [
          `${longs.length} trades \xB7 ${longWinRate.toFixed(0)}% win`,
          `${shorts.length} trades \xB7 ${shortWinRate.toFixed(0)}% win`
        ],
        textposition: "outside",
        textfont: { color: t.textSec, size: 11 },
        hovertemplate: "%{x}<br>P&L %{y:,.2f}<extra></extra>"
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      yaxis: { ...layout.yaxis, title: "Total P&L" },
      bargap: 0.3
    });
    plotInto(div, data, layout);
  }
  function renderDayOfWeekHeatmap(div, metrics) {
    const t = theme();
    const dated = metrics.tradeDetails.filter((td) => td.date);
    if (!dated.length) {
      plotInto(div, [], baseLayout(t));
      const note = element("div", "plot-empty", "No dates in this trade log \u2014 day-of-week heatmap needs dated trades.");
      div.appendChild(note);
      return;
    }
    const dow = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const months = /* @__PURE__ */ new Map();
    for (const td of dated) {
      const d = new Date(td.date);
      if (Number.isNaN(d.getTime())) continue;
      const mk = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      const di = (d.getDay() + 6) % 7;
      if (!months.has(mk)) months.set(mk, new Array(7).fill(0));
      months.get(mk)[di] += td.pnl;
    }
    const sortedMonths = Array.from(months.keys()).sort();
    const z = sortedMonths.map((mk) => months.get(mk));
    const data = [
      {
        type: "heatmap",
        z,
        x: dow,
        y: sortedMonths,
        colorscale: [[0, t.red], [0.5, "#11161c"], [1, t.green]],
        zmid: 0,
        text: z.map((row) => row.map((v) => v === 0 ? "\u2014" : signed(v, 0))),
        texttemplate: "%{text}",
        textfont: { size: 10, color: t.text },
        hovertemplate: "%{x} %{y}<br>P&L %{z:,.2f}<extra></extra>",
        showscale: false,
        xgap: 3,
        ygap: 3
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      margin: { l: 60, r: 18, t: 10, b: 34 },
      xaxis: { gridcolor: "rgba(0,0,0,0)", zerolinecolor: "rgba(0,0,0,0)", tickfont: { color: t.textSec, size: 11 }, side: "bottom" },
      yaxis: { gridcolor: "rgba(0,0,0,0)", zerolinecolor: "rgba(0,0,0,0)", tickfont: { color: t.textSec }, automargin: true }
    });
    plotInto(div, data, layout);
  }
  function renderWeeklyHeatmap(div, metrics) {
    const t = theme();
    const dated = metrics.tradeDetails.filter((td) => td.date);
    if (!dated.length) {
      plotInto(div, [], baseLayout(t));
      const note = element("div", "plot-empty", "No dates in this trade log \u2014 weekly returns heatmap needs dated trades.");
      div.appendChild(note);
      return;
    }
    const dow = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    let firstMs = Infinity;
    for (const td of dated) {
      const ms = new Date(td.date).getTime();
      if (Number.isFinite(ms)) firstMs = Math.min(firstMs, ms);
    }
    if (!Number.isFinite(firstMs)) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const weekMap = /* @__PURE__ */ new Map();
    for (const td of dated) {
      const ms = new Date(td.date).getTime();
      if (!Number.isFinite(ms)) continue;
      const week = Math.floor((ms - firstMs) / 864e5 / 7);
      const di = (new Date(td.date).getDay() + 6) % 7;
      if (!weekMap.has(week)) weekMap.set(week, new Array(7).fill(0));
      weekMap.get(week)[di] += td.pnl;
    }
    const weeks = Array.from(weekMap.keys()).sort((a, b) => a - b);
    const z = weeks.map((w) => weekMap.get(w));
    const yLabels = weeks.map((w) => `W${w + 1}`);
    const data = [
      {
        type: "heatmap",
        z,
        x: dow,
        y: yLabels,
        colorscale: [
          [0, "#1e3a8a"],
          [0.5, "#11161c"],
          [1, "#dc2626"]
        ],
        zmid: 0,
        text: z.map((row) => row.map((v) => v === 0 ? "" : signed(v, 0))),
        texttemplate: "%{text}",
        textfont: { size: 10, color: t.text },
        hovertemplate: "%{x} %{y}<br>P&L %{z:,.2f}<extra></extra>",
        showscale: true,
        colorbar: { title: "P&L", thickness: 8, tickfont: { color: t.textSec, size: 9 }, titlefont: { color: t.textSec, size: 10 } },
        xgap: 3,
        ygap: 3
      }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      margin: { l: 50, r: 50, t: 10, b: 34 },
      xaxis: { gridcolor: "rgba(0,0,0,0)", zerolinecolor: "rgba(0,0,0,0)", tickfont: { color: t.textSec, size: 11 }, side: "bottom" },
      yaxis: { gridcolor: "rgba(0,0,0,0)", zerolinecolor: "rgba(0,0,0,0)", tickfont: { color: t.textSec }, automargin: true }
    });
    plotInto(div, data, layout);
  }
  function renderAutocorrelation(div, metrics) {
    const t = theme();
    const r = metrics.returns;
    const maxLag = Math.min(12, r.length - 1);
    if (maxLag < 1) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const mean2 = r.reduce((a, b) => a + b, 0) / r.length;
    const variance2 = r.reduce((a, b) => a + (b - mean2) ** 2, 0) / r.length || 1;
    const lags = [];
    const acf = [];
    for (let k = 1; k <= maxLag; k += 1) {
      let cov = 0;
      for (let i = 0; i < r.length - k; i += 1) cov += (r[i] - mean2) * (r[i + k] - mean2);
      cov /= r.length - k;
      lags.push(k);
      acf.push(cov / variance2);
    }
    const ci = 1.96 / Math.sqrt(r.length);
    const data = [{
      x: lags,
      y: acf,
      type: "bar",
      marker: { color: acf.map((v) => Math.abs(v) > ci ? t.amber : t.blue) },
      hovertemplate: "Lag %{x}<br>ACF %{y:,.3f}<extra></extra>"
    }];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Lag", dtick: 1 },
      yaxis: { ...layout.yaxis, title: "Autocorrelation" },
      shapes: [
        { type: "line", x0: 0.5, x1: maxLag + 0.5, y0: ci, y1: ci, line: { color: t.grid, width: 1, dash: "dash" } },
        { type: "line", x0: 0.5, x1: maxLag + 0.5, y0: -ci, y1: -ci, line: { color: t.grid, width: 1, dash: "dash" } },
        { type: "line", x0: 0.5, x1: maxLag + 0.5, y0: 0, y1: 0, line: { color: t.grid, width: 1 } }
      ]
    });
    plotInto(div, data, layout);
  }
  function renderDurationVsPnl(div, metrics) {
    const t = theme();
    const r = metrics.returns;
    const dates = metrics.tradeDates;
    if (!dates.some((d) => d)) {
      plotInto(div, [], baseLayout(t));
      const note = element("div", "plot-empty", "No dates \u2014 hold time needs dated trades.");
      div.appendChild(note);
      return;
    }
    const x = [];
    const y = [];
    const colors = [];
    for (let i = 0; i < r.length; i += 1) {
      const cur = dates[i];
      const nxt = dates[i + 1];
      let gap = 0;
      if (cur && nxt) {
        const ms = new Date(nxt).getTime() - new Date(cur).getTime();
        if (Number.isFinite(ms)) gap = ms / 864e5;
      }
      x.push(gap);
      y.push(r[i]);
      colors.push(r[i] >= 0 ? t.green : t.red);
    }
    const data = [{ x, y, type: "scatter", mode: "markers", marker: { color: colors, size: 7 }, hovertemplate: "Hold %{x}d<br>P&L %{y:,.2f}<extra></extra>" }];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Gap to next trade (days)" },
      yaxis: { ...layout.yaxis, title: "P&L" },
      shapes: [{ type: "line", x0: 0, x1: Math.max(...x, 1), y0: 0, y1: 0, line: { color: t.grid, width: 1 } }]
    });
    plotInto(div, data, layout);
  }
  function renderLossStreaks(div, metrics) {
    const t = theme();
    const r = metrics.returns;
    const lengths = [];
    let cur = 0;
    for (const v of r) {
      if (v < 0) cur += 1;
      else if (cur > 0) {
        lengths.push(cur);
        cur = 0;
      }
    }
    if (cur > 0) lengths.push(cur);
    if (!lengths.length) {
      plotInto(div, [], baseLayout(t));
      const note = element("div", "plot-empty", "No losing streaks in this log.");
      div.appendChild(note);
      return;
    }
    const data = [{ x: lengths, type: "histogram", marker: { color: t.red }, hovertemplate: "%{x} losses in a row<br>%{y} streaks<extra></extra>" }];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Consecutive losses", dtick: 1 },
      yaxis: { ...layout.yaxis, title: "Streak count" }
    });
    plotInto(div, data, layout);
  }
  function renderMonthlyReturnsBar(div, metrics) {
    const t = theme();
    if (!metrics.monthlyReturns.length) {
      plotInto(div, [], baseLayout(t));
      const note = element("div", "plot-empty", "No dates \u2014 monthly returns need dated trades.");
      div.appendChild(note);
      return;
    }
    const labels = metrics.monthlyReturns.map((m) => `${m.year}-${String(m.month + 1).padStart(2, "0")}`);
    const pnls = metrics.monthlyReturns.map((m) => m.pnl);
    const data = [{ x: labels, y: pnls, type: "bar", marker: { color: pnls.map((v) => v >= 0 ? t.green : t.red) }, hovertemplate: "%{x}<br>%{y:,.2f}<extra></extra>" }];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "" },
      yaxis: { ...layout.yaxis, title: "P&L" }
    });
    plotInto(div, data, layout);
  }
  function renderCumWinLoss(div, metrics) {
    const t = theme();
    const r = metrics.returns;
    const x = r.map((_, i) => i + 1);
    let cw = 0;
    let cl = 0;
    const win = [];
    const loss = [];
    for (const v of r) {
      if (v > 0) cw += v;
      else cl += Math.abs(v);
      win.push(cw);
      loss.push(-cl);
    }
    const data = [
      { x, y: win, type: "scatter", mode: "lines", line: { color: t.green, width: 2 }, fill: "tozeroy", fillcolor: "rgba(52,211,153,0.12)", hovertemplate: "Cum wins %{y:,.2f}<extra></extra>" },
      { x, y: loss, type: "scatter", mode: "lines", line: { color: t.red, width: 2 }, fill: "tozeroy", fillcolor: "rgba(251,113,133,0.12)", hovertemplate: "Cum losses %{y:,.2f}<extra></extra>" }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Trade #" },
      yaxis: { ...layout.yaxis, title: "Cumulative $" }
    });
    plotInto(div, data, layout);
  }
  function renderStrategyKelly(div, metrics) {
    const t = theme();
    const p = metrics.winRate;
    const avgWin = metrics.winCount > 0 ? metrics.grossWins / metrics.winCount : 0;
    const avgLoss = metrics.lossCount > 0 ? metrics.grossLosses / metrics.lossCount : 0;
    const b = avgLoss > 0 ? avgWin / avgLoss : avgWin > 0 ? Infinity : 0;
    const kelly = b > 0 && Number.isFinite(b) ? (p * b - (1 - p)) / b : 0;
    const full = Math.max(0, Math.min(1, kelly));
    const data = [{
      x: ["Full Kelly", "Half Kelly", "Quarter Kelly"],
      y: [full, full / 2, full / 4],
      type: "bar",
      marker: { color: [t.amber, t.blue, t.green] },
      text: [percent(full), percent(full / 2), percent(full / 4)],
      textposition: "outside",
      textfont: { color: t.textSec, size: 11 },
      hovertemplate: "%{x}<br>%{y:.1%} of account per trade<extra></extra>"
    }];
    const layout = baseLayout(t);
    Object.assign(layout, {
      yaxis: { ...layout.yaxis, title: "Risk per trade", tickformat: ".0%", range: [0, Math.max(1, full * 1.2)] },
      bargap: 0.3
    });
    plotInto(div, data, layout);
  }
  function renderLossRecovery(div, metrics) {
    const t = theme();
    const eq = metrics.equity;
    if (eq.length < 2) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    let peak = eq[0];
    let inDd = false;
    let ddStart = 0;
    const recoveries = [];
    for (let i = 0; i < eq.length; i += 1) {
      if (eq[i] > peak) {
        if (inDd) {
          recoveries.push(i - ddStart);
          inDd = false;
        }
        peak = eq[i];
      } else if (!inDd) {
        inDd = true;
        ddStart = i;
      }
    }
    if (inDd) recoveries.push(eq.length - 1 - ddStart);
    if (!recoveries.length) {
      plotInto(div, [], baseLayout(t));
      const note = element("div", "plot-empty", "No drawdowns to recover from.");
      div.appendChild(note);
      return;
    }
    const data = [{ x: recoveries.map((_, i) => i + 1), y: recoveries, type: "bar", marker: { color: t.amber }, hovertemplate: "DD #%{x}<br>%{y} trades to recover<extra></extra>" }];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Drawdown event", dtick: 1 },
      yaxis: { ...layout.yaxis, title: "Trades to new high" }
    });
    plotInto(div, data, layout);
  }
  function renderDirectionOverTime(div, metrics) {
    const t = theme();
    const r = metrics.returns;
    const td = metrics.tradeDetails;
    const x = r.map((_, i) => i + 1);
    let cl = 0;
    let cs = 0;
    const L = [];
    const S = [];
    for (let i = 0; i < r.length; i += 1) {
      if (td[i].direction === "long") cl += r[i];
      else if (td[i].direction === "short") cs += r[i];
      L.push(cl);
      S.push(cs);
    }
    const data = [
      { x, y: L, type: "scatter", mode: "lines", line: { color: t.green, width: 2 }, hovertemplate: "Long cum %{y:,.2f}<extra></extra>" },
      { x, y: S, type: "scatter", mode: "lines", line: { color: t.red, width: 2 }, hovertemplate: "Short cum %{y:,.2f}<extra></extra>" }
    ];
    const layout = baseLayout(t);
    Object.assign(layout, {
      xaxis: { ...layout.xaxis, title: "Trade #" },
      yaxis: { ...layout.yaxis, title: "Cumulative P&L" }
    });
    plotInto(div, data, layout);
  }
  function sceneAxis(t, title) {
    return {
      title: { text: title, font: { color: t.textSec, size: 10 } },
      gridcolor: t.gridSoft,
      zerolinecolor: t.grid,
      showspikes: false,
      showbackground: true,
      backgroundcolor: "rgba(0,0,0,0)",
      tickfont: { color: t.textSec, size: 10 }
    };
  }
  function renderFan3D(div, mc) {
    const t = theme();
    const limit = Math.min(mc.paths.length, 30);
    if (!limit || !mc.paths[0]?.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const data = [];
    for (let p = 0; p < limit; p += 1) {
      const path = mc.paths[p];
      data.push({
        type: "scatter3d",
        mode: "lines",
        x: path.map((_, i) => i),
        y: path,
        z: Array(path.length).fill(p),
        line: { color: t.blue, width: 2 },
        opacity: 0.45 + p / Math.max(limit, 1) * 0.35,
        hovertemplate: `Path ${p + 1}<br>Trade %{x}<br>Equity %{y:,.2f}<extra></extra>`,
        name: `Path ${p + 1}`,
        showlegend: false
      });
    }
    const layout = {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, system-ui, sans-serif", size: 11 },
      margin: { l: 0, r: 0, t: 8, b: 0 },
      showlegend: false,
      scene: {
        xaxis: sceneAxis(t, "Trade"),
        yaxis: sceneAxis(t, "Equity"),
        zaxis: sceneAxis(t, "Path"),
        camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
        bgcolor: "rgba(0,0,0,0)"
      }
    };
    plotInto(div, data, layout);
  }
  function renderSurface3D(div, mc) {
    const t = theme();
    const limit = Math.min(mc.paths.length, 40);
    const len = mc.paths[0]?.length || 0;
    if (!limit || !len) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const z = [];
    for (let p = 0; p < limit; p += 1) {
      const path = mc.paths[p];
      const row = [];
      let peak = 0;
      for (const v of path) {
        peak = Math.max(peak, v);
        row.push(peak - v);
      }
      z.push(row);
    }
    const x = Array.from({ length: len }, (_, i) => i);
    const y = Array.from({ length: limit }, (_, i) => i);
    const data = [
      {
        type: "surface",
        x,
        y,
        z,
        colorscale: [[0, t.green], [0.5, t.amber], [1, t.red]],
        showscale: false,
        hovertemplate: "Path %{y}<br>Trade %{x}<br>Drawdown %{z:,.2f}<extra></extra>",
        opacity: 0.92
      }
    ];
    const layout = {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, system-ui, sans-serif", size: 11 },
      margin: { l: 0, r: 0, t: 8, b: 0 },
      showlegend: false,
      scene: {
        xaxis: sceneAxis(t, "Trade"),
        yaxis: sceneAxis(t, "Path"),
        zaxis: sceneAxis(t, "Drawdown"),
        camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
        bgcolor: "rgba(0,0,0,0)"
      }
    };
    plotInto(div, data, layout);
  }
  function renderDistribution3D(div, mc) {
    const t = theme();
    if (!mc.terminals.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const min = Math.min(...mc.terminals);
    const max = Math.max(...mc.terminals);
    const range = max - min || 1;
    const binCount = Math.min(24, Math.max(8, Math.floor(Math.sqrt(mc.terminals.length))));
    const counts = new Array(binCount).fill(0);
    for (const terminal of mc.terminals) {
      const bin = Math.min(binCount - 1, Math.max(0, Math.floor((terminal - min) / range * binCount)));
      counts[bin] += 1;
    }
    const maxCount = Math.max(...counts) || 1;
    const binCenters = counts.map((_, i) => min + (i + 0.5) / binCount * range);
    const stemX = [];
    const stemY = [];
    const stemZ = [];
    for (let i = 0; i < binCount; i += 1) {
      stemX.push(binCenters[i], binCenters[i], null);
      stemY.push(0, counts[i], null);
      stemZ.push(i, i, null);
    }
    const data = [
      {
        type: "scatter3d",
        mode: "lines",
        x: stemX,
        y: stemY,
        z: stemZ,
        line: { color: t.blue, width: 6 },
        hovertemplate: "Bin %{z}<br>Outcome %{x:,.2f}<br>Count %{y}<extra></extra>",
        showlegend: false
      },
      {
        type: "scatter3d",
        mode: "markers",
        x: binCenters,
        y: counts,
        z: counts.map((_, i) => i),
        marker: {
          size: counts.map((c) => 8 + c / maxCount * 18),
          color: counts,
          colorscale: [[0, t.blue], [1, t.amber]],
          opacity: 0.85,
          line: { color: "rgba(0,0,0,0)", width: 0 }
        },
        hovertemplate: "Outcome %{x:,.2f}<br>Count %{y}<extra></extra>",
        showlegend: false
      }
    ];
    const layout = {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, system-ui, sans-serif", size: 11 },
      margin: { l: 0, r: 0, t: 8, b: 0 },
      showlegend: false,
      scene: {
        xaxis: sceneAxis(t, "Outcome"),
        yaxis: sceneAxis(t, "Frequency"),
        zaxis: sceneAxis(t, "Bin"),
        camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
        bgcolor: "rgba(0,0,0,0)"
      }
    };
    plotInto(div, data, layout);
  }
  function renderTradeScatter3D(div, metrics, detail) {
    const t = theme();
    const r = metrics.returns;
    if (!r.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const x = r.map((_, i) => i + 1);
    const y = r;
    const z = r.map((_, i) => {
      const cur = metrics.tradeDates[i];
      const nxt = metrics.tradeDates[i + 1];
      if (cur && nxt) {
        const d1 = new Date(cur).getTime();
        const d2 = new Date(nxt).getTime();
        if (Number.isFinite(d1) && Number.isFinite(d2)) return (d2 - d1) / 864e5;
      }
      return 0;
    });
    const colors = r.map((v) => v >= 0 ? t.green : t.red);
    const data = [
      {
        type: "scatter3d",
        mode: "markers",
        x,
        y,
        z,
        marker: { size: 7, color: colors, line: { color: "rgba(0,0,0,0)", width: 0 } },
        hovertemplate: "Trade #%{x}<br>P&L %{y:,.2f}<br>Gap %{z:.1f}d<extra></extra>",
        name: "Trades"
      }
    ];
    const layout = {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, system-ui, sans-serif", size: 11 },
      margin: { l: 0, r: 0, t: 8, b: 0 },
      showlegend: false,
      scene: {
        xaxis: sceneAxis(t, "Trade #"),
        yaxis: sceneAxis(t, "P&L"),
        zaxis: sceneAxis(t, "Gap to next (days)"),
        camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
        bgcolor: "rgba(0,0,0,0)"
      }
    };
    plotInto(div, data, layout);
    bindClick(div, (pt) => {
      const idx = pt.pointNumber;
      if (!Number.isInteger(idx) || idx < 0 || idx >= r.length) return;
      const pnl = r[idx];
      const eq = metrics.equity[idx];
      const dd = metrics.drawdownSeries[idx];
      const date = metrics.tradeDates[idx];
      fillDetail(detail, `Trade #${idx + 1}`, [
        ["P&L", signed(pnl)],
        ["Equity after", signed(eq)],
        ["Drawdown from peak", signed(dd)],
        ["Outcome", pnl > 0 ? "Win" : pnl < 0 ? "Loss" : "Flat"],
        ["Date", date ? new Date(date).toLocaleDateString() : "\u2014"],
        ["Gap to next", `${z[idx].toFixed(1)}d`]
      ]);
    });
  }
  function renderEquitySurface3D(div, mc) {
    const t = theme();
    const limit = Math.min(mc.paths.length, 40);
    const len = mc.paths[0]?.length || 0;
    if (!limit || !len) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const z = [];
    for (let p = 0; p < limit; p += 1) z.push(mc.paths[p].slice());
    const x = Array.from({ length: len }, (_, i) => i);
    const y = Array.from({ length: limit }, (_, i) => i);
    const data = [
      {
        type: "surface",
        x,
        y,
        z,
        colorscale: [
          [0, t.red],
          [0.5, t.amber],
          [1, t.green]
        ],
        showscale: false,
        hovertemplate: "Path %{y}<br>Trade %{x}<br>Equity %{z:,.2f}<extra></extra>",
        opacity: 0.92
      }
    ];
    const layout = {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, system-ui, sans-serif", size: 11 },
      margin: { l: 0, r: 0, t: 8, b: 0 },
      showlegend: false,
      scene: {
        xaxis: sceneAxis(t, "Trade"),
        yaxis: sceneAxis(t, "Path"),
        zaxis: sceneAxis(t, "Equity"),
        camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
        bgcolor: "rgba(0,0,0,0)"
      }
    };
    plotInto(div, data, layout);
  }
  function renderReturnDist3D(div, metrics) {
    const t = theme();
    const r = metrics.returns;
    if (!r.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const min = Math.min(...r);
    const max = Math.max(...r);
    const range = max - min || 1;
    const bins = Math.min(20, Math.max(8, Math.floor(Math.sqrt(r.length))));
    const counts = new Array(bins).fill(0);
    for (const v of r) {
      const b = Math.min(bins - 1, Math.max(0, Math.floor((v - min) / range * bins)));
      counts[b] += 1;
    }
    const maxC = Math.max(...counts) || 1;
    const centers = counts.map((_, i) => min + (i + 0.5) / bins * range);
    const v95ret = -varCvar(r, 0.05).varVal;
    const v99ret = -varCvar(r, 0.01).varVal;
    const stemX = [];
    const stemY = [];
    const stemZ = [];
    for (let i = 0; i < bins; i += 1) {
      stemX.push(centers[i], centers[i], null);
      stemY.push(0, counts[i], null);
      stemZ.push(i, i, null);
    }
    const data = [
      {
        type: "scatter3d",
        mode: "lines",
        x: stemX,
        y: stemY,
        z: stemZ,
        line: { color: t.blue, width: 5 },
        hovertemplate: "Return %{x:,.2f}<br>Count %{y}<extra></extra>",
        showlegend: false
      },
      {
        type: "scatter3d",
        mode: "markers",
        x: centers,
        y: counts,
        z: counts.map((_, i) => i),
        marker: {
          size: counts.map((c) => 8 + c / maxC * 18),
          color: centers.map((c) => c <= v99ret ? "#7f1d1d" : c <= v95ret ? t.red : t.blue),
          line: { color: "rgba(0,0,0,0)", width: 0 }
        },
        hovertemplate: "Return %{x:,.2f}<br>Count %{y}<extra></extra>",
        showlegend: false
      },
      {
        type: "scatter3d",
        mode: "lines",
        x: [v95ret, v95ret],
        y: [0, maxC * 1.1],
        z: [0, bins - 1],
        line: { color: t.amber, width: 4 },
        hovertemplate: `VaR 95% %{x:,.2f}<extra></extra>`,
        showlegend: false
      },
      {
        type: "scatter3d",
        mode: "lines",
        x: [v99ret, v99ret],
        y: [0, maxC * 1.1],
        z: [0, bins - 1],
        line: { color: "#7f1d1d", width: 4 },
        hovertemplate: `VaR 99% %{x:,.2f}<extra></extra>`,
        showlegend: false
      }
    ];
    const layout = {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, system-ui, sans-serif", size: 11 },
      margin: { l: 0, r: 0, t: 8, b: 0 },
      showlegend: false,
      scene: {
        xaxis: sceneAxis(t, "Return"),
        yaxis: sceneAxis(t, "Frequency"),
        zaxis: sceneAxis(t, "Bin"),
        camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
        bgcolor: "rgba(0,0,0,0)"
      }
    };
    plotInto(div, data, layout);
  }
  function renderRollingVar3D(div, metrics) {
    const t = theme();
    const r = metrics.returns;
    if (r.length < 5) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const windows = [10, 20, 30, 50].filter((w) => w <= r.length * 2);
    if (!windows.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const x = r.map((_, i) => i + 1);
    const z = windows.map(
      (w) => r.map((_, i) => {
        const slice = r.slice(Math.max(0, i - w + 1), i + 1);
        const sorted = slice.slice().sort((a, b) => a - b);
        return sorted[Math.max(0, Math.floor(sorted.length * 0.05) - 1)];
      })
    );
    const data = [
      {
        type: "surface",
        x,
        y: windows.map(String),
        z,
        colorscale: [
          [0, t.green],
          [0.5, t.amber],
          [1, t.red]
        ],
        showscale: false,
        hovertemplate: "Trade %{x}<br>Window %{y}<br>VaR %{z:,.2f}<extra></extra>",
        opacity: 0.9
      }
    ];
    const layout = {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, system-ui, sans-serif", size: 11 },
      margin: { l: 0, r: 0, t: 8, b: 0 },
      showlegend: false,
      scene: {
        xaxis: sceneAxis(t, "Trade #"),
        yaxis: sceneAxis(t, "Window"),
        zaxis: sceneAxis(t, "VaR (95%)"),
        camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
        bgcolor: "rgba(0,0,0,0)"
      }
    };
    plotInto(div, data, layout);
  }
  function renderRollingDd3D(div, metrics) {
    const t = theme();
    const eq = metrics.equity;
    if (eq.length < 5) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const windows = [10, 20, 30, 50].filter((w) => w <= eq.length * 2);
    if (!windows.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const x = eq.map((_, i) => i + 1);
    const z = windows.map(
      (w) => eq.map((_, i) => {
        const start = Math.max(0, i - w + 1);
        let peak = eq[start];
        let maxDd = 0;
        for (let j = start; j <= i; j += 1) {
          peak = Math.max(peak, eq[j]);
          maxDd = Math.max(maxDd, peak - eq[j]);
        }
        return maxDd;
      })
    );
    const data = [
      {
        type: "surface",
        x,
        y: windows.map(String),
        z,
        colorscale: [
          [0, t.green],
          [0.5, t.amber],
          [1, t.red]
        ],
        showscale: false,
        hovertemplate: "Trade %{x}<br>Window %{y}<br>Max DD %{z:,.2f}<extra></extra>",
        opacity: 0.9
      }
    ];
    const layout = {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, system-ui, sans-serif", size: 11 },
      margin: { l: 0, r: 0, t: 8, b: 0 },
      showlegend: false,
      scene: {
        xaxis: sceneAxis(t, "Trade #"),
        yaxis: sceneAxis(t, "Window"),
        zaxis: sceneAxis(t, "Max drawdown"),
        camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
        bgcolor: "rgba(0,0,0,0)"
      }
    };
    plotInto(div, data, layout);
  }
  function renderRiskScatter3D(div, metrics, detail) {
    const t = theme();
    const r = metrics.returns;
    if (!r.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const x = r.map((_, i) => i + 1);
    const y = r;
    const z = metrics.drawdownSeries;
    const colors = r.map((v) => v >= 0 ? t.green : t.red);
    const data = [
      {
        type: "scatter3d",
        mode: "markers",
        x,
        y,
        z,
        marker: { size: 7, color: colors, line: { color: "rgba(0,0,0,0)", width: 0 } },
        hovertemplate: "Trade #%{x}<br>P&L %{y:,.2f}<br>Drawdown %{z:,.2f}<extra></extra>",
        name: "Trades"
      }
    ];
    const layout = {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, system-ui, sans-serif", size: 11 },
      margin: { l: 0, r: 0, t: 8, b: 0 },
      showlegend: false,
      scene: {
        xaxis: sceneAxis(t, "Trade #"),
        yaxis: sceneAxis(t, "P&L"),
        zaxis: sceneAxis(t, "Drawdown"),
        camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
        bgcolor: "rgba(0,0,0,0)"
      }
    };
    plotInto(div, data, layout);
    bindClick(div, (pt) => {
      const idx = pt.pointNumber;
      if (!Number.isInteger(idx) || idx < 0 || idx >= r.length) return;
      const pnl = r[idx];
      const dd = metrics.drawdownSeries[idx];
      const eq = metrics.equity[idx];
      const date = metrics.tradeDates[idx];
      fillDetail(detail, `Trade #${idx + 1} \u2014 risk`, [
        ["P&L", signed(pnl)],
        ["Equity after", signed(eq)],
        ["Drawdown from peak", signed(dd)],
        ["Outcome", pnl > 0 ? "Win" : pnl < 0 ? "Loss" : "Flat"],
        ["Date", date ? new Date(date).toLocaleDateString() : "\u2014"],
        ["Progress", `${idx + 1} / ${r.length}`]
      ]);
    });
  }
  function pathMaxDrawdown(path) {
    let peak = 0;
    let maxDd = 0;
    for (const v of path) {
      peak = Math.max(peak, v);
      maxDd = Math.max(maxDd, peak - v);
    }
    return maxDd;
  }
  function renderMcMaxDd3D(div, mc) {
    const t = theme();
    if (!mc.paths.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const maxDds = mc.paths.map(pathMaxDrawdown);
    const min = Math.min(...maxDds);
    const max = Math.max(...maxDds);
    const range = max - min || 1;
    const binCount = Math.min(20, Math.max(8, Math.floor(Math.sqrt(maxDds.length))));
    const counts = new Array(binCount).fill(0);
    for (const dd of maxDds) {
      const b = Math.min(binCount - 1, Math.max(0, Math.floor((dd - min) / range * binCount)));
      counts[b] += 1;
    }
    const maxC = Math.max(...counts) || 1;
    const centers = counts.map((_, i) => min + (i + 0.5) / binCount * range);
    const stemX = [];
    const stemY = [];
    const stemZ = [];
    for (let i = 0; i < binCount; i += 1) {
      stemX.push(centers[i], centers[i], null);
      stemY.push(0, counts[i], null);
      stemZ.push(i, i, null);
    }
    const data = [
      {
        type: "scatter3d",
        mode: "lines",
        x: stemX,
        y: stemY,
        z: stemZ,
        line: { color: t.red, width: 5 },
        hovertemplate: "Max DD %{x:,.2f}<br>Count %{y}<extra></extra>",
        showlegend: false
      },
      {
        type: "scatter3d",
        mode: "markers",
        x: centers,
        y: counts,
        z: counts.map((_, i) => i),
        marker: {
          size: counts.map((c) => 8 + c / maxC * 18),
          color: counts,
          colorscale: [[0, t.amber], [1, t.red]],
          line: { color: "rgba(0,0,0,0)", width: 0 }
        },
        hovertemplate: "Max DD %{x:,.2f}<br>Paths %{y}<extra></extra>",
        showlegend: false
      }
    ];
    const layout = {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, system-ui, sans-serif", size: 11 },
      margin: { l: 0, r: 0, t: 8, b: 0 },
      showlegend: false,
      scene: {
        xaxis: sceneAxis(t, "Max drawdown"),
        yaxis: sceneAxis(t, "Path count"),
        zaxis: sceneAxis(t, "Bin"),
        camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
        bgcolor: "rgba(0,0,0,0)"
      }
    };
    plotInto(div, data, layout);
  }
  function renderMcRiskScatter3D(div, mc, detail) {
    const t = theme();
    const limit = Math.min(mc.paths.length, 400);
    if (!limit) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const sampled = [];
    const step = Math.max(1, Math.floor(mc.paths.length / limit));
    const x = [];
    const y = [];
    const z = [];
    const colors = [];
    for (let p = 0; p < mc.paths.length; p += step) {
      const path = mc.paths[p];
      const terminal = path[path.length - 1];
      const maxDd = pathMaxDrawdown(path);
      let mn = Infinity;
      let mx = -Infinity;
      for (const v of path) {
        mn = Math.min(mn, v);
        mx = Math.max(mx, v);
      }
      sampled.push({ idx: p, terminal, maxDd, min: mn, max: mx });
      x.push(terminal);
      y.push(maxDd);
      z.push(p);
      colors.push(terminal >= 0 ? t.green : t.red);
    }
    const data = [
      {
        type: "scatter3d",
        mode: "markers",
        x,
        y,
        z,
        marker: { size: 5, color: colors, line: { color: "rgba(0,0,0,0)", width: 0 } },
        hovertemplate: "Path %{z}<br>Terminal %{x:,.2f}<br>Max DD %{y:,.2f}<extra></extra>",
        name: "Paths"
      }
    ];
    const layout = {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, system-ui, sans-serif", size: 11 },
      margin: { l: 0, r: 0, t: 8, b: 0 },
      showlegend: false,
      scene: {
        xaxis: sceneAxis(t, "Terminal equity"),
        yaxis: sceneAxis(t, "Max drawdown"),
        zaxis: sceneAxis(t, "Path #"),
        camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
        bgcolor: "rgba(0,0,0,0)"
      }
    };
    plotInto(div, data, layout);
    bindClick(div, (pt) => {
      const entry = sampled[pt.pointNumber];
      if (!entry) return;
      const rankBelow = mc.terminals.filter((v) => v <= entry.terminal).length;
      const rankPct = rankBelow / Math.max(mc.terminals.length, 1) * 100;
      fillDetail(detail, `MC path #${entry.idx + 1} \u2014 risk`, [
        ["Terminal equity", signed(entry.terminal)],
        ["Max drawdown", signed(-entry.maxDd)],
        ["Min equity", signed(entry.min)],
        ["Max equity", signed(entry.max)],
        ["Rank (terminal)", `${rankPct.toFixed(0)}% at or below`],
        ["Outcome", entry.terminal >= 0 ? "Positive" : "Negative"]
      ]);
    });
  }
  function renderMcPercentile3D(div, mc) {
    const t = theme();
    const len = mc.paths[0]?.length || 0;
    if (!len || !mc.paths.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const percentiles = [5, 10, 25, 50, 75, 90, 95];
    const x = Array.from({ length: len }, (_, i) => i + 1);
    const z = percentiles.map((p) => {
      const fraction = p / 100;
      const row = [];
      for (let i = 0; i < len; i += 1) {
        const col = mc.paths.map((path) => path[i]).sort((a, b) => a - b);
        row.push(pct(col, fraction));
      }
      return row;
    });
    const data = [
      {
        type: "surface",
        x,
        y: percentiles.map((p) => `p${p}`),
        z,
        colorscale: [
          [0, t.red],
          [0.5, t.amber],
          [1, t.green]
        ],
        showscale: false,
        hovertemplate: "Trade %{x}<br>%{y}<br>Equity %{z:,.2f}<extra></extra>",
        opacity: 0.92
      }
    ];
    const layout = {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, system-ui, sans-serif", size: 11 },
      margin: { l: 0, r: 0, t: 8, b: 0 },
      showlegend: false,
      scene: {
        xaxis: sceneAxis(t, "Trade #"),
        yaxis: sceneAxis(t, "Percentile"),
        zaxis: sceneAxis(t, "Equity"),
        camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
        bgcolor: "rgba(0,0,0,0)"
      }
    };
    plotInto(div, data, layout);
  }
  function renderRollingSharpe3D(div, metrics) {
    const t = theme();
    const r = metrics.returns;
    const windows = [10, 20, 30, 50].filter((w) => w <= r.length * 2);
    if (!windows.length || r.length < 5) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const x = r.map((_, i) => i + 1);
    const z = windows.map(
      (w) => r.map((_, i) => {
        const slice = r.slice(Math.max(0, i - w + 1), i + 1);
        const mean2 = slice.reduce((a, b) => a + b, 0) / slice.length;
        const variance2 = slice.reduce((a, b) => a + (b - mean2) ** 2, 0) / slice.length;
        const std = Math.sqrt(variance2);
        return std > 0 ? mean2 / std : 0;
      })
    );
    const data = [{
      type: "surface",
      x,
      y: windows.map(String),
      z,
      colorscale: [[0, t.red], [0.5, t.amber], [1, t.green]],
      showscale: false,
      hovertemplate: "Trade %{x}<br>Window %{y}<br>Sharpe %{z:,.2f}<extra></extra>",
      opacity: 0.9
    }];
    const layout = {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, system-ui, sans-serif", size: 11 },
      margin: { l: 0, r: 0, t: 8, b: 0 },
      showlegend: false,
      scene: { xaxis: sceneAxis(t, "Trade #"), yaxis: sceneAxis(t, "Window"), zaxis: sceneAxis(t, "Rolling Sharpe"), camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } }, bgcolor: "rgba(0,0,0,0)" }
    };
    plotInto(div, data, layout);
  }
  function renderRollingSortino3D(div, metrics) {
    const t = theme();
    const r = metrics.returns;
    const windows = [10, 20, 30, 50].filter((w) => w <= r.length * 2);
    if (!windows.length || r.length < 5) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const x = r.map((_, i) => i + 1);
    const z = windows.map(
      (w) => r.map((_, i) => {
        const slice = r.slice(Math.max(0, i - w + 1), i + 1);
        const mean2 = slice.reduce((a, b) => a + b, 0) / slice.length;
        const downside = slice.filter((v) => v < 0);
        if (!downside.length) return mean2 > 0 ? 5 : 0;
        const dd = Math.sqrt(downside.reduce((a, b) => a + b * b, 0) / slice.length);
        return dd > 0 ? mean2 / dd : 0;
      })
    );
    const data = [{
      type: "surface",
      x,
      y: windows.map(String),
      z,
      colorscale: [[0, t.red], [0.5, t.amber], [1, t.green]],
      showscale: false,
      hovertemplate: "Trade %{x}<br>Window %{y}<br>Sortino %{z:,.2f}<extra></extra>",
      opacity: 0.9
    }];
    const layout = {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, system-ui, sans-serif", size: 11 },
      margin: { l: 0, r: 0, t: 8, b: 0 },
      showlegend: false,
      scene: { xaxis: sceneAxis(t, "Trade #"), yaxis: sceneAxis(t, "Window"), zaxis: sceneAxis(t, "Rolling Sortino"), camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } }, bgcolor: "rgba(0,0,0,0)" }
    };
    plotInto(div, data, layout);
  }
  function renderAcAutocorrelation3D(div, metrics) {
    const t = theme();
    const r = metrics.returns;
    if (r.length < 10) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const n = r.length;
    const windows = Array.from(new Set([Math.max(5, Math.floor(n * 0.4)), Math.max(8, Math.floor(n * 0.6)), Math.max(10, Math.floor(n * 0.8)), n - 1].filter((w) => w >= 5 && w < n))).sort((a, b) => a - b);
    const maxLag = Math.min(8, Math.max(2, Math.floor(n / 4)));
    const lags = Array.from({ length: maxLag }, (_, i) => i + 1);
    const z = windows.map((w) => {
      const row = [];
      for (let k = 1; k <= maxLag; k += 1) {
        let cov = 0;
        let count = 0;
        for (let i = 0; i + w <= r.length; i += 1) {
          const slice = r.slice(i, i + w);
          const mean2 = slice.reduce((a, b) => a + b, 0) / slice.length;
          const variance2 = slice.reduce((a, b) => a + (b - mean2) ** 2, 0) / slice.length || 1;
          let c = 0;
          for (let j = 0; j < slice.length - k; j += 1) c += (slice[j] - mean2) * (slice[j + k] - mean2);
          c /= slice.length - k;
          cov += c / variance2;
          count += 1;
        }
        row.push(count > 0 ? cov / count : 0);
      }
      return row;
    });
    const data = [{
      type: "surface",
      x: lags,
      y: windows.map(String),
      z,
      colorscale: [[0, t.blue], [0.5, t.amber], [1, t.red]],
      showscale: false,
      hovertemplate: "Lag %{x}<br>Window %{y}<br>ACF %{z:,.3f}<extra></extra>",
      opacity: 0.9
    }];
    const layout = {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, system-ui, sans-serif", size: 11 },
      margin: { l: 0, r: 0, t: 8, b: 0 },
      showlegend: false,
      scene: { xaxis: sceneAxis(t, "Lag"), yaxis: sceneAxis(t, "Window"), zaxis: sceneAxis(t, "Autocorrelation"), camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } }, bgcolor: "rgba(0,0,0,0)" }
    };
    plotInto(div, data, layout);
  }
  function renderEquityDensity3D(div, mc) {
    const t = theme();
    const len = mc.paths[0]?.length || 0;
    if (!len || !mc.paths.length) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const allVals = [];
    for (const p of mc.paths) for (const v of p) allVals.push(v);
    const min = Math.min(...allVals);
    const max = Math.max(...allVals);
    const range = max - min || 1;
    const binCount = Math.min(24, Math.max(8, Math.floor(Math.sqrt(allVals.length))));
    const bins = Array.from({ length: binCount }, (_, b) => min + (b + 0.5) / binCount * range);
    const z = bins.map(() => new Array(len).fill(0));
    for (const p of mc.paths) {
      for (let i = 0; i < len; i += 1) {
        const v = p[i];
        const b = Math.min(binCount - 1, Math.max(0, Math.floor((v - min) / range * binCount)));
        z[b][i] += 1;
      }
    }
    const x = Array.from({ length: len }, (_, i) => i + 1);
    const data = [{
      type: "surface",
      x,
      y: bins.map((b) => Math.round(b)),
      z,
      colorscale: [[0, "#11161c"], [0.5, t.blue], [1, t.amber]],
      showscale: false,
      hovertemplate: "Trade %{x}<br>Equity %{y}<br>Paths %{z}<extra></extra>",
      opacity: 0.92
    }];
    const layout = {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, system-ui, sans-serif", size: 11 },
      margin: { l: 0, r: 0, t: 8, b: 0 },
      showlegend: false,
      scene: { xaxis: sceneAxis(t, "Trade #"), yaxis: sceneAxis(t, "Equity"), zaxis: sceneAxis(t, "Path count"), camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } }, bgcolor: "rgba(0,0,0,0)" }
    };
    plotInto(div, data, layout);
  }
  function renderRollingCalmar3D(div, metrics) {
    const t = theme();
    const eq = metrics.equity;
    const windows = [10, 20, 30, 50].filter((w) => w <= eq.length * 2);
    if (!windows.length || eq.length < 5) {
      plotInto(div, [], baseLayout(t));
      return;
    }
    const x = eq.map((_, i) => i + 1);
    const z = windows.map(
      (w) => eq.map((_, i) => {
        const start = Math.max(0, i - w + 1);
        let peak = eq[start];
        let maxDd = 0;
        for (let j = start; j <= i; j += 1) {
          peak = Math.max(peak, eq[j]);
          maxDd = Math.max(maxDd, peak - eq[j]);
        }
        const ret = eq[i] - eq[start];
        return maxDd > 0 ? ret / maxDd : ret > 0 ? 5 : 0;
      })
    );
    const data = [{
      type: "surface",
      x,
      y: windows.map(String),
      z,
      colorscale: [[0, t.red], [0.5, t.amber], [1, t.green]],
      showscale: false,
      hovertemplate: "Trade %{x}<br>Window %{y}<br>Calmar %{z:,.2f}<extra></extra>",
      opacity: 0.9
    }];
    const layout = {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: t.text, family: "Inter, system-ui, sans-serif", size: 11 },
      margin: { l: 0, r: 0, t: 8, b: 0 },
      showlegend: false,
      scene: { xaxis: sceneAxis(t, "Trade #"), yaxis: sceneAxis(t, "Window"), zaxis: sceneAxis(t, "Rolling Calmar"), camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } }, bgcolor: "rgba(0,0,0,0)" }
    };
    plotInto(div, data, layout);
  }
  function createDomRefs() {
    const $ = (id) => {
      const node = document.getElementById(id);
      if (!node) throw new Error(`Missing element #${id}`);
      return node;
    };
    const csvInput = $("csv-input");
    const fileInput = $("file-input");
    const runButton = $("run-button");
    const clearButton = $("clear-button");
    const sampleButton = $("sample-button");
    const status = $("status");
    const report = $("report");
    const mcPathsInput = $("mc-paths");
    const mcBlockInput = $("mc-block");
    const mcSeedInput = $("mc-seed");
    const propPresetSelect = $("prop-preset");
    const propFields = {
      name: $("prop-name"),
      accountSize: $("prop-account"),
      profitTarget: $("prop-target"),
      maxDailyLoss: $("prop-daily"),
      maxTotalDrawdown: $("prop-drawdown"),
      evaluationDays: $("prop-days"),
      payoutPct: $("prop-payout"),
      challengeFee: $("prop-fee"),
      minPayout: $("prop-min-payout"),
      payoutDays: $("prop-payout-days"),
      trailingDrawdown: $("prop-trailing"),
      resetFee: $("prop-reset-fee"),
      scaling: $("prop-scaling"),
      phases: $("prop-phases"),
      consistencyPct: $("prop-consistency")
    };
    const tabButtons = {
      performance: $("tab-performance"),
      montecarlo: $("tab-montecarlo"),
      propfirm: $("tab-propfirm"),
      views3d: $("tab-views3d")
    };
    const panels = {
      performance: $("panel-performance"),
      montecarlo: $("panel-montecarlo"),
      propfirm: $("panel-propfirm"),
      views3d: $("panel-views3d")
    };
    document.querySelectorAll("#panel-views3d .bt-card").forEach((card) => {
      const chartEl = card.querySelector("[id]");
      const id = chartEl?.id;
      const title = card.querySelector("h3")?.textContent || "";
      if (id) enhanceCardHead(card, id, title);
    });
    return {
      csvInput,
      fileInput,
      runButton,
      clearButton,
      sampleButton,
      status,
      report,
      mcPathsInput,
      mcBlockInput,
      mcSeedInput,
      propPresetSelect,
      propFields,
      tabs: $("tabs"),
      tabButtons,
      panels,
      fanChart: $("fan-chart"),
      surfaceChart: $("surface-chart"),
      distributionChart: $("distribution-chart"),
      tradeScatterChart: $("trade-scatter-chart"),
      equitySurfaceChart: $("equity-surface-chart"),
      varChart: $("var-chart"),
      rollingVarChart: $("rolling-var-chart"),
      rollingDdChart: $("rolling-dd-chart"),
      riskScatterChart: $("risk-scatter-chart"),
      mcMaxDdChart: $("mc-maxdd-chart"),
      mcRiskScatterChart: $("mc-risk-scatter-chart"),
      mcPercentileChart: $("mc-percentile-chart"),
      sharpe3dChart: $("sharpe3d-chart"),
      sortino3dChart: $("sortino3d-chart"),
      acf3dChart: $("acf3d-chart"),
      density3dChart: $("density3d-chart"),
      calmar3dChart: $("calmar3d-chart"),
      views3dDetail: $("views3d-detail"),
      animateSelect: $("animate-3d"),
      metricValue: () => void 0
    };
  }
  function enhanceCardHead(card, chartId, title) {
    if (card.querySelector(".chart-play")) return;
    const oldH3 = card.querySelector("h3");
    const head = element("div", "card-head", void 0);
    head.appendChild(element("h3", void 0, title));
    const info = CHART_INFO[chartId];
    if (info) head.appendChild(infoBadge(info));
    const play = element("button", "chart-play", "\u25B6");
    play.type = "button";
    play.title = "Play animation";
    head.appendChild(play);
    if (oldH3) card.replaceChild(head, oldH3);
    else card.insertBefore(head, card.firstChild);
    play.addEventListener("click", () => {
      const target = document.getElementById(chartId);
      if (target) playChart(target);
    });
  }
  function bindTabs(refs) {
    const resizeChartsInPanel = (panel) => {
      if (!plotlyAvailable()) return;
      panel.querySelectorAll(".plot-chart").forEach((d) => {
        try {
          Plotly.Plots.resize(d);
        } catch {
        }
      });
    };
    Object.entries(refs.tabButtons).forEach(([key, button]) => {
      button.addEventListener("click", () => {
        Object.entries(refs.tabButtons).forEach(([otherKey, other]) => {
          other.classList.toggle("active", otherKey === key);
          other.setAttribute("aria-selected", otherKey === key ? "true" : "false");
        });
        Object.entries(refs.panels).forEach(([otherKey, panel2]) => {
          panel2.classList.toggle("visible", otherKey === key);
        });
        const panel = refs.panels[key];
        if (panel) {
          if (key === "views3d" && lastData3D) {
            requestAnimationFrame(() => render3DViews(refs, lastData3D));
          } else {
            requestAnimationFrame(() => resizeChartsInPanel(panel));
          }
        }
      });
    });
  }
  function renderReport(refs, data) {
    const { metrics, monteCarlo, propFirm } = data;
    refs.report.classList.add("visible");
    const performance2 = refs.panels.performance;
    performance2.textContent = "";
    {
      const gradeRow = element("div", "grade-row", void 0);
      gradeRow.appendChild(element("div", "grade", metrics.grade));
      const copy = element("div", "grade-copy", void 0);
      copy.appendChild(element("strong", void 0, metrics.gradeLabel));
      copy.appendChild(
        element(
          "span",
          void 0,
          metrics.count >= 50 ? "Enough trades to take the breakdown seriously \u2014 but a higher grade needs strength on every pillar, not just a positive expectancy." : metrics.count >= 20 ? "A modest sample \u2014 the grade is directional, not conclusive. Add more trades to harden it." : "A very small sample \u2014 the grade is barely indicative. Collect more trades before trusting it."
        )
      );
      gradeRow.appendChild(copy);
      const breakdownHost = element("div", "grade-breakdown", void 0);
      for (const sub of metrics.gradeBreakdown) {
        const row = element("div", "grade-bar-row", void 0);
        row.appendChild(element("span", "grade-bar-label", `${sub.category} \xB7 ${sub.score}/${sub.max}`));
        const bar = element("div", "grade-bar-track", void 0);
        const fill = element("div", "grade-bar-fill", void 0);
        const ratio = sub.max > 0 ? sub.score / sub.max : 0;
        fill.style.width = `${ratio * 100}%`;
        fill.style.background = ratio >= 0.75 ? "var(--bt-green)" : ratio >= 0.45 ? "var(--bt-amber)" : "var(--bt-red)";
        bar.appendChild(fill);
        row.appendChild(bar);
        breakdownHost.appendChild(row);
      }
      const adviceList = element("ul", "grade-advice", void 0);
      if (metrics.gradeAdvice.length === 0) {
        adviceList.appendChild(element("li", void 0, "No weak pillars \u2014 the strategy scores well on profitability, consistency, risk control, robustness, and sample size."));
      } else {
        for (const tip of metrics.gradeAdvice) adviceList.appendChild(element("li", void 0, tip));
      }
      performance2.appendChild(
        buildCard("verdict-card", "QuantPad verdict", [
          gradeRow,
          element("p", "summary", `${metrics.gradeLabel} \u2014 ${metrics.gradeScore}/100 evidence score (${metrics.grade}).`),
          breakdownHost,
          element("h4", "grade-advice-title", "How to improve"),
          adviceList
        ])
      );
    }
    const perfDetail = detailPanel("perf-detail");
    performance2.appendChild(sectionTitle("Equity & P&L"));
    {
      const g = grid();
      const eq = chartCard("Equity curve", "equity-chart", "wide");
      g.appendChild(eq.card);
      renderEquityChart(eq.div, metrics, perfDetail);
      const pnl = chartCard("Per-trade P&L", "pnl-chart", "tall");
      g.appendChild(pnl.card);
      renderPnlBars(pnl.div, metrics, perfDetail);
      const vsidx = chartCard("P&L vs trade # (edge decay)", "pnl-vs-index-chart");
      g.appendChild(vsidx.card);
      renderPnlVsIndex(vsidx.div, metrics);
      const hist = chartCard("Per-trade return distribution", "returns-hist-chart");
      g.appendChild(hist.card);
      renderReturnHistogram(hist.div, metrics);
      const uwater = chartCard("Underwater drawdown", "underwater-chart");
      g.appendChild(uwater.card);
      renderUnderwaterDrawdown(uwater.div, metrics);
      performance2.appendChild(g);
    }
    performance2.appendChild(perfDetail);
    performance2.appendChild(sectionTitle("Risk & distribution"));
    {
      const g = grid();
      const box = chartCard("Returns box plot (wins vs losses)", "box-chart");
      g.appendChild(box.card);
      renderReturnsBox(box.div, metrics);
      const rsharpe = chartCard("Rolling Sharpe", "rolling-sharpe-chart");
      g.appendChild(rsharpe.card);
      renderRollingSharpe(rsharpe.div, metrics);
      const roll = chartCard("Rolling expectancy & win rate", "rolling-chart");
      g.appendChild(roll.card);
      renderRollingMetrics(roll.div, metrics);
      const qq = chartCard("Q-Q plot vs normal", "qq-chart");
      g.appendChild(qq.card);
      renderQQ(qq.div, metrics);
      performance2.appendChild(g);
    }
    {
      const g = grid();
      const mh = chartCard("Monthly returns", "monthly-heatmap-chart", "wide");
      g.appendChild(mh.card);
      renderMonthlyHeatmap(mh.div, metrics);
      performance2.appendChild(g);
    }
    performance2.appendChild(sectionTitle("Streaks & relationships"));
    {
      const g = grid();
      const cwr = chartCard("Cumulative win rate", "cum-winrate-chart");
      g.appendChild(cwr.card);
      renderCumulativeWinRate(cwr.div, metrics);
      const dir = chartCard("Long vs short performance", "direction-chart");
      g.appendChild(dir.card);
      renderDirectionBreakdown(dir.div, metrics);
      const dow = chartCard("P&L by day of week", "dow-heatmap-chart", "wide");
      g.appendChild(dow.card);
      renderDayOfWeekHeatmap(dow.div, metrics);
      const weekly = chartCard("Weekly returns heatmap (cold \u2192 hot)", "weekly-heatmap-chart", "wide");
      g.appendChild(weekly.card);
      renderWeeklyHeatmap(weekly.div, metrics);
      performance2.appendChild(g);
    }
    performance2.appendChild(sectionTitle("Strategy improvement"));
    {
      const g = grid();
      const acf = chartCard("Return autocorrelation (entry timing)", "acf-chart");
      g.appendChild(acf.card);
      renderAutocorrelation(acf.div, metrics);
      const dur = chartCard("Hold time vs P&L (cut winners/losers?)", "duration-pnl-chart");
      g.appendChild(dur.card);
      renderDurationVsPnl(dur.div, metrics);
      const streaks = chartCard("Losing-streak distribution (sizing)", "loss-streaks-chart");
      g.appendChild(streaks.card);
      renderLossStreaks(streaks.div, metrics);
      const kelly = chartCard("Position sizing (Kelly)", "strategy-kelly-chart");
      g.appendChild(kelly.card);
      renderStrategyKelly(kelly.div, metrics);
      performance2.appendChild(g);
    }
    {
      const g = grid();
      const monthly = chartCard("Monthly returns bar (seasonality)", "monthly-bar-chart");
      g.appendChild(monthly.card);
      renderMonthlyReturnsBar(monthly.div, metrics);
      const cumwl = chartCard("Cumulative winners vs losers", "cum-wl-chart");
      g.appendChild(cumwl.card);
      renderCumWinLoss(cumwl.div, metrics);
      const rec = chartCard("Loss recovery time (resilience)", "loss-recovery-chart");
      g.appendChild(rec.card);
      renderLossRecovery(rec.div, metrics);
      const dir = chartCard("Long vs short cumulative", "direction-over-time-chart");
      g.appendChild(dir.card);
      renderDirectionOverTime(dir.div, metrics);
      performance2.appendChild(g);
    }
    performance2.appendChild(sectionTitle("Summary"));
    const metricGrid = element("div", "metric-grid", void 0);
    metricGrid.append(
      metric("Trades", String(metrics.count)),
      metric("Win rate", percent(metrics.winRate)),
      metric("Expectancy", signed(metrics.expectancy)),
      metric("Profit factor", Number.isFinite(metrics.profitFactor) ? number(metrics.profitFactor) : "\u221E"),
      metric("Net result", signed(metrics.netPnl)),
      metric("Max drawdown", signed(-metrics.maxDrawdown)),
      metric("Avg hold time", toIsoDate(metrics.avgHoldMs)),
      metric("Best / worst", `${signed(metrics.bestTrade)} / ${signed(metrics.worstTrade)}`)
    );
    const riskList = element("ul", "risk-list", void 0);
    riskList.append(
      riskRow("Max drawdown", `${signed(-metrics.maxDrawdown)} (${percent(metrics.maxDrawdownPct)} from peak)`),
      riskRow("Outcome dispersion", number(metrics.standardDeviation)),
      riskRow("Sharpe-like ratio", number(metrics.sharpeLike)),
      riskRow("Max consecutive wins", String(metrics.maxConsecutiveWins)),
      riskRow("Max consecutive losses", String(metrics.maxConsecutiveLosses))
    );
    const avgWin = metrics.winCount > 0 ? metrics.grossWins / metrics.winCount : 0;
    const avgLoss = metrics.lossCount > 0 ? metrics.grossLosses / metrics.lossCount : 0;
    const payoff = avgLoss > 0 ? avgWin / avgLoss : avgWin > 0 ? Infinity : 0;
    const tradeStatsGrid = element("div", "metric-grid", void 0);
    tradeStatsGrid.append(
      metric("Avg win", signed(avgWin)),
      metric("Avg loss", signed(-avgLoss)),
      metric("Payoff ratio", Number.isFinite(payoff) ? number(payoff, 2) : "\u221E"),
      metric("Largest win", signed(metrics.bestTrade)),
      metric("Largest loss", signed(metrics.worstTrade)),
      metric("R-expectancy", number(metrics.rExpectancy, 2)),
      metric("Win / loss count", `${metrics.winCount} / ${metrics.lossCount}`),
      metric("Std deviation", number(metrics.standardDeviation))
    );
    {
      const g = grid();
      g.appendChild(buildCard("metrics-card", "Performance summary", [metricGrid]));
      g.appendChild(buildCard("metrics-card", "Risk and robustness", [riskList]));
      g.appendChild(buildCard("metrics-card", "Trade statistics", [tradeStatsGrid]));
      performance2.appendChild(g);
    }
    {
      const v95 = varCvar(metrics.returns, 0.05);
      const v99 = varCvar(metrics.returns, 0.01);
      const varGrid = element("div", "metric-grid", void 0);
      varGrid.append(
        metric("VaR 95%", signed(-v95.varVal)),
        metric("CVaR 95%", signed(-v95.cvar)),
        metric("VaR 99%", signed(-v99.varVal)),
        metric("CVaR 99%", signed(-v99.cvar)),
        metric("Worst trade", signed(metrics.worstTrade)),
        metric("Max drawdown", signed(-metrics.maxDrawdown))
      );
      const g = grid();
      g.appendChild(buildCard("metrics-card", "Value at Risk (per trade)", [varGrid]));
      performance2.appendChild(g);
    }
    performance2.appendChild(sectionTitle("Calendar & trade log"));
    {
      const calDetail = detailPanel("cal-detail");
      const card = element("article", "bt-card metrics-card", void 0);
      const head = element("div", "card-head", void 0);
      head.appendChild(element("h3", void 0, "Trading calendar \u2014 click a day to inspect"));
      head.appendChild(infoBadge("Each day colored by its net P&L (green = profit, red = loss). Click a day to see that day\u2019s trades. Months flow 2-per-row."));
      card.appendChild(head);
      const calHost = element("div", "cal-host", void 0);
      card.appendChild(calHost);
      card.appendChild(calDetail);
      performance2.appendChild(card);
      renderTradingCalendar(calHost, metrics, calDetail);
    }
    {
      const card = element("article", "bt-card metrics-card", void 0);
      const head = element("div", "card-head", void 0);
      head.appendChild(element("h3", void 0, "Trade log"));
      head.appendChild(infoBadge("Every parsed trade in order: direction, entry/exit, size, P&L, cumulative equity, and drawdown at that point."));
      card.appendChild(head);
      const host = element("div", void 0, void 0);
      card.appendChild(host);
      performance2.appendChild(card);
      renderTradeLogTable(host, metrics);
    }
    const montePanel = refs.panels.montecarlo;
    montePanel.textContent = "";
    const mcGrid = element("div", "metric-grid", void 0);
    mcGrid.append(
      metric("Terminal p5", signed(monteCarlo.p5)),
      metric("Median terminal", signed(monteCarlo.p50)),
      metric("Terminal p95", signed(monteCarlo.p95)),
      metric("Positive paths", percent(monteCarlo.positivePathsPct)),
      metric("Risk of ruin", percent(monteCarlo.riskOfRuinPct / 100)),
      metric("DD p95", signed(-monteCarlo.drawdownPercentiles.p95))
    );
    montePanel.appendChild(buildCard("metrics-card", "Monte Carlo summary", [mcGrid]));
    {
      const g = grid();
      const bands = chartCard("Equity percentile bands", "mc-bands-chart");
      g.appendChild(bands.card);
      renderMonteCarloBands(bands.div, monteCarlo);
      const dist = chartCard("Terminal outcome distribution", "mc-dist-chart");
      g.appendChild(dist.card);
      renderTerminalDistribution(dist.div, monteCarlo);
      montePanel.appendChild(g);
    }
    {
      const mcDetail = detailPanel("mc-detail");
      const g = grid();
      const paths = chartCard("Individual paths \u2014 click to inspect", "mc-paths-chart", "wide");
      g.appendChild(paths.card);
      renderMonteCarloPaths(paths.div, monteCarlo, mcDetail);
      montePanel.appendChild(g);
      montePanel.appendChild(mcDetail);
    }
    montePanel.appendChild(sectionTitle("Monte Carlo analytics"));
    {
      const g = grid();
      const ddDist = chartCard("Max drawdown distribution", "mc-dd-dist-chart");
      g.appendChild(ddDist.card);
      renderMcDrawdownDistribution(ddDist.div, monteCarlo);
      const sharpeDist = chartCard("Path Sharpe distribution", "mc-sharpe-dist-chart");
      g.appendChild(sharpeDist.card);
      renderMcSharpeDistribution(sharpeDist.div, monteCarlo);
      const calmarDist = chartCard("Path Calmar distribution", "mc-calmar-dist-chart");
      g.appendChild(calmarDist.card);
      renderMcCalmarDistribution(calmarDist.div, monteCarlo);
      const durDist = chartCard("Underwater duration distribution", "mc-dd-duration-chart");
      g.appendChild(durDist.card);
      renderMcDrawdownDuration(durDist.div, monteCarlo);
      montePanel.appendChild(g);
    }
    {
      const g = grid();
      const ror = chartCard("Risk of ruin over time", "mc-ror-chart");
      g.appendChild(ror.card);
      renderMcRiskOfRuin(ror.div, monteCarlo);
      const pop = chartCard("Probability of profit over time", "mc-pop-chart");
      g.appendChild(pop.card);
      renderMcProbOfProfit(pop.div, monteCarlo);
      const cdf = chartCard("Terminal equity CDF", "mc-cdf-chart");
      g.appendChild(cdf.card);
      renderMcTerminalCDF(cdf.div, monteCarlo);
      const ttd = chartCard("Time-to-max-drawdown", "mc-ttd-chart");
      g.appendChild(ttd.card);
      renderMcTimeToDrawdown(ttd.div, monteCarlo);
      montePanel.appendChild(g);
    }
    {
      const g = grid();
      const uwater = chartCard("Underwater envelope (avg drawdown over time)", "mc-underwater-chart", "wide");
      g.appendChild(uwater.card);
      renderMcUnderwaterEnvelope(uwater.div, monteCarlo);
      montePanel.appendChild(g);
    }
    {
      const g = grid();
      const extreme = chartCard("Best / worst / median paths", "mc-extreme-chart", "wide");
      g.appendChild(extreme.card);
      renderMcExtremePaths(extreme.div, monteCarlo);
      montePanel.appendChild(g);
    }
    const footnote = element(
      "p",
      "footnote",
      `${monteCarlo.config.paths} paths, block size ${monteCarlo.config.blockSize}, seed ${monteCarlo.config.seed}.`
    );
    montePanel.appendChild(footnote);
    const propPanel = refs.panels.propfirm;
    propPanel.textContent = "";
    propPanel.appendChild(sectionTitle("Prop firm simulation"));
    const propGrid = element("div", "metric-grid", void 0);
    propGrid.append(
      metric("Pass rate", percent(propFirm.passRatePct / 100)),
      metric("Fail rate", percent(propFirm.failRatePct / 100)),
      metric("Avg days to target", propFirm.averageDaysToTarget === null ? "\u2014" : number(propFirm.averageDaysToTarget, 1)),
      metric("Expected value", signed(propFirm.expectedValue)),
      metric("Payout probability", percent(propFirm.payoutProbabilityPct / 100)),
      metric("Simulations", String(propFirm.runs))
    );
    propPanel.appendChild(buildCard("metrics-card", `${propFirm.config.name} \u2014 simulation`, [propGrid]));
    const passRate = propFirm.passRatePct / 100;
    const accountsToOnePass = passRate > 0 ? 1 / passRate : Infinity;
    const pAtLeast1in3 = 1 - Math.pow(1 - passRate, 3);
    const pAtLeast1in5 = 1 - Math.pow(1 - passRate, 5);
    const payoutPerPass = payoutPerPassFor(propFirm);
    const meetsMinPayout = payoutPerPass >= propFirm.config.minPayout;
    const effectivePayout = meetsMinPayout ? payoutPerPass : 0;
    const phasesPassRate = Math.pow(passRate, propFirm.config.phases);
    const payoutPerAttempt = passRate * payoutPerPass;
    const costPerFail = propFirm.config.challengeFee;
    const expPayout = passRate * effectivePayout;
    const expCost = (1 - passRate) * costPerFail;
    const breakEvenPassRate = costPerFail > 0 ? costPerFail / (costPerFail + effectivePayout) : 0;
    const profitFactorProp = expCost > 0 ? expPayout / expCost : expPayout > 0 ? Infinity : 0;
    const payoffRatio = costPerFail > 0 ? payoutPerPass / costPerFail : Infinity;
    const kellyFraction = effectivePayout > 0 ? propFirm.expectedValue / effectivePayout : 0;
    const edgePerFee = costPerFail > 0 ? propFirm.expectedValue / costPerFail * 100 : 0;
    const costToOnePass = Number.isFinite(accountsToOnePass) ? propFirm.config.challengeFee + Math.max(0, Math.ceil(accountsToOnePass) - 1) * propFirm.config.resetFee : Infinity;
    const netPerPass = payoutPerPass - (Number.isFinite(costToOnePass) ? costToOnePass : 0);
    const econGrid = element("div", "metric-grid", void 0);
    econGrid.append(
      metric("Pass rate", percent(passRate)),
      metric("Avg profit at pass", propFirm.avgProfitAtPass === null ? "\u2014" : signed(propFirm.avgProfitAtPass, 0)),
      metric("Profit split", percent(propFirm.config.payoutPct / 100)),
      metric("Payout per pass", signed(payoutPerPass, 0)),
      metric("Meets min payout", meetsMinPayout ? `yes (\u2265 ${number(propFirm.config.minPayout, 0)})` : `no (< ${number(propFirm.config.minPayout, 0)})`),
      metric("Net EV / attempt", signed(propFirm.expectedValue, 0)),
      metric("Expected payout / attempt", signed(payoutPerAttempt, 0)),
      metric("Challenge fee (per fail)", signed(-costPerFail, 0)),
      metric("Reset fee", signed(-propFirm.config.resetFee, 0)),
      metric("Accounts to one pass", Number.isFinite(accountsToOnePass) ? number(accountsToOnePass, 2) : "\u221E"),
      metric("Expected cost to one pass", Number.isFinite(costToOnePass) ? signed(-costToOnePass, 0) : "\u221E"),
      metric("Net per pass (after fees)", signed(netPerPass, 0)),
      metric("Phases pass rate", `\xD7${propFirm.config.phases} = ${percent(phasesPassRate)}`),
      metric("Break-even pass rate", percent(breakEvenPassRate)),
      metric("Profit factor (prop)", Number.isFinite(profitFactorProp) ? number(profitFactorProp, 2) : "\u221E"),
      metric("Payoff ratio (payout/fee)", Number.isFinite(payoffRatio) ? number(payoffRatio, 1) : "\u221E"),
      metric("Kelly fraction", percent(Math.max(0, kellyFraction))),
      metric("Edge per fee", `${edgePerFee >= 0 ? "+" : ""}${edgePerFee.toFixed(0)}%`),
      metric("P(\u22651 pass \xB7 3 accts)", percent(pAtLeast1in3)),
      metric("P(\u22651 pass \xB7 5 accts)", percent(pAtLeast1in5)),
      metric("Target / account", percent(propFirm.config.profitTarget / propFirm.config.accountSize)),
      metric("Scaling on pass", `\xD7${propFirm.config.scaling}`),
      metric("Drawdown type", propFirm.config.trailingDrawdown ? "trailing" : "static"),
      metric("Consistency rule", propFirm.config.consistencyPct > 0 ? `max ${propFirm.config.consistencyPct}%/day` : "disabled"),
      metric("Payout frequency", `every ${propFirm.config.payoutDays}d`),
      metric("Avg days to target", propFirm.averageDaysToTarget === null ? "\u2014" : number(propFirm.averageDaysToTarget, 1))
    );
    propPanel.appendChild(buildCard("metrics-card", "Prop firm economics (your real money)", [econGrid]));
    propPanel.appendChild(
      element(
        "p",
        "footnote",
        `Payout per pass is computed from the average profit actually earned when passing (${propFirm.avgProfitAtPass === null ? "target" : number(propFirm.avgProfitAtPass, 0)}) \xD7 the ${propFirm.config.payoutPct}% profit split${meetsMinPayout ? "" : " \u2014 below the minimum withdrawal, so it is held until it accumulates"}. Prop balance is the firm\u2019s money; you only risk the fee from your real balance (lost on fail, refunded on pass).`
      )
    );
    {
      const g = grid();
      const ev = chartCard("Expected value breakdown (per attempt)", "ev-waterfall-chart");
      g.appendChild(ev.card);
      renderEvWaterfall(ev.div, propFirm);
      const avg = chartCard("Average equity path vs target", "avg-path-chart");
      g.appendChild(avg.card);
      renderAverageEquityPath(avg.div, propFirm);
      propPanel.appendChild(g);
    }
    {
      const g = grid();
      const donut = chartCard("Pass / fail outcome", "prop-donut-chart", "tall");
      g.appendChild(donut.card);
      renderPropDonut(donut.div, propFirm);
      const payout = chartCard("Payout probability", "prop-payout-donut-chart", "tall");
      g.appendChild(payout.card);
      renderPayoutDonut(payout.div, propFirm);
      propPanel.appendChild(g);
    }
    {
      const g = grid();
      const prob = chartCard("Pass probability (\u22651 pass in N accounts)", "prop-prob-chart");
      g.appendChild(prob.card);
      renderPassProbabilityCurve(prob.div, propFirm);
      const growth = chartCard("Real balance growth over N accounts", "prop-growth-chart");
      g.appendChild(growth.card);
      renderAccountGrowth(growth.div, propFirm);
      propPanel.appendChild(g);
    }
    propPanel.appendChild(sectionTitle("Economics analysis"));
    {
      const g = grid();
      const evpr = chartCard("EV vs pass rate (break-even)", "prop-evpr-chart");
      g.appendChild(evpr.card);
      renderEvVsPassRate(evpr.div, propFirm);
      const kelly = chartCard("Kelly growth vs bet fraction", "prop-kelly-chart");
      g.appendChild(kelly.card);
      renderKellyGrowth(kelly.div, propFirm);
      const ror = chartCard("Risk of ruin over N accounts", "prop-ror-chart");
      g.appendChild(ror.card);
      renderRiskOfRuinAccounts(ror.div, propFirm);
      const payoff2 = chartCard("Payoff ratio (payout vs fee)", "prop-payoff-chart", "tall");
      g.appendChild(payoff2.card);
      renderPayoffRatioBar(payoff2.div, propFirm);
      const pf = chartCard("Profit factor vs pass rate", "prop-pf-chart");
      g.appendChild(pf.card);
      renderProfitFactorVsPassRate(pf.div, propFirm);
      propPanel.appendChild(g);
    }
    propPanel.appendChild(sectionTitle("Run outcomes"));
    {
      const propDetail = detailPanel("prop-detail");
      const g = grid();
      const runs = chartCard("Sample run equity paths \u2014 click to inspect", "prop-runs-chart", "wide");
      g.appendChild(runs.card);
      renderPropSamplePaths(runs.div, propFirm, propDetail);
      propPanel.appendChild(g);
      propPanel.appendChild(propDetail);
    }
    {
      const g = grid();
      const term = chartCard("Run P&L distribution (pass vs fail)", "prop-terminal-chart");
      g.appendChild(term.card);
      renderPropTerminalDistribution(term.div, propFirm);
      const days = chartCard("Days to target (passing runs)", "prop-days-chart", "tall");
      g.appendChild(days.card);
      renderDaysToTarget(days.div, propFirm);
      const fail = chartCard("Failure modes", "prop-failures-chart", "tall");
      g.appendChild(fail.card);
      renderFailureBar(fail.div, propFirm);
      propPanel.appendChild(g);
    }
    const failureList = element("ul", "risk-list", void 0);
    if (propFirm.failures.length === 0) {
      failureList.appendChild(element("li", void 0, "No failures recorded in this run."));
    } else {
      for (const failure of propFirm.failures) {
        failureList.appendChild(
          riskRow(failure.reason, `${failure.count} (${percent(failure.pct)})`)
        );
      }
    }
    propPanel.appendChild(buildCard("metrics-card", "Failure modes", [failureList]));
    refs.metricValue = () => void 0;
    lastData3D = data;
    if (refs.panels.views3d.classList.contains("visible")) {
      render3DViews(refs, data);
    }
    requestAnimationFrame(() => {
      if (!plotlyAvailable()) return;
      document.querySelectorAll(".plot-chart").forEach((d) => {
        if (d.clientWidth > 0 && d.clientHeight > 0) {
          try {
            Plotly.Plots.resize(d);
          } catch {
          }
        }
      });
    });
  }
  var METRIC_INFO = {
    Trades: "Number of usable trades parsed from your log. More trades = more confidence in every other metric.",
    "Win rate": "Share of trades that closed in profit.",
    Expectancy: "Average P&L per trade. Positive = the edge pays you per trade over the long run.",
    "Profit factor": "Gross wins \xF7 gross losses. Above 1 = profitable; above 1.5 = solid.",
    "Net result": "Total P&L across all trades.",
    "Max drawdown": "Worst peak-to-trough drop in the equity curve.",
    "Avg hold time": "Average time a position was held (from dated trades).",
    "Best / worst": "Largest single win and largest single loss.",
    "Avg win": "Average profit on a winning trade.",
    "Avg loss": "Average loss on a losing trade.",
    "Payoff ratio": "Avg win \xF7 avg loss. How big winners are vs losers.",
    "Largest win": "Single biggest winning trade.",
    "Largest loss": "Single biggest losing trade.",
    "R-expectancy": "Expectancy in units of risk (return per unit of std deviation).",
    "Win / loss count": "Number of winning trades vs losing trades.",
    "Std deviation": "Dispersion of per-trade returns. Higher = more volatile P&L.",
    "VaR 95%": "Value at Risk \u2014 the loss you\u2019d exceed only 5% of the time per trade.",
    "CVaR 95%": "Conditional VaR (expected shortfall) \u2014 the average loss in the worst 5%.",
    "VaR 99%": "The loss exceeded only 1% of the time.",
    "CVaR 99%": "Average loss in the worst 1%.",
    "Terminal p5": "5th-percentile ending equity across Monte Carlo paths (worst plausible).",
    "Median terminal": "50th-percentile ending equity (typical outcome).",
    "Terminal p95": "95th-percentile ending equity (best plausible).",
    "Positive paths": "Share of Monte Carlo paths that ended in profit.",
    "Risk of ruin": "Share of paths that ended below zero.",
    "DD p95": "95th-percentile drawdown across paths (worst-case drawdown).",
    "Pass rate": "Share of simulated attempts that passed the firm rules.",
    "Fail rate": "Share of attempts that failed (breached a limit or ran out of time).",
    "Avg days to target": "Mean days passing runs took to reach the profit target.",
    "Expected value": "Net expected $ per attempt (payout on pass \u2212 fee on fail).",
    "Payout probability": "Probability of getting a payout = pass rate per attempt.",
    Simulations: "Number of bootstrapped runs simulated.",
    "Payout per pass": "Dollars you receive on a pass = profit target \xD7 payout %.",
    "Challenge fee (per fail)": "The fee you lose from your real balance when an attempt fails.",
    "Net EV / attempt": "Expected change to your real balance per attempt.",
    "Expected payout / attempt": "Pass rate \xD7 payout per pass.",
    "Accounts to one pass": "Expected attempts needed for one pass = 1 \xF7 pass rate.",
    "Expected cost to one pass": "Fees you\u2019d pay to get one pass = accounts to pass \xD7 fee.",
    "Net per pass (after fees)": "Payout per pass minus the fees spent to get there.",
    "Break-even pass rate": "The pass rate at which EV = 0. Below this, the firm is not worth trying.",
    "Profit factor (prop)": "Expected payout \xF7 expected cost per attempt.",
    "Payoff ratio (payout/fee)": "Payout per pass \xF7 fee. How many fees one payout covers.",
    "Kelly fraction": "Optimal share of your bankroll to risk per attempt (full Kelly).",
    "Edge per fee": "EV as a % of the fee \u2014 return per dollar of fee paid.",
    "P(\u22651 pass \xB7 3 accts)": "Probability of at least one pass in 3 attempts.",
    "P(\u22651 pass \xB7 5 accts)": "Probability of at least one pass in 5 attempts.",
    "Target / account": "Profit target as a % of the firm\u2019s balance.",
    "Consistency rule": "Max profit a single day can contribute as % of the target. A run that hits the target on one big day fails this rule.",
    "Drawdown type": "Static = the loss limit is fixed; trailing = it tightens as your balance rises (harder).",
    "Payout frequency": "How often you can withdraw from the funded account (informational).",
    "Scaling on pass": "Account-size multiplier applied after passing (scaling plan); affects future payouts.",
    "Phases pass rate": "Combined pass rate across all phases = single-phase pass rate raised to the phase count."
  };
  function metric(label, value) {
    const card = element("div", "metric-card", void 0);
    card.appendChild(element("div", "metric-label", label));
    card.appendChild(element("div", "metric-value", value));
    const hint = METRIC_INFO[label];
    if (hint) card.appendChild(element("div", "metric-hint", hint));
    return card;
  }
  function riskRow(label, value) {
    const row = element("li", void 0, void 0);
    row.appendChild(element("span", void 0, label));
    row.appendChild(element("strong", void 0, value));
    return row;
  }
  var CARD_INFO = {
    "QuantPad verdict": "An overall grade built from 5 pillars (profitability, consistency, risk control, robustness, sample size). It\u2019s only as strong as the weakest pillar \u2014 a positive expectancy alone won\u2019t earn an A.",
    "Performance summary": "The headline numbers for the backtest. Hover any tile for what it means.",
    "Risk and robustness": "How volatile and how reliable the edge is \u2014 drawdown, dispersion, Sharpe-like ratio, and worst winning/losing streaks.",
    "Trade statistics": "Per-trade shape of the edge \u2014 average win/loss, payoff ratio, largest win/loss, and R-expectancy.",
    "Value at Risk (per trade)": "Tail-risk per trade. VaR is the loss exceeded only X% of the time; CVaR is the average loss in that worst tail.",
    "Monte Carlo summary": "Outcome distribution from bootstrapped resampling. p5/p50/p95 = the worst / typical / best plausible ending equity.",
    "Prop firm economics (your real money)": "Your real-balance economics: you pay the fee (lost on fail, refunded on pass) and receive the payout on pass. The prop balance is the firm\u2019s money, not yours.",
    "Failure modes": "Why attempts failed \u2014 daily-loss breach, max-drawdown breach, or running out of evaluation days."
  };
  function infoBadge(text) {
    const badge = element("span", "chart-info", "i");
    badge.appendChild(element("span", "chart-info-tip", text));
    return badge;
  }
  function buildCard(className, title, children) {
    const card = element("article", `report-card ${className}`, void 0);
    const head = element("div", "card-head", void 0);
    head.appendChild(element("h3", void 0, title));
    const info = CARD_INFO[title] || (title.endsWith("\u2014 simulation") ? "Pass/fail results from simulating the firm rules (target, daily loss, max drawdown, evaluation days) on resampled trades sized to the firm\u2019s balance." : "");
    if (info) head.appendChild(infoBadge(info));
    card.appendChild(head);
    children.forEach((child) => card.appendChild(child));
    return card;
  }
  var threeDObserver = null;
  var threeDState = /* @__PURE__ */ new Map();
  function setup3DLazy(refs, data) {
    if (!plotlyAvailable()) return;
    fillDetail(refs.views3dDetail, "Click to inspect", [["Hint", "Click any point on the trade scatter above."]]);
    const items = [
      { div: refs.fanChart, render: () => renderFan3D(refs.fanChart, data.monteCarlo) },
      { div: refs.surfaceChart, render: () => renderSurface3D(refs.surfaceChart, data.monteCarlo) },
      { div: refs.distributionChart, render: () => renderDistribution3D(refs.distributionChart, data.monteCarlo) },
      { div: refs.tradeScatterChart, render: () => renderTradeScatter3D(refs.tradeScatterChart, data.metrics, refs.views3dDetail) },
      { div: refs.equitySurfaceChart, render: () => renderEquitySurface3D(refs.equitySurfaceChart, data.monteCarlo) },
      { div: refs.varChart, render: () => renderReturnDist3D(refs.varChart, data.metrics) },
      { div: refs.rollingVarChart, render: () => renderRollingVar3D(refs.rollingVarChart, data.metrics) },
      { div: refs.rollingDdChart, render: () => renderRollingDd3D(refs.rollingDdChart, data.metrics) },
      { div: refs.riskScatterChart, render: () => renderRiskScatter3D(refs.riskScatterChart, data.metrics, refs.views3dDetail) },
      { div: refs.mcMaxDdChart, render: () => renderMcMaxDd3D(refs.mcMaxDdChart, data.monteCarlo) },
      { div: refs.mcRiskScatterChart, render: () => renderMcRiskScatter3D(refs.mcRiskScatterChart, data.monteCarlo, refs.views3dDetail) },
      { div: refs.mcPercentileChart, render: () => renderMcPercentile3D(refs.mcPercentileChart, data.monteCarlo) },
      { div: refs.sharpe3dChart, render: () => renderRollingSharpe3D(refs.sharpe3dChart, data.metrics) },
      { div: refs.sortino3dChart, render: () => renderRollingSortino3D(refs.sortino3dChart, data.metrics) },
      { div: refs.acf3dChart, render: () => renderAcAutocorrelation3D(refs.acf3dChart, data.metrics) },
      { div: refs.density3dChart, render: () => renderEquityDensity3D(refs.density3dChart, data.monteCarlo) },
      { div: refs.calmar3dChart, render: () => renderRollingCalmar3D(refs.calmar3dChart, data.metrics) }
    ];
    threeDState.clear();
    items.forEach((it) => {
      releaseAutoplay(it.div);
      try {
        Plotly.purge(it.div);
      } catch {
      }
      threeDState.set(it.div, { render: it.render, rendered: false });
    });
    if (threeDObserver) threeDObserver.disconnect();
    threeDObserver = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          const st = threeDState.get(e.target);
          if (!st) continue;
          if (e.isIntersecting && !st.rendered) {
            st.render();
            st.rendered = true;
          } else if (!e.isIntersecting && st.rendered) {
            releaseAutoplay(e.target);
            try {
              Plotly.purge(e.target);
            } catch {
            }
            st.rendered = false;
          }
        }
      },
      { rootMargin: "300px 0px", threshold: 0.01 }
    );
    items.forEach((it) => threeDObserver.observe(it.div));
  }
  function render3DViews(refs, data) {
    setup3DLazy(refs, data);
  }
  function populatePropPresets(refs) {
    refs.propPresetSelect.textContent = "";
    for (const preset of PROP_FIRM_PRESETS) {
      const option = element("option", void 0, preset.name);
      option.value = preset.name;
      refs.propPresetSelect.appendChild(option);
    }
    refs.propPresetSelect.value = PROP_FIRM_PRESETS[0].name;
    applyPropConfig(refs, PROP_FIRM_PRESETS[0]);
  }
  function applyPropConfig(refs, config) {
    refs.propFields.name.value = config.name;
    refs.propFields.accountSize.value = String(config.accountSize);
    refs.propFields.profitTarget.value = String(config.profitTarget);
    refs.propFields.maxDailyLoss.value = String(config.maxDailyLoss);
    refs.propFields.maxTotalDrawdown.value = String(config.maxTotalDrawdown);
    refs.propFields.evaluationDays.value = String(config.evaluationDays);
    refs.propFields.payoutPct.value = String(config.payoutPct);
    refs.propFields.challengeFee.value = String(config.challengeFee);
    refs.propFields.minPayout.value = String(config.minPayout);
    refs.propFields.payoutDays.value = String(config.payoutDays);
    refs.propFields.trailingDrawdown.value = String(config.trailingDrawdown ? 1 : 0);
    refs.propFields.resetFee.value = String(config.resetFee);
    refs.propFields.scaling.value = String(config.scaling);
    refs.propFields.phases.value = String(config.phases);
    refs.propFields.consistencyPct.value = String(config.consistencyPct);
  }
  function readPropConfig(refs) {
    const read = (key, fallback) => {
      const parsed = Number(refs.propFields[key].value);
      return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
    };
    const readNonNeg = (key, fallback) => {
      const parsed = Number(refs.propFields[key].value);
      return Number.isFinite(parsed) && parsed >= 0 ? parsed : fallback;
    };
    return {
      name: refs.propFields.name.value.trim() || "Custom firm",
      accountSize: read("accountSize", 1e5),
      profitTarget: read("profitTarget", 1e4),
      maxDailyLoss: read("maxDailyLoss", 5e3),
      maxTotalDrawdown: read("maxTotalDrawdown", 1e4),
      evaluationDays: Math.round(read("evaluationDays", 30)),
      payoutPct: Math.min(100, Math.max(0, read("payoutPct", 80))),
      challengeFee: readNonNeg("challengeFee", 549),
      minPayout: readNonNeg("minPayout", 1e3),
      payoutDays: Math.round(read("payoutDays", 14)),
      trailingDrawdown: Number(refs.propFields.trailingDrawdown.value) >= 1,
      resetFee: readNonNeg("resetFee", 549),
      scaling: Math.max(1, read("scaling", 1)),
      phases: Math.min(3, Math.max(1, Math.round(read("phases", 1)))),
      consistencyPct: Math.min(100, Math.max(0, readNonNeg("consistencyPct", 50)))
    };
  }

  // backtester-src/sample.ts
  var SAMPLE_TRADE_LOG = (() => {
    const header = "Trade #,Type,Signal,Date/Time,Price,Qty,P&L,Cumulative P&L,Drawdown,Run-up,Cumulative P&L %,Buy & Hold %,Trade #";
    const rows = [header];
    const data = [
      [1, "long", "2025-01-03 09:30", "2025-01-05 16:00", 4200.5, 15, 2400],
      [2, "short", "2025-01-07 10:00", "2025-01-08 11:00", 4300, 15, -285],
      [3, "long", "2025-01-10 09:30", "2025-01-12 15:00", 4250, 15, 690],
      [4, "long", "2025-01-14 10:00", "2025-01-15 14:00", 4280, 8, 488],
      [5, "short", "2025-01-17 10:00", "2025-01-17 15:00", 4310, 15, -3500],
      [6, "long", "2025-01-22 09:30", "2025-01-24 16:00", 4260, 15, 885],
      [7, "short", "2025-01-27 10:00", "2025-01-28 11:00", 4340, 15, -195],
      [8, "long", "2025-01-31 09:30", "2025-02-03 15:00", 4270, 8, 672],
      [9, "long", "2025-02-04 09:30", "2025-02-06 16:00", 4290, 15, 2300],
      [10, "short", "2025-02-07 10:00", "2025-02-10 11:00", 4380, 15, -435],
      [11, "long", "2025-02-12 09:30", "2025-02-14 15:00", 4300, 8, 608],
      [12, "long", "2025-02-18 09:30", "2025-02-20 16:00", 4310, 15, 773],
      [13, "short", "2025-02-21 10:00", "2025-02-24 11:00", 4400, 15, -308],
      [14, "long", "2025-02-26 09:30", "2025-02-28 15:00", 4320, 8, 536],
      [15, "long", "2025-03-03 09:30", "2025-03-05 16:00", 4300, 15, 2200],
      [16, "short", "2025-03-06 10:00", "2025-03-07 11:00", 4450, 15, -3500],
      [17, "long", "2025-03-11 09:30", "2025-03-13 15:00", 4340, 8, 704],
      [18, "long", "2025-03-17 09:30", "2025-03-19 16:00", 4360, 15, 2200],
      [19, "short", "2025-03-20 10:00", "2025-03-21 11:00", 4420, 15, -263],
      [20, "long", "2025-03-26 09:30", "2025-03-28 15:00", 4350, 8, 392],
      [21, "long", "2025-04-02 09:30", "2025-04-04 16:00", 4380, 15, 2200],
      [22, "short", "2025-04-08 10:00", "2025-04-09 11:00", 4480, 15, -3500],
      [23, "long", "2025-04-15 09:30", "2025-04-17 15:00", 4400, 8, 760],
      [24, "long", "2025-04-22 09:30", "2025-04-24 16:00", 4410, 8, 584]
    ];
    let cum = 0;
    for (const [num, dir, entryDate, exitDate, entry, qty, pnl] of data) {
      const exit = dir === "long" ? entry + pnl / qty : entry - pnl / qty;
      const entryType = dir === "long" ? "Entry long" : "Entry short";
      const exitType = dir === "long" ? "Exit long" : "Exit short";
      rows.push(`${num},${entryType},,${entryDate},${entry},${qty},,,,,,, ,${num}`);
      cum += pnl;
      rows.push(`${num},${exitType},,${exitDate},${exit.toFixed(2)},${qty},${pnl.toFixed(2)},${cum.toFixed(2)},,,,, ,${num}`);
    }
    return rows.join("\n");
  })();

  // backtester-src/main.ts
  function init() {
    const refs = createDomRefs();
    bindTabs(refs);
    populatePropPresets(refs);
    refs.report.classList.remove("visible");
    const reshuffleButton = document.getElementById("reshuffle-button");
    if (reshuffleButton) reshuffleButton.disabled = true;
    const animSelect = document.getElementById("anim-charts");
    const rotateSelect = document.getElementById("animate-3d");
    const animToggle = document.getElementById("anim-toggle");
    const syncAnimationUi = () => {
      const on = animationsAreEnabled();
      if (animSelect) animSelect.value = on ? "on" : "off";
      if (animToggle) {
        animToggle.textContent = on ? "Stop animations" : "Start animations";
        animToggle.setAttribute("aria-pressed", on ? "false" : "true");
        animToggle.classList.toggle("is-off", !on);
      }
    };
    const applyAnimationSettings = () => {
      const wasOn = animationsAreEnabled();
      const on = !animSelect || animSelect.value === "on";
      setAnimationsEnabled(on);
      setAutoRotateEnabled(!rotateSelect || rotateSelect.value === "on");
      if (on && !wasOn) rearmAll();
      syncAnimationUi();
    };
    applyAnimationSettings();
    if (animSelect) animSelect.addEventListener("change", applyAnimationSettings);
    if (rotateSelect) rotateSelect.addEventListener("change", applyAnimationSettings);
    if (animToggle) {
      animToggle.addEventListener("click", () => {
        if (animSelect) animSelect.value = animationsAreEnabled() ? "off" : "on";
        applyAnimationSettings();
      });
    }
    refs.propPresetSelect.addEventListener("change", () => {
      const preset = PROP_FIRM_PRESETS.find((item) => item.name === refs.propPresetSelect.value);
      if (preset) applyPropConfig(refs, preset);
    });
    refs.fileInput.addEventListener("change", () => {
      const file = refs.fileInput.files && refs.fileInput.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        refs.csvInput.value = String(reader.result || "");
        refs.status.className = "status";
        refs.status.textContent = `${file.name} loaded. Run the backtest when ready.`;
      };
      reader.readAsText(file);
    });
    const dropZone = document.getElementById("drop-zone");
    if (dropZone) {
      dropZone.addEventListener("click", () => refs.fileInput.click());
      dropZone.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          refs.fileInput.click();
        }
      });
      ["dragenter", "dragover"].forEach(
        (name) => dropZone.addEventListener(name, (event) => {
          event.preventDefault();
          dropZone.classList.add("dragging");
        })
      );
      ["dragleave", "drop"].forEach(
        (name) => dropZone.addEventListener(name, (event) => {
          event.preventDefault();
          dropZone.classList.remove("dragging");
        })
      );
      dropZone.addEventListener("drop", (event) => {
        const file = event.dataTransfer && event.dataTransfer.files && event.dataTransfer.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = () => {
          refs.csvInput.value = String(reader.result || "");
          run({ reveal: true });
        };
        reader.readAsText(file);
      });
    }
    refs.runButton.addEventListener("click", () => run({ reveal: true }));
    refs.sampleButton.addEventListener("click", () => {
      refs.csvInput.value = SAMPLE_TRADE_LOG;
      refs.fileInput.value = "";
      run({ reveal: true });
    });
    refs.clearButton.addEventListener("click", () => {
      refs.csvInput.value = "";
      refs.fileInput.value = "";
      refs.report.classList.remove("visible");
      refs.status.className = "status";
      refs.status.textContent = "";
      if (reshuffleButton) reshuffleButton.disabled = true;
    });
    let lastData = null;
    let lastContext = null;
    function run(options = {}) {
      refs.status.className = "status";
      refs.report.classList.remove("visible");
      try {
        const log = buildTradeLog(refs.csvInput.value);
        const metrics = computeMetrics(log);
        const paths = Math.min(Math.max(Number(refs.mcPathsInput.value) || 1e3, 10), 5e3);
        const blockSize = Math.min(Math.max(Number(refs.mcBlockInput.value) || 1, 1), log.trades.length);
        const seed = Number(refs.mcSeedInput.value) || hashSeed(log.trades.map((trade) => trade.pnl));
        const monteCarlo = runMonteCarlo(metrics.returns, { paths, blockSize, seed });
        const propConfig = readPropConfig(refs);
        const strategyBaseline = Math.max(1, Number(document.getElementById("strategy-baseline")?.value) || 1e5);
        const propFirm = runPropFirmSimulation(log.trades, propConfig, { runs: 2e3, seed, strategyBaseline });
        lastData = {
          log: {
            count: log.trades.length,
            ignored: log.ignored,
            detected: log.detected,
            derivedPnl: log.derivedPnl,
            hasDates: log.hasDates
          },
          metrics,
          monteCarlo,
          propFirm
        };
        lastContext = { returns: metrics.returns, trades: log.trades, propConfig };
        renderReport(refs, lastData);
        const platforms = ["tradingview", "ninjatrader", "multicharts", "metatrader", "tradestation"];
        const platform = (log.detected || []).find((d) => platforms.includes(d));
        refs.status.textContent = `Backtest complete \u2014 ${log.trades.length} trades analyzed${log.ignored ? `, ${log.ignored} rows skipped` : ""}${platform ? `. Detected: ${platform[0].toUpperCase()}${platform.slice(1)}` : ""}.`;
        if (reshuffleButton) reshuffleButton.disabled = false;
        if (options.reveal) {
          requestAnimationFrame(() => refs.report.scrollIntoView({ behavior: "smooth", block: "start" }));
        }
      } catch (error) {
        refs.status.className = "status error";
        refs.status.textContent = error instanceof Error ? error.message : String(error);
        if (reshuffleButton) reshuffleButton.disabled = true;
      }
    }
    function reshuffle() {
      if (!lastData || !lastContext) return;
      refs.status.className = "status";
      try {
        const seed = Math.floor(Math.random() * 1e9);
        const paths = Math.min(Math.max(Number(refs.mcPathsInput.value) || 1e3, 10), 5e3);
        const blockSize = Math.min(Math.max(Number(refs.mcBlockInput.value) || 1, 1), lastContext.returns.length);
        const monteCarlo = runMonteCarlo(lastContext.returns, { paths, blockSize, seed });
        const strategyBaseline = Math.max(1, Number(document.getElementById("strategy-baseline")?.value) || 1e5);
        const propFirm = runPropFirmSimulation(lastContext.trades, lastContext.propConfig, { runs: 2e3, seed, strategyBaseline });
        lastData = { ...lastData, monteCarlo, propFirm };
        renderReport(refs, lastData);
        refs.mcSeedInput.value = String(seed);
        refs.status.textContent = `Reshuffled \u2014 seed ${seed}. ${lastContext.returns.length} trades, ${paths} paths.`;
      } catch (error) {
        refs.status.className = "status error";
        refs.status.textContent = error instanceof Error ? error.message : String(error);
      }
    }
    if (reshuffleButton) reshuffleButton.addEventListener("click", reshuffle);
    refs.csvInput.value = SAMPLE_TRADE_LOG;
    run();
  }
  window.quantpadBacktesterInit = init;
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
