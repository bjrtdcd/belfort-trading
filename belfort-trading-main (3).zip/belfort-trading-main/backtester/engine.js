var BelfortEngine = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // backtester-src/engine.ts
  var engine_exports = {};
  __export(engine_exports, {
    PROP_FIRM_PRESETS: () => PROP_FIRM_PRESETS,
    REGIME_COLORS: () => REGIME_COLORS,
    REGIME_ORDER: () => REGIME_ORDER,
    SAMPLE_TRADE_LOG: () => SAMPLE_TRADE_LOG,
    attributeRegimes: () => attributeRegimes,
    autoBlockSize: () => autoBlockSize,
    autocorrelation: () => autocorrelation,
    buildOverfitReport: () => buildOverfitReport,
    buildTradeLog: () => buildTradeLog,
    computeMetrics: () => computeMetrics,
    computeRegimeStats: () => computeRegimeStats,
    defaultPropFirmConfig: () => defaultPropFirmConfig,
    deflatedSharpeRatio: () => deflatedSharpeRatio,
    detectRegimes: () => detectRegimes,
    hashSeed: () => hashSeed,
    mulberry32: () => mulberry32,
    parseCsv: () => parseCsv,
    probabilityOfBacktestOverfitting: () => probabilityOfBacktestOverfitting,
    purgedKFold: () => purgedKFold,
    regimeEquityBands: () => regimeEquityBands,
    runMonteCarlo: () => runMonteCarlo,
    runPropFirmSimulation: () => runPropFirmSimulation,
    runRegimeAwareMC: () => runRegimeAwareMC,
    runStationaryBootstrap: () => runStationaryBootstrap,
    walkForward: () => walkForward
  });

  // backtester-src/csv.ts
  var normalize = (value) => String(value || "").trim().toLowerCase().replace(/[%$£€]/g, "").replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");
  var RESULT_ALIASES = [
    "pnl",
    "profit",
    "profit_loss",
    "profitloss",
    "net_pnl",
    "net_profit",
    "net_return",
    "return",
    "returns",
    "ret",
    "r",
    "r_multiple",
    "r_multiple_points",
    "profit_pct",
    "return_pct",
    "pnl_pct",
    "net",
    "realized_pnl",
    "pl",
    "gain",
    "gains"
  ];
  var DATE_ALIASES = [
    "date",
    "datetime",
    "date_time",
    "date_time_1",
    "timestamp",
    "time",
    "trade_date",
    "entry_date",
    "entry_time",
    "exit_date",
    "exit_time",
    "open_time",
    "close_time",
    "opened_at",
    "closed_at",
    "open_date",
    "close_date"
  ];
  var ENTRY_ALIASES = ["entry", "entry_price", "avg_entry_price", "open", "open_price", "entry_price_1", "price_1", "buy_price", "entry_fill_price"];
  var EXIT_ALIASES = ["exit", "exit_price", "avg_exit_price", "close", "close_price", "exit_price_1", "price_2", "sell_price", "exit_fill_price"];
  var SIZE_ALIASES = ["size", "quantity", "qty", "shares", "contracts", "units", "lots", "volume", "position"];
  var DIRECTION_ALIASES = ["direction", "side", "position", "type", "action", "signal", "b_s", "long_short"];
  var FEE_ALIASES = ["fee", "fees", "commission", "commissions", "comm", "cost", "slippage", "swap"];
  var QUANTITY_RE = /^([0-9.]+)(m|k|klote|lot)?$/i;
  var SHORT_RE = /^(short|sell|s|bajista|put)$/i;
  var LONG_RE = /^(long|buy|l|call)$/i;
  function parseNumber(raw) {
    const value = String(raw ?? "").trim();
    if (!value) return NaN;
    const negative = /^\(.*\)$/.test(value);
    let cleaned = value.replace(/[()$£€,%\s]/g, "");
    cleaned = cleaned.replace(/(\d)[,.](\d)/g, "$1.$2");
    const parsed = Number(cleaned);
    if (Number.isNaN(parsed)) {
      const match = value.replace(/[()$£€,\s]/g, "").match(/^[+-]?(\d+)$/);
      return match ? negative ? -Number(match[1]) : Number(match[1]) : NaN;
    }
    return negative ? -parsed : parsed;
  }
  function parseSize(raw) {
    const value = String(raw ?? "").trim();
    if (!value) return null;
    const match = value.match(QUANTITY_RE);
    if (!match) return null;
    let number = parseFloat(match[1]);
    if (Number.isNaN(number)) return null;
    const suffix = (match[2] || "").toLowerCase();
    if (suffix === "k") number *= 1e3;
    else if (suffix === "m") number *= 1e6;
    return number;
  }
  function parseDate(raw) {
    const s = String(raw ?? "").trim();
    if (!s) return null;
    const base = new Date(s);
    if (!Number.isNaN(base.getTime())) return base.toISOString();
    let m = s.match(/^(\d{4})[.\/-](\d{1,2})[.\/-](\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?)?$/i);
    if (m) {
      let h = m[4] ? +m[4] : 0;
      if (m[7]) h = h % 12 + (/PM/i.test(m[7]) ? 12 : 0);
      const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], h, m[5] ? +m[5] : 0, m[6] ? +m[6] : 0));
      if (!Number.isNaN(d.getTime())) return d.toISOString();
    }
    m = s.match(/^(\d{1,2})[\/.](\d{1,2})[\/.](\d{2,4})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?)?$/i);
    if (m) {
      let yr = +m[3];
      if (yr < 100) yr += 2e3;
      let mo = +m[1], da = +m[2];
      if (mo > 12) {
        const t = mo;
        mo = da;
        da = t;
      }
      let h = m[4] ? +m[4] : 0;
      if (m[7]) h = h % 12 + (/PM/i.test(m[7]) ? 12 : 0);
      const d = new Date(Date.UTC(yr, mo - 1, da, h, m[5] ? +m[5] : 0, m[6] ? +m[6] : 0));
      if (!Number.isNaN(d.getTime())) return d.toISOString();
    }
    return null;
  }
  function detectPlatform(headers) {
    if (headers.includes("instrument")) return "ninjatrader";
    if (headers.includes("swap") || headers.includes("volume") && headers.includes("commission")) return "metatrader";
    if (headers.includes("contracts") && (headers.includes("signal") || headers.includes("profit_loss") || headers.includes("profitloss"))) return "multicharts";
    if (headers.includes("type") && headers.includes("price") && headers.includes("date_time")) return "tradingview";
    if (headers.includes("order_id") || headers.includes("ticket")) return "metatrader";
    return null;
  }
  function parseCsv(text) {
    const rows = [];
    let row = [];
    let cell = "";
    let quoted = false;
    for (let i = 0; i < text.length; i += 1) {
      const char = text[i];
      const next = text[i + 1];
      if (char === '"' && quoted && next === '"') {
        cell += '"';
        i += 1;
        continue;
      }
      if (char === '"') {
        quoted = !quoted;
        continue;
      }
      if (char === "," && !quoted) {
        row.push(cell);
        cell = "";
        continue;
      }
      if ((char === "\n" || char === "\r") && !quoted) {
        if (char === "\r" && next === "\n") i += 1;
        row.push(cell);
        if (row.some((v) => v.trim())) rows.push(row);
        row = [];
        cell = "";
        continue;
      }
      cell += char;
    }
    if (cell.length || row.length) {
      row.push(cell);
      if (row.some((v) => v.trim())) rows.push(row);
    }
    return rows;
  }
  function findIndex(headers, aliases) {
    for (const alias of aliases) {
      const index = headers.indexOf(alias);
      if (index >= 0) return index;
    }
    return -1;
  }
  function isTradingViewFormat(headers) {
    return headers.includes("type") && headers.includes("price") && headers.includes("date_time");
  }
  function parseTradingViewTradeList(rows) {
    const headers = rows[0].map(normalize);
    const typeIdx = headers.indexOf("type");
    const dateIdx = headers.indexOf("date_time");
    const priceIdx = headers.indexOf("price");
    const qtyIdx = headers.indexOf("qty") >= 0 ? headers.indexOf("qty") : headers.indexOf("quantity");
    const pnlIdx = headers.indexOf("p_l");
    const tradeNumIdx = headers.indexOf("trade");
    if (typeIdx < 0 || priceIdx < 0 || dateIdx < 0) return null;
    const groups = /* @__PURE__ */ new Map();
    for (let r = 1; r < rows.length; r += 1) {
      const row = rows[r];
      if (!row.some((v) => v.trim())) continue;
      const key = tradeNumIdx >= 0 && row[tradeNumIdx] ? row[tradeNumIdx].trim() : String(r);
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(row);
    }
    const trades = [];
    groups.forEach((group) => {
      let entry = group.find((row) => /entry/i.test(row[typeIdx] || ""));
      let exit = group.find((row) => /exit/i.test(row[typeIdx] || ""));
      if (!entry && !exit) {
        entry = group[0];
        exit = group[group.length - 1];
      }
      if (!entry || !exit) return;
      const typeStr = (entry[typeIdx] || "").toLowerCase();
      const direction = /short/.test(typeStr) ? "short" : /long/.test(typeStr) ? "long" : "unknown";
      const entryPrice = parseNumber(entry[priceIdx]);
      const exitPrice = parseNumber(exit[priceIdx]);
      const qty = qtyIdx >= 0 ? parseSize((entry[qtyIdx] || exit[qtyIdx] || "").trim()) : null;
      const size = qty ?? 1;
      let pnl = pnlIdx >= 0 ? parseNumber(exit[pnlIdx] || "") : NaN;
      if (!Number.isFinite(pnl) && Number.isFinite(entryPrice) && Number.isFinite(exitPrice)) {
        const sign = direction === "short" ? -1 : 1;
        pnl = (exitPrice - entryPrice) * sign * size;
      }
      if (!Number.isFinite(pnl)) return;
      const rawDate = (exit[dateIdx] || "").trim();
      const date = parseDate(rawDate);
      trades.push({
        row: 0,
        date,
        direction,
        entry: Number.isFinite(entryPrice) ? entryPrice : null,
        exit: Number.isFinite(exitPrice) ? exitPrice : null,
        size: qtyIdx >= 0 ? qty : null,
        fee: 0,
        pnl
      });
    });
    trades.sort((a, b) => {
      if (a.date && b.date) return new Date(a.date).getTime() - new Date(b.date).getTime();
      return 0;
    });
    trades.forEach((trade, index) => {
      trade.row = index + 2;
    });
    return trades;
  }
  function buildTradeLog(text) {
    const rows = parseCsv(text);
    if (rows.length < 2) {
      throw new Error("Add a header row and at least two trade rows to run a backtest.");
    }
    const headers = rows[0].map(normalize);
    if (isTradingViewFormat(headers)) {
      const tvTrades = parseTradingViewTradeList(rows);
      if (tvTrades && tvTrades.length >= 2) {
        const platform2 = detectPlatform(headers) || "tradingview";
        return {
          trades: tvTrades,
          ignored: 0,
          detected: [platform2, "date", "entry", "exit", "size", "direction"],
          derivedPnl: false,
          hasDates: tvTrades.some((trade) => trade.date !== null)
        };
      }
      throw new Error(
        "TradingView trade list detected but fewer than two complete trades were found. Each trade needs both an Entry and an Exit fill."
      );
    }
    const resultIndex = findIndex(headers, RESULT_ALIASES);
    const dateIndex = findIndex(headers, DATE_ALIASES);
    const entryIndex = findIndex(headers, ENTRY_ALIASES);
    const exitIndex = findIndex(headers, EXIT_ALIASES);
    const sizeIndex = findIndex(headers, SIZE_ALIASES);
    const directionIndex = findIndex(headers, DIRECTION_ALIASES);
    const feeIndex = findIndex(headers, FEE_ALIASES);
    if (resultIndex < 0 && (entryIndex < 0 || exitIndex < 0)) {
      throw new Error(
        "No usable result column. Include pnl/profit/return, or entry and exit price columns."
      );
    }
    const trades = [];
    let ignored = 0;
    let derived = false;
    const detected = [];
    const platform = detectPlatform(headers);
    if (platform) detected.push(platform);
    if (resultIndex >= 0) detected.push(headers[resultIndex]);
    if (dateIndex >= 0) detected.push("date");
    if (entryIndex >= 0) detected.push("entry");
    if (exitIndex >= 0) detected.push("exit");
    if (sizeIndex >= 0) detected.push("size");
    if (directionIndex >= 0) detected.push("direction");
    if (feeIndex >= 0) detected.push("fee");
    for (let r = 1; r < rows.length; r += 1) {
      const values = rows[r];
      const read = (index) => index >= 0 && index < values.length ? values[index] : "";
      let pnl = NaN;
      if (resultIndex >= 0) {
        pnl = parseNumber(read(resultIndex));
      }
      if (!Number.isFinite(pnl) && entryIndex >= 0 && exitIndex >= 0) {
        const entry2 = parseNumber(read(entryIndex));
        const exit2 = parseNumber(read(exitIndex));
        const size2 = sizeIndex >= 0 ? parseSize(read(sizeIndex)) : 1;
        if (Number.isFinite(entry2) && Number.isFinite(exit2)) {
          const directionRaw2 = read(directionIndex);
          const direction2 = SHORT_RE.test(directionRaw2) ? -1 : 1;
          pnl = (exit2 - entry2) * direction2 * (size2 ?? 1);
          derived = true;
        }
      }
      if (!Number.isFinite(pnl)) {
        ignored += 1;
        continue;
      }
      const rawDate = read(dateIndex).trim();
      const date = parseDate(rawDate);
      const fee = feeIndex >= 0 ? parseNumber(read(feeIndex)) : 0;
      const directionRaw = read(directionIndex);
      let direction = "unknown";
      if (directionRaw) {
        if (LONG_RE.test(directionRaw)) direction = "long";
        else if (SHORT_RE.test(directionRaw)) direction = "short";
      }
      const entry = entryIndex >= 0 ? parseNumber(read(entryIndex)) : null;
      const exit = exitIndex >= 0 ? parseNumber(read(exitIndex)) : null;
      const size = sizeIndex >= 0 ? parseSize(read(sizeIndex)) : null;
      trades.push({
        row: r + 1,
        date,
        direction,
        entry: Number.isFinite(entry) ? entry : null,
        exit: Number.isFinite(exit) ? exit : null,
        size,
        fee: Number.isFinite(fee) ? fee : 0,
        pnl: pnl - (Number.isFinite(fee) ? fee : 0)
      });
    }
    if (trades.length < 2) {
      throw new Error("At least two valid trade rows are required after parsing.");
    }
    return {
      trades,
      ignored,
      detected,
      derivedPnl: derived,
      hasDates: trades.some((trade) => trade.date !== null)
    };
  }

  // backtester-src/metrics.ts
  function percentileSorted(sorted, fraction) {
    if (sorted.length === 0) return 0;
    const idx = Math.min(sorted.length - 1, Math.floor(sorted.length * fraction));
    return sorted[idx];
  }
  function mean(arr) {
    if (arr.length === 0) return 0;
    let s = 0;
    for (let i = 0; i < arr.length; i += 1) s += arr[i];
    return s / arr.length;
  }
  function variance(arr, m) {
    if (arr.length < 2) return 0;
    const mu = m == null ? mean(arr) : m;
    let s = 0;
    for (let i = 0; i < arr.length; i += 1) {
      const d = arr[i] - mu;
      s += d * d;
    }
    return s / arr.length;
  }
  function stddev(arr, m) {
    return Math.sqrt(variance(arr, m));
  }
  function sampleSkew(arr, m) {
    if (arr.length < 3) return 0;
    const sd = stddev(arr, m);
    if (sd === 0) return 0;
    let s = 0;
    for (let i = 0; i < arr.length; i += 1) {
      const d = (arr[i] - m) / sd;
      s += d * d * d;
    }
    const n = arr.length;
    const g1 = Math.sqrt(n * (n - 1)) / (n - 2) * (s / n);
    return Number.isFinite(g1) ? g1 : 0;
  }
  function sampleKurtosis(arr, m) {
    if (arr.length < 4) return 0;
    const sd = stddev(arr, m);
    if (sd === 0) return 0;
    let s = 0;
    for (let i = 0; i < arr.length; i += 1) {
      const d = (arr[i] - m) / sd;
      s += d * d * d * d;
    }
    const n = arr.length;
    const m4 = s / n;
    const g2 = (n - 1) / ((n - 2) * (n - 3)) * ((n + 1) * m4 - 3 * (n - 1));
    return Number.isFinite(g2) ? g2 : 0;
  }
  function computeMetrics(log, opts = {}) {
    const trades = log.trades;
    const returns = trades.map((trade) => trade.pnl);
    const wins = returns.filter((value) => value > 0);
    const losses = returns.filter((value) => value < 0);
    const count = returns.length;
    const winCount = wins.length;
    const lossCount = losses.length;
    const winRate = count > 0 ? winCount / count : 0;
    const grossWins = wins.reduce((total, value) => total + value, 0);
    const grossLosses = Math.abs(losses.reduce((total, value) => total + value, 0));
    const netPnl = returns.reduce((total, value) => total + value, 0);
    const expectancy = count > 0 ? netPnl / count : 0;
    let equity = 0;
    const equitySeries = [];
    const drawdownSeries = [];
    const drawdownPctSeries = [];
    const tradeDates = [];
    const monthlyMap = /* @__PURE__ */ new Map();
    let peak = 0;
    let maxDrawdown = 0;
    let currentDdDuration = 0;
    let maxDrawdownDuration = 0;
    let longestDdStartIdx = -1;
    let longestDdEndIdx = -1;
    let ulcerSqSum = 0;
    for (let i = 0; i < returns.length; i += 1) {
      const value = returns[i];
      equity += value;
      equitySeries.push(equity);
      const prevPeak = peak;
      peak = Math.max(peak, equity);
      const drawdown = equity - peak;
      drawdownSeries.push(drawdown);
      const ddPct = peak > 0 ? drawdown / peak * 100 : 0;
      drawdownPctSeries.push(ddPct);
      ulcerSqSum += ddPct * ddPct;
      maxDrawdown = Math.min(maxDrawdown, drawdown);
      if (drawdown < 0) {
        if (prevPeak === peak) {
          currentDdDuration += 1;
        } else {
          currentDdDuration = 1;
        }
        if (currentDdDuration > maxDrawdownDuration) {
          maxDrawdownDuration = currentDdDuration;
          longestDdEndIdx = i;
          longestDdStartIdx = i - currentDdDuration + 1;
        }
      } else {
        currentDdDuration = 0;
      }
      const trade = trades[i];
      const iso = trade.date ?? null;
      tradeDates.push(iso);
      if (iso) {
        const parsed = new Date(iso);
        if (!Number.isNaN(parsed.getTime())) {
          const key = `${parsed.getFullYear()}-${parsed.getMonth()}`;
          monthlyMap.set(key, (monthlyMap.get(key) || 0) + value);
        }
      }
    }
    const monthlyReturns = Array.from(monthlyMap.entries()).map(([key, pnl]) => {
      const [year, month] = key.split("-").map(Number);
      return { year, month, pnl };
    }).sort((a, b) => a.year !== b.year ? a.year - b.year : a.month - b.month);
    const tradeDetails = trades.map((trade, i) => ({
      index: i + 1,
      date: trade.date,
      direction: trade.direction,
      entry: trade.entry,
      exit: trade.exit,
      size: trade.size,
      pnl: returns[i],
      equity: equitySeries[i],
      drawdown: drawdownSeries[i]
    }));
    let maxConsecutiveWins = 0;
    let maxConsecutiveLosses = 0;
    let currentWins = 0;
    let currentLosses = 0;
    for (const value of returns) {
      if (value > 0) {
        currentWins += 1;
        currentLosses = 0;
        maxConsecutiveWins = Math.max(maxConsecutiveWins, currentWins);
      } else if (value < 0) {
        currentLosses += 1;
        currentWins = 0;
        maxConsecutiveLosses = Math.max(maxConsecutiveLosses, currentLosses);
      }
    }
    const mean3 = expectancy;
    const variance3 = count > 0 ? returns.reduce((total, value) => total + (value - mean3) ** 2, 0) / count : 0;
    const standardDeviation = Math.sqrt(variance3);
    const dated = trades.filter((trade) => trade.date !== null).sort(
      (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
    );
    let avgHoldMs = null;
    if (dated.length > 1) {
      let totalHold = 0;
      let pairs = 0;
      for (let i = 1; i < dated.length; i += 1) {
        const current = new Date(dated[i].date).getTime();
        const previous = new Date(dated[i - 1].date).getTime();
        if (Number.isFinite(current) && Number.isFinite(previous)) {
          totalHold += current - previous;
          pairs += 1;
        }
      }
      if (pairs > 0) avgHoldMs = totalHold / pairs;
    }
    const bestTrade = returns.length > 0 ? Math.max(...returns) : 0;
    const worstTrade = returns.length > 0 ? Math.min(...returns) : 0;
    const positivePathsPct = winRate;
    const sharpeLike = standardDeviation > 0 ? mean3 / standardDeviation * Math.sqrt(Math.max(count, 1)) : 0;
    const rExpectancy = standardDeviation > 0 ? expectancy / standardDeviation : 0;
    const score = gradeScore({
      expectancy,
      profitFactor: grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? 3 : 0,
      winRate,
      maxDrawdownAbs: Math.abs(maxDrawdown),
      grossWins,
      count,
      positivePathsPct,
      sharpeLike,
      rExpectancy,
      maxConsecutiveLosses
    });
    const MS_PER_YEAR = 365.25 * 24 * 3600 * 1e3;
    let tradesPerYear = 252;
    if (avgHoldMs && avgHoldMs > 0) {
      tradesPerYear = Math.min(Math.max(MS_PER_YEAR / avgHoldMs, 1), 25e4);
    }
    const annualizedReturn = expectancy * tradesPerYear;
    const annualizedVolatility = standardDeviation * Math.sqrt(tradesPerYear);
    const sharpe = standardDeviation > 0 ? expectancy / standardDeviation * Math.sqrt(tradesPerYear) : 0;
    const downsideReturns = returns.filter((r) => r < 0);
    const downsideDeviation = downsideReturns.length > 0 ? Math.sqrt(downsideReturns.reduce((s, r) => s + r * r, 0) / Math.max(count, 1)) : 0;
    const sortino = downsideDeviation > 0 ? expectancy / downsideDeviation * Math.sqrt(tradesPerYear) : 0;
    const maxDrawdownAbs = Math.abs(maxDrawdown);
    const calmar = maxDrawdownAbs > 0 ? annualizedReturn / maxDrawdownAbs : 0;
    const omega = grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? Infinity : 0;
    const recoveryFactor = maxDrawdownAbs > 0 ? netPnl / maxDrawdownAbs : 0;
    const gainPain = grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? Infinity : 0;
    const ulcerIndex = count > 0 ? Math.sqrt(ulcerSqSum / count) : 0;
    const sortedReturns = returns.slice().sort((a, b) => a - b);
    const p5 = percentileSorted(sortedReturns, 0.05);
    const p95 = percentileSorted(sortedReturns, 0.95);
    const tailRatio = p5 < 0 ? Math.abs(p95) / Math.abs(p5) : 0;
    const valueAtRisk95 = Math.abs(p5);
    const tailCount = Math.max(1, Math.floor(count * 0.05));
    let cvarSum = 0;
    for (let i = 0; i < tailCount; i += 1) cvarSum += sortedReturns[i] || 0;
    const cvar95 = Math.abs(cvarSum / tailCount);
    let maxDrawdownDurationDays = null;
    if (longestDdStartIdx >= 0 && longestDdEndIdx >= longestDdStartIdx) {
      const startIso = tradeDates[longestDdStartIdx];
      const endIso = tradeDates[longestDdEndIdx];
      if (startIso && endIso) {
        const t0 = new Date(startIso).getTime();
        const t1 = new Date(endIso).getTime();
        if (Number.isFinite(t0) && Number.isFinite(t1) && t1 >= t0) {
          maxDrawdownDurationDays = (t1 - t0) / (24 * 3600 * 1e3);
        }
      }
    }
    const avgWin = winCount > 0 ? grossWins / winCount : 0;
    const avgLoss = lossCount > 0 ? -(grossLosses / lossCount) : 0;
    const winLossRatio = avgLoss < 0 ? avgWin / Math.abs(avgLoss) : 0;
    const skewness = sampleSkew(returns, mean3);
    const kurtosis = sampleKurtosis(returns, mean3) + 3;
    let benchmark = null;
    let beta = null;
    let alpha = null;
    let informationRatio = null;
    if (opts.benchmark && opts.benchmark.returns && opts.benchmark.returns.length > 1) {
      benchmark = opts.benchmark.name;
      const br = opts.benchmark.returns;
      const n = Math.min(returns.length, br.length);
      if (n > 2) {
        let bmSum = 0;
        for (let i = 0; i < n; i += 1) bmSum += br[i];
        const bmMean = bmSum / n;
        let bmVarSum = 0;
        for (let i = 0; i < n; i += 1) bmVarSum += (br[i] - bmMean) ** 2;
        const bmVar = bmVarSum / n;
        if (bmVar > 0) {
          let cov = 0;
          for (let i = 0; i < n; i += 1) cov += (returns[i] - expectancy) * (br[i] - bmMean);
          cov /= n;
          beta = cov / bmVar;
          alpha = expectancy - beta * bmMean;
          const active = [];
          for (let i = 0; i < n; i += 1) active.push(returns[i] - br[i]);
          let activeSum = 0;
          for (let i = 0; i < active.length; i += 1) activeSum += active[i];
          const activeMean = activeSum / active.length;
          let activeVarSum = 0;
          for (let i = 0; i < active.length; i += 1) activeVarSum += (active[i] - activeMean) ** 2;
          const activeStd = Math.sqrt(activeVarSum / Math.max(active.length, 1));
          informationRatio = activeStd > 0 ? activeMean / activeStd * Math.sqrt(tradesPerYear) : 0;
        }
      }
    }
    let turnover = null;
    const sizedTrades = trades.filter((t) => t.entry != null && t.size != null);
    if (sizedTrades.length > 0 && peak > 0) {
      let notional = 0;
      for (const t of sizedTrades) {
        const sz = Math.abs(t.size);
        const px = Math.abs(t.entry);
        notional += sz * px;
      }
      turnover = notional / peak;
    }
    return {
      count,
      winCount,
      lossCount,
      winRate,
      grossWins,
      grossLosses,
      profitFactor: grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? Infinity : 0,
      netPnl,
      expectancy,
      rExpectancy: standardDeviation > 0 ? expectancy / standardDeviation : 0,
      standardDeviation,
      sharpeLike: standardDeviation > 0 ? mean3 / standardDeviation * Math.sqrt(Math.max(count, 1)) : 0,
      maxDrawdown: Math.abs(maxDrawdown),
      maxDrawdownPct: peak > 0 ? Math.abs(maxDrawdown) / peak : 0,
      maxConsecutiveWins,
      maxConsecutiveLosses,
      avgHoldMs,
      bestTrade,
      worstTrade,
      equity: equitySeries,
      drawdownSeries,
      returns,
      tradeDates,
      monthlyReturns,
      tradeDetails,
      grade: score.grade,
      gradeLabel: score.label,
      gradeScore: score.score,
      gradeBreakdown: score.breakdown,
      gradeAdvice: score.advice,
      tradesPerYear,
      annualizedReturn,
      annualizedVolatility,
      sharpe,
      sortino,
      calmar,
      omega,
      tailRatio,
      valueAtRisk95,
      cvar95,
      maxDrawdownDuration,
      maxDrawdownDurationDays,
      recoveryFactor,
      ulcerIndex,
      gainPain,
      avgWin,
      avgLoss,
      winLossRatio,
      skewness,
      kurtosis,
      benchmark,
      beta,
      alpha,
      informationRatio,
      turnover
    };
  }
  function gradeScore(metrics) {
    const subs = [];
    let prof = 0;
    if (metrics.expectancy > 0) prof += 10;
    if (metrics.profitFactor >= 2) prof += 15;
    else if (metrics.profitFactor >= 1.5) prof += 10;
    else if (metrics.profitFactor >= 1.15) prof += 4;
    subs.push({ category: "Profitability", score: prof, max: 25 });
    let cons = 0;
    if (metrics.winRate >= 0.55) cons += 10;
    else if (metrics.winRate >= 0.45) cons += 6;
    else if (metrics.winRate >= 0.35) cons += 3;
    if (metrics.positivePathsPct >= 0.7) cons += 10;
    else if (metrics.positivePathsPct >= 0.55) cons += 6;
    else if (metrics.positivePathsPct >= 0.4) cons += 3;
    subs.push({ category: "Consistency", score: cons, max: 20 });
    let risk = 0;
    if (metrics.grossWins > 0) {
      if (metrics.maxDrawdownAbs <= metrics.grossWins * 0.25) risk += 15;
      else if (metrics.maxDrawdownAbs <= metrics.grossWins * 0.5) risk += 10;
      else if (metrics.maxDrawdownAbs <= metrics.grossWins) risk += 4;
    }
    if (metrics.maxConsecutiveLosses <= 3) risk += 10;
    else if (metrics.maxConsecutiveLosses <= 5) risk += 6;
    else if (metrics.maxConsecutiveLosses <= 8) risk += 2;
    subs.push({ category: "Risk control", score: risk, max: 25 });
    let rob = 0;
    if (metrics.sharpeLike >= 2) rob += 10;
    else if (metrics.sharpeLike >= 1.2) rob += 7;
    else if (metrics.sharpeLike >= 0.6) rob += 3;
    if (metrics.rExpectancy >= 0.3) rob += 10;
    else if (metrics.rExpectancy >= 0.15) rob += 6;
    else if (metrics.rExpectancy >= 0.05) rob += 2;
    subs.push({ category: "Robustness", score: rob, max: 20 });
    let samp = 0;
    if (metrics.count >= 200) samp += 10;
    else if (metrics.count >= 100) samp += 8;
    else if (metrics.count >= 50) samp += 5;
    else if (metrics.count >= 20) samp += 3;
    else if (metrics.count >= 5) samp += 1;
    subs.push({ category: "Sample size", score: samp, max: 10 });
    const score = subs.reduce((a, s) => a + s.score, 0);
    const grade = score >= 88 ? "A" : score >= 74 ? "B" : score >= 58 ? "C" : score >= 40 ? "D" : "F";
    const labels = {
      A: "Strong evidence",
      B: "Promising evidence",
      C: "Mixed evidence",
      D: "Weak evidence",
      F: "Needs work"
    };
    const advice = [];
    if (prof < 15) advice.push("Improve profitability: filter trades with weak edge or tighten stops to lift profit factor above 1.5.");
    if (cons < 12) advice.push("Raise consistency: review losing streaks and entry timing (see autocorrelation) to push the win rate above 50%.");
    if (risk < 15) advice.push("Tighten risk control: reduce position size or add a hard stop to cap drawdown and consecutive losses.");
    if (rob < 12) advice.push("Strengthen robustness: the risk-adjusted return is thin \u2014 favor higher-expectancy setups to improve the Sharpe-like ratio.");
    if (samp < 5) advice.push("Gather more trades: the sample is small, so every metric here carries low confidence.");
    return { score, grade, label: labels[grade], breakdown: subs, advice };
  }

  // backtester-src/rng.ts
  function mulberry32(seed) {
    let state = seed >>> 0;
    return () => {
      state = state + 1831565813 >>> 0;
      let value = state;
      value = Math.imul(value ^ value >>> 15, value | 1);
      value ^= value + Math.imul(value ^ value >>> 7, value | 61);
      return ((value ^ value >>> 14) >>> 0) / 4294967296;
    };
  }
  function hashSeed(values) {
    let seed = 2166136261;
    for (let i = 0; i < values.length; i += 1) {
      const bits = Math.round(values[i] * 100) | 0;
      seed = (seed ^ bits) * 16777619 >>> 0;
      seed = (seed ^ i * 2654435761) >>> 0;
    }
    return seed >>> 0;
  }
  function shuffle(array, random) {
    const copy = array.slice();
    for (let i = copy.length - 1; i > 0; i -= 1) {
      const j = Math.floor(random() * (i + 1));
      const swap = copy[i];
      copy[i] = copy[j];
      copy[j] = swap;
    }
    return copy;
  }

  // backtester-src/montecarlo.ts
  function runMonteCarlo(returns, config, startingBalance = 0) {
    if (returns.length < 2) {
      throw new Error("At least two trades are required for Monte Carlo.");
    }
    const paths = Math.min(Math.max(config.paths, 10), 5e3);
    const blockSize = Math.min(Math.max(config.blockSize, 1), Math.max(returns.length, 1));
    const random = mulberry32(config.seed);
    const numberOfBlocks = Math.ceil(returns.length / blockSize);
    const pathEquity = [];
    const terminals = [];
    const drawdowns = [];
    for (let path = 0; path < paths; path += 1) {
      const blocks = [];
      for (let block = 0; block < numberOfBlocks; block += 1) {
        const start = Math.floor(random() * returns.length);
        for (let offset = 0; offset < blockSize; offset += 1) {
          blocks.push(returns[(start + offset) % returns.length]);
        }
      }
      const sampled = blocks.slice(0, returns.length);
      let equity = startingBalance;
      const series = [];
      let peak = startingBalance;
      let maxDrawdown = 0;
      for (const value of sampled) {
        equity += value;
        series.push(equity);
        peak = Math.max(peak, equity);
        maxDrawdown = Math.max(maxDrawdown, peak - equity);
      }
      pathEquity.push(series);
      terminals.push(equity);
      drawdowns.push(maxDrawdown);
    }
    const sorted = terminals.slice().sort((a, b) => a - b);
    const sortedDrawdowns = drawdowns.slice().sort((a, b) => a - b);
    const positivePaths = terminals.filter((value) => value > startingBalance).length;
    return {
      config,
      terminals,
      paths: pathEquity,
      p5: percentile(sorted, 0.05),
      p50: percentile(sorted, 0.5),
      p95: percentile(sorted, 0.95),
      positivePaths,
      positivePathsPct: positivePaths / paths,
      riskOfRuinPct: percentile(sorted, 0.05) < startingBalance ? lowTailRisk(terminals, startingBalance) : 0,
      drawdownPercentiles: {
        p50: percentile(sortedDrawdowns, 0.5),
        p95: percentile(sortedDrawdowns, 0.95)
      }
    };
  }
  function percentile(sorted, fraction) {
    if (sorted.length === 0) return 0;
    const index = Math.min(sorted.length - 1, Math.floor(sorted.length * fraction));
    return sorted[index];
  }
  function lowTailRisk(terminals, startingBalance) {
    const loss = terminals.filter((value) => value < startingBalance).length;
    return loss / terminals.length * 100;
  }

  // backtester-src/propfirm.ts
  var PROP_FIRM_PRESETS = [
    {
      name: "FTMO 100k",
      accountSize: 1e5,
      profitTarget: 1e4,
      maxDailyLoss: 5e3,
      maxTotalDrawdown: 1e4,
      evaluationDays: 30,
      payoutPct: 80,
      challengeFee: 549,
      minPayout: 1e3,
      payoutDays: 14,
      trailingDrawdown: false,
      resetFee: 549,
      scaling: 1,
      phases: 1,
      consistencyPct: 50
    },
    {
      name: "FTMO 50k",
      accountSize: 5e4,
      profitTarget: 5e3,
      maxDailyLoss: 2500,
      maxTotalDrawdown: 5e3,
      evaluationDays: 30,
      payoutPct: 80,
      challengeFee: 299,
      minPayout: 500,
      payoutDays: 14,
      trailingDrawdown: false,
      resetFee: 299,
      scaling: 1,
      phases: 1,
      consistencyPct: 50
    },
    {
      name: "Apex 100k",
      accountSize: 1e5,
      profitTarget: 6e3,
      maxDailyLoss: 4500,
      maxTotalDrawdown: 5e3,
      evaluationDays: 30,
      payoutPct: 90,
      challengeFee: 150,
      minPayout: 500,
      payoutDays: 1,
      trailingDrawdown: false,
      resetFee: 150,
      scaling: 1,
      phases: 1,
      consistencyPct: 0
    },
    {
      name: "Topstep 50k",
      accountSize: 5e4,
      profitTarget: 3e3,
      maxDailyLoss: 2e3,
      maxTotalDrawdown: 2e3,
      evaluationDays: 15,
      payoutPct: 100,
      challengeFee: 165,
      minPayout: 500,
      payoutDays: 5,
      trailingDrawdown: true,
      resetFee: 165,
      scaling: 1,
      phases: 1,
      consistencyPct: 50
    },
    {
      name: "E8 100k",
      accountSize: 1e5,
      profitTarget: 8e3,
      maxDailyLoss: 3e3,
      maxTotalDrawdown: 6e3,
      evaluationDays: 30,
      payoutPct: 100,
      challengeFee: 599,
      minPayout: 500,
      payoutDays: 7,
      trailingDrawdown: false,
      resetFee: 599,
      scaling: 2,
      phases: 1,
      consistencyPct: 50
    }
  ];
  function defaultPropFirmConfig() {
    return { ...PROP_FIRM_PRESETS[0] };
  }
  function tradesPerDay(trades) {
    const days = /* @__PURE__ */ new Set();
    for (const trade of trades) {
      if (trade.date) days.add(trade.date.slice(0, 10));
    }
    return Math.max(days.size, 1);
  }
  function runPropFirmSimulation(trades, config, options) {
    const runs = Math.min(Math.max(options.runs, 10), 1e4);
    const random = mulberry32(options.seed);
    const baseline = options.strategyBaseline && options.strategyBaseline > 0 ? options.strategyBaseline : config.accountSize;
    const scale = config.accountSize / baseline;
    const pnl = trades.map((trade) => trade.pnl * scale);
    const actualDays = tradesPerDay(trades);
    const tradesPerDayCount = pnl.length / actualDays;
    const dailyLossLimit = config.maxDailyLoss;
    const totalDrawdownLimit = config.maxTotalDrawdown;
    const target = config.profitTarget;
    let passCount = 0;
    let daysToTargetTotal = 0;
    let daysToTargetCount = 0;
    let profitAtPassTotal = 0;
    let daysPerAttemptTotal = 0;
    const passDaysList = [];
    const failures = {
      "Daily loss breach": 0,
      "Max total drawdown breach": 0,
      "Consistency rule breach": 0,
      "Evaluation period expired": 0
    };
    const consistencyLimit = config.consistencyPct > 0 && config.consistencyPct < 100 ? config.consistencyPct / 100 * config.profitTarget : Infinity;
    const sampleRuns = [];
    let passSamples = 0;
    const failByReason = {};
    const MAX_PASS_SAMPLES = 12;
    const MAX_FAIL_PER_REASON = 4;
    const SAFETY_CAP = config.evaluationDays * Math.max(1, Math.ceil(tradesPerDayCount)) * 50;
    for (let run = 0; run < runs; run += 1) {
      let order = shuffle(pnl, random);
      let cursor = 0;
      let balance = config.accountSize;
      let peak = config.accountSize;
      let trough = config.accountSize;
      let dailyNet = 0;
      let maxDailyProfit = 0;
      let tradesToday = 0;
      let day = 1;
      let result = "fail";
      let failureReason = "Evaluation period expired";
      const runEquity = [config.accountSize];
      for (let iter = 0; iter < SAFETY_CAP; iter += 1) {
        if (cursor >= order.length) {
          order = shuffle(pnl, random);
          cursor = 0;
        }
        if (tradesToday >= tradesPerDayCount && day < config.evaluationDays) {
          day += 1;
          dailyNet = 0;
          tradesToday = 0;
        }
        const pnlThisTrade = order[cursor];
        cursor += 1;
        tradesToday += 1;
        balance += pnlThisTrade;
        dailyNet += pnlThisTrade;
        if (dailyNet > maxDailyProfit) maxDailyProfit = dailyNet;
        runEquity.push(balance);
        peak = Math.max(peak, balance);
        trough = Math.min(trough, balance);
        if (dailyNet <= -dailyLossLimit) {
          result = "fail";
          failureReason = "Daily loss breach";
          break;
        }
        const totalBreach = config.trailingDrawdown ? peak - balance >= totalDrawdownLimit : balance <= config.accountSize - totalDrawdownLimit;
        if (totalBreach) {
          result = "fail";
          failureReason = "Max total drawdown breach";
          break;
        }
        if (balance - config.accountSize >= target) {
          if (maxDailyProfit > consistencyLimit) {
            result = "fail";
            failureReason = "Consistency rule breach";
          } else {
            result = "pass";
          }
          break;
        }
        if (day >= config.evaluationDays && tradesToday >= tradesPerDayCount) {
          result = "fail";
          failureReason = "Evaluation period expired";
          break;
        }
      }
      daysPerAttemptTotal += day;
      if (result === "pass") {
        passCount += 1;
        daysToTargetTotal += day;
        daysToTargetCount += 1;
        passDaysList.push(day);
        profitAtPassTotal += balance - config.accountSize;
      } else {
        failures[failureReason] = (failures[failureReason] || 0) + 1;
      }
      const wantSample = result === "pass" && passSamples < MAX_PASS_SAMPLES || result === "fail" && (failByReason[failureReason] || 0) < MAX_FAIL_PER_REASON;
      if (wantSample) {
        sampleRuns.push({
          equity: runEquity,
          outcome: result,
          reason: result === "pass" ? "Target reached" : failureReason,
          days: day,
          peak,
          trough,
          terminal: balance,
          accountSize: config.accountSize,
          profitTarget: target,
          maxDrawdown: config.maxTotalDrawdown
        });
        if (result === "pass") passSamples += 1;
        else failByReason[failureReason] = (failByReason[failureReason] || 0) + 1;
      }
    }
    const passRate = passCount / runs;
    const avgProfitAtPass = passCount > 0 ? profitAtPassTotal / passCount : null;
    const profitAtPass = avgProfitAtPass !== null ? avgProfitAtPass : config.profitTarget;
    const payoutPerPass = profitAtPass * config.payoutPct / 100;
    const effectivePayout = payoutPerPass >= config.minPayout ? payoutPerPass : 0;
    const expectedValue = passRate * effectivePayout - (1 - passRate) * config.challengeFee;
    const TRADING_DAYS_PER_YEAR = 252;
    const averageDaysToTarget = daysToTargetCount > 0 ? daysToTargetTotal / daysToTargetCount : null;
    const medianDaysToTarget = passDaysList.length ? passDaysList.slice().sort((a, b) => a - b)[Math.floor(passDaysList.length / 2)] : null;
    const avgDaysPerAttempt = daysPerAttemptTotal / runs;
    const attemptsPerYear = avgDaysPerAttempt > 0 ? TRADING_DAYS_PER_YEAR / avgDaysPerAttempt : 0;
    const evalsPassedPerYear = attemptsPerYear * passRate;
    const expectedAttemptsToPass = passRate > 0 ? 1 / passRate : Infinity;
    const expectedCostToPass = Number.isFinite(expectedAttemptsToPass) ? config.challengeFee + (expectedAttemptsToPass - 1) * config.resetFee : Infinity;
    const annualExpectedValue = attemptsPerYear * expectedValue;
    const annualExpectedPayout = evalsPassedPerYear * effectivePayout;
    const roiPerAttempt = config.challengeFee > 0 ? expectedValue / config.challengeFee : 0;
    const failureList = Object.entries(failures).map(([reason, count]) => ({ reason, count, pct: count / runs })).filter((failure) => failure.count > 0).sort((a, b) => b.count - a.count);
    return {
      config,
      passRatePct: passRate * 100,
      failRatePct: (1 - passRate) * 100,
      averageDaysToTarget,
      medianDaysToTarget,
      avgDaysPerAttempt,
      avgProfitAtPass,
      effectivePayout,
      expectedValue,
      payoutProbabilityPct: passRate * 100,
      attemptsPerYear,
      evalsPassedPerYear,
      expectedAttemptsToPass,
      expectedCostToPass,
      annualExpectedValue,
      annualExpectedPayout,
      roiPerAttempt,
      failures: failureList,
      runs,
      passCount,
      sampleRuns
    };
  }

  // backtester-src/sample.ts
  var SAMPLE_TRADE_LOG = (() => {
    const header = "Trade #,Type,Signal,Date/Time,Price,Qty,P&L,Cumulative P&L,Drawdown,Run-up,Cumulative P&L %,Buy & Hold %,Trade #";
    const rows = [header];
    const data = [
      [1, "long", "2025-01-03 09:30", "2025-01-05 16:00", 4200.5, 15, 2400],
      [2, "short", "2025-01-07 10:00", "2025-01-08 11:00", 4300, 15, -285],
      [3, "long", "2025-01-10 09:30", "2025-01-12 15:00", 4250, 15, 690],
      [4, "long", "2025-01-14 10:00", "2025-01-15 14:00", 4280, 8, 488],
      [5, "short", "2025-01-17 10:00", "2025-01-17 15:00", 4310, 15, -3500],
      [6, "long", "2025-01-22 09:30", "2025-01-24 16:00", 4260, 15, 885],
      [7, "short", "2025-01-27 10:00", "2025-01-28 11:00", 4340, 15, -195],
      [8, "long", "2025-01-31 09:30", "2025-02-03 15:00", 4270, 8, 672],
      [9, "long", "2025-02-04 09:30", "2025-02-06 16:00", 4290, 15, 2300],
      [10, "short", "2025-02-07 10:00", "2025-02-10 11:00", 4380, 15, -435],
      [11, "long", "2025-02-12 09:30", "2025-02-14 15:00", 4300, 8, 608],
      [12, "long", "2025-02-18 09:30", "2025-02-20 16:00", 4310, 15, 773],
      [13, "short", "2025-02-21 10:00", "2025-02-24 11:00", 4400, 15, -308],
      [14, "long", "2025-02-26 09:30", "2025-02-28 15:00", 4320, 8, 536],
      [15, "long", "2025-03-03 09:30", "2025-03-05 16:00", 4300, 15, 2200],
      [16, "short", "2025-03-06 10:00", "2025-03-07 11:00", 4450, 15, -3500],
      [17, "long", "2025-03-11 09:30", "2025-03-13 15:00", 4340, 8, 704],
      [18, "long", "2025-03-17 09:30", "2025-03-19 16:00", 4360, 15, 2200],
      [19, "short", "2025-03-20 10:00", "2025-03-21 11:00", 4420, 15, -263],
      [20, "long", "2025-03-26 09:30", "2025-03-28 15:00", 4350, 8, 392],
      [21, "long", "2025-04-02 09:30", "2025-04-04 16:00", 4380, 15, 2200],
      [22, "short", "2025-04-08 10:00", "2025-04-09 11:00", 4480, 15, -3500],
      [23, "long", "2025-04-15 09:30", "2025-04-17 15:00", 4400, 8, 760],
      [24, "long", "2025-04-22 09:30", "2025-04-24 16:00", 4410, 8, 584]
    ];
    let cum = 0;
    for (const [num, dir, entryDate, exitDate, entry, qty, pnl] of data) {
      const exit = dir === "long" ? entry + pnl / qty : entry - pnl / qty;
      const entryType = dir === "long" ? "Entry long" : "Entry short";
      const exitType = dir === "long" ? "Exit long" : "Exit short";
      rows.push(`${num},${entryType},,${entryDate},${entry},${qty},,,,,,, ,${num}`);
      cum += pnl;
      rows.push(`${num},${exitType},,${exitDate},${exit.toFixed(2)},${qty},${pnl.toFixed(2)},${cum.toFixed(2)},,,,, ,${num}`);
    }
    return rows.join("\n");
  })();

  // backtester-src/regimes.ts
  var REGIME_COLORS = {
    "Bull\xB7Low Vol": "#2dd4bf",
    "Bull\xB7High Vol": "#fbbf24",
    "Bear\xB7Low Vol": "#38bdf8",
    "Bear\xB7High Vol": "#fb7185"
  };
  var REGIME_ORDER = ["Bull\xB7Low Vol", "Bull\xB7High Vol", "Bear\xB7Low Vol", "Bear\xB7High Vol"];
  var SHORT_WINDOW = 3;
  var LONG_WINDOW_MIN = 8;
  function rollingMean(arr, i, w) {
    const start = Math.max(0, i - w + 1);
    let sum = 0;
    let count = 0;
    for (let j = start; j <= i; j += 1) {
      sum += arr[j];
      count += 1;
    }
    return count > 0 ? sum / count : arr[i];
  }
  function rollingStd(arr, i, w) {
    const start = Math.max(0, i - w + 1);
    let sum = 0;
    let count = 0;
    for (let j = start; j <= i; j += 1) {
      sum += arr[j];
      count += 1;
    }
    const mean3 = count > 0 ? sum / count : 0;
    let variance3 = 0;
    for (let j = start; j <= i; j += 1) variance3 += (arr[j] - mean3) ** 2;
    return count > 0 ? Math.sqrt(variance3 / count) : 0;
  }
  function median(arr) {
    if (!arr.length) return 0;
    const sorted = arr.slice().sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
  }
  function detectRegimes(metrics) {
    const equity = metrics.equity;
    const returns = metrics.returns;
    const n = returns.length;
    if (n < 4) return [];
    const longWindow = Math.max(LONG_WINDOW_MIN, Math.floor(n / 3));
    const shortStds = [];
    const longStds = [];
    for (let i = 0; i < n; i += 1) {
      shortStds.push(rollingStd(returns, i, SHORT_WINDOW));
      longStds.push(rollingStd(returns, i, longWindow));
    }
    const shortMedian = median(shortStds);
    const longMedian = median(longStds);
    const points = [];
    for (let i = 0; i < n; i += 1) {
      const shortMean = rollingMean(equity, i, SHORT_WINDOW);
      const shortTrend = equity[i] >= shortMean ? "bull" : "bear";
      const shortVol = shortStds[i] > shortMedian ? "high" : "low";
      const shortRegime = `${shortTrend === "bull" ? "Bull" : "Bear"}\xB7${shortVol === "high" ? "High Vol" : "Low Vol"}`;
      const longMean = rollingMean(equity, i, longWindow);
      const longTrend = equity[i] >= longMean ? "bull" : "bear";
      const longVol = longStds[i] > longMedian ? "high" : "low";
      const longRegime = `${longTrend === "bull" ? "Bull" : "Bear"}\xB7${longVol === "high" ? "High Vol" : "Low Vol"}`;
      points.push({
        index: i,
        trend: shortTrend,
        volatility: shortVol,
        regime: shortRegime,
        shortRegime,
        longRegime
      });
    }
    return points;
  }
  function attributeRegimes(regimes, mode) {
    return regimes.map((rp, i) => {
      if (mode === "entry") return rp.shortRegime;
      if (mode === "dominant") return rp.longRegime;
      const next = regimes[i + 1];
      return next ? next.shortRegime : rp.shortRegime;
    });
  }
  function computeRegimeStats(returns, attributed) {
    const total = returns.length;
    const groups = {
      "Bull\xB7Low Vol": [],
      "Bull\xB7High Vol": [],
      "Bear\xB7Low Vol": [],
      "Bear\xB7High Vol": []
    };
    attributed.forEach((regime, i) => {
      groups[regime].push(returns[i]);
    });
    return REGIME_ORDER.map((regime) => {
      const trades = groups[regime];
      const count = trades.length;
      const netPnl = trades.reduce((a, b) => a + b, 0);
      const wins = trades.filter((v) => v > 0).length;
      return {
        regime,
        color: REGIME_COLORS[regime],
        exposurePct: total > 0 ? count / total * 100 : 0,
        netPnl,
        winRate: count > 0 ? wins / count : 0,
        trades: count,
        avgTrade: count > 0 ? netPnl / count : 0
      };
    });
  }
  function regimeEquityBands(attributed) {
    const bands = [];
    if (!attributed.length) return bands;
    let current = attributed[0];
    let start = 0;
    for (let i = 1; i < attributed.length; i += 1) {
      if (attributed[i] !== current) {
        bands.push({ start, end: i, regime: current, color: REGIME_COLORS[current] });
        current = attributed[i];
        start = i;
      }
    }
    bands.push({ start, end: attributed.length, regime: current, color: REGIME_COLORS[current] });
    return bands;
  }
  function runRegimeAwareMC(returns, attributed, options) {
    const n = returns.length;
    if (n < 2) {
      return { paths: [], terminals: [], p5: 0, p50: 0, p95: 0, positivePathsPct: 0, underwaterPct: 0, drawdownPercentiles: { p5: 0, p50: 0, p95: 0 }, config: { ...options } };
    }
    const random = mulberry32(options.seed);
    const paths = [];
    const terminals = [];
    const allMaxDrawdowns = [];
    const regimeGroups = {
      "Bull\xB7Low Vol": [],
      "Bull\xB7High Vol": [],
      "Bear\xB7Low Vol": [],
      "Bear\xB7High Vol": []
    };
    attributed.forEach((regime, i) => regimeGroups[regime].push(i));
    const allIndices = returns.map((_, i) => i);
    function randomIndexFrom(arr) {
      return arr[Math.floor(random() * arr.length)];
    }
    for (let p = 0; p < options.paths; p += 1) {
      let equity = 0;
      const path = [0];
      let peak = 0;
      let maxDrawdown = 0;
      let underwaterCount = 0;
      for (let i = 0; i < n; i += 1) {
        let idx;
        if (options.regimeAware) {
          const group = regimeGroups[attributed[i]];
          idx = group.length > 0 ? randomIndexFrom(group) : randomIndexFrom(allIndices);
        } else {
          idx = Math.floor(random() * n);
        }
        equity += returns[idx];
        path.push(equity);
        peak = Math.max(peak, equity);
        maxDrawdown = Math.max(maxDrawdown, peak - equity);
        if (equity < peak) underwaterCount += 1;
      }
      paths.push(path);
      terminals.push(equity);
      allMaxDrawdowns.push(maxDrawdown);
    }
    const sortedTerminals = terminals.slice().sort((a, b) => a - b);
    const p5 = sortedTerminals[Math.floor(sortedTerminals.length * 0.05)] || 0;
    const p50 = sortedTerminals[Math.floor(sortedTerminals.length * 0.5)] || 0;
    const p95 = sortedTerminals[Math.floor(sortedTerminals.length * 0.95)] || 0;
    const positivePaths = terminals.filter((t) => t >= 0).length;
    const sortedDD = allMaxDrawdowns.sort((a, b) => a - b);
    return {
      paths,
      terminals,
      p5,
      p50,
      p95,
      positivePathsPct: positivePaths / terminals.length * 100,
      underwaterPct: 0,
      // computed per-path average below
      drawdownPercentiles: {
        p5: sortedDD[Math.floor(sortedDD.length * 0.05)] || 0,
        p50: sortedDD[Math.floor(sortedDD.length * 0.5)] || 0,
        p95: sortedDD[Math.floor(sortedDD.length * 0.95)] || 0
      },
      config: { ...options }
    };
  }

  // backtester-src/overfit.ts
  function mean2(arr) {
    if (arr.length === 0) return 0;
    let s = 0;
    for (let i = 0; i < arr.length; i += 1) s += arr[i];
    return s / arr.length;
  }
  function variance2(arr, m) {
    if (arr.length < 2) return 0;
    const mu = m == null ? mean2(arr) : m;
    let s = 0;
    for (let i = 0; i < arr.length; i += 1) {
      const d = arr[i] - mu;
      s += d * d;
    }
    return s / arr.length;
  }
  function stddev2(arr, m) {
    return Math.sqrt(variance2(arr, m));
  }
  function tradeSharpe(returns) {
    if (returns.length < 2) return 0;
    const sd = stddev2(returns);
    return sd > 0 ? mean2(returns) / sd : 0;
  }
  function percentileSorted2(sorted, fraction) {
    if (sorted.length === 0) return 0;
    const idx = Math.min(sorted.length - 1, Math.floor(sorted.length * fraction));
    return sorted[idx];
  }
  function erfApprox(x) {
    const sign = x < 0 ? -1 : 1;
    const ax = Math.abs(x);
    const t = 1 / (1 + 0.3275911 * ax);
    const y = 1 - ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-ax * ax);
    return sign * y;
  }
  function normalCdf(x) {
    return 0.5 * (1 + erfApprox(x / Math.SQRT2));
  }
  function inverseNormalCdf(p) {
    if (p <= 0) return -Infinity;
    if (p >= 1) return Infinity;
    const a = [-39.69683028665376, 220.9460984245205, -275.9285104469687, 138.357751867269, -30.66479806614716, 2.506628277459239];
    const b = [-54.47609879822406, 161.5858368580409, -155.6989798598866, 66.80131188771972, -13.28068155288572];
    const c = [-0.007784894002430293, -0.3223964580411365, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783];
    const d = [0.007784695709041462, 0.3224671290700398, 2.445134137142996, 3.754408661907416];
    const plow = 0.02425;
    const phigh = 1 - plow;
    let q, r;
    let x = 0;
    if (p < plow) {
      q = Math.sqrt(-2 * Math.log(p));
      x = (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
    } else if (p <= phigh) {
      q = p - 0.5;
      r = q * q;
      x = (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
    } else {
      q = Math.sqrt(-2 * Math.log(1 - p));
      x = -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
    }
    return x;
  }
  function autocorrelation(returns, lag = 1) {
    if (returns.length <= lag + 1) return 0;
    const mu = mean2(returns);
    let num = 0;
    let den = 0;
    for (let i = 0; i < returns.length; i += 1) {
      den += (returns[i] - mu) ** 2;
    }
    if (den === 0) return 0;
    for (let i = lag; i < returns.length; i += 1) {
      num += (returns[i] - mu) * (returns[i - lag] - mu);
    }
    return num / den;
  }
  function autoBlockSize(returns) {
    if (returns.length < 4) return 1;
    const rho = autocorrelation(returns, 1);
    const r = Math.min(Math.max(rho, -0.5), 0.95);
    const denom = 1 - 2 * r + r * r;
    if (denom <= 1e-6) return Math.min(Math.max(returns.length >> 2, 1), 30);
    const b = 1 / denom;
    return Math.min(Math.max(Math.round(b), 1), Math.min(30, Math.max(returns.length >> 2, 1)));
  }
  function runStationaryBootstrap(returns, config) {
    if (returns.length < 2) {
      throw new Error("At least two trades are required for the stationary bootstrap.");
    }
    const paths = Math.min(Math.max(Math.floor(config.paths), 10), 5e3);
    const blockLength = Math.min(Math.max(config.blockLength, 1), Math.max(returns.length, 1));
    const p = 1 / blockLength;
    const random = mulberry32(config.seed);
    const startingBalance = config.startingBalance ?? 0;
    const pathEquity = [];
    const terminals = [];
    const drawdowns = [];
    for (let path = 0; path < paths; path += 1) {
      const n = returns.length;
      const idxs = [Math.floor(random() * n)];
      for (let i = 1; i < n; i += 1) {
        if (random() < p) {
          idxs.push(Math.floor(random() * n));
        } else {
          idxs.push((idxs[i - 1] + 1) % n);
        }
      }
      let equity = startingBalance;
      const series = [];
      let peak = startingBalance;
      let maxDrawdown = 0;
      for (let i = 0; i < n; i += 1) {
        equity += returns[idxs[i]];
        series.push(equity);
        peak = Math.max(peak, equity);
        maxDrawdown = Math.max(maxDrawdown, peak - equity);
      }
      pathEquity.push(series);
      terminals.push(equity);
      drawdowns.push(maxDrawdown);
    }
    const sorted = terminals.slice().sort((a, b) => a - b);
    const sortedDrawdowns = drawdowns.slice().sort((a, b) => a - b);
    const positivePaths = terminals.filter((v) => v > startingBalance).length;
    return {
      config,
      terminals,
      paths: pathEquity,
      p5: percentileSorted2(sorted, 0.05),
      p50: percentileSorted2(sorted, 0.5),
      p95: percentileSorted2(sorted, 0.95),
      positivePaths,
      positivePathsPct: positivePaths / paths,
      riskOfRuinPct: percentileSorted2(sorted, 0.05) < startingBalance ? terminals.filter((v) => v < startingBalance).length / terminals.length * 100 : 0,
      drawdownPercentiles: {
        p50: percentileSorted2(sortedDrawdowns, 0.5),
        p95: percentileSorted2(sortedDrawdowns, 0.95)
      }
    };
  }
  function walkForward(returns, opts = {}) {
    const folds = Math.min(Math.max(Math.floor(opts.folds ?? 5), 2), 20);
    const minFoldSize = Math.max(Math.floor(opts.minFoldSize ?? 8), 2);
    const tpy = Math.max(opts.tradesPerYear ?? 252, 1);
    if (returns.length < folds * minFoldSize) {
      return {
        folds: [],
        meanIsSharpe: 0,
        meanOosSharpe: 0,
        meanDegradation: 0,
        oosPositivePct: 0,
        verdict: "unstable"
      };
    }
    const foldSize = Math.floor(returns.length / folds);
    const out = [];
    let isSharpeSum = 0;
    let oosSharpeSum = 0;
    let oosPositiveCount = 0;
    let degradationSum = 0;
    let degradationCount = 0;
    for (let i = 1; i < folds; i += 1) {
      const isStart = 0;
      const isEnd = i * foldSize;
      const oosStart = isEnd;
      const oosEnd = i === folds - 1 ? returns.length : (i + 1) * foldSize;
      const isReturns = returns.slice(isStart, isEnd);
      const oosReturns = returns.slice(oosStart, oosEnd);
      const isSharpe = tradeSharpe(isReturns) * Math.sqrt(tpy);
      const oosSharpe = tradeSharpe(oosReturns) * Math.sqrt(tpy);
      const isMean = mean2(isReturns);
      const oosMean = mean2(oosReturns);
      const degradation = isSharpe > 0 ? oosSharpe / isSharpe : oosSharpe > 0 ? Infinity : 0;
      const oosPositive = oosMean > 0;
      out.push({
        isRange: [isStart, isEnd],
        oosRange: [oosStart, oosEnd],
        isSharpe: Number.isFinite(isSharpe) ? isSharpe : 0,
        oosSharpe: Number.isFinite(oosSharpe) ? oosSharpe : 0,
        isMean,
        oosMean,
        degradation: Number.isFinite(degradation) ? degradation : 0,
        oosPositive
      });
      isSharpeSum += isSharpe;
      oosSharpeSum += oosSharpe;
      if (oosPositive) oosPositiveCount += 1;
      if (Number.isFinite(degradation) && degradation > 0) {
        degradationSum += degradation;
        degradationCount += 1;
      }
    }
    const foldCount = Math.max(out.length, 1);
    const meanIsSharpe = isSharpeSum / foldCount;
    const meanOosSharpe = oosSharpeSum / foldCount;
    const meanDegradation = degradationCount > 0 ? degradationSum / degradationCount : 0;
    const oosPositivePct = oosPositiveCount / foldCount;
    let verdict;
    if (oosPositivePct >= 0.7 && meanOosSharpe > 0 && meanDegradation >= 0.6) verdict = "stable";
    else if (oosPositivePct >= 0.5 && meanOosSharpe > 0) verdict = "decaying";
    else verdict = "unstable";
    return {
      folds: out,
      meanIsSharpe,
      meanOosSharpe,
      meanDegradation,
      oosPositivePct,
      verdict
    };
  }
  function purgedKFold(returns, opts = {}) {
    const folds = Math.min(Math.max(Math.floor(opts.folds ?? 5), 2), 10);
    const purge = Math.max(Math.floor(opts.purge ?? Math.max(Math.round(returns.length * 0.01), 1)), 0);
    const embargo = Math.max(Math.floor(opts.embargo ?? purge), 0);
    const tpy = Math.max(opts.tradesPerYear ?? 252, 1);
    const n = returns.length;
    if (n < folds * 6) {
      return {
        nFolds: folds,
        purge,
        embargo,
        folds: [],
        meanIsSharpe: 0,
        meanOosSharpe: 0,
        oosPositivePct: 0
      };
    }
    const bounds = [];
    const foldSize = Math.floor(n / folds);
    for (let k = 0; k < folds; k += 1) {
      const start = k * foldSize;
      const end = k === folds - 1 ? n : (k + 1) * foldSize;
      bounds.push([start, end]);
    }
    const foldResults = [];
    let isSharpeSum = 0;
    let oosSharpeSum = 0;
    let oosPositiveCount = 0;
    for (let k = 0; k < folds; k += 1) {
      const [testStart, testEnd] = bounds[k];
      const purgeStart = Math.max(0, testStart - purge);
      const purgeEnd = Math.min(n, testEnd + embargo);
      const isReturns = returns.map((r, i) => i >= purgeStart && i < purgeEnd ? null : r).filter((r) => r !== null);
      const oosReturns = returns.slice(testStart, testEnd);
      if (isReturns.length < 2 || oosReturns.length < 2) continue;
      const isSharpe = tradeSharpe(isReturns) * Math.sqrt(tpy);
      const oosSharpe = tradeSharpe(oosReturns) * Math.sqrt(tpy);
      const degradation = isSharpe > 0 ? oosSharpe / isSharpe : oosSharpe > 0 ? Infinity : 0;
      const oosPositive = mean2(oosReturns) > 0;
      foldResults.push({
        isSharpe: Number.isFinite(isSharpe) ? isSharpe : 0,
        oosSharpe: Number.isFinite(oosSharpe) ? oosSharpe : 0,
        degradation: Number.isFinite(degradation) ? degradation : 0,
        oosPositive
      });
      isSharpeSum += isSharpe;
      oosSharpeSum += oosSharpe;
      if (oosPositive) oosPositiveCount += 1;
    }
    const fc = Math.max(foldResults.length, 1);
    return {
      nFolds: folds,
      purge,
      embargo,
      folds: foldResults,
      meanIsSharpe: isSharpeSum / fc,
      meanOosSharpe: oosSharpeSum / fc,
      oosPositivePct: oosPositiveCount / fc
    };
  }
  function deflatedSharpeRatio(input) {
    const { sharpe, years, skew, kurtosis, trials } = input;
    const N = Math.max(Math.floor(trials), 1);
    const T = Math.max(years, 1e-6);
    const v = (1 - skew * sharpe + (kurtosis - 1) / 4 * sharpe * sharpe) / Math.max(T - 1, 1e-6);
    const stdSR = Math.sqrt(Math.max(v, 1e-12));
    let eMax = 0;
    if (N > 1) {
      const z = inverseNormalCdf(1 - 1 / N);
      if (Number.isFinite(z)) {
        const term = (1 - skew) * z + skew / 6 * (z * z - 1);
        eMax = Number.isFinite(term) ? stdSR * term : 0;
      }
    }
    const dsr = normalCdf((sharpe - eMax) / stdSR);
    const sr0 = eMax;
    let verdict;
    if (dsr >= 0.95) verdict = "credible";
    else if (dsr >= 0.8) verdict = "marginal";
    else verdict = "inflated";
    return {
      dsr: Math.min(Math.max(dsr, 0), 1),
      sr0,
      trials: N,
      verdict
    };
  }
  function probabilityOfBacktestOverfitting(matrix) {
    const nStrategies = matrix.length;
    if (nStrategies < 2) {
      return { pbo: 0, nStrategies, nSplits: 0, verdict: "not overfit" };
    }
    const T = matrix[0].length;
    if (T < 4) {
      return { pbo: 0, nStrategies, nSplits: 0, verdict: "not overfit" };
    }
    const cut = Math.floor(T / 2);
    const isRets = matrix.map((row) => row.slice(0, cut));
    const oosRets = matrix.map((row) => row.slice(cut));
    const isMean = isRets.map(mean2);
    const isOrder = isMean.map((v, i) => ({ v, i })).sort((a, b) => a.v - b.v).map((o) => o.i);
    const bestIs = isOrder[isOrder.length - 1];
    const oosMean = oosRets.map(mean2);
    const oosOrder = oosMean.map((v, i) => ({ v, i })).sort((a, b) => a.v - b.v).map((o) => o.i);
    const oosRank = new Array(nStrategies);
    oosOrder.forEach((idx, rank) => {
      oosRank[idx] = rank;
    });
    const medianRank = (nStrategies - 1) / 2;
    let belowMedian = 0;
    let comparisons = 0;
    for (let i = 0; i < nStrategies; i += 1) {
      for (let j = i + 1; j < nStrategies; j += 1) {
        const iIsBetter = isMean[i] >= isMean[j];
        const winner = iIsBetter ? i : j;
        if (oosRank[winner] < medianRank) belowMedian += 1;
        comparisons += 1;
      }
    }
    const pbo = comparisons > 0 ? belowMedian / comparisons : 0;
    let verdict;
    if (pbo < 0.1) verdict = "not overfit";
    else if (pbo < 0.25) verdict = "suspect";
    else verdict = "overfit";
    return { pbo, nStrategies, nSplits: 1, verdict };
  }
  function buildOverfitReport(returns, metrics, opts = {}) {
    if (returns.length < 10) {
      throw new Error("Need at least 10 trades to run overfit checks (walk-forward, purged CV, DSR).");
    }
    const tpy = Math.max(opts.tradesPerYear ?? metrics.tradesPerYear ?? 252, 1);
    const years = opts.years ?? metrics.count / tpy;
    const trials = Math.max(opts.trials ?? 1, 1);
    const seed = opts.seed ?? 6221293;
    const paths = Math.min(Math.max(Math.floor(opts.paths ?? 1e3), 50), 5e3);
    const WF_MIN_FOLD = 4;
    const PKF_MIN_FOLD = 3;
    const maxFoldsByCount = Math.max(2, Math.floor(returns.length / WF_MIN_FOLD));
    const requestedFolds = Math.min(Math.max(Math.floor(opts.folds ?? 5), 2), 10);
    const folds = Math.min(requestedFolds, maxFoldsByCount);
    const canWalkForward = returns.length >= folds * WF_MIN_FOLD;
    const canPurge = returns.length >= folds * PKF_MIN_FOLD;
    const wf = canWalkForward ? walkForward(returns, { folds, tradesPerYear: tpy, minFoldSize: WF_MIN_FOLD }) : { folds: [], meanIsSharpe: 0, meanOosSharpe: 0, meanDegradation: 0, oosPositivePct: 0, verdict: "unstable" };
    const pkf = canPurge ? purgedKFold(returns, { folds, tradesPerYear: tpy }) : { nFolds: folds, purge: 0, embargo: 0, folds: [], meanIsSharpe: 0, meanOosSharpe: 0, oosPositivePct: 0 };
    const dsr = deflatedSharpeRatio({
      sharpe: metrics.sharpe,
      years,
      skew: metrics.skewness,
      kurtosis: metrics.kurtosis,
      trials
    });
    let pbo = null;
    if (opts.pboMatrix && opts.pboMatrix.length >= 2 && opts.pboMatrix[0].length >= 4) {
      pbo = probabilityOfBacktestOverfitting(opts.pboMatrix);
    }
    const sb = runStationaryBootstrap(returns, {
      paths,
      blockLength: autoBlockSize(returns),
      seed
    });
    const lines = [];
    lines.push(`Walk-forward (${folds} folds${folds < requestedFolds ? `, auto-reduced from ${requestedFolds} for ${returns.length} trades` : ""}): mean IS SR ${wf.meanIsSharpe.toFixed(2)} \u2192 OOS SR ${wf.meanOosSharpe.toFixed(2)} (${(wf.oosPositivePct * 100).toFixed(0)}% of folds positive OOS), verdict: ${wf.verdict}.`);
    lines.push(`Purged K-fold (purge ${pkf.purge}, embargo ${pkf.embargo}): mean IS SR ${pkf.meanIsSharpe.toFixed(2)} \u2192 OOS SR ${pkf.meanOosSharpe.toFixed(2)}, ${(pkf.oosPositivePct * 100).toFixed(0)}% of folds positive OOS.`);
    lines.push(`Deflated Sharpe: observed ${metrics.sharpe.toFixed(2)}, threshold ${dsr.sr0.toFixed(2)} (N=${trials}), DSR ${(dsr.dsr * 100).toFixed(1)}% - verdict: ${dsr.verdict}.`);
    if (pbo) {
      lines.push(`PBO: ${(pbo.pbo * 100).toFixed(1)}% over ${pbo.nStrategies} strategies - verdict: ${pbo.verdict}.`);
    } else {
      lines.push("PBO: skipped (no parameter-scan matrix supplied - run optimize_lean first, then pass its results to run_pbo for a real overfit probability).");
    }
    lines.push(`Stationary bootstrap (block length ${sb.config.blockLength}): p5 ${sb.p5.toFixed(0)} \xB7 p50 ${sb.p50.toFixed(0)} \xB7 p95 ${sb.p95.toFixed(0)} \xB7 ${(sb.positivePathsPct * 100).toFixed(1)}% paths positive \xB7 DD p95 ${sb.drawdownPercentiles.p95.toFixed(0)}.`);
    let verdict;
    const oosOk = wf.oosPositivePct >= 0.5 && pkf.oosPositivePct >= 0.5 && dsr.dsr >= 0.8;
    const oosMarginal = wf.oosPositivePct >= 0.4 && pkf.oosPositivePct >= 0.4;
    if (pbo && pbo.pbo >= 0.25) {
      verdict = `Overfit - PBO ${(pbo.pbo * 100).toFixed(0)}%; the in-sample edge does not survive out of sample.`;
    } else if (!oosOk && !oosMarginal) {
      verdict = `Unstable - ${wf.verdict} walk-forward, DSR ${(dsr.dsr * 100).toFixed(0)}%; treat the in-sample edge as luck.`;
    } else if (oosOk) {
      verdict = `Credible - ${wf.verdict} walk-forward, DSR ${(dsr.dsr * 100).toFixed(0)}%${pbo ? `, PBO ${(pbo.pbo * 100).toFixed(0)}%` : ""}; the edge survives out of sample.`;
    } else {
      verdict = `Marginal - ${wf.verdict} walk-forward, DSR ${(dsr.dsr * 100).toFixed(0)}%; the edge thins out of sample.`;
    }
    return {
      walkForward: wf,
      purgedKFold: pkf,
      deflatedSharpe: dsr,
      pbo,
      stationaryBootstrap: sb,
      summary: lines.join("\n"),
      verdict
    };
  }
  return __toCommonJS(engine_exports);
})();
