# Belfort Trading route code

These files contain the packaged Belfort Trading route code.

## Routes

- `../js/app/sign-in/page-247d7bfe2f5e217e.js`
  - Real `/sign-in` route entry.
  - Reads `redirect_url` from the query string.
  - Renders the Clerk `SignIn` component with Belfort Trading's appearance tokens.
  - Redirects to `/post-sign-in` by default.

- `../js/app/subscribe/page-55674403a4489c96.js`
  - Real `/subscribe` route entry.
  - Checks `/api/is-paid` with credentials.
  - Redirects paid users to `/projects`.
  - Renders the launch/standard pricing flow and checkout component.

- `../js/app/subscribe/loading-653aa8336bf52069.js`
  - Real subscribe loading route chunk.

## Important runtime note

These are compiled chunks and depend on the rest of the Next.js runtime, shared chunks, Clerk, and Belfort Trading API endpoints. They are not standalone source files and cannot provide the protected `/projects`, `/quant-copilot`, or `/social` application code without an authorized subscription and the server runtime.

The original public homepage export remains at `../index.html` with its existing `css/`, `fonts/`, `images/`, and `js/` bundles.
